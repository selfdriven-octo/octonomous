'use strict';
// v0.9 composition language. Never executes tools, evaluates JavaScript, or grants authority.
const { tokenize } = require('./parser');
const { digest, verifiedSigned } = require('./canonical');
const { amountToLovelace } = require('./compiler-units');

const fail = (why) => { throw new Error(`OctoLang mission error: ${why}`); };
const idPattern = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function parseMission(source) {
  if (typeof source !== 'string' || !/^\s*(?:(?:#|\/\/)[^\n]*\s*)*mission\b/.test(source)) fail('expected mission declaration');
  const t = tokenize(source); let i = 0;
  const peek = () => t[i];
  const take = s => { if (peek().raw !== s) fail(`expected ${s}, found ${peek().raw} at ${peek().line}:${peek().col}`); i++; };
  const identifier = () => { const v=peek(); if (v.type !== 'symbol' || !idPattern.test(v.raw)) fail(`expected identifier at ${v.line}:${v.col}`); i++; return v.raw; };
  const str = () => { if (peek().type !== 'string') fail('expected string literal'); return JSON.parse(t[i++].raw); };
  const number = () => { if (peek().type !== 'number') fail('expected numeric literal'); return t[i++].raw; };
  const fields = syntax => {
    take('{'); const a = {};
    while (peek().raw !== '}') {
      if (peek().type === 'eof') fail('unterminated block');
      const k=identifier(); if (!Object.hasOwn(syntax,k) || Object.hasOwn(a,k)) fail(`unknown or repeated field ${k}`);
      a[k] = syntax[k]();
    }
    take('}'); return a;
  };
  const required = (o, keys, name) => { if (Object.keys(o).length !== keys.length || keys.some(k => !Object.hasOwn(o,k))) fail(`${name} requires ${keys.join(', ')}`); };
  take('mission'); const name=identifier(); take('{');
  const ast={name, contexts:[],inputs:[],roles:[],constraints:[],tasks:[],outcomes:[],capabilities:[],proofs:[],anchors:[]};
  while (peek().raw !== '}') {
    if (peek().type === 'eof') fail('unterminated mission');
    const kind=identifier();
    if (kind === 'goal') { if (ast.goal) fail('duplicate goal'); ast.goal=str(); }
    else if (kind === 'on') { take('violation'); if (ast.onViolation) fail('duplicate on violation'); ast.onViolation=identifier(); }
    else if (kind === 'context') { const label=identifier(); const val=fields({ claim:str, issuer:str, status:identifier, max_age:()=>number()+identifier() }); required(val,['claim','issuer','status','max_age'],'context'); ast.contexts.push({label,...val}); }
    else if (kind === 'input') { const label=identifier(); const val=fields({ type:identifier }); required(val,['type'],'input'); ast.inputs.push({label,...val}); }
    else if (kind === 'role') { const label=identifier(); const val=fields({ capability:str }); required(val,['capability'],'role'); ast.roles.push({label,...val}); }
    else if (kind === 'capability') { const label=identifier(); const val=fields({role:identifier,name:str,fields:str,service:str}); required(val,['role','name','fields','service'],'capability'); ast.capabilities.push({label,...val}); }
    else if (kind === 'anchor') { const label=identifier(); const val=fields({backend:identifier,network:str,contract:str}); required(val,['backend','network','contract'],'anchor'); ast.anchors.push({label,...val}); }
    else if (kind === 'proof') { const label=identifier(); const val=fields({task:identifier,kind:identifier,service:str}); if(!val.task||!val.kind)fail('proof requires task and kind'); ast.proofs.push({label,...val}); }
    else if (kind === 'constraint') { const label=identifier(); const val=fields({ input:identifier, max:()=>({value:number(),unit:identifier()}), context:identifier }); if (!!val.input === !!val.context || (val.input && !val.max)) fail('constraint needs either input+max or context'); ast.constraints.push({label,...val}); }
    else if (kind === 'task') { const label=identifier(); const val=fields({ role:identifier, depends:()=>peek().type==='string'?str():identifier(), require:identifier, produces:str }); required(val,['role','depends','require','produces'],'task'); ast.tasks.push({label,...val}); }
    else if (kind === 'outcome') { const label=identifier(); const val=fields({ task:identifier, evidence:str }); required(val,['task','evidence'],'outcome'); ast.outcomes.push({label,...val}); }
    else fail(`unknown declaration ${kind}`);
    if (ast.contexts.length > 16 || ast.inputs.length>16 || ast.roles.length>16 || ast.constraints.length>32 || ast.tasks.length>32 || ast.outcomes.length>32 || ast.capabilities.length>16 || ast.proofs.length>64 || ast.anchors.length>1) fail('mission exceeds declaration limit');
  }
  take('}'); if (peek().type !== 'eof') fail('trailing tokens');
  return ast;
}
function ageMs(v) {
  const m=/^([1-9][0-9]{0,5})(m|h|d)$/.exec(v);
  if(!m)fail('max_age must be 1m–365d');
  const n=Number(m[1])*({m:60000,h:3600000,d:86400000})[m[2]];
  if(n>365*86400000)fail('context age must be <=365d');
  return n;
}
function nonempty(v,label,max=128) { if(typeof v!=='string'||!v.trim()||v.length>max)fail(`invalid ${label}`); return v; }
function compileMission(source) {
  const a = typeof source==='string'?parseMission(source):source;
  nonempty(a.goal,'goal',500); if(a.onViolation!=='DENY')fail('on violation DENY mandatory');
  if(!a.contexts.length||!a.inputs.length||!a.roles.length||!a.tasks.length||!a.outcomes.length)fail('inputs, roles, tasks and outcomes required');
  const unique = (list,label) => { const s=new Set(); for(const x of list){if(!idPattern.test(x.label)||s.has(x.label))fail(`duplicate or invalid ${label}: ${x.label}`);s.add(x.label);}return s; };
  const contexts=unique(a.contexts,'context'); const inputs=unique(a.inputs,'input'); const roles=unique(a.roles,'role'); const tasks=unique(a.tasks,'task'); unique(a.constraints,'constraint'); unique(a.outcomes,'outcome'); unique(a.capabilities||[],'capability'); unique(a.proofs||[],'proof'); unique(a.anchors||[],'anchor');
  const typed=!!((a.capabilities||[]).length||(a.proofs||[]).length);
  if(typed&&(!(a.capabilities||[]).length||!(a.proofs||[]).length))fail('typed missions require capability and proof declarations');
  if((a.anchors||[]).length && !typed)fail('Midnight anchor requires typed proof declarations');
  const compiled={schema:(a.anchors||[]).length?'octolang.mission.v1.3':(typed?'octolang.mission.v1.2':'octolang.mission.v0.9'),name:a.name,goal:a.goal,
    contexts:a.contexts.map(c=>{if(c.status!=='VERIFIED')fail('context requires VERIFIED');return {label:c.label,claim:nonempty(c.claim,'claim'),issuer:nonempty(c.issuer,'issuer'),maxAgeMs:ageMs(c.max_age)};}),
    inputs:a.inputs.map(v=>{if(!['ada','integer','text','boolean'].includes(v.type))fail(`unknown input type ${v.type}`);return v;}),
    roles:a.roles.map(r=>({label:r.label,capability:nonempty(r.capability,'capability')})),
    constraints:a.constraints.map(c=>{
      if(c.context){if(!contexts.has(c.context)||c.input||c.max)fail('invalid context constraint');return {label:c.label,type:'context',context:c.context};}
      if(!inputs.has(c.input)||!c.max)fail('unknown input in constraint');
      const v=a.inputs.find(i=>i.label===c.input);if(!['ada','integer'].includes(v.type))fail('max constraint needs ada or integer');
      if(v.type==='ada')return {label:c.label,type:'max',input:c.input,max:amountToLovelace(c.max.value,c.max.unit),unit:'lovelace'};
      if(c.max.unit!=='count'||!/^(0|[1-9]\d*)$/.test(c.max.value)||BigInt(c.max.value)>BigInt(Number.MAX_SAFE_INTEGER))fail('integer max must be safe positive count');
      return {label:c.label,type:'max',input:c.input,max:c.max.value,unit:'count'};
    }),
    tasks:a.tasks.map(t=>{
      if(!roles.has(t.role))fail(`task ${t.label} has unknown role`);
      if(t.require!=='none'&&!contexts.has(t.require))fail(`task ${t.label} has unknown context`);
      nonempty(t.produces,'produces');
      const dependencies=t.depends==='none'?[]:t.depends.split(',').map(s=>s.trim());
      if(dependencies.some(d=>!tasks.has(d)||d===t.label)||new Set(dependencies).size!==dependencies.length)fail(`invalid dependencies for ${t.label}`);
      return {label:t.label,role:t.role,dependencies,requiredContext:t.require,produces:t.produces};
    }),
    ...(typed?{capabilities:a.capabilities.map(c=>{
      if(!roles.has(c.role))fail(`capability ${c.label} has unknown role`);
      const role=a.roles.find(r=>r.label===c.role);
      if(role.capability!==c.name)fail(`capability ${c.label} must match role capability`);
      if(!/^service\.[a-z][a-z0-9.]*(?:[a-z0-9])$/.test(c.name)||c.name.length>120)fail('typed capability must name an external service');
      if(!/^[a-z0-9-]{2,48}$/.test(c.service))fail('invalid capability service identity');
      if(typeof c.fields!=='string'||!c.fields.length||c.fields.length>400)fail('invalid typed capability fields');
      const mappings=c.fields.split(',').map(v=>v.trim());
      if(mappings.length>8||new Set(mappings).size!==mappings.length)fail('duplicate or excessive capability field');
      const fields=mappings.map(v=>{const m=/^([a-z_][a-z_0-9]*):(ada|integer|text|boolean)$/.exec(v);
        if(!m||!inputs.has(m[1])||a.inputs.find(i=>i.label===m[1]).type!==m[2])fail(`unknown or mismatched typed capability field: ${v}`);
        return {name:m[1],type:m[2]};});
      return {label:c.label,role:c.role,name:c.name,service:c.service,fields};
    }),proofs:a.proofs.map(p=>{
      const task=a.tasks.find(t=>t.label===p.task);
      if(!task)fail(`unknown proof task ${p.task}`);
      if(!['service_receipt','controller_receipt','agent_receipt'].includes(p.kind))fail(`unknown proof kind ${p.kind}`);
      if(p.kind==='service_receipt'){
        if(!/^[a-z0-9-]{2,48}$/.test(p.service||''))fail('service_receipt must specify exact trusted service identity');
        const role=a.roles.find(r=>r.label===task.role);const cap=a.capabilities.find(c=>c.role===task.role);
        if(!cap||cap.name!==role.capability||cap.service!==p.service)fail('service_receipt must match declared capability and service');
      }else if(p.service!==undefined)fail('non-service proof cannot set service');
      return {label:p.label,task:p.task,kind:p.kind,...(p.service?{service:p.service}:{})};
    })}:{ }),
    ...((a.anchors||[]).length?{anchors:a.anchors.map(x=>{
      if(x.backend!=='midnight')fail('only midnight backend supported in v1.3');
      if(!/^[a-z][a-z0-9_-]{2,39}$/.test(x.network))fail('invalid Midnight network identifier');
      if(!/^[a-zA-Z0-9_-]{8,128}$/.test(x.contract))fail('invalid pinned Midnight contract identifier');
      return {label:x.label,backend:x.backend,network:x.network,contract:x.contract,phase:'post_execution'};
    })}:{}),
    outcomes:a.outcomes.map(o=>{
      const t=a.tasks.find(x=>x.label===o.task);
      if(!t||o.evidence!==t.produces)fail(`outcome ${o.label} must match a declared task and exact evidence`);
      return {label:o.label,task:o.task,evidence:o.evidence};
    }),onViolation:'DENY'};
  if(typed){
    const builtins=new Set(['research','validate','intent.record','audit']);
    for(const r of compiled.roles)if(!builtins.has(r.capability)&&compiled.capabilities.filter(c=>c.role===r.label).length!==1)fail(`external role ${r.label} requires exactly one capability contract`);
    for(const c of compiled.capabilities)if(compiled.capabilities.filter(x=>x.role===c.role).length!==1)fail('only one capability contract per role');
    for(const task of compiled.tasks){
      const related=compiled.proofs.filter(p=>p.task===task.label);
      if(!related.length)fail(`task ${task.label} requires explicit proof declaration`);
      const role=compiled.roles.find(r=>r.label===task.role);
      if(!builtins.has(role.capability)&&!related.some(p=>p.kind==='service_receipt'))fail(`external task ${task.label} must require service_receipt`);
      if(builtins.has(role.capability)&&related.some(p=>p.kind==='service_receipt'))fail('local task cannot require external service_receipt');
    }
  }
  // Deterministic, general DAG with lexical tie-breaking. Unsupported cycles fail compilation.
  const ordered=[];const waiting=new Map(compiled.tasks.map(x=>[x.label,x]));
  while(waiting.size){const ready=[...waiting.values()].filter(x=>x.dependencies.every(d=>ordered.includes(d))).sort((a,b)=>a.label<b.label?-1:a.label>b.label?1:0);
    if(!ready.length)fail('cyclic dependencies'); for(const t of ready){ordered.push(t.label);waiting.delete(t.label);}}
  compiled.order=ordered;
  return {...compiled,digest:digest(compiled)};
}
function verifyMission(m) {
  if(!m||!['octolang.mission.v0.9','octolang.mission.v1.2','octolang.mission.v1.3'].includes(m.schema))return false;
  const {digest:hash,...rest}=m;
  return typeof hash==='string'&&hash===digest(rest);
}
function isoWindow(p,now,maxMs=300000) {
  if(!p||typeof p.issuedAt!=='string'||typeof p.expiresAt!=='string'||!/^\d{4}-\d\d-\d\dT/.test(p.issuedAt))return false;
  const a=Date.parse(p.issuedAt),b=Date.parse(p.expiresAt);
  return Number.isFinite(a)&&Number.isFinite(b)&&a<=now+30000&&b>now&&b>a&&b-a<=maxMs;
}
function validInput(input,type) {
  if(type==='ada') { try{amountToLovelace(input,'ADA');return true;}catch{return false;} }
  if(type==='integer')return typeof input==='string'&&/^(?:0|[1-9]\d*)$/.test(input)&&BigInt(input)<=BigInt(Number.MAX_SAFE_INTEGER);
  if(type==='text')return typeof input==='string'&&input.length>0&&input.length<=500;
  return typeof input==='boolean';
}
function planMission({mission,request,review,claims=[],grants=[],trust,now=Date.now()}) {
  const {verifyReview,verifyClaim}=require('./runtime');
  const deny=reason=>({status:'DENY',reason});
  try {
    if(!verifyMission(mission))return deny('Mission digest mismatch');
    if(!verifyReview(mission,review,trust,now))return deny('Human signature required for exact mission digest');
    if(request?.schema!=='octolang.mission-request.v0.9'||request.missionDigest!==mission.digest||
      !/^[a-zA-Z0-9_.:-]{1,80}$/.test(request.subject||'')||
      typeof request.nonce!=='string'||request.nonce.length<16||!isoWindow(request,now))return deny('Invalid or expired mission request');
    if(!request.inputs||Object.getPrototypeOf(request.inputs)!==Object.prototype||
      Object.keys(request.inputs).length!==mission.inputs.length)return deny('Input count mismatch');
    for(const v of mission.inputs)if(!Object.hasOwn(request.inputs,v.label)||!validInput(request.inputs[v.label],v.type))return deny(`Invalid typed input ${v.label}`);
    for(const c of mission.constraints)if(c.type==='max'){
      const inputType=mission.inputs.find(v=>v.label===c.input).type;
      const n=inputType==='ada'?BigInt(amountToLovelace(request.inputs[c.input],'ADA')):BigInt(request.inputs[c.input]);
      if(n>BigInt(c.max))return deny(`Constraint ${c.label} exceeded`);
    }
    const contextEvidence={};
    for(const c of mission.contexts){const proof=claims.find(p=>verifyClaim(p,{...c,status:'VERIFIED'},request.subject,trust,now));
      if(!proof)return deny(`Missing independently verifiable context ${c.label}`);
      contextEvidence[c.label]=digest(proof);
    }
    const requestDigest=digest(request);
    const assignments={},used=new Set();
    for(const role of mission.roles){
      const options=grants.filter(g=>{
        const p=g?.payload;return p?.schema==='octolang.agent-grant.v0.9'&&p.missionDigest===mission.digest&&
          p.role===role.label&&p.capability===role.capability&&typeof p.agent==='string'&&
          /^[a-zA-Z0-9_.:-]{1,80}$/.test(p.agent)&&!used.has(p.agent)&&
          p.issuer&&trust?.grantIssuers?.[p.issuer]&&trust?.agents?.[p.agent]&&
          typeof p.nonce==='string'&&p.nonce.length>=16&&isoWindow(p,now,24*3600000)&&verifiedSigned(g,trust.grantIssuers[p.issuer]);
      }).sort((a,b)=>a.payload.agent<b.payload.agent?-1:a.payload.agent>b.payload.agent?1:0);
      if(!options.length)return deny(`No trusted grant for role ${role.label}`);
      assignments[role.label]={agent:options[0].payload.agent,grantDigest:digest(options[0])};used.add(options[0].payload.agent);
    }
    const plan={schema:'octolang.mission-plan.v0.9',missionDigest:mission.digest,requestDigest,
      contextRoot:digest(contextEvidence),assignments,steps:mission.order.map(id=>{
        const task=mission.tasks.find(t=>t.label===id);
        return {...task,agent:assignments[task.role].agent};
      })};
    return {status:'READY_FOR_SIMULATION',plan:{...plan,digest:digest(plan)},contextEvidence};
  }catch(e){return deny(`Invalid request or evidence: ${e.message}`);}
}
function verifyMissionEvidence({mission,request,plan,receipts,review,claims,grants,trust,now=Date.now()}) {
  const deny=reason=>({status:'DENY',reason});
  try{
    if(['octolang.mission.v1.2','octolang.mission.v1.3'].includes(mission?.schema))return deny('Typed proof requirements require v1.2 execution controller and independent proof verifier');
    if(!verifyMission(mission)||plan?.missionDigest!==mission.digest||request?.missionDigest!==mission.digest)return deny('Mission/request mismatch');
    // Independent verification must also recheck the reviewed mission, signed grants,
    // typed constraints and signed VCG claims. A signed task receipt alone is insufficient.
    const fresh=planMission({mission,request,review,claims,grants,trust,now});
    if(fresh.status!=='READY_FOR_SIMULATION'||fresh.plan.digest!==plan.digest)return deny(`Mission authority or plan verification failed: ${fresh.reason||'plan mismatch'}`);
    const {digest:planDigest,...planBody}=plan;
    if(digest(planBody)!==planDigest||plan.requestDigest!==digest(request))return deny('Plan digest mismatch');
    if(!Array.isArray(plan.steps)||plan.steps.length!==mission.tasks.length||
      plan.steps.some((s,i)=>{const expected=mission.tasks.find(t=>t.label===mission.order[i]);return !expected||s.label!==expected.label||s.role!==expected.role||s.produces!==expected.produces||
        digest(s.dependencies)!==digest(expected.dependencies)||s.requiredContext!==expected.requiredContext||
        s.agent!==plan.assignments?.[s.role]?.agent;}))return deny('Plan steps differ from compiled mission');
    if(!Array.isArray(receipts)||receipts.length!==plan.steps.length)return deny('Missing or extra receipts');
    const evidence={},usedNonces=new Set();
    for(let i=0;i<plan.steps.length;i++){
      const s=plan.steps[i],receipt=receipts[i],p=receipt?.payload;
      const expectedDeps=Object.fromEntries(s.dependencies.map(d=>[d,evidence[d]]));
      if(s.dependencies.some(d=>!evidence[d]))return deny('Missing dependency evidence');
      if(p?.nonce && usedNonces.has(p.nonce))return deny('Duplicate evidence nonce');
      if(p?.schema!=='octolang.mission-evidence.v0.9'||p.missionDigest!==mission.digest||p.planDigest!==plan.digest||
        p.requestDigest!==plan.requestDigest||p.contextRoot!==plan.contextRoot||
        p.task!==s.label||p.role!==s.role||p.agent!==s.agent||p.evidence!==s.produces||
        p.outcome!=='SIMULATED'||digest(p.dependencies)!==digest(expectedDeps)||
        typeof p.nonce!=='string'||p.nonce.length<16||!isoWindow(p,now,300000)||
        !trust?.agents?.[p.agent]||!verifiedSigned(receipt,trust.agents[p.agent]))return deny(`Unverifiable evidence for task ${s.label}`);
      usedNonces.add(p.nonce);evidence[s.label]=digest(receipt);
    }
    for(const o of mission.outcomes)if(!evidence[o.task])return deny(`Unproven outcome ${o.label}`);
    return {status:'VERIFIED_SIMULATION',outcomes:mission.outcomes.map(o=>({name:o.label,evidenceDigest:evidence[o.task]})),root:digest(evidence)};
  }catch(e){return deny(`Evidence validation failed: ${e.message}`);}
}
module.exports={parseMission,compileMission,verifyMission,planMission,verifyMissionEvidence};
