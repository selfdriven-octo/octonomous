'use strict';
const { digest, verifiedSigned } = require('./canonical');
const { amountToLovelace } = require('./compiler');

const fail = (status, reason, more = {}) => ({ status, reason, ...more });
const validDate = iso => typeof iso === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,3})?Z$/.test(iso) && Number.isFinite(Date.parse(iso));
function timeWindow(p, now, maxMs = 365 * 86400000) {
  if (!validDate(p.issuedAt) || !validDate(p.expiresAt)) return false;
  const start = Date.parse(p.issuedAt), end = Date.parse(p.expiresAt);
  return start <= now + 30000 && end > now && start < end && end - start <= maxMs;
}
function verifyReview(policy, review, trusted, now) {
  const p = review?.payload;
  return p?.schema === 'octolang.review.v1' && p.scoreDigest === policy.digest &&
    typeof p.reviewer === 'string' && trusted?.reviewers?.[p.reviewer] &&
    typeof p.nonce === 'string' && p.nonce.length >= 16 && timeWindow(p, now) &&
    verifiedSigned(review, trusted.reviewers[p.reviewer]);
}
function verifyClaim(claim, required, target, trusted, now) {
  const p = claim?.payload;
  return p?.schema === 'octolang.claim.v1' && p.issuer === required.issuer &&
    p.claim === required.claim && p.subject === target && p.status === 'VERIFIED' &&
    typeof p.nonce === 'string' && p.nonce.length >= 16 &&
    timeWindow(p, now) && now - Date.parse(p.issuedAt) <= required.maxAgeMs &&
    !!trusted?.issuers?.[p.issuer] && verifiedSigned(claim, trusted.issuers[p.issuer]);
}
function verifyApproval(approval, requestDigest, policy, trusted, now) {
  const p = approval?.payload;
  return p?.schema === 'octolang.approval.v1' && p.approver === policy.approval.signer &&
    p.requestDigest === requestDigest && p.scoreDigest === policy.digest &&
    typeof p.nonce === 'string' && p.nonce.length >= 16 &&
    timeWindow(p, now, 3600000) && !!trusted?.approvers?.[p.approver] &&
    verifiedSigned(approval, trusted.approvers[p.approver]);
}
function verifyReceipt(receipt, requestDigest, policy, trusted, now) {
  const p = receipt?.payload;
  return p?.schema === 'octolang.execution-receipt.v1' && p.type === policy.expectedReceipt &&
    p.requestDigest === requestDigest && p.scoreDigest === policy.digest &&
    p.outcome === 'SIMULATED' && typeof p.nonce === 'string' && p.nonce.length >= 16 &&
    timeWindow(p, now, 180000) && !!trusted?.executors?.[p.executor] &&
    verifiedSigned(receipt, trusted.executors[p.executor]);
}
function evaluate({ policy, request, claims = [], approvals = [], review, trusted, usedNonces = new Set(), now = Date.now() }) {
  try {
    if (!policy || !['octolang.policy.v0.1','octolang.policy.v0.4','octolang.policy.v0.5'].includes(policy.schema)) return fail('DENY', 'Unsupported compiled policy');
    const { digest: givenDigest, ...body } = policy;
    if (digest(body) !== givenDigest) return fail('DENY', 'Compiled policy digest mismatch');
    if (!verifyReview(policy, review, trusted, now)) return fail('DENY', 'Human review signature missing or invalid');
    if (!request || request.schema !== 'octolang.action-request.v1' ||
        request.scoreDigest !== policy.digest || typeof request.nonce !== 'string' || request.nonce.length < 16 ||
        typeof request.target !== 'string' || request.target.length < 1 ||
        !timeWindow(request, now, 300000)) return fail('DENY', 'Invalid or expired action request');
    const requestDigest = digest(request);
    if (usedNonces.has(request.nonce)) return fail('DENY', 'Replay: action nonce already used', { requestDigest });
    const agent = policy.agents.find(a => a.name === request.agent && a.capability === request.capability);
    if (!agent || request.capability !== policy.action || request.currency !== 'ADA') return fail('DENY', 'Agent or capability not authorised', { requestDigest });
    const amount = BigInt(amountToLovelace(String(request.amount), request.currency));
    if (amount > BigInt(agent.limitLovelace)) return fail('DENY', 'Agent spending limit exceeded', { requestDigest });
    const required = policy.contexts.find(c => c.label === policy.requiredContext);
    if (!required || !claims.some(c => verifyClaim(c, required, request.target, trusted, now))) {
      return fail('DENY', 'No valid signed context claim for this supplier', { requestDigest });
    }
    if (amount > BigInt(policy.approval.aboveLovelace)) {
      if (approvals.length === 0) return fail('ESCALATE', 'Signed project-steward approval required', { requestDigest });
      if (!approvals.some(a => verifyApproval(a, requestDigest, policy, trusted, now))) {
        return fail('DENY', 'Approvals provided do not authorise exact request', { requestDigest });
      }
    }
    return fail('ALLOW', 'All local demo preconditions satisfied', { requestDigest, scoreDigest: policy.digest });
  } catch (e) { return fail('DENY', `Invalid request or policy: ${e.message}`); }
}
async function simulate({ policy, request, claims, approvals, review, trusted, usedNonces, executor }) {
  // Demonstration-only, process-local replay guard; NOT an atomic production capability store.
  if (!(usedNonces instanceof Set)) throw new TypeError('Pass a process-local Set as usedNonces');
  const decision = evaluate({ policy, request, claims, approvals, review, trusted, usedNonces });
  if (decision.status !== 'ALLOW') return { decision, simulation: null };
  usedNonces.add(request.nonce);
  try {
    const receipt = await executor({ request, requestDigest: decision.requestDigest, scoreDigest: policy.digest, type: policy.expectedReceipt });
    if (!verifyReceipt(receipt, decision.requestDigest, policy, trusted, Date.now())) {
      return { decision: fail('DENY', 'Mock executor receipt failed verification'), simulation: null };
    }
    return { decision, simulation: { outcome: 'SIMULATED', receipt, evidenceRecorded: policy.recordEvidence } };
  } catch (e) {
    return { decision: fail('DENY', `Simulator failed: ${e.message}`), simulation: null };
  }
}
module.exports = { evaluate, simulate, verifyReview, verifyClaim, verifyApproval, verifyReceipt };
