'use strict';
const { parse } = require('./parser');
const { digest } = require('./canonical');
const { compileMission } = require('./mission');
const REQUIRED_CONTEXT = ['claim', 'issuer', 'status', 'max_age'];
const REQUIRED_AGENT = ['capability', 'limit', 'delegate'];
const assert = (ok, text) => { if (!ok) throw new Error(`OctoLang compile error: ${text}`); };
const complete = (o, fields, name) => { for (const key of fields) assert(o && Object.hasOwn(o, key), `${name} missing ${key}`); };
function amountToLovelace(value, currency) {
  assert(currency === 'ADA', 'only ADA supported in v0.1');
  assert(/^(?:0|[1-9]\d*)(?:\.\d{1,6})?$/.test(value), 'ADA amount must be nonnegative with <= 6 decimals');
  const [whole, fract = ''] = value.split('.');
  const x = BigInt(whole) * 1000000n + BigInt((fract + '000000').slice(0, 6));
  assert(x <= 45000000000000000n, 'ADA amount exceeds supply bound');
  return x.toString();
}
function parseAge(value) {
  const m = /^(\d+)(m|h|d)$/.exec(value || '');
  assert(!!m, 'max_age expects duration e.g. 30d, 12h or 30m');
  const ms = Number(m[1]) * ({ m: 60000, h: 3600000, d: 86400000 }[m[2]]);
  assert(Number.isSafeInteger(ms) && ms > 0 && ms <= 365 * 86400000, 'max_age out of range');
  return ms;
}
function compile(source) {
  if (typeof source === 'string' && /^\s*(?:(?:#|\/\/)[^\n]*\s*)*mission\b/.test(source)) return compileMission(source);
  const a = typeof source === 'string' ? parse(source) : source;
  assert(typeof a.intent === 'string' && a.intent.trim().length > 0 && a.intent.length <= 500, 'intent required (max 500 chars)');
  assert(Array.isArray(a.contexts) && a.contexts.length > 0, 'at least one context required');
  assert(Array.isArray(a.agents) && a.agents.length > 0, 'at least one agent required');
  assert(a.before && a.after && a.onViolation === 'DENY', 'before, after and on violation DENY required');
  assert(a.before.action === a.after.action, 'before/after action must match');
  assert(a.before.require, 'before must require context');
  assert(a.after.require && a.after.record === true, 'after must require receipt and record evidence');
  assert(a.before.approve, 'v0.1 requires explicit conditional approval rule');
  const labels = new Set();
  const contexts = a.contexts.map(c => {
    complete(c, REQUIRED_CONTEXT, 'context');
    assert(!labels.has(c.label), `duplicate context ${c.label}`); labels.add(c.label);
    assert(c.status === 'VERIFIED', 'only VERIFIED status allowed as policy requirement');
    assert(c.claim && c.issuer, 'context claim and issuer cannot be empty');
    return { label: c.label, claim: c.claim, issuer: c.issuer, status: c.status, maxAgeMs: parseAge(c.max_age) };
  });
  assert(labels.has(a.before.require), 'before references unknown context');
  labels.clear();
  const agents = a.agents.map(agent => {
    complete(agent, REQUIRED_AGENT, 'agent');
    assert(!labels.has(agent.label), `duplicate agent ${agent.label}`); labels.add(agent.label);
    assert(agent.delegate === false, 'v0.1 does not support delegated capabilities');
    assert(a.ensemble || agent.capability === a.before.action, 'agent capability must match the before action');
    return { name: agent.label, capability: agent.capability, limitLovelace: amountToLovelace(agent.limit.value, agent.limit.currency), delegate: false };
  });
  assert(a.before.approve.approver.length > 0, 'approval signer required');
  const policy = {
    schema: a.federation ? 'octolang.policy.v0.5' : a.ensemble ? 'octolang.policy.v0.4' : 'octolang.policy.v0.1', score: a.name, intent: a.intent,
    contexts, agents,
    action: a.before.action, requiredContext: a.before.require,
    approval: { signer: a.before.approve.approver, aboveLovelace: amountToLovelace(a.before.approve.threshold.value, a.before.approve.threshold.currency) },
    expectedReceipt: a.after.require, recordEvidence: true, onViolation: 'DENY'
  };
  if (a.ensemble) {
    const steps = a.ensemble.steps;
    assert(steps.length === 3, 'v0.4 ensemble must have exactly research, purchase and audit steps');
    const stepNames = new Set();
    const allowed = ['research', 'purchase', 'audit'];
    steps.forEach((s, i) => {
      complete(s, ['agent','capability','depends','require','evidence'], `step ${s.id}`);
      assert(!stepNames.has(s.id), `duplicate ensemble step ${s.id}`);
      assert(s.capability === allowed[i], `step ${i+1} must have ${allowed[i]} capability`);
      assert(labels.has(s.agent), `step ${s.id} references unknown agent ${s.agent}`);
      const agent = agents.find(x => x.name === s.agent);
      assert(agent.capability === s.capability, `step ${s.id} exceeds assigned agent capability`);
      assert(s.require === a.before.require, `step ${s.id} must share VCC-checked context (v0.4)`);
      assert(s.depends === (i === 0 ? 'none' : steps[i-1].id), `step ${s.id} must depend on preceding step`);
      assert(s.evidence.length > 0 && s.evidence.length <= 100, 'step evidence name required');
      stepNames.add(s.id);
    });
    assert(new Set(steps.map(s => s.agent)).size === 3, 'each ensemble step requires a distinct agent');
    assert(steps[1].agent === agents.find(x => x.capability === a.before.action)?.name,
      'purchase step must belong to original authorised action agent');
    assert(steps[1].require === a.before.require, 'purchase step must use original VCC context');
    assert(agents.length === 3, 'v0.4 requires exactly three scoped agents');
    for (const agent of agents) if (agent.capability !== 'purchase') assert(BigInt(agent.limitLovelace) === 0n,
      'non-purchasing agents must have zero spending limit');
    policy.ensemble = { name: a.ensemble.name, steps: steps.map(s => ({ ...s })) };
  }
  if (a.federation) {
    assert(!!a.ensemble, 'federation requires an ensemble');
    assert(a.federation.name.length <= 64, 'federation name too long');
    const members = a.federation.members;
    assert(members.length === 3, 'v0.5 federation requires exactly three members');
    const agentNames = policy.ensemble.steps.map(s => s.agent);
    const ids = new Set(), communities = new Set();
    for (const member of members) {
      assert(agentNames.includes(member.agent) && !ids.has(member.agent), 'unknown or duplicate federation agent');
      assert(/^[a-zA-Z0-9_-]{3,64}$/.test(member.community), 'invalid community identifier');
      assert(!communities.has(member.community) && member.community !== 'community-coordinator', 'federation requires distinct member communities');
      ids.add(member.agent); communities.add(member.community);
    }
    assert(agentNames.every(id => ids.has(id)), 'every ensemble agent requires a community');
    policy.federation = { name: a.federation.name,
      members: agentNames.map(agent => ({ agent, community:members.find(m => m.agent === agent).community })) };
  }
  return { ...policy, digest: digest(policy) };
}
module.exports = { compile, amountToLovelace };
