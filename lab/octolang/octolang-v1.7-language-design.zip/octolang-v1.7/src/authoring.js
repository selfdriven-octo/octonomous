'use strict';
const { compile } = require('./compiler');

// Model-generated text is always UNTRUSTED; no model output becomes executable authority.
const SYSTEM_INSTRUCTIONS = `You are a DRAFTING assistant for OctoLang v0.1.
Return ONLY syntactically valid .octo text. Never claim the policy is approved.
The human reviewer will independently check intent, every permission, every source,
limits, escalation thresholds, evidence requirements and the compiled digest.
Supported grammar (exactly one of each named block):
score name {
  intent "human-readable goal"
  context source_name { claim "claim.key" issuer "trusted-issuer" status VERIFIED max_age 30d }
  agent actor_name { capability "purchase" limit 100 ADA delegate false }
  before purchase { require source_name approve "trusted-steward" when amount > 50 ADA }
  after purchase { require receipt "payment" record evidence }
  on violation DENY
}
Only ADA supported, delegate must be false. Untrusted claims must never be called verified
without an independent signed evidence verifier configured in the runtime.`;

async function propose({ userIntent, modelAdapter }) {
  if (typeof userIntent !== 'string' || !userIntent.trim() || userIntent.length > 2000) {
    throw new TypeError('userIntent must be a nonempty string up to 2000 chars');
  }
  if (typeof modelAdapter !== 'function') throw new TypeError('modelAdapter(prompt) is required');
  const raw = await modelAdapter({ system: SYSTEM_INSTRUCTIONS, user: userIntent });
  if (typeof raw !== 'string') throw new TypeError('Model must return plain .octo text');
  const compiled = compile(raw); // reject unsafe, unsupported, malformed or incomplete drafts
  return { draft: raw, compiled, status: 'AWAITING_HUMAN_REVIEW', digest: compiled.digest };
}
const ENSEMBLE_SYSTEM_INSTRUCTIONS = `You draft OctoLang v0.4 MULTI-AGENT scores as unapproved source text only.
Use exactly THREE different agents with capability research, purchase, audit in that order;
research and audit each have a 0 ADA limit; buyer has a finite ADA spending limit;
all delegation must be false; preserve before/after purchase and on violation DENY.
Each step uses the same verified context as the before purchase rule and depends on its predecessor.
Exact three-step grammar:
ensemble supplies {
  step find_supplier { agent scout capability "research" depends none require accredited_provider evidence "signed.supplier-shortlist" }
  step record_purchase_intent { agent buyer capability "purchase" depends find_supplier require accredited_provider evidence "signed.local-intent" }
  step verify_receipt { agent checker capability "audit" depends record_purchase_intent require accredited_provider evidence "signed.audit-summary" }
}
Full sample score:
score community_ensemble {
  intent "Research, record and audit the purchase intent"
  context accredited_provider { claim "supplier.accredited" issuer "community-registry" status VERIFIED max_age 30d }
  agent scout { capability "research" limit 0 ADA delegate false }
  agent buyer { capability "purchase" limit 100 ADA delegate false }
  agent checker { capability "audit" limit 0 ADA delegate false }
  before purchase { require accredited_provider approve "project-steward" when amount > 50 ADA }
  after purchase { require receipt "payment" record evidence }
  ensemble supplies {
    step find_supplier { agent scout capability "research" depends none require accredited_provider evidence "signed.supplier-shortlist" }
    step record_purchase_intent { agent buyer capability "purchase" depends find_supplier require accredited_provider evidence "signed.local-intent" }
    step verify_receipt { agent checker capability "audit" depends record_purchase_intent require accredited_provider evidence "signed.audit-summary" }
  }
  on violation DENY
}
Return raw .octo source, no Markdown. A human must review and sign before execution.`;
async function proposeEnsemble({ userIntent, modelAdapter }) {
  if (typeof userIntent !== 'string' || !userIntent.trim() || userIntent.length > 500) throw new TypeError('Intent length must be 1–500');
  if (typeof modelAdapter !== 'function') throw new TypeError('AI model adapter is missing');
  const draft = await modelAdapter({ system: ENSEMBLE_SYSTEM_INSTRUCTIONS, user: userIntent });
  if (typeof draft !== 'string') throw new TypeError('Model must return OctoLang source');
  const compiled = compile(draft);
  if (!compiled.ensemble) throw new Error('AI did not produce a v0.4 ensemble score');
  return { draft, compiled, status:'AWAITING_HUMAN_REVIEW', digest:compiled.digest };
}
const FEDERATION_SYSTEM_INSTRUCTIONS = ENSEMBLE_SYSTEM_INSTRUCTIONS + `
For federation v0.5, include exactly this top-level declaration inside score, after ensemble:
  federation community_supplies {
    member scout { community "community-research" }
    member buyer { community "community-execution" }
    member checker { community "community-audit" }
  }
The three distinct community IDs become human-reviewed mandatory score constraints.
Only these three identities and the fixed three-step ensemble are supported.
Never return signatures, shared secrets, approval grants or executable tool code.
`;
async function proposeFederation({ userIntent, modelAdapter }) {
  if (typeof userIntent !== 'string' || !userIntent.trim() || userIntent.length > 500) throw new TypeError('Intent length must be 1–500');
  if (typeof modelAdapter !== 'function') throw new TypeError('AI model adapter is missing');
  const draft = await modelAdapter({ system:FEDERATION_SYSTEM_INSTRUCTIONS, user:userIntent });
  if (typeof draft !== 'string') throw new TypeError('AI must return OctoLang source');
  const compiled=compile(draft);
  if (compiled.schema !== 'octolang.policy.v0.5' || !compiled.federation) throw new Error('AI did not produce a valid v0.5 federation score');
  return { draft, compiled, status:'AWAITING_HUMAN_REVIEW', digest:compiled.digest };
}
module.exports = { SYSTEM_INSTRUCTIONS, ENSEMBLE_SYSTEM_INSTRUCTIONS, FEDERATION_SYSTEM_INSTRUCTIONS,
  propose, proposeEnsemble, proposeFederation };

// v0.9 goal-to-mission prompt; models produce proposals only and cannot issue grants.
const MISSION_SYSTEM_INSTRUCTIONS = `Draft an UNAPPROVED OctoLang v0.9 mission. Output only raw source, not Markdown.\n${require('node:fs').readFileSync(require('node:path').join(__dirname,'../examples/community-mission.octo'),'utf8')}\nKeep the same strict grammar and 4 roles, verified context, typed input and all constraints. Use the requested goal text. Never add arbitrary code, secret credentials or execution permissions. Valid compilation alone grants nothing.`;
module.exports.MISSION_SYSTEM_INSTRUCTIONS = MISSION_SYSTEM_INSTRUCTIONS;
