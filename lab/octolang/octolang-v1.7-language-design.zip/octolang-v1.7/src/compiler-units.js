'use strict';
// Shared deterministic ADA quantity parser (same monetary semantics as v0.1).
function amountToLovelace(value,currency) {
  if(currency!=='ADA'||typeof value!=='string'||!/^(?:0|[1-9]\d*)(?:\.\d{1,6})?$/.test(value))throw Error('Invalid ADA quantity');
  const [whole,fraction='']=value.split('.');const n=BigInt(whole)*1000000n+BigInt((fraction+'000000').slice(0,6));
  if(n>45000000000000000n)throw Error('ADA exceeds supply bound');
  return n.toString();
}
module.exports={amountToLovelace};
