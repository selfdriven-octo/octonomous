'use strict';

function tokenize(source) {
  if (source.length > 64 * 1024) throw new SyntaxError('Score exceeds 64 KB source limit');
  const out = [];
  let i = 0, line = 1, col = 1;
  while (i < source.length) {
    const rest = source.slice(i);
    const n = rest.match(/^(?:\s+|#[^\n]*|\/\/[^\n]*)/);
    if (n) {
      for (const c of n[0]) { if (c === '\n') { line++; col = 1; } else col++; }
      i += n[0].length;
      continue;
    }
    const value = rest.match(/^(?:"(?:\\["\\nrt]|[^"\\\r\n])*"|[A-Za-z_][A-Za-z0-9_.-]*|\d+(?:\.\d+)?|[{}>])/);
    if (!value) throw new SyntaxError(`Unexpected character at ${line}:${col}`);
    const raw = value[0];
    out.push({ raw, line, col, type: raw[0] === '"' ? 'string' : /^[0-9]/.test(raw) ? 'number' : 'symbol' });
    col += raw.length; i += raw.length;
    if (out.length > 2000) throw new SyntaxError('Too many tokens');
  }
  out.push({ raw: '<EOF>', line, col, type: 'eof' });
  return out;
}
function parse(source) {
  const tokens = tokenize(source);
  let pos = 0;
  const peek = () => tokens[pos];
  const error = message => { throw new SyntaxError(`${message} at ${peek().line}:${peek().col}`); };
  const take = raw => { if (peek().raw !== raw) error(`Expected ${raw}, found ${peek().raw}`); pos++; };
  const next = (type, label) => {
    if (peek().type !== type) error(`Expected ${label || type}`);
    const t = peek(); pos++; return t.raw;
  };
  const id = () => { const raw = next('symbol', 'identifier'); if (!/^[a-zA-Z_][a-zA-Z0-9_-]*$/.test(raw)) error('Invalid identifier'); return raw; };
  const str = () => JSON.parse(next('string'));
  const number = () => next('number');
  const unique = (object, key) => { if (Object.hasOwn(object, key)) error(`Duplicate keyword ${key}`); };
  const block = parsers => {
    take('{'); const result = {};
    while (peek().raw !== '}') {
      if (peek().type === 'eof') error('Unterminated block');
      const field = id(); unique(result, field);
      if (!parsers[field]) error(`Unknown field ${field}`);
      result[field] = parsers[field]();
    }
    take('}'); return result;
  };
  take('score'); const name = id(); take('{');
  const ast = { name, contexts: [], agents: [] };
  let seen = new Set();
  while (peek().raw !== '}') {
    if (peek().type === 'eof') error('Unterminated score');
    const key = id();
    if (key === 'context') {
      const label = id();
      ast.contexts.push({ label, ...block({ claim: str, issuer: str, status: id, max_age: () => { const n = number(); const unit = id(); return `${n}${unit}`; } }) });
    } else if (key === 'agent') {
      const label = id();
      ast.agents.push({ label, ...block({ capability: str, limit: () => ({ value: number(), currency: id() }), delegate: () => { const v = id(); if (!['true', 'false'].includes(v)) error('Expected true or false'); return v === 'true'; } }) });
    } else if (key === 'ensemble') {
      if (seen.has(key)) error('Multiple ensemble blocks unsupported');
      const ensembleName = id(); take('{');
      const steps = [];
      while (peek().raw !== '}') {
        if (peek().type === 'eof') error('Unterminated ensemble');
        take('step'); const stepName = id();
        steps.push({ id: stepName, ...block({
          agent: id,
          capability: str,
          depends: id,
          require: id,
          evidence: str
        }) });
        if (steps.length > 8) error('Too many ensemble steps');
      }
      take('}'); ast.ensemble = { name: ensembleName, steps }; seen.add(key);
    } else if (key === 'federation') {
      if (seen.has(key)) error('Multiple federation blocks unsupported');
      const federationName = id(); take('{');
      const members = [];
      while (peek().raw !== '}') {
        if (peek().type === 'eof') error('Unterminated federation block');
        take('member'); const agent = id();
        members.push({ agent, ...block({ community: str }) });
        if (members.length > 8) error('Too many federation members');
      }
      take('}'); ast.federation = { name:federationName, members }; seen.add(key);
    } else if (key === 'before') {
      if (seen.has(key)) error('Multiple before blocks unsupported in v0.1');
      const action = id();
      ast.before = { action, ...block({ require: id, approve: () => { const approver = str(); take('when'); take('amount'); take('>'); const value = number(); const currency = id(); return { approver, threshold: { value, currency } }; } }) };
      seen.add(key);
    } else if (key === 'after') {
      if (seen.has(key)) error('Multiple after blocks unsupported in v0.1');
      const action = id();
      ast.after = { action, ...block({ require: () => { take('receipt'); return str(); }, record: () => { take('evidence'); return true; } }) };
      seen.add(key);
    } else if (key === 'intent') {
      if (seen.has(key)) error('Duplicate intent');
      ast.intent = str(); seen.add(key);
    } else if (key === 'on') {
      if (seen.has(key)) error('Duplicate on violation');
      take('violation'); const decision = id();
      if (decision !== 'DENY') error('v0.1 requires on violation DENY');
      ast.onViolation = decision; seen.add(key);
    } else error(`Unknown score declaration ${key}`);
  }
  take('}');
  if (peek().type !== 'eof') error('Trailing tokens');
  return ast;
}
module.exports = { tokenize, parse };
