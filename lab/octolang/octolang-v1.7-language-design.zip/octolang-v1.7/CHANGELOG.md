# v1.7.0 — Adaptive/recursive composition language track

- Added bounded `composition` / `node` declarations over existing v1.6 typed mission IR. Nodes use only declared root tasks and inherit their exact effects, roles, proofs, contexts and dependencies.
- Added canonical, domain-separated `octolang.composition-ir.v1.7` with stable schedule, nesting depth and aggregate worst-case budget units.
- Added independently checkable signed Ed25519 governance mandate and role-grant **preflight**; signatures never originate from AI-authored source.
- Added signed plan revision proposals with old/new IR and mandate bindings; no changes to existing node task identity or resource ceilings.
- Added an effect-free demonstration, `octolang-compose` CLI, 19 frozen language vectors and security tests.
- Preserved legacy OctoLang/Midnight/runtime interfaces and digests; no real dynamic execution or persistent revision-ledger is claimed.

---

# OctoLang v1.6 — Language Design Track

- Draft formal grammar and typing semantics for supported `mission` declarations (`docs/LANGUAGE-FORMAL-v1.6.md`).
- Versioned, deterministic, domain-separated typed IR (`octolang.typed-ir.v1.6`) and legacy digest/source binding.
- New reference `octolang-language` CLI: `check`, `compile`, `verify`. **Non-executing**.
- Static diagnostics for unused roles/inputs, missing bounds, unscoped contexts, unobserved tasks, legacy proof gaps, unresolved capabilities.
- Separate offline IR structure/semantic verifier rejecting changed roles, effect types, graph schedules, service identities and declared proof bindings even when rehashed.
- Frozen positive/negative conformance vectors and dedicated tests.
- Existing OctoLang v1.5 runtime, network federation and Midnight functionality unchanged. No new live integration and no new execution privileges.

---

# Changelog

## v1.5.0 — Midnight local acceptance toolkit (20 October 2026)

- New read-only preflight: node, Docker Compose, Compact compiler, generated artifacts, SDK install, local ports and wallet configuration **presence only**.
- New standalone, read-only local indexer observer with off-chain signed evidence + human publication approval checks. No wallet secret or salt leaves the process in the observation request.
- Transaction result now records local `submittedAt` and `observedAt` audit timestamps; legacy v1.4 results cannot be accepted by the v1.5 assessment until regenerated on a new submission.
- New detailed, operator-gated runbook and fail-closed acceptance tests.
- **No live proof or actual chain transaction executed in the build environment**, because Docker, Compact and local Devnet are unavailable.

---

# v1.4.0 — Midnight local Devnet operator bridge

- Added a bounded, explicit live Midnight SDK adapter using the generated Compact contract, `deployContract`, `findDeployedContract`, `callTx.anchorEvidence`, and indexer ledger checks.
- Added optional pinned SDK dependencies and local-only WalletFacade integration with encrypted private state, signer-held secrets, saved wallet snapshots and separate human anchor authorisation.
- Added a deploy CLI, local evidence export bound to the deployed contract, approval CLI, preflight doctor, and developer runbook.
- Live chain publishing requires an explicit `YES_LOCAL_DEVNET` opt-in, and never occurs in Studio or AI composition.
- All SDK interactions are unit-tested using injected API fixtures; no actual Midnight network transaction or Compact compile ran in the build environment.
- Remaining gaps: production audit, independent finality, durable transaction recovery, and ZK circuit proof of OctoLang's off-chain policy.

---

## OctoLang v1.2.0 — Typed Capability and Proof Contracts

- Added opt-in `.octo` `capability` declarations binding a role, operator-approved external capability name, exact signed service identity, and named `input:type` disclosure fields.
- Added `proof` declarations for each task: `service_receipt`, `controller_receipt`, or `agent_receipt` (Ed25519 signatures only; **not** zero-knowledge/Groth16 proofs).
- Compiler emits `octolang.mission.v1.2` with contract/proof declarations cryptographically bound into the reviewed mission digest; legacy `.v0.9` missions compile unchanged.
- Execution controller checks the type contracts against the independently trusted signed service manifest **before** reserving an action and **at the point of effect**; unexpected input fields or service substitutions fail closed.
- Independent offline receipt verifier revalidates signed manifests, human approval, agent grants, context, service receipt, controller receipt and agent receipt, and returns digest-linked `typedProofs`.
- Browser Studio can inspect/review typed missions but deliberately cannot execute externally provisioned services or simulate fake execution proofs.
- Added reference `.octo` mission, example CLI, language/security guide, 22 new adversarial/regression tests.
- Demo only contacts a loopback note-writing service; no payments, wallet access or third-party connections.

# OctoLang Changelog

## v1.1.0 — Signed External Capability Services (20 October 2026)

- Extend v1.0 `MissionExecutionController` to accept **separately signed, mission-scoped capability manifests**. No arbitrary URL or tool can be generated by AI-authored scores.
- Keep deterministic human-review, verified context, independent agent grants, execution-time checks, one-use tool tokens and persistent replay reservations.
- Add separate capability-operator and service-signer Ed25519 trust anchors, short-lived signed requests, idempotency keys, signed service results and tool/evidence digest binding.
- Add loopback-only HTTP note service as the first demonstrably real network effect; remote HTTPS is an opt-in, preliminary transport profile, not a production recommendation.
- Add independent external evidence verifier with supplied public key pins and demo export.
- Introduce 14 capability and adversarial tests. Existing tests preserved; `npm test` runs serially to avoid pre-existing multi-process test contention.
- Limitations: no public network deployment, wallet/payment, Groth16 or third-party provider integration; synthetic keys and local service only.

---

# v1.0.0 — Verified Local Mission Execution Controller (20 October 2026)

- Added `mission/executor.js` to execute v0.9 compiled and human-approved missions through the **actual vendored Octonomous Runtime 1.0** `Runtime`, `Policy`, `ToolRegistry` and file store.
- Four hard-allowlisted local capabilities (`research`, `validate`, `intent.record`, `audit`), no dynamic tools or external effects beyond an intent journal append.
- New review/grant/context rechecks before **and at** tool execution; one-use tokens; agent-key binding; durable nonce reservations and crash-sticky reconciliation.
- Added signed controller tool receipts, agent evidence linked to exact plan and dependency digests, and independent `verifyExecutionEvidence`.
- Added export of public-only evidence bundle and explicit separately supplied trust-pins CLI verifier, plus Studio's opt-in local execution control.
- Added 15 regression/security tests; **94 passing total** in main test suite before clean package validation.
- Preserved earlier simulation, studio, federation and distributed demos. **No general-purpose autonomous external execution** is implied.

---

# OctoLang v0.9.0 — Missions and verifiable composition (2026-10-20)

- New independent `mission` grammar/compiler (`src/mission.js`) for variable-length roles/tasks, typed inputs, bounded constraints, deterministic DAG planning and explicitly named outcomes. Legacy `.octo score` grammar and schema/digests untouched.
- Capability-based role assignment from independently signed, issuer-trusted, mission-bound agent grants. Human-signed review and signed context claims are mandatory before planning.
- Independently re-verifiable *synthetic* task receipts with exact plan, request, context and dependency bindings. Produces evidence commitments, not claims of actual real-world execution.
- Browser Studio adds isolated Mission compose / compile / review / mock-verify panel and API. Optional AI composition uses the configured provider; offline mode works without one. No new privileged external tool endpoint.
- New example, `npm run mission`, guide and **12 additional automated tests** (79 total).
- Research limitations: in-memory fixtures, local demo only. No real autonomous mission executor, production VC standard, payment, ZK proof or Cardano adapter.

---

# OctoLang v0.8.0 — Verifiable Agent Development Platform

- Signed, 3-minute peer agent presentations served only over existing pinned mTLS. Descriptors bind the peer's previously issued credential, role, scope, endpoint, compiled score digest and independently signed local governance grant.
- Coordinator independently verifies live discovery before each OFP step without accepting discovered identities as new authority.
- Research community signs a short-lived verified context root; coordinator, execution and audit peers independently revalidate source claims, freshness, issuer, signers, context binding and credential.
- Studio Observe panel provides a **read-only**, input-redacted, independently reverified view of durable distributed runs; no browser-to-network authority bridging.
- Added targeted positive/adversarial platform tests, preserving all v0.7 tests. Experimental credentials remain custom signed JSON, not W3C VC interop.
- No live spending, Cardano, Midnight, Groth16, payments or open network exposure.

---

# Changelog

## v0.7.0 — Independently provisioned community hosts and durable OFP delivery

- Separate-host-capable peer commands with per-peer on-host Ed25519 and TLS key generation.
- Signed public-only registrations, explicit fingerprint approval, issuer-signed activation bundles and peer-signed local governance grants.
- Explicitly pinned self-signed mutual TLS for peer processes on private/VPN interfaces, alongside original signed OFP envelopes.
- Crash-persistent coordinator outbox: immutable signed intent, attempted envelopes, validated contributions, resume with same signed inputs.
- Peer-local signed contribution cache: retries create new OFP envelope, reissue receipt for same immutable payload without repeating effect.
- Fail-closed sticky uncertain operations and coordinator lock; operator reconciliation required after an ambiguous crash.
- 11 adversarial and recovery tests added (61 total), plus clean-extraction demo.
- Maintains v0.6 loopback pilot, in-process Studio, and all earlier OctoLang features.
- Explicit limitations: no physical multi-host deployment validation, no production PKI, no auto revocation distribution, no exact-once external effects, no Cardano, no real payments.

# OctoLang v0.6 — Real Process Network Pilot

**New:** three independent Node.js peer *processes*, authenticated OFP request/reply over loopback HTTP or optional mutual TLS, persistent Ed25519 identities, custom signed scoped demo credentials, per-community signed governance grants, local revocation list, isolated peer VCC/VCG checks, persistent per-peer replay reservations, independently signed agent contributions, original Octonomous Runtime 1.0 recording tool and pinned coordinator-side transcript verification.

**Testing:** 10 adversarial network tests added to the 40 earlier tests; quick demo `npm run network:mtls`, or manual key provision + three `network/peer.js` processes + `npm run network:conduct`.

**Not implemented:** separate physical hosts/real Internet federation, production TLS PKI, standard W3C VCs, automatic trust enrolment, distributed exactly-once processing, real purchases/payment, Cardano, Groth16 or proof of external facts. Browser Studio retains v0.5's in-process federation.

---

# OctoLang v0.5 — Signed federation pilot

- Added `federation NAME { member AGENT { community "COMMUNITY" } }` to `.octo`; compiler rejects missing/duplicate/unknown roles, duplicate community identities, self-assignment and delegation; all assignments bound to signed policy digest.
- Integrated actual Octonomous Federation Protocol 1.0.0 (OFP 2.0 signed envelopes), using separately scoped local signing providers, explicit recipient and sender checks and VCC verification at every stage.
- Added peer-local demo grant table not derived from inbound data and in-memory broker across three simulated sovereign communities.
- Added run/envelope ID/nonce cross-process sticky `wx` filesystem reservations; replay after engine restart and concurrent invocation is denied. No automatic retries or rollback.
- Retained native Octonomous Runtime 1.0 buyer journal and independently verified signed agent contributions; no payment.
- Added browser federation composer and conductor, optional AI drafting, and `npm run federation` CLI demonstration.
- Added eight adversarial/end-to-end tests; **40 tests pass**, including original 32.
- Added docs/FEDERATION.md listing non-implemented distributed network, persistent identity, KERI, proof, Cardano and production recovery features.

---

# Changelog

## v0.4.0 — Agent-to-Agent Composition (2026-10-19)

- Added `ensemble` score declaration with ordered, capability-scoped `step` blocks and explicit predecessor dependencies.
- Enforced bounded **three-agent** roles: `research -> purchase -> audit`, distinct agent identities, no delegation and zero spending rights for research/audit.
- Added independent Ed25519-signed per-agent contribution receipts bound to the exact reviewed score, request digest, VCG root, declared evidence type, predecessor digest and bounded validity window.
- Added per-step deterministic VCC re-checks and independent verification of **partial** and complete chains. Invalid steps fail closed and do not advance to subsequent steps.
- Buyer stage uses **real vendored Octonomous Runtime 1.0**, its native policy and ToolRegistry, to append only a local intent. Scout and checker remain mock identities and mock work.
- Added a browser Studio multi-agent template and optional AI multi-agent drafting mode. Existing review pairing and mock steward approval remain mandatory.
- Added `npm run ensemble` and `npm run ensemble-check` for a self-contained CLI demo.
- Added nine tests covering permissions, altered evidence, forgeries, dependency breaks, human/steward approval, concurrent replay and guarded studio HTTP flow. **32 total tests pass.**
- Explicitly not implemented: real distributed agents, durable replay across process restart, external tools/payments, OFP, Groth16, Cardano/Midnight settlement.

## v0.3.0

See `docs/INTEGRATION.md` for the original verified-context and runtime-bridge design. All v0.3 commands and original 23 tests remain available.

## v0.2.0 / v0.1.0

Earlier proof-of-concept language, offline/AI composition, browser human review, and deterministic local simulation.

## v1.3.0 — Midnight proof-backend integration seam (20 October 2026)

- Added an optional `anchor ... { backend midnight network "..." contract "..." }` declaration, covered by a distinct v1.3 mission digest and human review.
- Added `midnight/bridge.js` with independently verified evidence commitments, separate human-signed anchor authorisation, optional operator-supplied submit/read adapter, signed observer attestations, and independent state-reader checks.
- Added an illustrative Compact commitment-registry contract and detailed pinned-SDK deployment guidance.
- Added an **in-memory mock** adapter and a no-network end-to-end demonstration.
- Added nine targeted tests for the proof bridge and failure modes. Existing v1.2 missions and workflows remain compatible.
- **Not implemented:** verified Midnight on-chain submission, live SDK/wallet connector, actual Groth16/Compact proving, public-network chain finality verification, production-grade durable network retry handling, or contract authorisation.
