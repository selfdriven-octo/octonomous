'use strict';
const crypto=require('node:crypto');
const { createEndpoint }=require('../federation/engine');
const { publicKey }=require('./identity');
const { digest }=require('../src/canonical');
const { DurableClaims }=require('../federation/durable');
const path=require('node:path');
function endpoint(config, privateKey) {
  const directory=new Map(Object.entries(config.directory).map(([k,v])=>[k,publicKey(v.communityKeySpki)]));
  return createEndpoint(config.id,{privateKey,publicKey:crypto.createPublicKey(privateKey)},directory);
}
async function send(ep,to,messageType,payload) {
  const { envelope }=await ep.envelopes.create({input:{senderCommunityId:ep.id,recipientCommunityId:to,
    messageType,payload,lifetimeSeconds:120}});
  return envelope;
}
async function receive(ep,envelope,durable,kind) {
  if(!envelope || envelope.recipientCommunityId!==ep.id || envelope.messageType!==kind ||
    JSON.stringify(envelope).length>160000) throw new Error('OFP recipient/type/payload bound check failed');
  await ep.envelopes.verify({envelope,expectedRecipientCommunityId:ep.id});
  const now=Date.now(),issued=Date.parse(envelope.issuedAt),expired=Date.parse(envelope.expiresAt);
  if(!Number.isFinite(issued)||!Number.isFinite(expired)|| issued>now+30000||expired<=now||expired-issued>125000)
    throw new Error('OFP message expired or oversized time window');
  durable.reserveEnvelope(envelope);
  return envelope.payload;
}
function claimsIn(dir) { return new DurableClaims(path.join(dir,'state','claims')); }
function actorKeys(config) {return Object.fromEntries(Object.entries(config.directory)
  .filter(([,item])=>item.agent).map(([,item])=>[item.agent,publicKey(item.agentKeySpki)]));}
function publicAnchors(config) {
  const entries=type=>Object.fromEntries(Object.entries(config.trusted[type]).map(([n,k])=>[n,publicKey(k)]));
  return {reviewers:entries('reviewers'),issuers:entries('issuers'),approvers:entries('approvers')};
}
function payloadBindings({payload,local,step,inputs}) {
  if(payload?.schema!=='octolang.network-step.v0.6'||payload.stepId!==step.id ||
    payload.stepIndex!==inputs.policy.ensemble.steps.indexOf(step) ||
    payload.scoreDigest!==inputs.policy.digest||payload.requestDigest!==digest(inputs.request)||
    payload.contextRoot!==undefined && typeof payload.contextRoot!=='string' ||
    payload.actionNonce!==inputs.request.nonce||payload.agent!==step.agent||
    payload.capability!==step.capability||payload.community!==local.id ||
    payload.priorDigest!==(payload.contributions.length?digest(payload.contributions.at(-1)):null))
    throw new Error('Network score/step/context/predecessor binding mismatch');
}
module.exports={endpoint,send,receive,claimsIn,actorKeys,publicAnchors,payloadBindings};
