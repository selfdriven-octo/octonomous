'use strict';
const http=require('node:http');
const https=require('node:https');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {digest,signed}=require('../src/canonical');
const {assess}=require('../integration/vcc');
const {OctonomousBridge}=require('../integration/bridge');
const {verifyLocalReceipt}=require('../integration/verify');
const {verifyPartialTranscript}=require('../ensemble/verify');
const {loadPeer,loadRevocations,publicKey,verifyCredential,verifyGrant,COORDINATOR}=require('./identity');
const {endpoint,send,receive,claimsIn,actorKeys,publicAnchors,payloadBindings}=require('./common');
const {StepStore}=require('../distributed/steps');
const {present}=require('../platform/discovery');
const {makeAttestation,verifyAttestation}=require('../platform/context');
const MAX_BODY=180000;
function fail(message){throw new Error(message);}
function createPeer({root,id}) {
  const peer=loadPeer(root,id), {local,dir,identity,agent}=peer;
  const ep=endpoint(local,identity), durable=claimsIn(dir),stepStore=local.remote?new StepStore(dir):null;
  const trusted=publicAnchors(local), trustedAgentKeys=actorKeys(local);
  const journalSignerSpki=local.directory['community-execution'].agentKeySpki;
  const bridge=new OctonomousBridge({dataDir:path.join(dir,'state','effects')});
  bridge.signer={privateKey:agent,publicKey:crypto.createPublicKey(agent)}; // stable receipt identity across restarts
  async function handle(envelope) {
    if(envelope.senderCommunityId!==COORDINATOR) fail('Only pinned coordinator may initiate a step');
    const payload=await receive(ep,envelope,durable,'octolang.step.request.v0.6');
    const inputs=payload?.inputs;
    if(!inputs||!Array.isArray(payload.contributions)||payload.contributions.length>3) fail('Missing bounded score inputs');
    const {policy,request}=inputs;
    if(policy?.schema!=='octolang.policy.v0.5'||!policy.federation||policy.digest!==local.scoreDigest)
      fail('Score not part of independently provisioned governance');
    const index=payload.stepIndex,step=policy.ensemble?.steps?.[index];
    if(!step||payload.contributions.length!==index||policy.federation.members[index]?.community!==local.id)
      fail('Unexpected role, step order or community assignment');
    payloadBindings({payload,local,step,inputs});
    const my=local.directory[local.id];
    const credential=verifyCredential({credential:local.credentials[local.id],
      authorityKey:publicKey(local.credentialAuthoritySpki),revokedIds:loadRevocations(dir),expected:my});
    verifyGrant({grant:local.grant,governanceKey:publicKey(my.governanceKeySpki),credential,scoreDigest:policy.digest});
    const member=policy.agents.find(x=>x.name===step.agent);
    if(!member||member.capability!==my.capability||member.delegate!==false||BigInt(member.limitLovelace)>BigInt(my.maxLovelace))
      fail('Peer capability exceeds independently authorised grant');
    const fixed={...inputs,trusted,usedNonces:new Set()}; // NEVER accept trust anchors from the network
    const checked=assess(fixed);
    if(checked.decision.status!=='ALLOW'||payload.contextRoot!==checked.snapshot.root)
      fail(`Peer VCC refused request (${checked.decision.reason})`);
    if(local.remote && index>0)verifyAttestation(payload.contributions[0]?.output?.contextAttestation,
      {inputs,config:local,revokedIds:loadRevocations(dir)});
    if(index>0)verifyPartialTranscript({inputs:fixed,contributions:payload.contributions,
      trustedAgentKeys,receiptSignerPublicKeySpki:journalSignerSpki});
    // Remote requests use a persistent idempotent completed receipt, including after peer restart.
    // An unfinished claim is deliberately sticky and requires operator reconciliation.
    const cached=stepStore?.lookup(payload);
    if(cached?.cached){
      const contribution=cached.contribution;
      verifyPartialTranscript({inputs:fixed,contributions:[...payload.contributions,contribution],
        trustedAgentKeys,receiptSignerPublicKeySpki:journalSignerSpki});
      return send(ep,COORDINATOR,'octolang.step.result.v0.6',{
        schema:'octolang.network-result.v0.6',community:local.id,stepId:step.id,
        scoreDigest:policy.digest,responseTo:digest(envelope),contributionDigest:digest(contribution),
        credentialId:credential.id,contribution});
    }
    if(stepStore)stepStore.claim(payload);
    // Durable action nonce reservation precedes any effect, even if restarted with a fresh envelope.
    durable.reserveRun({...request,nonce:`${request.nonce}:${step.id}`});
    const previous=payload.contributions.at(-1)||null;
    let output;
    if(step.capability==='research') {
      output={schema:'octolang.step-output.v0.4',kind:'DEMO_SUPPLIER_RESEARCH',target:request.target,
        claimDigest:digest(inputs.claims[0]),note:'Independent process validated the signed demo registry claim; not real supplier accreditation'};
      if(local.remote)output.contextAttestation=makeAttestation({peer,inputs});
    } else if(step.capability==='purchase') {
      // Recheck local credential/revocation and grant at tool boundary.
      const nowCredential=verifyCredential({credential:local.credentials[local.id],authorityKey:publicKey(local.credentialAuthoritySpki),
        revokedIds:loadRevocations(dir),expected:my});
      verifyGrant({grant:local.grant,governanceKey:publicKey(my.governanceKeySpki),credential:nowCredential,scoreDigest:policy.digest});
      const result=await bridge.dispatch(fixed);
      if(result.status!=='RECORDED_LOCAL_INTENT'||!result.effect?.ok)fail('Octonomous Runtime refused local intent');
      if(!verifyLocalReceipt({record:result.effect.record,receipt:result.effect.receipt,receiptSignerPublicKeySpki:journalSignerSpki}))
        fail('Journal receipt independently invalid');
      output={schema:'octolang.step-output.v0.4',kind:'RECORDED_LOCAL_INTENT',record:result.effect.record,receipt:result.effect.receipt};
    } else if(step.capability==='audit') {
      output={schema:'octolang.step-output.v0.4',kind:'DEMO_AUDIT',subjectContributionDigest:digest(previous),
        localReceiptValid:true,note:'Independent mock audit process verified signed chain; no financial audit performed'};
    } else fail('Unknown agent capability');
    const now=Date.now();
    const claim={schema:'octolang.agent-contribution.v0.4',scoreDigest:policy.digest,
      requestDigest:digest(request),contextRoot:checked.snapshot.root,ensemble:policy.ensemble.name,
      stepId:step.id,agent:step.agent,capability:step.capability,evidence:step.evidence,
      outputDigest:digest(output),priorDigest:previous?digest(previous):null,
      issuedAt:new Date(now).toISOString(),expiresAt:new Date(now+120000).toISOString(),nonce:crypto.randomUUID()};
    const contribution={output,attestation:signed(claim,agent)};
    verifyPartialTranscript({inputs:fixed,contributions:[...payload.contributions,contribution],
      trustedAgentKeys,receiptSignerPublicKeySpki:journalSignerSpki});
    if(stepStore)stepStore.complete(payload,contribution);
    return send(ep,COORDINATOR,'octolang.step.result.v0.6',{
      schema:'octolang.network-result.v0.6',community:local.id,stepId:step.id,
      scoreDigest:policy.digest,responseTo:digest(envelope),contributionDigest:digest(contribution),
      credentialId:credential.id,contribution});
  }
  const tlsOptions=local.tls?{cert:fs.readFileSync(path.join(dir,'tls-cert.pem')),
    key:fs.readFileSync(path.join(dir,'tls-key.pem')),
    ca:local.remote?local.directory[COORDINATOR].tlsCertPem:fs.readFileSync(path.join(dir,'../governance/demo-ca.pem')),
    requestCert:true,rejectUnauthorized:true}:null;
  const server=(tlsOptions?https.createServer.bind(https,tlsOptions):http.createServer)(async(req,res)=>{
    const sendJson=(code,payload)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(JSON.stringify(payload));};
    if(!local.remote && req.socket.remoteAddress!=='127.0.0.1'&&req.socket.remoteAddress!=='::1')return sendJson(403,{error:'loopback only'});
    if(local.tls && (!req.client.authorized || req.socket.getPeerCertificate()?.subject?.CN!==COORDINATOR ||
       (local.remote && crypto.createHash('sha256').update(req.socket.getPeerCertificate(true).raw||'').digest('hex')!==
         crypto.createHash('sha256').update(new crypto.X509Certificate(local.directory[COORDINATOR].tlsCertPem).raw).digest('hex'))))
      return sendJson(403,{error:'mutual TLS coordinator identity required'});
    if(req.method==='GET'&&req.url==='/health')return sendJson(200,{status:'ready',community:local.id});
    if(req.method==='GET'&&req.url==='/agent'){
      try {return sendJson(200,{presentation:present(peer)});}
      catch(e){return sendJson(403,{error:'DENY',reason:e.message.slice(0,250)});}
    }
    if(req.method!=='POST'||req.url!=='/ofp'||!String(req.headers['content-type']).startsWith('application/json'))
      return sendJson(404,{error:'Not found'});
    let chunks=[],size=0;
    try{
      for await(const chunk of req){size+=chunk.length;if(size>MAX_BODY)fail('Request too large');chunks.push(chunk);}
      const body=JSON.parse(Buffer.concat(chunks).toString('utf8'));
      const reply=await handle(body.envelope);
      return sendJson(200,{envelope:reply});
    } catch(e){return sendJson(403,{error:'DENY',reason:e.message.slice(0,250)});}
  });
  return {server,peer,handle};
}
if(require.main===module){
  try{
    const root=process.argv[2]||'.octolang-network',id=process.argv[3];
    const {server,peer}=createPeer({root,id});
    const port=new URL(peer.local.url).port;
    const bind=peer.local.remote?(process.env.OCTOLANG_BIND||'127.0.0.1'):'127.0.0.1';
    server.listen(Number(port),bind,()=>console.log(`[${id}] OFP peer listening on ${bind}:${port} ${peer.local.remote?'DISTINCT HOST pinned-mTLS':peer.local.tls?'mTLS':'signed HTTP loopback'} (no payment tools)`));
  }catch(e){console.error(e.message);process.exitCode=1;}
}
module.exports={createPeer};
