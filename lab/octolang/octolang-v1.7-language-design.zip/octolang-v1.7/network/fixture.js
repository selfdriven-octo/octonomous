'use strict';
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const {signed,digest}=require('../src/canonical');
const {compile}=require('../src/compiler');
const {privateKey,COORDINATOR,loadCoordinator}=require('./identity');
const source=fs.readFileSync(path.join(__dirname,'../examples/community-federation.octo'),'utf8');
function fixture(root,{amount='75',nonce=crypto.randomUUID()}={}) {
  const node=loadCoordinator(root),policy=compile(source);
  const owner=privateKey(node.dir,'reviewer'), issuer=privateKey(node.dir,'issuer'), approver=privateKey(node.dir,'approver');
  const now=Date.now(),minutes=n=>new Date(now+n*60000).toISOString();
  if(policy.digest!==node.local.scoreDigest)throw new Error('Fixture score not pre-governed by provisioner');
  const request={schema:'octolang.action-request.v1',scoreDigest:policy.digest,agent:'buyer',capability:'purchase',
    amount:String(amount),currency:'ADA',target:'supplier-42',nonce,
    issuedAt:minutes(-1),expiresAt:minutes(4)};
  const review=signed({schema:'octolang.review.v1',reviewer:'community-owner',scoreDigest:policy.digest,
    issuedAt:minutes(-1),expiresAt:minutes(60),nonce:crypto.randomUUID()},owner);
  const claim=signed({schema:'octolang.claim.v1',issuer:'community-registry',claim:'supplier.accredited',
    subject:request.target,status:'VERIFIED',issuedAt:minutes(-1),expiresAt:minutes(40),nonce:crypto.randomUUID()},issuer);
  const approval=signed({schema:'octolang.approval.v1',approver:'project-steward',scoreDigest:policy.digest,
    requestDigest:digest(request),issuedAt:minutes(-1),expiresAt:minutes(10),nonce:crypto.randomUUID()},approver);
  return {policy,request,review,claims:[claim],approvals:[approval]};
}
module.exports={fixture};
