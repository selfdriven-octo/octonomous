'use strict';
const {digest}=require('../src/canonical');
const {assess}=require('../integration/vcc');
const {verifyPartialTranscript,verifyTranscript}=require('../ensemble/verify');
const {loadCoordinator,loadRevocations,verifyCredential,publicKey,ensureLoopback,COORDINATOR}=require('./identity');
const {endpoint,send,receive,claimsIn,actorKeys,publicAnchors}=require('./common');
const {exchange}=require('./transport');
function fail(text){throw new Error(text);}
class NetworkCoordinator {
  constructor({root}) {
    const node=loadCoordinator(root);
    this.dir=node.dir;this.config=node.local;
    this.endpoint=endpoint(node.local,node.identity);
    this.durable=claimsIn(node.dir);
    this.trusted=publicAnchors(node.local);
    this.trustedAgentKeys=actorKeys(node.local);
    this.receiptSignerPublicKeySpki=node.local.directory['community-execution'].agentKeySpki;
  }
  async run(inputs,{onRequest}={}) {
    const policy=inputs?.policy, request=inputs?.request;
    if(policy?.schema!=='octolang.policy.v0.5'||policy.digest!==this.config.scoreDigest||!policy.federation)
      return {status:'DENY',reason:'Unprovisioned reviewed federation score',contributions:[]};
    const fixed={...inputs,trusted:this.trusted,usedNonces:new Set()};
    const checked=assess(fixed);
    if(checked.decision.status!=='ALLOW')return {status:checked.decision.status,reason:checked.decision.reason,contributions:[]};
    try{this.durable.reserveRun(request);}catch(e){return {status:'DENY',reason:e.message,contributions:[]};}
    const contributions=[],wire=[];
    try {
      for(const [index,step] of policy.ensemble.steps.entries()) {
        const community=policy.federation.members[index]?.community;
        const member=this.config.directory[community];
        if(!member||member.agent!==step.agent||member.capability!==step.capability)fail('Unrecognised peer assignment');
        const credential=verifyCredential({credential:this.config.credentials[community],
          authorityKey:publicKey(this.config.credentialAuthoritySpki),
          revokedIds:loadRevocations(this.dir),expected:member});
        const role=policy.agents.find(a=>a.name===step.agent);
        if(!role || BigInt(role.limitLovelace)>BigInt(credential.maxLovelace)||role.delegate!==false)
          fail('Action exceeds independently credentialled role');
        const payload={schema:'octolang.network-step.v0.6',community,stepId:step.id,stepIndex:index,
          agent:step.agent,capability:step.capability,scoreDigest:policy.digest,requestDigest:digest(request),
          contextRoot:checked.snapshot.root,actionNonce:request.nonce,
          priorDigest:contributions.length?digest(contributions.at(-1)):null,
          inputs:{policy,request,claims:inputs.claims,approvals:inputs.approvals,review:inputs.review},contributions};
        const outgoing=await send(this.endpoint,community,'octolang.step.request.v0.6',payload);
        if(onRequest)await onRequest(outgoing,index);
        const response=await exchange(this.config,this.dir,community,'POST','/ofp',{envelope:outgoing});
        const obj=response.value;
        if(response.status!==200)fail(`Peer ${community} rejected request: ${obj?.reason || 'DENY'}`);
        const incoming=obj?.envelope;
        if(incoming?.senderCommunityId!==community)fail('OFP result sender mismatched expected credential');
        const reply=await receive(this.endpoint,incoming,this.durable,'octolang.step.result.v0.6');
        if(reply?.schema!=='octolang.network-result.v0.6'||reply.community!==community||
          reply.credentialId!==credential.id||reply.scoreDigest!==policy.digest||reply.stepId!==step.id||
          reply.responseTo!==digest(outgoing)||reply.contributionDigest!==digest(reply.contribution))
          fail('Response not bound to exact request and pinned credential');
        const candidate=[...contributions,reply.contribution];
        verifyPartialTranscript({inputs:fixed,contributions:candidate,trustedAgentKeys:this.trustedAgentKeys,
          receiptSignerPublicKeySpki:this.receiptSignerPublicKeySpki});
        contributions.push(reply.contribution);
        wire.push({sender:outgoing.senderCommunityId,recipient:outgoing.recipientCommunityId,
          requestId:outgoing.id,responseId:incoming.id,requestDigest:digest(outgoing),responseDigest:digest(incoming)});
      }
      const verified=verifyTranscript({inputs:fixed,contributions,trustedAgentKeys:this.trustedAgentKeys,
        receiptSignerPublicKeySpki:this.receiptSignerPublicKeySpki});
      return {status:'COMPLETED_NETWORK_LOOPBACK_DEMO',verified,contributions,wire,
        note:'Signed OFP over independent loopback HTTP peer processes. Demo governance and claims. Buyer only records local INTENT; no real payment.'};
    } catch(e) {return {status:'FAILED_CLOSED',reason:e.message,contributions,wire,
      note:'Crash-sticky replay claims remain consumed; any earlier buyer journal effect needs manual reconciliation.'};}
  }
}
module.exports={NetworkCoordinator};
