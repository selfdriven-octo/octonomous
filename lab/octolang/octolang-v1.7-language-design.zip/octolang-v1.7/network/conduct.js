'use strict';
// Drive provisioned, already running local OFP peers. No attempt to start or trust endpoints dynamically.
const path=require('node:path');
const {fixture}=require('./fixture');
const {NetworkCoordinator}=require('./coordinator');
async function conduct(root) {
  const inputs=fixture(root),outcome=await new NetworkCoordinator({root}).run(inputs);
  console.log(JSON.stringify({status:outcome.status,reason:outcome.reason,
    wireMessages:outcome.wire?.length*2,verified:outcome.verified,
    buyerJournal:path.join(path.resolve(root),'community-execution','state','effects','local-intents.jsonl'),
    note:'Review, registry claim and steward approval are explicit DEMO fixtures. Buyer writes a local INTENT only.'},null,2));
  if(outcome.status!=='COMPLETED_NETWORK_LOOPBACK_DEMO')process.exitCode=1;
  return outcome;
}
if(require.main===module)conduct(process.argv[2]||'.octolang-network').catch(e=>{console.error(e);process.exitCode=1});
module.exports={conduct};
