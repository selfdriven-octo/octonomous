'use strict';
// Demo-only operator provisioning. Keys are never accepted from a network request.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {execFileSync}=require('node:child_process');
const { signed, verifiedSigned, digest } = require('../src/canonical');
const { compile } = require('../src/compiler');
const SCORE = path.join(__dirname,'../examples/community-federation.octo');
const COORDINATOR = 'community-coordinator';
const MEMBERS = [
  {id:'community-research',agent:'scout',capability:'research',maxLovelace:'0'},
  {id:'community-execution',agent:'buyer',capability:'purchase',maxLovelace:'100000000'},
  {id:'community-audit',agent:'checker',capability:'audit',maxLovelace:'0'}
];
const spki = key => key.export({type:'spki',format:'der'}).toString('base64');
function publicKey(base64) {
  if(typeof base64 !== 'string' || base64.length > 200) throw new Error('Invalid pinned key');
  const key=crypto.createPublicKey({key:Buffer.from(base64,'base64'),format:'der',type:'spki'});
  if(key.asymmetricKeyType !== 'ed25519' || spki(key) !== base64) throw new Error('Expected canonical Ed25519 SPKI key');
  return key;
}
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600}); }
function makeKey(directory, name) {
  const k=crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(path.join(directory,name+'.pem'),k.privateKey.export({type:'pkcs8',format:'pem'}),{flag:'wx',mode:0o600});
  return spki(k.publicKey);
}
function privateKey(dir,name) {
  const p=path.join(dir,name+'.pem');
  if((fs.statSync(p).mode & 0o077) !== 0) throw new Error(`Identity key permissions too broad: ${p}`);
  return crypto.createPrivateKey(fs.readFileSync(p));
}
function readJson(file) {return JSON.parse(fs.readFileSync(file,'utf8'));}
function verifyCredential({ credential, authorityKey, revokedIds, expected, now=Date.now() }) {
  const p=credential?.payload;
  if (!p || p.schema!=='octolang.demo-community-credential.v0.6' ||
      !verifiedSigned(credential,authorityKey) ||
      typeof p.id!=='string' || (revokedIds||[]).includes(p.id) ||
      Date.parse(p.notBefore)>now || Date.parse(p.expiresAt)<=now ||
      !Number.isFinite(Date.parse(p.notBefore)) || !Number.isFinite(Date.parse(p.expiresAt)) ||
      Date.parse(p.expiresAt)-Date.parse(p.notBefore)>31*86400000 ||
      !p.id.startsWith('cred:') || !expected ||
      p.issuer!=='demo-governance-root' || p.community!==expected.id || p.agent!==expected.agent || p.capability!==expected.capability ||
      p.maxLovelace!==expected.maxLovelace || p.communityKeySpki!==expected.communityKeySpki ||
      p.agentKeySpki!==expected.agentKeySpki) throw new Error('Credential invalid, revoked, untrusted or outside scope');
  return p;
}
function verifyGrant({grant,governanceKey,credential,scoreDigest,now=Date.now()}) {
  const p=grant?.payload;
  if(!p || p.schema!=='octolang.local-governance-grant.v0.6' ||
    !verifiedSigned(grant,governanceKey) || !credential ||
    p.community!==credential.community || p.agent!==credential.agent ||
    p.capability!==credential.capability || p.maxLovelace!==credential.maxLovelace ||
    p.credentialId!==credential.id || p.scoreDigest!==scoreDigest || p.delegate!==false ||
    Date.parse(p.notBefore)>now || Date.parse(p.expiresAt)<=now ||
    !Number.isFinite(Date.parse(p.expiresAt))) throw new Error('Peer-local governance grant denied');
  return p;
}
function loadPeer(root,id) {
  if(!MEMBERS.some(m=>m.id===id)) throw new Error('Unknown independently operated peer');
  const dir=path.resolve(root,id), local=readJson(path.join(dir,'local.json'));
  if(local.id!==id || local.role!=='peer') throw new Error('Peer provisioning mismatch');
  const identity=privateKey(dir,'community'); const agent=privateKey(dir,'agent');
  if(spki(crypto.createPublicKey(identity))!==local.directory[id].communityKeySpki ||
     spki(crypto.createPublicKey(agent))!==local.directory[id].agentKeySpki) throw new Error('Private key does not match pinned public identity');
  return {dir,local,identity,agent};
}
function loadCoordinator(root) {
  const dir=path.resolve(root,COORDINATOR),local=readJson(path.join(dir,'local.json'));
  const identity=privateKey(dir,'community');
  if(spki(crypto.createPublicKey(identity))!==local.directory[COORDINATOR].communityKeySpki) throw new Error('Coordinator identity mismatch');
  return {dir,local,identity};
}
function loadRevocations(dir) {
  const r=readJson(path.join(dir,'revoked.json'));
  if(!Array.isArray(r.revokedCredentialIds)||r.revokedCredentialIds.some(x=>typeof x!=='string')) throw new Error('Invalid local revocation registry');
  return r.revokedCredentialIds;
}
function ensureLoopback(urlString) {
  const url=new URL(urlString);
  if(!['http:','https:'].includes(url.protocol) || !['127.0.0.1','localhost','[::1]'].includes(url.hostname) ||
    !/^(\/ofp|\/health)$/.test(url.pathname) || url.username || url.password || url.search || url.hash)
    throw new Error('v0.6 demo transport is loopback-only HTTP; non-local deployment needs TLS/mTLS adapter');
  return url;
}
function createTlsFixture(root) {
  // Operator-generated short-lived development PKI, never for production or non-loopback use.
  const gov=path.join(root,'governance');
  const call=(...args)=>execFileSync('openssl',args,{stdio:'pipe'});
  call('req','-x509','-nodes','-newkey','rsa:2048','-sha256','-days','7',
    '-subj','/CN=OctoLang-Demo-CA','-keyout',path.join(gov,'demo-ca-key.pem'),'-out',path.join(gov,'demo-ca.pem'));
  fs.chmodSync(path.join(gov,'demo-ca-key.pem'),0o600);
  for(const id of [COORDINATOR,...MEMBERS.map(m=>m.id)]) {
    const dir=path.join(root,id),key=path.join(dir,'tls-key.pem'),cert=path.join(dir,'tls-cert.pem');
    const csr=path.join(dir,'tls.csr'),ext=path.join(dir,'tls.ext');
    call('req','-new','-nodes','-newkey','rsa:2048','-subj',`/CN=${id}`,'-keyout',key,'-out',csr);
    fs.writeFileSync(ext,'subjectAltName=DNS:localhost,IP:127.0.0.1\nextendedKeyUsage=serverAuth,clientAuth\n',{mode:0o600});
    call('x509','-req','-in',csr,'-CA',path.join(gov,'demo-ca.pem'),'-CAkey',path.join(gov,'demo-ca-key.pem'),
      '-CAcreateserial','-out',cert,'-days','7','-sha256','-extfile',ext);
    fs.chmodSync(key,0o600);fs.rmSync(csr);fs.rmSync(ext);
  }
  return path.join(gov,'demo-ca.pem');
}
function provision(root,{ports=[9811,9812,9813],tls=false}={}) {
  root=path.resolve(root);
  if(fs.existsSync(root)) throw new Error(`Provisioning directory exists; refusing to overwrite identities: ${root}`);
  if(ports.length!==3 || ports.some(p=>!Number.isInteger(p)||p<1024||p>65535) || new Set(ports).size!==3)
    throw new Error('Three distinct non-privileged ports required');
  fs.mkdirSync(root,{recursive:true,mode:0o700});
  const main=path.join(root,COORDINATOR);fs.mkdirSync(main,{mode:0o700});
  const gov=path.join(root,'governance');fs.mkdirSync(gov,{mode:0o700});
  const score=compile(fs.readFileSync(SCORE,'utf8'));
  const authority=makeKey(gov,'credential-authority');
  const reviewer=makeKey(main,'reviewer'); const issuer=makeKey(main,'issuer'); const approver=makeKey(main,'approver');
  const cKey=makeKey(main,'community');
  const directory={ [COORDINATOR]:{id:COORDINATOR,communityKeySpki:cKey} };
  const urls={};
  for(let i=0;i<MEMBERS.length;i++) {
    const m=MEMBERS[i],dir=path.join(root,m.id);fs.mkdirSync(dir,{mode:0o700});
    const communityKeySpki=makeKey(dir,'community'),agentKeySpki=makeKey(dir,'agent');
    const governanceKeySpki=makeKey(dir,'governance');
    directory[m.id]={...m,communityKeySpki,agentKeySpki,governanceKeySpki};
    urls[m.id]=`${tls?'https':'http'}://127.0.0.1:${ports[i]}`;
  }
  if(tls)createTlsFixture(root);
  const now=Date.now(), notBefore=new Date(now-60000).toISOString(), expiresAt=new Date(now+7*86400000).toISOString();
  const authorityKey=privateKey(gov,'credential-authority');
  const credentials={};
  for(const m of MEMBERS) {
    const d=directory[m.id];
    credentials[m.id]=signed({schema:'octolang.demo-community-credential.v0.6', id:'cred:'+crypto.randomUUID(),
      issuer:'demo-governance-root',community:m.id,agent:m.agent,capability:m.capability,maxLovelace:m.maxLovelace,
      communityKeySpki:d.communityKeySpki,agentKeySpki:d.agentKeySpki,notBefore,expiresAt},authorityKey);
  }
  for(const m of MEMBERS) {
    const dir=path.join(root,m.id);const govkey=privateKey(dir,'governance');
    const grant=signed({schema:'octolang.local-governance-grant.v0.6',community:m.id,agent:m.agent,
      capability:m.capability,maxLovelace:m.maxLovelace,credentialId:credentials[m.id].payload.id,
      scoreDigest:score.digest,delegate:false,notBefore,expiresAt},govkey);
    writeJson(path.join(dir,'local.json'),{role:'peer',id:m.id,url:urls[m.id],directory,urls,
      credentialAuthoritySpki:authority,credentials,grant,scoreDigest:score.digest,
      tls:!!tls,trusted:{reviewers:{'community-owner':reviewer},issuers:{'community-registry':issuer},approvers:{'project-steward':approver}}});
    writeJson(path.join(dir,'revoked.json'),{revokedCredentialIds:[]});
  }
  writeJson(path.join(main,'local.json'),{role:'coordinator',id:COORDINATOR,directory,urls,
    credentialAuthoritySpki:authority,credentials,scoreDigest:score.digest,
    tls:!!tls,trusted:{reviewers:{'community-owner':reviewer},issuers:{'community-registry':issuer},approvers:{'project-steward':approver}}});
  writeJson(path.join(main,'revoked.json'),{revokedCredentialIds:[]});
  writeJson(path.join(root,'manifest.json'),{schema:'octolang.network-manifest.v0.6',scoreDigest:score.digest,urls,
    communities:Object.keys(directory),governance:'DEMO_OPERATOR_PROVISIONED',network:tls?'LOOPBACK_MTLS_WITH_SIGNED_OFP':'LOOPBACK_HTTP_WITH_SIGNED_OFP'});
  return {root,scoreDigest:score.digest,urls};
}
module.exports={MEMBERS,COORDINATOR,spki,publicKey,privateKey,readJson,writeJson,loadPeer,loadCoordinator,
  loadRevocations,verifyCredential,verifyGrant,ensureLoopback,provision};
if(require.main===module){
  try{console.log(JSON.stringify(provision(process.argv[2]||'.octolang-network',{tls:process.argv.includes('--mtls')}),null,2));}
  catch(e){console.error(e.message);process.exitCode=1;}
}
