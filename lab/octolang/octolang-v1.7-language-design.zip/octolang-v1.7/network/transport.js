'use strict';
const fs=require('node:fs');
const path=require('node:path');
const https=require('node:https');
const tls=require('node:tls');
const {ensureLoopback,COORDINATOR}=require('./identity');
async function exchange(config,identityDir,community,method,route,body=null) {
  const url=config.remote?new URL(config.urls[community]+route):ensureLoopback(config.urls[community]+route);
  if(config.remote&&(url.protocol!=='https:'||url.username||url.password||url.hash||url.search||
    !['/ofp','/health','/agent'].includes(url.pathname)))throw Error('Remote OFP requires pinned HTTPS peer URL');
  if((url.protocol==='https:')!==config.tls)throw new Error('Transport protocol not pinned to provisioning mode');
  if(url.protocol==='http:') {
    const response=await fetch(url,{method,headers:body?{'content-type':'application/json'}:{},
      body:body?JSON.stringify(body):undefined,redirect:'error',signal:AbortSignal.timeout(7000)});
    const raw=await response.text();if(raw.length>180000)throw new Error('Oversized response');
    let value;try{value=JSON.parse(raw)}catch{throw new Error('Malformed peer response')}
    return {status:response.status,value};
  }
  return new Promise((resolve,reject)=>{
    const payload=body?JSON.stringify(body):null;
    const req=https.request(url,{method,rejectUnauthorized:true,
      ca:config.remote?config.directory[community].tlsCertPem:fs.readFileSync(path.join(identityDir,'../governance/demo-ca.pem')),
      cert:fs.readFileSync(path.join(identityDir,'tls-cert.pem')),
      key:fs.readFileSync(path.join(identityDir,'tls-key.pem')),
      checkServerIdentity:(hostname,cert)=>{
        const error=tls.checkServerIdentity(hostname,cert);if(error)return error;
        if(cert.subject?.CN!==community)return new Error('Peer TLS identity does not match pinned community');
        if(config.remote){
          const actual=require('node:crypto').createHash('sha256').update(cert.raw).digest('hex');
          const expected=require('node:crypto').createHash('sha256').update(new (require('node:crypto').X509Certificate)(config.directory[community].tlsCertPem).raw).digest('hex');
          if(actual!==expected)return new Error('Peer TLS certificate fingerprint mismatch');
        }
      },
      timeout:6500,headers:payload?{'content-type':'application/json','content-length':Buffer.byteLength(payload)}:{}},res=>{
      let data='',size=0;
      res.on('data',chunk=>{size+=chunk.length;if(size>180000){req.destroy(new Error('Oversized response'));return;}data+=chunk;});
      res.on('end',()=>{try{resolve({status:res.statusCode,value:JSON.parse(data)});}catch(e){reject(new Error('Malformed TLS peer response'));}});
    });
    req.on('timeout',()=>req.destroy(new Error('TLS request timeout')));
    req.on('error',reject);
    req.end(payload||undefined);
  });
}
module.exports={exchange};
