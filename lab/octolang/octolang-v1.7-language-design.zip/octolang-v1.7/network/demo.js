'use strict';
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {spawn}=require('node:child_process');
const {provision,MEMBERS}=require('./identity');
const {fixture}=require('./fixture');
const {NetworkCoordinator}=require('./coordinator');
const {exchange}=require('./transport');
const {loadCoordinator}=require('./identity');
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function waitForPeers(root,urls,children) {
  const config=loadCoordinator(root);
  for(let retry=0;retry<100;retry++) {
    if(children.some(ch=>ch.exitCode!==null))throw new Error('Network peer process terminated');
    const ready=await Promise.all(Object.keys(urls).map(async community=>{
      try {return (await exchange(config.local,config.dir,community,'GET','/health')).status===200;} catch{return false;}
    }));
    if(ready.every(Boolean))return;
    await wait(50);
  }
  throw new Error('Network peers did not come online');
}
async function spawnPeers(root) {
  const config=require('./identity').readJson(path.join(root,'manifest.json'));
  const children=MEMBERS.map(m=>spawn(process.execPath,[path.join(__dirname,'peer.js'),root,m.id],{
    stdio:['ignore','pipe','pipe'],env:{...process.env}}));
  try {await waitForPeers(root,config.urls,children);return {children,config};}
  catch(e) {for(const ch of children)ch.kill();throw e;}
}
async function stopPeers(children){
  for(const ch of children) if(ch.exitCode===null)ch.kill('SIGTERM');
  await Promise.all(children.map(ch=>new Promise(resolve=>ch.exitCode!==null?resolve():ch.once('exit',resolve))));
}
async function demo() {
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-network-v06-'));
  fs.rmSync(root,{recursive:true,force:true}); // provision deliberately refuses to overwrite a directory
  const {urls}=provision(root,{tls:process.env.OCTOLANG_DEMO_TLS==='1'});
  let running;
  try{
    running=await spawnPeers(root);
    const inputs=fixture(root),first=await new NetworkCoordinator({root}).run(inputs);
    if(first.status!=='COMPLETED_NETWORK_LOOPBACK_DEMO')throw new Error(first.reason||first.status);
    const repeat=await new NetworkCoordinator({root}).run(inputs);
    if(repeat.status!=='DENY')throw new Error('Replay accepted after coordinator restart');
    const journal=path.join(root,'community-execution','state','effects','local-intents.jsonl');
    console.log(JSON.stringify({status:first.status,actualPeerProcesses:running.children.map(x=>x.pid),
      urls,networkSignedMessages:first.wire.length*2,scoreDigest:inputs.policy.digest,
      chainHead:first.verified.chainHead,duplicateAfterNewCoordinator:repeat.status,
      journal,notice:'Experimental loopback-only network; separate Node.js OS processes. No purchases/payments.',transport:process.env.OCTOLANG_DEMO_TLS==='1'?'mTLS + signed OFP':'HTTP loopback + signed OFP'},null,2));
    return {root,first,repeat};
  } finally {if(running)await stopPeers(running.children);}
}
if(require.main===module)demo().catch(e=>{console.error(e);process.exitCode=1});
module.exports={demo,spawnPeers,stopPeers};
