'use strict';
const $ = id => document.getElementById(id);
let current = null;
let actionId = null;
let reviewerKey = null;
const utf8 = new TextEncoder();
const bytesToB64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes)));
const canonical = x => {
  if (x === null || ['string', 'boolean', 'number'].includes(typeof x)) return JSON.stringify(x);
  if (Array.isArray(x)) return `[${x.map(canonical).join(',')}]`;
  if (x && typeof x === 'object') return `{${Object.keys(x).sort().map(k => `${JSON.stringify(k)}:${canonical(x[k])}`).join(',')}}`;
  throw new Error('Unserialisable signed data');
};
async function post(route, body) {
  const response = await fetch('/api/' + route, { method:'POST', headers: { 'content-type':'application/json', 'x-octolang-local':'studio' }, body: JSON.stringify(body) });
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || `HTTP ${response.status}`);
  return value;
}
function notify(message, error = false) { $('notice').textContent = message; $('notice').classList.toggle('error', error); }
function showDraft(draft) {
  current = draft;
  actionId = null;
  $('source').value = draft.source;
  $('draftStatus').textContent = draft.approved ? 'Reviewed and signed' : 'Compiled · awaiting human review';
  $('reviewStatus').textContent = draft.approved ? 'Signed policy' : 'Awaiting review';
  const p = draft.policy;
  const ada = x => (Number(x) / 1e6).toString() + ' ADA';
  $('summary').textContent = [
    `Intent: ${p.intent}`,
    `Action / agent: ${p.action} / ${p.agents.map(a => a.name).join(', ')}`,
    `Spending limit: ${p.agents.map(a => ada(a.limitLovelace)).join(', ')}`,
    `Human escalation: > ${ada(p.approval.aboveLovelace)} by ${p.approval.signer}`,
    `Evidence: signed ${p.contexts.map(c => c.claim + ' from ' + c.issuer).join(', ')}`,
    `Context maximum age: ${p.contexts.map(c => (c.maxAgeMs / 86400000) + ' days').join(', ')}`,
    `Before action: require ${p.requiredContext}; after: ${p.expectedReceipt} receipt`,
    'Delegation: disabled | On violation: DENY',
    `SHA-256 policy digest: ${p.digest}`,
    `Origin: ${draft.origin} | Approval: ${draft.approved ? 'SIGNED' : 'NOT SIGNED'}`,
    '',
    'IMPORTANT: the demo claim issuer and approver are temporary MOCK signers.'
  ].join('\n');
  if (p.ensemble) {
    $('summary').textContent += '\n\nMulti-agent score: '+p.ensemble.name + '\n'+p.ensemble.steps.map(s=>`  ${s.id}: ${s.agent} / ${s.capability} → ${s.evidence} (after ${s.depends})`).join('\n');
  }
  if (p.federation) $('summary').textContent += '\n\nFederation (human-reviewed):\n' + p.federation.members.map(m=>`  ${m.agent} → ${m.community}`).join('\n');
  $('decision').textContent = 'No action prepared for this score.';
  $('ensembleResult').textContent = 'Awaiting an approved multi-agent score.';
}
function requireCurrent() {
  if (!current) throw new Error('Generate or compile a score first.');
  if ($('source').value !== current.source) throw new Error('You edited the source. Validate & compile edits before continuing.');
}
function openDb() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open('octolang-review-v0.2', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('keys');
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function loadKey() {
  try {
    const db = await openDb();
    const v = await new Promise((resolve,reject) => {
      const tx = db.transaction('keys', 'readonly');
      const q = tx.objectStore('keys').get('local-reviewer');
      q.onsuccess = () => resolve(q.result || null); q.onerror = () => reject(q.error);
    });
    db.close(); return v;
  } catch { return null; }
}
async function storeKey(value) {
  try {
    const db = await openDb();
    await new Promise((resolve,reject) => {
      const tx = db.transaction('keys','readwrite');
      tx.objectStore('keys').put(value, 'local-reviewer');
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch { notify('Browser key storage unavailable; private key works only until page reload.'); }
}
async function getOrCreateKey() {
  if (reviewerKey) return reviewerKey;
  reviewerKey = await loadKey();
  if (reviewerKey) return reviewerKey;
  const pair = await crypto.subtle.generateKey({ name:'Ed25519' }, false, ['sign', 'verify']);
  reviewerKey = { privateKey: pair.privateKey, spki: bytesToB64(await crypto.subtle.exportKey('spki', pair.publicKey)) };
  await storeKey(reviewerKey);
  return reviewerKey;
}
async function signedReview(policyDigest) {
  const key = await getOrCreateKey();
  const payload = { schema:'octolang.review.v1', reviewer:'local-reviewer', scoreDigest:policyDigest,
    issuedAt:new Date(Date.now()-1000).toISOString(), expiresAt:new Date(Date.now()+3600000).toISOString(), nonce:crypto.randomUUID() };
  const signature = await crypto.subtle.sign('Ed25519', key.privateKey, utf8.encode(canonical(payload)));
  return { payload, signature: bytesToB64(signature) };
}
function bind(id, fn) {
  $(id).addEventListener('click', () => Promise.resolve().then(fn).catch(e => notify(e.message, true)));
}
bind('compose', async () => {
  notify('Composing a new unapproved score…');
  const result = await post('compose', { intent:$('intent').value, mode:$('mode').value });
  showDraft(result); notify('Draft compiled. Read its scope, evidence requirements and limits before signing.');
});
bind('compile', async () => {
  const result = await post('compile', { source:$('source').value });
  showDraft(result); notify('Validated and compiled. Any change to the source requires a fresh signature.');
});
bind('enroll', async () => {
  const key = await getOrCreateKey();
  const result = await post('enroll', { pairingCode:$('pairing').value.trim().toUpperCase(), publicKeySpki:key.spki });
  $('pairing').value = '';
  $('reviewStatus').textContent = 'Reviewer paired · ' + result.keyFingerprint;
  notify('Browser reviewer key is paired to this local server session.');
});
bind('review', async () => {
  requireCurrent();
  if (!confirm('Have you inspected the permissions, spending limit, issuer and approval threshold? Sign exactly this compiled digest?\n\n' + current.policy.digest)) return;
  const result = await post('review', { review:await signedReview(current.policy.digest) });
  current.approved = true;
  $('draftStatus').textContent = 'Reviewed and signed';
  $('reviewStatus').textContent = 'Signed through ' + result.expiresAt;
  notify('Signed review accepted. The runtime now checks this exact policy digest.');
});
bind('prepare', async () => {
  requireCurrent();
  const result = await post('prepare', { amount:$('amount').value.trim(), target:$('target').value.trim() });
  actionId = result.id;
  $('decision').textContent = JSON.stringify({ request:result.request, decision:result.decision, evidence:result.source }, null, 2);
  notify(result.decision.status === 'ESCALATE' ? 'A separate mock steward approval is required.' : 'Pre-execution check complete: ' + result.decision.status);
});
bind('steward', async () => {
  requireCurrent(); if (!actionId) throw new Error('Prepare an action first.');
  if (!confirm('Generate a DEMO-only signed approval from the local mock steward?')) return;
  const result = await post('steward-approve', { id:actionId });
  $('decision').textContent = JSON.stringify(result, null, 2);
  notify('The temporary demo steward signed this exact request digest.');
});
bind('recordLocal', async () => {
  requireCurrent(); if (!actionId) throw new Error('Prepare an action first.');
  if (!confirm('Write an approved INTENT to a local JSONL journal using Octonomous Runtime? No purchase/payment occurs.')) return;
  const result = await post('record-local', { id:actionId });
  $('decision').textContent = JSON.stringify(result, null, 2);
  notify(result.status === 'RECORDED_LOCAL_INTENT' ? 'Octonomous Runtime recorded a local intent; NO funds moved.' : `No record: ${result.decision?.status || result.status} (${result.error || result.decision?.reason || 'unknown'}).`);
});
bind('runEnsemble', async () => {
  requireCurrent(); if (!actionId) throw new Error('Prepare an action first.');
  if (!current.policy.ensemble) throw new Error('Compile an ensemble score to enable conducting.');
  if (!confirm('Conduct demo scout → buyer → checker? Buyer writes only a local purchase INTENT, with no payment. All agent identities are mock local signers.')) return;
  const result = await post('ensemble-run', { id:actionId });
  $('ensembleResult').textContent = JSON.stringify(result, null, 2);
  notify(result.status === 'COMPLETED_LOCAL_DEMO' ? 'Multi-agent score verified and local intent recorded. NO payment.' : `Score stopped: ${result.status}: ${result.reason || 'policy rejected'}`);
});
bind('runFederation', async () => {
  requireCurrent(); if (!actionId) throw new Error('Prepare an action first.');
  if (current.policy.schema !== 'octolang.policy.v0.5') throw new Error('Compile a v0.5 federation score first.');
  if (!confirm('Exchange signed OFP messages between three simulated communities, with persistent replay reservations? Only a local purchase INTENT is written; NO payment or external networking.')) return;
  const result=await post('federation-run',{id:actionId});
  $('ensembleResult').textContent=JSON.stringify(result,null,2);
  notify(result.status==='COMPLETED_FEDERATED_LOCAL_DEMO'
    ? 'Federated protocol demo verified. Only local purchase intent recorded; NO payment.'
    : `Federation stopped: ${result.status}: ${result.reason || 'policy rejected'}`);
});
bind('simulate', async () => {
  requireCurrent(); if (!actionId) throw new Error('Prepare an action first.');
  const result = await post('simulate', { id:actionId });
  $('decision').textContent = JSON.stringify(result, null, 2);
  notify(result.decision.status === 'ALLOW' ? 'Simulated only. Signed mock receipt returned; no real-world action.' : `No action: ${result.decision.status}.`);
});
async function init() {
  const status = await fetch('/api/status').then(r => r.json());
  if (status.draft) showDraft({ ...status.draft, approved:status.approved });
  $('mode').querySelector('option[value="openai"]').disabled = !status.openAIAvailable;
  $('mode').querySelector('option[value="openai-ensemble"]').disabled = !status.openAIAvailable;
  $('mode').querySelector('option[value="openai-federation"]').disabled = !status.openAIAvailable;
  if (!status.openAIAvailable) $('mode').title = 'Set OPENAI_API_KEY on the server for optional AI composing';
  if (status.enrolled) $('reviewStatus').textContent = 'Local reviewer paired; approval ' + (status.approved ? 'active' : 'pending');
  await loadKey().then(k => { reviewerKey = k; });
}
init().catch(e => notify(e.message, true));

// v0.8 read-only distributed monitoring; no browser-to-network execution bridge.
bind('refreshDistributed', async () => {
  const response=await fetch('/api/distributed/status',{cache:'no-store'});
  const result=await response.json();
  if(!response.ok)throw Error(result.error||'Monitor not available');
  $('distributedResult').textContent=JSON.stringify(result,null,2);
  notify(result.configured?'Read-only federated status refreshed. No actions performed.':'Set OCTOLANG_DISTRIBUTED_HOME for coordinator monitoring.');
});

bind('verifyAgents', async () => {
  const response=await fetch('/api/distributed/discover',{cache:'no-store'});
  const result=await response.json();
  if(!response.ok)throw Error(result.error||'Discovery not available');
  $('discoveryResult').textContent=JSON.stringify(result,null,2);
  notify(result.configured?'Live identities, credentials and governance proofs checked independently. Discovery grants NO rights.':'Set OCTOLANG_DISTRIBUTED_HOME and start the independent peer processes.');
});


// v0.9 mission workflows are deliberately isolated from legacy purchase execution.
let missionDraft = null;
function showMission(d) {
  missionDraft=d;
  $('missionSource').value=d.source;
  const m=d.mission;
  $('missionSummary').textContent=[`Goal: ${m.goal}`,`Mission digest: ${m.digest}`,`Typed inputs: ${m.inputs.map(x=>x.label+':'+x.type).join(', ')}`,
    `Roles: ${m.roles.map(x=>x.label+' needs '+x.capability).join(', ')}`,
    ...(m.capabilities?.length?[`Signed service contracts: ${m.capabilities.map(c=>c.role+' → '+c.name+' @ '+c.service+' (disclose '+c.fields.map(f=>f.name+':'+f.type).join(', ')+')').join('; ')}`]:[]),
    ...(m.proofs?.length?[`Required verified proof types: ${m.proofs.map(p=>p.task+' → '+p.kind+(p.service?' @ '+p.service:'')).join('; ')}`]:[]),
    `Constraints: ${m.constraints.map(x=>x.label+':'+x.type+(x.type==='max'?' <= '+x.max+' '+x.unit:' signed '+x.context)).join(', ')}`,
    `Verified context: ${m.contexts.map(x=>x.claim+' from '+x.issuer).join(', ')}`,
    `Task order: ${m.order.join(' → ')}`,
    `Outcomes: ${m.outcomes.map(x=>x.label+' <- '+x.task).join(', ')}`,
    'Approval: NOT SIGNED · typed external services require separately provisioned CLI authority; no browser execution'].join('\n');
  $('missionResult').textContent='Compile, inspect and sign before verifying a mock outcome.';
}
function currentMission() {
  if(!missionDraft)throw Error('Compile a mission first.');
  if($('missionSource').value!==missionDraft.source)throw Error('Source changed: compile and review again.');
  return missionDraft;
}
bind('missionCompose',async()=>{
  const r=await post('mission/compose',{goal:$('missionGoal').value,mode:$('missionMode').value});
  showMission(r);notify('Mission proposed. Inspect roles, constraints and outcomes before approval.');
});
bind('missionCompile',async()=>{
  const r=await post('mission/compile',{source:$('missionSource').value});
  showMission(r);notify('Mission compiled; previous approval (if any) invalidated.');
});
bind('missionReview',async()=>{
  const draft=currentMission();
  if(!confirm('Inspect the mission goal, agent roles, required issuer evidence, limits, task dependencies and outcomes. Sign this exact mission digest?\n'+draft.mission.digest))return;
  const r=await post('mission/review',{review:await signedReview(draft.mission.digest)});
  $('missionSummary').textContent+='\nApproved by local reviewer through '+r.expiresAt;
  notify('Exact mission digest approved for mock simulation only.');
});
bind('missionVerify',async()=>{
  currentMission();
  const r=await post('mission/verify-demo',{subject:$('missionSubject').value.trim(),inputs:{amount:$('missionAmount').value.trim(),priority:'3',project:$('missionGoal').value.slice(0,500)||'Demo',urgent:false}});
  $('missionResult').textContent=JSON.stringify(r,null,2);
  notify(r.verified?.status==='VERIFIED_SIMULATION'?'All signed simulated outcomes verify; NO tools executed.':`Mission denied: ${r.decision?.reason||'evidence check failed'}`);
});
// OpenAI composition is opt-in and configured separately on the server.
fetch('/api/status').then(r=>r.json()).then(s=>{for(const mode of ['openai','openai-typed'])$('missionMode').querySelector(`option[value="${mode}"]`).disabled=!s.openAIAvailable;}).catch(()=>{});

// v1.0: an explicit local-only, four-tool allowlisted Octonomous execution path.
bind('missionExecute',async()=>{
  currentMission();
  if(!confirm('Execute the human-reviewed mission through four bounded local Octonomous tools? The buyer will write ONE local intent journal record. Synthetic claims and grants; NO payment, network calls or purchase.'))return;
  const r=await post('mission/execute-local',{subject:$('missionSubject').value.trim(),inputs:{amount:$('missionAmount').value.trim(),priority:'3',project:$('missionGoal').value.slice(0,500)||'Demo',urgent:false}});
  $('missionResult').textContent=JSON.stringify(r,null,2);
  notify(r.status==='COMPLETED_LOCAL_MISSION'?'The local intent was recorded through Octonomous Runtime. Verify signed tool receipts; no payment.':`Mission was not completed: ${r.status} (${r.reason||'denied'})`);
});
