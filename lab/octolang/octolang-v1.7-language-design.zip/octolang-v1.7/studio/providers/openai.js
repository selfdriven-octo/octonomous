'use strict';
const { SYSTEM_INSTRUCTIONS } = require('../../src/authoring');
// Optional: requires explicit user choice and an OPENAI_API_KEY on the server.
function makeOpenAIAdapter({ apiKey = process.env.OPENAI_API_KEY,
  model = process.env.OCTOLANG_OPENAI_MODEL || 'gpt-5-mini', fetchFn = global.fetch } = {}) {
  if (!apiKey) return null;
  return async ({ user, system }) => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    try {
      const response = await fetchFn('https://api.openai.com/v1/responses', {
        method: 'POST', signal: controller.signal,
        headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
        body: JSON.stringify({ model, instructions: (system || SYSTEM_INSTRUCTIONS) + '\nOutput raw .octo text only; do not add Markdown fences.', input: user, max_output_tokens: 1800 })
      });
      if (!response.ok) throw new Error(`AI provider request failed (HTTP ${response.status})`);
      const payload = await response.json();
      const result = payload.output_text || (payload.output || []).flatMap(x => x.content || []).filter(x => x.type === 'output_text').map(x => x.text).join('');
      if (typeof result !== 'string' || result.length === 0) throw new Error('AI provider returned no score text');
      return result.trim();
    } finally { clearTimeout(timeout); }
  };
}
module.exports = { makeOpenAIAdapter };
