'use strict';
const {compile}=require('../src/compiler');
const {verifyReview}=require('../src/runtime');
const {planMission,verifyMissionEvidence}=require('../src/mission');
const {template,fixtures}=require('../mission/demo');
const {MissionExecutionController}=require('../mission/executor');
const path=require('node:path');
const crypto=require('node:crypto');
const {MISSION_SYSTEM_INSTRUCTIONS}=require('../src/authoring');
function error(message,statusCode=400){throw Object.assign(new Error(message),{statusCode});}
class MissionStudio {
  constructor(studio){this.studio=studio;this.current=null;this.review=null;this.controllerKeys=crypto.generateKeyPairSync('ed25519');}
  setSource(source,origin='manual'){
    if(typeof source!=='string')error('Expected .octo source string');
    const mission=compile(source);
    if(!['octolang.mission.v0.9','octolang.mission.v1.2'].includes(mission.schema))error('Expected mission (not legacy score)');
    this.current={source,mission,origin};this.review=null;
    return {...this.current,approved:false};
  }
  async compose(goal,mode='offline',modelAdapter){
    if(typeof goal!=='string'||!goal.trim()||goal.length>500)error('Goal must contain 1–500 characters');
    if(mode==='offline')return this.setSource(template.replace('"Research suppliers, record an intent and audit the outcome"',JSON.stringify(goal.trim())),'offline-template');
    if(mode==='offline-typed')return this.setSource(require('../proofs/demo').typedSource.replace('"Research suppliers, record an intent and audit the outcome"',JSON.stringify(goal.trim())),'offline-typed-template');
    if(!['openai','openai-typed'].includes(mode))error('Unsupported mission composer mode');
    if(typeof modelAdapter!=='function')error('No AI provider configured',503);
    const system=mode==='openai-typed'?
      `Draft an UNAPPROVED OctoLang v1.2 typed mission. Return raw .octo source only. Use the following complete validated example as grammar. Keep independently pinned capability/service names, input field disclosures, all four roles and proof obligations unchanged; only adapt the human-readable goal. Model output grants NO authority.\n${require('../proofs/demo').typedSource}`:
      MISSION_SYSTEM_INSTRUCTIONS;
    const source=await modelAdapter({user:goal,system});
    return this.setSource(source,'ai-unapproved');
  }
  acceptReview(review){
    if(!this.current)error('Compile mission first');
    if(!verifyReview(this.current.mission,review,this.studio.trusted,Date.now())||review?.payload?.reviewer!=='local-reviewer')error('Pair reviewer and sign exact mission digest',403);
    this.review=review;return {approved:true,missionDigest:this.current.mission.digest,expiresAt:review.payload.expiresAt};
  }
  async executeDemo({subject='supplier-42',inputs={}}={}){
    if(!this.current||!verifyReview(this.current.mission,this.review,this.studio.trusted,Date.now()))
      error('Mission requires valid human-signed review',403);
    const mission=this.current.mission;
    if(mission.schema==='octolang.mission.v1.2')error('Typed capability missions must run from the independently provisioned CLI; browser Studio cannot grant external service permissions',403);
    const f=fixtures(mission,{subject,inputs});
    f.trust.reviewers=this.studio.trusted.reviewers;
    const engine=new MissionExecutionController({
      dataDir:path.join(this.studio.dataDir,'mission-execution-v1'),
      controllerKeyPair:this.controllerKeys,
      agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([k,v])=>[k,v.privateKey]))
    });
    const out=await engine.execute({mission,request:f.request,review:this.review,
      claims:f.claims,grants:f.grants,trust:f.trust});
    return {...out,syntheticEvidence:true,executionProfile:'LOCAL_BUILTINS_ONLY',
      controllerTrust:'demo locally generated key; public key must be independently pinned for third-party verification'};
  }
  demo({subject='supplier-42',inputs={}}={}){
    if(!this.current||!verifyReview(this.current.mission,this.review,this.studio.trusted,Date.now()))error('Mission requires valid human-signed review',403);
    const mission=this.current.mission;
    if(mission.schema==='octolang.mission.v1.2')error('Typed proof obligations require actual signed execution receipts, not synthetic simulation',403);
    // Demo fixtures are local synthetic signatures; they are NEVER accepted as real issuer grants.
    const f=fixtures(mission,{subject,inputs});
    f.trust.reviewers=this.studio.trusted.reviewers;
    const result=planMission({mission,request:f.request,review:this.review,claims:f.claims,grants:f.grants,trust:f.trust});
    if(result.status!=='READY_FOR_SIMULATION')return {decision:result,simulated:false};
    const receipts=f.simulate(result.plan);
    const verified=verifyMissionEvidence({mission,request:f.request,plan:result.plan,receipts,review:this.review,claims:f.claims,grants:f.grants,trust:f.trust});
    return {decision:result.status,plan:result.plan,verified,simulated:true,syntheticEvidence:true,
      externalToolsExecuted:false,noPayments:true};
  }
}
module.exports={MissionStudio};
