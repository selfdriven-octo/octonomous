'use strict';
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const {compile}=require('../src/compiler');
const {template,fixtures}=require('./demo');
const {MissionExecutionController}=require('./executor');
const {exportPins}=require('./bundle');
async function demo(){
  const mission=compile(template),f=fixtures(mission);
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-mission-v1-'));
  const controller=new MissionExecutionController({dataDir:root,
    agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([k,v])=>[k,v.privateKey]))});
  const result=await controller.execute({mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust});
  if(result.status!=='COMPLETED_LOCAL_MISSION')throw Error(result.reason||result.status);
  // Never place private signing keys into the transferable verification bundle.
  const evidenceFile=path.join(root,'mission-evidence-bundle.json');
  const pinsFile=path.join(root,'trusted-public-keys.json');
  fs.writeFileSync(evidenceFile,JSON.stringify({mission,request:f.request,review:f.review,
    claims:f.claims,grants:f.grants,plan:result.plan,receipts:result.receipts},null,2),{mode:0o600});
  fs.writeFileSync(pinsFile,JSON.stringify(exportPins(f.trust,controller.controllerKeys.publicKey),null,2),{mode:0o600});
  console.log(JSON.stringify({dataDir:root,evidenceFile,pinsFile,journalFile:path.join(root,'local-intents.jsonl'),mission:mission.name,status:result.status,
    tasks:result.receipts.map(r=>({task:r.agentReceipt.payload.task,tool:r.effectReceipt.payload.tool,outcome:r.result.outcome})),
    verification:result.verification,notes:'Synthetic credentials. Actual Octonomous Runtime tool calls; only local journal intent written, no payment.'},null,2));
}
if(require.main===module)demo().catch(e=>{console.error(e);process.exitCode=1;});
module.exports={demo};
