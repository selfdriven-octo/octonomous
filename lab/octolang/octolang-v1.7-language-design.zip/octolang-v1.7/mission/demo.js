'use strict';
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const {compile}=require('../src/compiler');const {signed,digest}=require('../src/canonical');
const {planMission,verifyMissionEvidence}=require('../src/mission');
const template=fs.readFileSync(path.join(__dirname,'../examples/community-mission.octo'),'utf8');
function fixtures(mission,{subject='supplier-42',inputs={amount:'75',priority:'3',project:'School learning project',urgent:false},now=Date.now(),reviewerKey}={}){
  const key=()=>crypto.generateKeyPairSync('ed25519');
  const reviewer=reviewerKey||key(),issuer=key(),grantIssuer=key();
  const agents=Object.fromEntries(mission.roles.map(r=>[r.label, key()]));
  const issue=(schema,other,signer,duration=240000)=>signed({schema,...other,issuedAt:new Date(now-1000).toISOString(),expiresAt:new Date(now+duration).toISOString(),nonce:crypto.randomUUID()},signer.privateKey);
  const trust={reviewers:{'local-reviewer':reviewer.publicKey},issuers:{'community-registry':issuer.publicKey},grantIssuers:{'demo-governance':grantIssuer.publicKey},agents:Object.fromEntries(Object.entries(agents).map(([id,k])=>[id,k.publicKey]))};
  const review=issue('octolang.review.v1',{reviewer:'local-reviewer',scoreDigest:mission.digest},reviewer,3600000);
  const request={schema:'octolang.mission-request.v0.9',missionDigest:mission.digest,subject,inputs,issuedAt:new Date(now-1000).toISOString(),expiresAt:new Date(now+240000).toISOString(),nonce:crypto.randomUUID()};
  const claims=mission.contexts.map(c=>issue('octolang.claim.v1',{issuer:c.issuer,claim:c.claim,subject,status:'VERIFIED'},issuer,240000));
  const grants=mission.roles.map(r=>issue('octolang.agent-grant.v0.9',{missionDigest:mission.digest,role:r.label,agent:r.label,capability:r.capability,issuer:'demo-governance'},grantIssuer,240000));
  function simulate(plan){
    const evidence={};
    const receipts=plan.steps.map(step=>{
      const deps=Object.fromEntries(step.dependencies.map(d=>[d,evidence[d]]));
      const rec=issue('octolang.mission-evidence.v0.9',{missionDigest:mission.digest,planDigest:plan.digest,requestDigest:plan.requestDigest,
        contextRoot:plan.contextRoot,task:step.label,role:step.role,agent:step.agent,evidence:step.produces,
        dependencies:deps,outcome:'SIMULATED'},agents[step.agent]);
      evidence[step.label]=digest(rec);return rec;
    });
    return receipts;
  }
  return {trust,review,request,claims,grants,agents,simulate};
}
function demo(){
  const mission=compile(template), f=fixtures(mission);
  const result=planMission({mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust});
  if(result.status!=='READY_FOR_SIMULATION')throw Error(result.reason);
  const receipts=f.simulate(result.plan);
  const verified=verifyMissionEvidence({mission,request:f.request,plan:result.plan,receipts,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust});
  if(verified.status!=='VERIFIED_SIMULATION')throw Error(verified.reason);
  console.log(JSON.stringify({mission:mission.name,missionDigest:mission.digest,selection:result.plan.assignments,
    taskOrder:result.plan.steps.map(s=>s.label),outcome:verified,noRealActions:true},null,2));
  return {mission,fixtures:f,result,receipts,verified};
}
if(require.main===module)try{demo();}catch(e){console.error(e.stack);process.exitCode=1;}
module.exports={template,fixtures,demo};
