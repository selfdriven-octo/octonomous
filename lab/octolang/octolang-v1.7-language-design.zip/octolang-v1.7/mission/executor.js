'use strict';
// OctoLang v1.0 bounded local mission execution pilot. AI never grants capability authority.
// Only four built-in tools are executable. No shell, network, wallet or payment capability.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const Octonomous = require('../vendor/octonomous-runtime');
const {digest, signed, verifiedSigned} = require('../src/canonical');
const {planMission} = require('../src/mission');
const {assertContracts,verifyTypedProofs} = require('../capabilities/contracts');

const TOOLS = Object.freeze({
  'research': 'mission.local.research',
  'validate': 'mission.local.validate',
  'intent.record': 'mission.local.record-intent',
  'audit': 'mission.local.audit'
});
const STATUS = 'VERIFIED_LOCAL_EXECUTION_RECEIPTS';
const STATUS_EXT = 'VERIFIED_CAPABILITY_EXECUTION_RECEIPTS';
const deny = reason => ({status:'DENY', reason, executed:false});
const iso = ms => new Date(ms).toISOString();

function publicKeyMatches(privateKey, publicKey) {
  try {
    const probe=Buffer.from('octolang.mission.signer-match.v1');
    return crypto.verify(null,probe,publicKey,crypto.sign(null,probe,privateKey));
  } catch { return false; }
}

// Independently rechecks signature, authority, exact plan, tool/effect binding and dependencies.
// A signed receipt is evidence of what the LOCAL controlled tool reports, not external truth.
function verifyExecutionEvidence({mission, request, plan, review, claims, grants, trust, receipts, controllerPublicKey, capabilityRegistry, now=Date.now(), journalEntries}) {
  const failure = reason => ({status:'DENY',reason});
  try {
    const fresh=planMission({mission,request,review,claims,grants,trust,now});
    if(fresh.status!=='READY_FOR_SIMULATION'||fresh.plan.digest!==plan?.digest)return failure('Mission authority or plan has changed');
    if(!Array.isArray(receipts)||receipts.length!==plan.steps.length||!controllerPublicKey)return failure('Missing execution evidence');
    assertContracts({mission,registry:capabilityRegistry,now});
    const seen=new Set(), prior={};
    for(let i=0;i<plan.steps.length;i++) {
      const step=plan.steps[i], item=receipts[i], p=item?.agentReceipt?.payload, e=item?.effectReceipt?.payload;
      const role=mission.roles.find(x=>x.label===step.role);
      const external=role&&!TOOLS[role.capability];
      const resolved=external?capabilityRegistry?.resolve(role.capability,mission.digest,now):null;
      const tool=role&&(TOOLS[role.capability]||resolved?.tool);
      if(!tool||seen.has(p?.nonce))return failure(`Unsupported/replayed tool at ${step.label}`);
      const deps=Object.fromEntries(step.dependencies.map(k=>[k,prior[k]]));
      if(step.dependencies.some(k=>!prior[k]))return failure(`Missing predecessor at ${step.label}`);
      if(!p||p.schema!=='octolang.mission-execution-evidence.v1'||p.outcome!=='EXECUTED_LOCAL'||
        p.missionDigest!==mission.digest||p.planDigest!==plan.digest||p.requestDigest!==plan.requestDigest||
        p.contextRoot!==plan.contextRoot||p.task!==step.label||p.role!==step.role||p.agent!==step.agent||
        p.capability!==role.capability||p.tool!==tool||p.evidence!==step.produces||
        (external?p.capabilityManifestDigest!==resolved.manifestDigest:p.capabilityManifestDigest!==undefined)||
        digest(p.dependencies)!==digest(deps)||p.effectReceiptDigest!==digest(item.effectReceipt)||
        typeof p.nonce!=='string'||p.nonce.length<16||typeof p.issuedAt!=='string'||!Number.isFinite(Date.parse(p.issuedAt))||
        Math.abs(Date.parse(p.issuedAt)-now)>300000||!verifiedSigned(item.agentReceipt,trust?.agents?.[step.agent]))return failure(`Invalid signed agent result ${step.label}`);
      if(!e||e.schema!=='octolang.mission-tool-receipt.v1'||e.outcome!=='LOCAL_TOOL_COMPLETED'||
        e.missionDigest!==mission.digest||e.planDigest!==plan.digest||e.requestDigest!==plan.requestDigest||
        e.task!==step.label||e.agent!==step.agent||e.tool!==tool||
        e.eventId!==p.eventId||e.resultDigest!==digest(item.result)||
        (external?e.capabilityManifestDigest!==resolved.manifestDigest:e.capabilityManifestDigest!==undefined)||
        !verifiedSigned(item.effectReceipt,controllerPublicKey))return failure(`Invalid local tool receipt ${step.label}`);
      if(step.dependencies.some(k=>!prior[k]))return failure(`Missing dependency at ${step.label}`);
      if(external) {
        if(!capabilityRegistry.verifyExternalResult(item.result,{mission,plan,request,step,controllerPublicKey,now}))
          return failure(`Invalid external service receipt ${step.label}`);
      } else if(role.capability==='intent.record') {
        if(item.result?.ok!==true||item.result?.outcome!=='RECORDED_LOCAL_INTENT'||item.result?.record?.missionDigest!==mission.digest||
          item.result.record.planDigest!==plan.digest||item.result.record.requestDigest!==plan.requestDigest||
          item.result.record.task!==step.label)return failure('Local journal record does not match mission');
        if(journalEntries && !journalEntries.some(row=>digest(row)===digest(item.result.record)))return failure('Local journal record not found');
      } else if(item.result?.ok!==true||item.result?.outcome!=='CHECKED_LOCAL'||item.result?.tool!==tool||
        item.result?.task!==step.label||item.result?.subject!==request.subject||
        item.result?.contextRoot!==plan.contextRoot||digest(item.result?.previousEvidenceDigests)!==digest(deps))
        return failure(`Unexpected local tool result ${step.label}`);
      seen.add(p.nonce);prior[step.label]=digest(item.agentReceipt);
    }
    for(const outcome of mission.outcomes)if(!prior[outcome.task])return failure(`Missing outcome ${outcome.label}`);
    const typedProofs=verifyTypedProofs({mission,plan,receipts});
    return {status:receipts.some(r=>r.result?.outcome==='EXTERNAL_SERVICE_RECORDED')?STATUS_EXT:STATUS,typedProofs, outcomeEvidence:mission.outcomes.map(o=>({name:o.label,task:o.task,evidenceDigest:prior[o.task]})),root:digest(prior)};
  } catch(err) { return failure(`Verification failed: ${err.message}`); }
}

class MissionExecutionController {
  constructor({dataDir, agentPrivateKeys={}, controllerKeyPair, toolHook, capabilityRegistry}={}) {
    this.dataDir=dataDir||fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v1-'));
    fs.mkdirSync(this.dataDir,{recursive:true,mode:0o700});
    fs.mkdirSync(path.join(this.dataDir,'claims'),{recursive:true,mode:0o700});
    this.agentPrivateKeys=agentPrivateKeys;
    this.controllerKeys=controllerKeyPair||crypto.generateKeyPairSync('ed25519');
    this.toolHook=toolHook;
    this.capabilityRegistry=capabilityRegistry||null;
    this.toolMap={...TOOLS};
    for(const capability of capabilityRegistry?.entries.keys()||[]) {
      if(TOOLS[capability])throw Error('Cannot override built-in capability');
      this.toolMap[capability]=capabilityRegistry.resolve(capability,capabilityRegistry.entries.get(capability).payload.missionDigest).tool;
    }
    this.pending=new Map();
    this.tools=new Octonomous.ToolRegistry();
    Object.values(this.toolMap).forEach(name=>this.tools.register({name,description:'OctoLang allowlisted capability'},(input,ctx)=>this._effect(name,input,ctx)));
    this.runtime=new Octonomous.Runtime({
      store:new Octonomous.stores.FileStore({basePath:path.join(this.dataDir,'beings')}),
      tools:this.tools, policy:new Octonomous.Policy(),
      cognition:{
        consider:()=>Promise.resolve({relevant:true}),
        decide:({event})=>Promise.resolve(this._decide(event)),
        reflect:({actionResult})=>Promise.resolve({kind:'OCTOLANG_MISSION_V1',success:actionResult?.ok===true})
      }
    });
  }
  _decide(event) {
    const slot=this.pending.get(event?.payload?.token);
    if(!slot||slot.state!=='issued'||slot.eventId!==event.id||slot.tool!==event.payload?.tool||
      event.type!=='octolang.mission-authorised-tool')return {shouldAct:false,action:{enabled:false},commitment:{enabled:false}};
    return {shouldAct:true,rationale:'Exact reviewed mission and independently signed grant rechecked by controller',
      action:{enabled:true,tool:slot.tool,input:{token:slot.token}},commitment:{enabled:false}};
  }
  async _effect(tool,input,ctx) {
    const slot=this.pending.get(input?.token);
    if(!slot||slot.state!=='issued'||slot.tool!==tool||slot.eventId!==ctx?.event?.id||
      slot.beingId!==ctx?.being?.id||ctx?.governance?.allowed!==true||
      ctx?.decision?.action?.tool!==tool)throw Error('Missing one-use controller grant or Octonomous runtime permission');
    // Effect-time verification protects against expiration/revocation or mutation between planning and acting.
    const refreshed=planMission(slot.params);
    if(refreshed.status!=='READY_FOR_SIMULATION'||refreshed.plan.digest!==slot.plan.digest) {
      slot.state='rejected';throw Error('Effect-time VCC recheck failed');
    }
    try{assertContracts({mission:slot.params.mission,registry:this.capabilityRegistry});}
    catch(e){slot.state='rejected';throw Error(`Effect-time typed contract failure: ${e.message}`);}
    if(slot.manifestDigest){
      const resolved=this.capabilityRegistry?.resolve(slot.capability,slot.params.mission.digest);
      if(!resolved||resolved.manifestDigest!==slot.manifestDigest){slot.state='rejected';throw Error('External capability changed or expired');}
    }
    slot.state='consumed'; // one use even on downstream failure
    if(this.toolHook)await this.toolHook(slot);
    if(slot.manifestDigest)return this.capabilityRegistry.invoke(slot.capability,{
      mission:slot.params.mission,plan:slot.plan,request:slot.params.request,step:slot.step,
      manifestDigest:slot.manifestDigest,controllerPrivateKey:this.controllerKeys.privateKey
    });
    const {request,mission}=slot.params;
    if(tool===TOOLS['intent.record']) {
      const record={schema:'octolang.mission-local-intent.v1',missionDigest:mission.digest,
        planDigest:slot.plan.digest,requestDigest:slot.plan.requestDigest,
        task:slot.step.label,eventId:slot.eventId,subject:request.subject,
        amount:request.inputs.amount,currency:'ADA',project:request.inputs.project,
        recordedAt:new Date().toISOString()};
      fs.appendFileSync(path.join(this.dataDir,'local-intents.jsonl'),JSON.stringify(record)+'\n',{encoding:'utf8',flag:'a',mode:0o600});
      return {ok:true,outcome:'RECORDED_LOCAL_INTENT',record};
    }
    return {ok:true,outcome:'CHECKED_LOCAL',tool,subject:request.subject,
      previousEvidenceDigests:slot.previous,contextRoot:slot.plan.contextRoot,task:slot.step.label};
  }
  async execute(params) {
    const {mission,request,trust}=params||{};
    const preflight=planMission(params||{});
    if(preflight.status!=='READY_FOR_SIMULATION')return deny(preflight.reason||'Mission denied');
    const plan=preflight.plan;
    try{assertContracts({mission,registry:this.capabilityRegistry});}
    catch(e){return deny(`Typed capability contract denied: ${e.message}`);}
    // The execution profile intentionally supports only these bounded capabilities.
    for(const role of mission.roles){
      if(!this.toolMap[role.capability])return deny(`No enabled local tool or signed capability for ${role.capability}`);
      if(!TOOLS[role.capability]){
        try{
          const manifest=this.capabilityRegistry.resolve(role.capability,mission.digest).entry.payload;
          if(manifest.inputFields.some(name=>!mission.inputs.some(field=>field.label===name)))
            return deny('Capability manifest requests undeclared mission inputs');
        }catch(e){return deny(`External capability denied: ${e.message}`);}
      }
    }
    if(mission.roles.some(r=>r.capability==='intent.record') &&
      (!mission.inputs.some(x=>x.label==='amount'&&x.type==='ada')||
       !mission.inputs.some(x=>x.label==='project'&&x.type==='text')))
      return deny('Local intent tool requires typed amount:ada and project:text inputs');
    for(const role of mission.roles){
      const agent=plan.assignments[role.label].agent;
      if(!publicKeyMatches(this.agentPrivateKeys[agent],trust?.agents?.[agent]))return deny(`No independent locally provisioned signer for agent ${agent}`);
    }
    // Reserve BEFORE awaiting filesystem/runtime actions. Exclusive creation prevents concurrent or restarted replay.
    const key=digest({missionDigest:mission.digest,nonce:request.nonce});
    const claim=path.join(this.dataDir,'claims',key+'.json');
    try {fs.writeFileSync(claim,JSON.stringify({status:'IN_PROGRESS',missionDigest:mission.digest,requestDigest:plan.requestDigest}),{flag:'wx',mode:0o600});}
    catch(e) {return deny(e.code==='EEXIST'?'Mission request already reserved (replay or reconciliation required)':`Cannot reserve request: ${e.message}`);}
    const receipts=[];const earlier={};
    try {
      for(const step of plan.steps) {
        const role=mission.roles.find(r=>r.label===step.role),tool=this.toolMap[role.capability];
        const manifestDigest=TOOLS[role.capability]?null:this.capabilityRegistry.resolve(role.capability,mission.digest).manifestDigest;
        const fresh=planMission(params);
        if(fresh.status!=='READY_FOR_SIMULATION'||fresh.plan.digest!==plan.digest)throw Error(`VCC pre-tool validation failed for ${step.label}`);
        if(step.dependencies.some(k=>!earlier[k]))throw Error(`Missing dependency for ${step.label}`);
        const previous=Object.fromEntries(step.dependencies.map(k=>[k,earlier[k]]));
        const token=crypto.randomUUID(),eventId=crypto.randomUUID(),beingId='mission_'+key.slice(0,16)+'_'+step.label;
        const slot={token,eventId,beingId,tool,step,plan,params,previous,state:'issued',
          capability:role.capability,manifestDigest};
        this.pending.set(token,slot);
        let execution;
        try {
          await this.runtime.registerBeing({id:beingId,identity:{kind:'octolang-local-demo',agent:step.agent},
            purpose:mission.goal,subscriptions:['octolang.mission-authorised-tool'],
            authority:{allowedTools:[tool],requiresApproval:[]},memory:{}});
          execution=await this.runtime.handleEventForBeing(beingId,{id:eventId,type:'octolang.mission-authorised-tool',
            sourceBeingId:beingId,payload:{token,tool}});
        }finally {this.pending.delete(token);}
        const result=execution?.actionResult;
        if(slot.state!=='consumed'||!result||result.ok!==true||
          !['RECORDED_LOCAL_INTENT','CHECKED_LOCAL','EXTERNAL_SERVICE_RECORDED'].includes(result.outcome)||
          execution?.governance?.allowed!==true)throw Error(`Octonomous tool did not complete ${step.label}`);
        const effectReceipt=signed({schema:'octolang.mission-tool-receipt.v1',missionDigest:mission.digest,
          planDigest:plan.digest,requestDigest:plan.requestDigest,task:step.label,agent:step.agent,tool,eventId,
          resultDigest:digest(result),outcome:'LOCAL_TOOL_COMPLETED',
          ...(manifestDigest?{capabilityManifestDigest:manifestDigest}:{})},this.controllerKeys.privateKey);
        const now=Date.now();
        const agentReceipt=signed({schema:'octolang.mission-execution-evidence.v1',missionDigest:mission.digest,
          planDigest:plan.digest,requestDigest:plan.requestDigest,contextRoot:plan.contextRoot,
          task:step.label,role:step.role,agent:step.agent,capability:role.capability,tool,
          evidence:step.produces,dependencies:previous,effectReceiptDigest:digest(effectReceipt),
          ...(manifestDigest?{capabilityManifestDigest:manifestDigest}:{}),
          eventId,outcome:'EXECUTED_LOCAL',nonce:crypto.randomUUID(),issuedAt:iso(now)},
          this.agentPrivateKeys[step.agent]);
        receipts.push({agentReceipt,effectReceipt,result});
        earlier[step.label]=digest(agentReceipt);
      }
      const journalPath=path.join(this.dataDir,'local-intents.jsonl');
      const journalEntries=fs.existsSync(journalPath)?fs.readFileSync(journalPath,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
      const verified=verifyExecutionEvidence({...params,plan,receipts,controllerPublicKey:this.controllerKeys.publicKey,
        capabilityRegistry:this.capabilityRegistry,journalEntries});
      if(![STATUS,STATUS_EXT].includes(verified.status))throw Error(`Post-execution verification failed: ${verified.reason}`);
      const hadExternal=receipts.some(r=>r.result?.outcome==='EXTERNAL_SERVICE_RECORDED');
      const out={status:hadExternal?'COMPLETED_CAPABILITY_MISSION':'COMPLETED_LOCAL_MISSION',missionDigest:mission.digest,plan,
        receipts,verification:verified,controllerPublicKeySpki:this.controllerKeys.publicKey.export({type:'spki',format:'der'}).toString('base64'),
        dataDir:this.dataDir, externalToolsExecuted:hadExternal,payments:false};
      fs.writeFileSync(claim,JSON.stringify({status:out.status,missionDigest:mission.digest,requestDigest:plan.requestDigest,
        evidenceRoot:verified.root}),{mode:0o600});
      return out;
    }catch(e){
      // Reservation remains sticky after any ambiguous failure; no automatic retry of side effects.
      try {fs.writeFileSync(claim,JSON.stringify({status:'REQUIRES_RECONCILIATION',reason:e.message,completedSteps:receipts.map(x=>x.agentReceipt.payload.task)}),{mode:0o600});}catch{}
      return {status:'REQUIRES_RECONCILIATION',reason:e.message,completedSteps:receipts.map(x=>x.agentReceipt.payload.task),executed:false};
    }
  }
}
module.exports={MissionExecutionController,verifyExecutionEvidence,TOOLS,STATUS,STATUS_EXT};
