'use strict';
// Offline post-run verifier. Trust pins MUST be obtained independently of an untrusted bundle.
const fs=require('node:fs');const crypto=require('node:crypto');
const {verifyExecutionEvidence}=require('./executor');
const exportKey=key=>key.export({type:'spki',format:'der'}).toString('base64');
const fromSpki=base64=>{
  if(typeof base64!=='string'||!base64||base64.length>256)throw Error('Invalid trust pin');
  const bytes=Buffer.from(base64,'base64');
  if(bytes.toString('base64')!==base64)throw Error('Invalid trust pin encoding');
  const publicKey=crypto.createPublicKey({key:bytes,format:'der',type:'spki'});
  if(publicKey.asymmetricKeyType!=='ed25519')throw Error('Only Ed25519 pins supported');
  return publicKey;
};
const exportPins=(trust,controller)=>{
  const pins={};
  for(const type of ['reviewers','issuers','grantIssuers','agents'])
    pins[type]=Object.fromEntries(Object.entries(trust[type]||{}).map(([name,key])=>[name,exportKey(key)]));
  pins.controller=exportKey(controller);
  return pins;
};
const importPins=pins=>{
  const trust={};
  for(const type of ['reviewers','issuers','grantIssuers','agents'])
    trust[type]=Object.fromEntries(Object.entries(pins[type]||{}).map(([name,key])=>[name,fromSpki(key)]));
  return {trust,controllerPublicKey:fromSpki(pins.controller)};
};
function verifyFiles(bundleFile,pinsFile,journalFile){
  const bundle=JSON.parse(fs.readFileSync(bundleFile,'utf8'));
  const pins=JSON.parse(fs.readFileSync(pinsFile,'utf8'));
  const {trust,controllerPublicKey}=importPins(pins);
  const journalEntries=fs.readFileSync(journalFile,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
  return verifyExecutionEvidence({...bundle,trust,controllerPublicKey,journalEntries});
}
if(require.main===module) {
  const [bundle,pins,journal]=process.argv.slice(2);
  if(!bundle||!pins||!journal){console.error('Usage: node mission/bundle.js <evidence-bundle.json> <independently-pinned-public-keys.json> <local-intents.jsonl>');process.exitCode=2;}
  else try {const out=verifyFiles(bundle,pins,journal);console.log(JSON.stringify(out,null,2));if(out.status!=='VERIFIED_LOCAL_EXECUTION_RECEIPTS')process.exitCode=1;}
  catch(err){console.error(err.message);process.exitCode=1;}
}
module.exports={exportPins,importPins,verifyFiles};
