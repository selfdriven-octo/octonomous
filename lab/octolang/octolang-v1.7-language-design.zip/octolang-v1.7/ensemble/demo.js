'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { demoSetup } = require('../src/demo');
const { EnsembleEngine } = require('./engine');
const { verifyTranscript } = require('./verify');
async function demo() {
  const score = fs.readFileSync(path.join(__dirname, '../examples/community-ensemble.octo'), 'utf8');
  const setup = demoSetup(score), request = setup.request('75');
  const inputs = { policy:setup.policy, request, claims:[setup.claim()], approvals:[setup.approval(request)], review:setup.review, trusted:setup.trusted };
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'octolang-ensemble-'));
  const engine = new EnsembleEngine({ dataDir:directory }); engine.registerDemoAgents(setup.policy);
  const result = await engine.run(inputs);
  if (result.status !== 'COMPLETED_LOCAL_DEMO') throw new Error(result.reason || result.status);
  const keys = Object.fromEntries(Object.entries(result.agentPublicKeysSpki).map(([name, key]) => [name, crypto.createPublicKey({ key: Buffer.from(key,'base64'), type:'spki', format:'der' })]));
  const independent = verifyTranscript({ inputs, contributions:result.contributions, trustedAgentKeys:keys, receiptSignerPublicKeySpki:result.receiptSignerPublicKeySpki });
  console.log(JSON.stringify({ status:result.status, agents:independent.verifiedAgents, chainHead:independent.chainHead,
    scoreDigest:independent.scoreDigest, contextRoot:independent.contextRoot,
    localJournal:path.join(directory,'local-intents.jsonl'), note:'Demo mock scout and checker, only real effect is a local journal append. No payment.' },null,2));
}
if (require.main === module) demo().catch(e => { console.error(e); process.exitCode=1; });
module.exports = { demo };
