'use strict';
// Independent verifier: caller must supply/pin public keys out of band.
const { digest, verifiedSigned } = require('../src/canonical');
const { assess } = require('../integration/vcc');
const { verifyLocalReceipt } = require('../integration/verify');

function verifyPartialTranscript({ inputs, contributions, trustedAgentKeys, receiptSignerPublicKeySpki, now = Date.now() }) {
  const { policy, request } = inputs || {};
  if (!policy?.ensemble || !['octolang.policy.v0.4','octolang.policy.v0.5'].includes(policy.schema)) throw new Error('No compiled v0.4 ensemble');
  if (!Array.isArray(contributions) || contributions.length < 1 || contributions.length > policy.ensemble.steps.length) throw new Error('Invalid contribution chain length');
  const { decision, snapshot } = assess({ ...inputs, usedNonces: new Set(), now });
  if (decision.status !== 'ALLOW') throw new Error(`VCC denied transcript: ${decision.reason}`);
  let previous = null;
  for (let index = 0; index < contributions.length; index++) {
    const step = policy.ensemble.steps[index], part = contributions[index];
    const p = part?.attestation?.payload;
    const key = trustedAgentKeys?.[step.agent];
    if (!key || !verifiedSigned(part.attestation, key)) throw new Error(`Agent ${step.agent} signature untrusted or invalid`);
    if (p?.schema !== 'octolang.agent-contribution.v0.4' || p.scoreDigest !== policy.digest ||
        p.requestDigest !== digest(request) || p.contextRoot !== snapshot.root ||
        p.ensemble !== policy.ensemble.name || p.stepId !== step.id || p.agent !== step.agent ||
        p.capability !== step.capability || p.evidence !== step.evidence ||
        p.outputDigest !== digest(part.output) || p.priorDigest !== (previous ? digest(previous) : null)) {
      throw new Error(`Contribution ${step.id} not bound to score, context, output or predecessor`);
    }
    const issued = Date.parse(p.issuedAt), expires = Date.parse(p.expiresAt);
    if (!Number.isFinite(issued) || !Number.isFinite(expires) || issued > now + 30000 ||
        expires <= now || expires - issued > 300000 ||
        typeof p.nonce !== 'string' || p.nonce.length < 16) throw new Error(`Contribution ${step.id} expired or invalid`);
    const o = part.output;
    if (o?.schema !== 'octolang.step-output.v0.4') throw new Error(`Invalid output ${step.id}`);
    if (step.capability === 'research') {
      if (o.kind !== 'DEMO_SUPPLIER_RESEARCH' || o.target !== request.target ||
          !inputs.claims.some(claim => digest(claim) === o.claimDigest)) throw new Error('Research evidence invalid');
    } else if (step.capability === 'purchase') {
      const record = o.record;
      if (o.kind !== 'RECORDED_LOCAL_INTENT' || !record ||
          record.scoreDigest !== policy.digest || record.requestDigest !== digest(request) ||
          record.contextRoot !== snapshot.root || record.agent !== request.agent ||
          record.amount !== request.amount || record.supplier !== request.target ||
          !verifyLocalReceipt({ record, receipt: o.receipt, receiptSignerPublicKeySpki })) {
        throw new Error('Unverified Octonomous Runtime local effect or receipt');
      }
    } else if (step.capability === 'audit') {
      if (o.kind !== 'DEMO_AUDIT' || o.subjectContributionDigest !== digest(contributions[index - 1]) ||
          o.localReceiptValid !== true) throw new Error('Audit evidence does not bind purchase step');
    } else throw new Error('Unknown step capability');
    previous = part;
  }
  return { verified: true, decision: 'ALLOW', scoreDigest: policy.digest,
    requestDigest: digest(request), contextRoot: snapshot.root, chainHead: digest(previous),
    verifiedAgents: policy.ensemble.steps.slice(0, contributions.length).map(x => x.agent),
    note: 'Signature/claim consistency verified; demo agent statements are not independent real-world truth.' };
}
function verifyTranscript(params) {
  const count = params?.inputs?.policy?.ensemble?.steps?.length;
  if (!Array.isArray(params?.contributions) || params.contributions.length !== count) throw new Error('Incomplete contribution chain');
  return verifyPartialTranscript(params);
}
module.exports = { verifyTranscript, verifyPartialTranscript };
