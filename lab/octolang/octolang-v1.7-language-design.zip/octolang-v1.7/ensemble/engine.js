'use strict';
// Bounded agent-to-agent score orchestration; mock research/audit, REAL original Octonomous local journal.
const crypto = require('node:crypto');
const { digest, signed } = require('../src/canonical');
const { assess } = require('../integration/vcc');
const { OctonomousBridge } = require('../integration/bridge');
const { verifyLocalReceipt } = require('../integration/verify');
const { verifyTranscript, verifyPartialTranscript } = require('./verify');

class EnsembleEngine {
  constructor({ dataDir, bridge, actors, usedNonces } = {}) {
    this.usedNonces = usedNonces || new Set();
    this.inFlight = new Set();
    this.bridge = bridge || new OctonomousBridge({ dataDir, usedNonces: this.usedNonces });
    this.actors = actors || {
      research: crypto.generateKeyPairSync('ed25519'),
      audit: crypto.generateKeyPairSync('ed25519')
    };
    this.agents = new Map();
    this.demoOnly = true;
  }
  // Pin agent signing keys by BOTH agent identity and declared capability.
  registerLocalAgent({ name, capability, privateKey, publicKey }) {
    if (!['research', 'audit'].includes(capability)) throw new Error('Only mock research/audit signers can be registered');
    if (this.agents.has(name)) throw new Error('Agent already registered');
    if (!privateKey || !publicKey || privateKey.asymmetricKeyType !== 'ed25519' || publicKey.asymmetricKeyType !== 'ed25519') throw new Error('Ed25519 keys required');
    this.agents.set(name, { capability, privateKey, publicKey });
  }
  _keysFor(policy) {
    const keys = {};
    for (const step of policy.ensemble.steps) {
      if (step.capability === 'purchase') keys[step.agent] = this.bridge.signer.publicKey;
      else {
        const actor = this.agents.get(step.agent);
        if (!actor || actor.capability !== step.capability) throw new Error('Required agent signer not registered with matching capability');
        keys[step.agent] = actor.publicKey;
      }
    }
    return keys;
  }
  registerDemoAgents(policy) {
    if (!policy?.ensemble) throw new Error('Missing ensemble');
    for (const s of policy.ensemble.steps) {
      if (s.capability === 'research' || s.capability === 'audit') {
        if (!this.agents.has(s.agent)) this.registerLocalAgent({ name: s.agent, capability: s.capability,
          ...this.actors[s.capability] });
      }
    }
  }
  async run(inputs) {
    const { policy, request } = inputs || {};
    if (!policy?.ensemble || policy.schema !== 'octolang.policy.v0.4') return { status: 'DENY', reason: 'v0.4 ensemble required', contributions: [] };
    const prepared = assess({ ...inputs, usedNonces: this.usedNonces });
    if (prepared.decision.status !== 'ALLOW') return { status: prepared.decision.status, reason: prepared.decision.reason, contributions: [] };
    if (this.inFlight.has(request.nonce)) return { status: 'DENY', reason: 'Ensemble nonce in flight', contributions: [] };
    // Synchronous reservation before the first await. Consumed even if a later step fails, preventing partial replay.
    this.inFlight.add(request.nonce);
    const contributions = [];
    try {
      const trustedAgentKeys = this._keysFor(policy);
      const receiptSignerPublicKeySpki = this.bridge.signer.publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
      const snapshotRoot = prepared.snapshot.root;
      for (const step of policy.ensemble.steps) {
        // Stage-time check: revalidate credentials and unchanged VCG root; active nonce belongs to this score.
        const current = assess({ ...inputs, usedNonces: new Set() });
        if (current.decision.status !== 'ALLOW' || current.snapshot.root !== snapshotRoot) throw new Error(`VCC denied step ${step.id}: ${current.decision.reason || 'context root changed'}`);
        let output, signer;
        if (step.capability === 'research') {
          signer = this.agents.get(step.agent).privateKey;
          output = { schema:'octolang.step-output.v0.4', kind:'DEMO_SUPPLIER_RESEARCH', target:request.target,
            claimDigest:digest(inputs.claims[0]), note:'Mock agent observed pinned signed claim; does not establish supplier truth' };
        } else if (step.capability === 'purchase') {
          signer = this.bridge.signer.privateKey;
          const result = await this.bridge.dispatch(inputs);
          if (result.status !== 'RECORDED_LOCAL_INTENT' || result.effect?.ok !== true) throw new Error(`Octonomous runtime failed: ${result.decision?.reason || result.error || result.status}`);
          if (!verifyLocalReceipt({ record:result.effect.record, receipt:result.effect.receipt, receiptSignerPublicKeySpki })) throw new Error('Local receipt signature invalid');
          output = { schema:'octolang.step-output.v0.4', kind:'RECORDED_LOCAL_INTENT', record:result.effect.record, receipt:result.effect.receipt };
        } else if (step.capability === 'audit') {
          signer = this.agents.get(step.agent).privateKey;
          output = { schema:'octolang.step-output.v0.4', kind:'DEMO_AUDIT', subjectContributionDigest:digest(contributions.at(-1)),
            localReceiptValid: true, note:'Mock audit assertion signed by separate demo identity' };
        } else throw new Error('Unsupported ensemble capability');
        const now = Date.now();
        const payload = { schema:'octolang.agent-contribution.v0.4', scoreDigest:policy.digest,
          requestDigest:digest(request), contextRoot:snapshotRoot, ensemble:policy.ensemble.name,
          stepId:step.id, agent:step.agent, capability:step.capability, evidence:step.evidence,
          outputDigest:digest(output), priorDigest:contributions.length ? digest(contributions.at(-1)) : null,
          issuedAt:new Date(now).toISOString(), expiresAt:new Date(now+240000).toISOString(), nonce:crypto.randomUUID() };
        const attestation = signed(payload, signer);
        contributions.push({ output, attestation });
        // Independently verify each new contribution before advancing the score.
        verifyPartialTranscript({ inputs, contributions, trustedAgentKeys, receiptSignerPublicKeySpki });
      }
      const verified = verifyTranscript({ inputs, contributions, trustedAgentKeys, receiptSignerPublicKeySpki });
      return { status:'COMPLETED_LOCAL_DEMO', verified, contributions,
        agentPublicKeysSpki:Object.fromEntries(Object.entries(trustedAgentKeys).map(([name,key]) => [name,key.export({ type:'spki', format:'der' }).toString('base64')])),
        receiptSignerPublicKeySpki, note:'Demo research and audit; one authorised local purchase-intent journal record, no external transaction' };
    } catch (e) {
      return { status:'FAILED_CLOSED', reason:e.message, contributions, note:'Some prior local steps may have recorded an intent; no automatic rollback.' };
    } finally {
      // The bridge itself reserves the request nonce if purchase ran. For early failure reserve locally as well.
      this.usedNonces.add(request.nonce);
      this.inFlight.delete(request.nonce);
    }
  }
}
module.exports = { EnsembleEngine };
