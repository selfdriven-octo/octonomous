#!/usr/bin/env node
'use strict';
// Frozen conformance vectors; test runner NEVER regenerates expected hashes.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {compileLanguage,verifyArtifact}=require('../../language/v1.6');
const {verifyIR}=require('../../language/v1.6/validate');
const fixtures=path.join(__dirname,'cases');
const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'manifest.json'),'utf8'));
function run() {
  assert.equal(manifest.schema,'octolang.conformance.v1.6');
  assert(manifest.vectors.length>=20,'too few vectors');
  const seen=new Set();
  for (const v of manifest.vectors) {
    assert(/^[a-z0-9-]+\.octo$/.test(v.file));assert(!seen.has(v.file));seen.add(v.file);
    const source=fs.readFileSync(path.join(fixtures,v.file),'utf8');
    if (!v.accepted) {
      assert.throws(()=>compileLanguage(source),e=>e.message.includes(v.errorIncludes),v.file);
    } else {
      const artifact=compileLanguage(source);
      assert.equal(artifact.irDigest,v.typedIRDigest,v.file);
      assert.deepEqual(artifact.diagnostics.map(d=>d.code),v.warnings,v.file);
      assert.equal(verifyIR(artifact.ir,artifact.irDigest).valid,true,v.file);
      assert.equal(verifyArtifact(source,artifact).valid,true,v.file);
    }
  }
  return manifest.vectors.length;
}
if (require.main===module) Promise.resolve().then(run).then(n=>console.log(`PASS ${n} frozen OctoLang v1.6 conformance vectors`)).catch(e=>{console.error(e);process.exitCode=1;});
module.exports={run};
