# Maintainer-only fixture generator. The runner uses FROZEN manifest.json digests.
from pathlib import Path
import json, subprocess, hashlib
root=Path(__file__).resolve().parents[2]
path=Path(__file__).resolve().parent
cases=path/'cases'; cases.mkdir(exist_ok=True)
base=(root/'examples/community-mission.octo').read_text()
proof=(root/'examples/community-proofs.octo').read_text()
midnight=(root/'examples/community-midnight.octo').read_text()
def put(name,content): (cases/(name+'.octo')).write_text(content)
put('mission-basic',base)
put('mission-comment', '// This has no semantic effect.\n'+base)
put('mission-role-reorder', base.replace('  role scout { capability "research" }\n  role reviewer { capability "validate" }', '  role reviewer { capability "validate" }\n  role scout { capability "research" }'))
put('mission-input-reorder', base.replace('  input amount { type ada }\n  input priority { type integer }','  input priority { type integer }\n  input amount { type ada }'))
put('mission-dependency-reorder',base.replace('"find_supplier,record_intent"','"record_intent,find_supplier"'))
put('mission-types',proof)
put('mission-midnight',midnight)
put('mission-distinct',base.replace('mission learning_materials','mission renewable_projects'))
put('reject-legacy-score',(root/'examples/community-supplies.octo').read_text())
put('reject-unknown-input-type',base.replace('type ada','type javascript',1))
put('reject-non-deny',base.replace('on violation DENY','on violation ALLOW'))
put('reject-cycle',base.replace('role scout depends none', 'role scout depends independent_audit'))
put('reject-unknown-dependency',base.replace('role scout depends none','role scout depends missing'))
put('reject-unbound-role',base.replace('role scout depends none','role unknown depends none'))
put('reject-duplicate-label',base.replace('  role scout { capability "research" }','  role scout { capability "research" }\n  role scout { capability "research" }'))
put('reject-invalid-unit',base.replace('max 100 ADA','max 100 ETH'))
put('reject-unknown-field',base.replace('input amount { type ada }','input amount { type ada execute true }'))
put('reject-outcome',base.replace('task record_intent evidence "intent.recorded"','task record_intent evidence "fabricated"'))
put('reject-service-identity',proof.replace('service "notes-provider"','service "other-provider"',1))
put('reject-missing-proof',proof.replace('  proof audit_proof { task independent_audit kind agent_receipt }',''))
put('reject-malformed',base[:-2])
put('reject-js',base+'\nrequire("fs")\n')
entries=[]
for f in sorted(cases.glob('*.octo')):
    p=subprocess.run(['node','bin/octolang-language.js','compile',str(f)],cwd=root,capture_output=True,text=True)
    if p.returncode==0:
        a=json.loads(p.stdout);entries.append(dict(file=f.name,accepted=True,typedIRDigest=a['irDigest'],warnings=[d['code'] for d in a['diagnostics']]))
    else:
        entries.append(dict(file=f.name,accepted=False,errorIncludes=p.stderr.strip().split(':')[0] if False else p.stderr.strip().split('\n')[0][:36]))
(path/'manifest.json').write_text(json.dumps({'schema':'octolang.conformance.v1.6','vectors':entries},indent=2)+'\n')
