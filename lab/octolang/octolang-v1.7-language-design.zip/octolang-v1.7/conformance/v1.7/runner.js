#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {compileComposition,verifyComposition}=require('../../language/v1.7');
const {verifyIR}=require('../../language/v1.7/validate');
const {compileLanguage}=require('../../language/v1.6');
const manifest=require('./manifest.json');
function run(){
 assert.equal(manifest.schema,'octolang.conformance.v1.7');assert(manifest.vectors.length>=15);
 const mission=fs.readFileSync(path.join(__dirname,'../../examples/community-proofs.octo'),'utf8');
 const root=compileLanguage(mission);const seen=new Set();
 for(const vector of manifest.vectors){
   assert.match(vector.file,/^[a-z-]+\.octo$/);assert(!seen.has(vector.file));seen.add(vector.file);
   const s=fs.readFileSync(path.join(__dirname,'cases',vector.file),'utf8');
   if(vector.accepted){const artifact=compileComposition(s,mission);
     assert.equal(artifact.irDigest,vector.irDigest,vector.file);
     assert.equal(verifyIR(artifact.ir,root.ir,artifact.irDigest).valid,true,vector.file);
     assert.equal(verifyComposition(s,mission,artifact).valid,true,vector.file);
   }else assert.throws(()=>compileComposition(s,mission),e=>e.message.includes(vector.errorIncludes),vector.file);
 }
 return manifest.vectors.length;
}
if(require.main===module)Promise.resolve().then(run).then(x=>console.log(`PASS ${x} frozen OctoLang v1.7 composition vectors`)).catch(e=>{console.error(e);process.exitCode=1;});
module.exports={run};
