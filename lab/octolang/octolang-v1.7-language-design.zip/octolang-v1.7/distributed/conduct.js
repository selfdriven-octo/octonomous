'use strict';
const {fixture}=require('../network/fixture');
const {DistributedCoordinator}=require('./coordinator');
const {readFileSync}=require('node:fs');
const {resolve}=require('node:path');
async function main(home,{resume=false}={}){
  const engine=new DistributedCoordinator({root:home});
  const entries=engine.pending();
  const inputs=resume?entries.at(-1)?.inputs:fixture(home);
  if(!inputs)throw Error('No pending signed inputs to resume');
  const result=await engine.run(inputs,{maxAttempts:3,delayMs:300});
  console.log(JSON.stringify({status:result.status,reason:result.reason,steps:result.contributions?.length,
    verified:result.verified,nextStep:result.nextStep,attempts:result.attempts,note:result.note},null,2));
  if(result.status!=='COMPLETED_DISTRIBUTED_DEMO')process.exitCode=1;
  return result;
}
if(require.main===module)main(process.argv[2]||'.octolang-distributed-coordinator',
  {resume:process.argv.includes('--resume')}).catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={main};
