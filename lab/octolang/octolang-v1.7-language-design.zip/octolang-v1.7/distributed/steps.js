'use strict';
// Peer-local crash-sticky stage receipts. Never retry an uncertain external effect.
const fs=require('node:fs');
const path=require('node:path');
const {digest}=require('../src/canonical');
function fail(reason){throw Error(reason);}
function durableWrite(filename,value){
  const dir=path.dirname(filename);fs.mkdirSync(dir,{recursive:true,mode:0o700});
  const temp=filename+'.'+process.pid+'.'+require('node:crypto').randomUUID()+'.tmp';
  const fd=fs.openSync(temp,'wx',0o600);
  try{fs.writeFileSync(fd,JSON.stringify(value));fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
  fs.renameSync(temp,filename);
  const dh=fs.openSync(dir,'r');try{fs.fsyncSync(dh);}finally{fs.closeSync(dh);}
}
class StepStore{
  constructor(directory){this.dir=path.join(directory,'state','steps');fs.mkdirSync(this.dir,{recursive:true,mode:0o700});}
  _paths(payload){
    const inputs=payload?.inputs,request=inputs?.request;
    if(!request||typeof request.nonce!=='string'||request.nonce.length>128)fail('Invalid action nonce');
    const key=digest([request.scoreDigest,request.nonce,payload.community,payload.stepId]);
    return {claim:path.join(this.dir,key+'.claimed'),receipt:path.join(this.dir,key+'.receipt.json')};
  }
  lookup(payload){
    const p=this._paths(payload),hash=digest(payload);
    if(fs.existsSync(p.receipt)){
      const saved=JSON.parse(fs.readFileSync(p.receipt,'utf8'));
      if(saved.payloadDigest!==hash)fail('STAGE_CONFLICT: replay with changed step inputs');
      return {cached:true,contribution:saved.contribution};
    }
    if(fs.existsSync(p.claim))fail('RECONCILIATION_REQUIRED: prior stage did not commit a receipt');
    return {cached:false};
  }
  claim(payload){
    const p=this._paths(payload);
    try{const fd=fs.openSync(p.claim,'wx',0o600);try{fs.writeFileSync(fd,digest(payload));fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
    catch(e){if(e.code==='EEXIST')fail('RECONCILIATION_REQUIRED: stage already claimed');throw e;}
  }
  complete(payload,contribution){
    const p=this._paths(payload);
    if(!fs.existsSync(p.claim)||fs.existsSync(p.receipt))fail('Stage receipt collision');
    durableWrite(p.receipt,{payloadDigest:digest(payload),contribution});
  }
}
module.exports={StepStore,durableWrite};
