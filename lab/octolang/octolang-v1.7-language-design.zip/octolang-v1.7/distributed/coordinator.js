'use strict';
// Durable, bounded at-least-once OFP delivery. Never assumes exactly-once external effects.
const fs=require('node:fs');
const path=require('node:path');
const {digest}=require('../src/canonical');
const {assess}=require('../integration/vcc');
const {verifyPartialTranscript,verifyTranscript}=require('../ensemble/verify');
const {loadCoordinator,loadRevocations,verifyCredential,publicKey}=require('../network/identity');
const {endpoint,send,receive,claimsIn,actorKeys,publicAnchors}=require('../network/common');
const {exchange}=require('../network/transport');
const {durableWrite}=require('./steps');
const {verifyAttestation}=require('../platform/context');
const {verifyPresentation}=require('../platform/discovery');
function fail(message){throw Error(message);}
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
class DistributedCoordinator{
  constructor({root}){
    const node=loadCoordinator(root);
    if(!node.local.remote||!node.local.tls)fail('Coordinator must be distributed and pinned mutual-TLS enabled');
    this.dir=node.dir;this.config=node.local;
    this.endpoint=endpoint(node.local,node.identity);
    this.durable=claimsIn(node.dir);
    this.trusted=publicAnchors(node.local);
    this.trustedAgentKeys=actorKeys(node.local);
    this.receiptSignerPublicKeySpki=node.local.directory['community-execution'].agentKeySpki;
    this.outboxDir=path.join(this.dir,'state','outbox');fs.mkdirSync(this.outboxDir,{recursive:true,mode:0o700});
  }
  _file(inputs){const {policy,request}=inputs;
    if(!request||typeof request.nonce!=='string'||request.nonce.length>128)fail('Missing unique action nonce');
    return path.join(this.outboxDir,digest([policy.digest,request.nonce])+'.json');
  }
  async discover(community){
    if(!this.config.directory[community]||community===this.config.id)throw Error('Unknown peer discovery target');
    const result=await exchange(this.config,this.dir,community,'GET','/agent');
    if(result.status!==200)throw Error('Peer denied discovery: '+(result.value?.reason||result.status));
    return verifyPresentation(result.value?.presentation,{config:this.config,community,
      revokedIds:loadRevocations(this.dir)});
  }
  pending(){return fs.readdirSync(this.outboxDir).filter(x=>x.endsWith('.json'))
    .map(x=>({file:path.join(this.outboxDir,x),value:JSON.parse(fs.readFileSync(path.join(this.outboxDir,x),'utf8'))}))
    .filter(x=>x.value.status==='WAITING_DELIVERY').map(x=>({file:x.file,inputs:x.value.inputs}));}
  async run(inputs,{maxAttempts=2,delayMs=150,onStep}={}){
    if(!Number.isInteger(maxAttempts)||maxAttempts<1||maxAttempts>10||delayMs<0||delayMs>20000)
      fail('Bounded retry settings required');
    if(inputs?.policy?.schema!=='octolang.policy.v0.5'||!inputs.policy.federation||
       inputs.policy.digest!==this.config.scoreDigest)
      return {status:'DENY',reason:'Unprovisioned reviewed federation score',contributions:[]};
    let file,lock;
    try {file=this._file(inputs);lock=file+'.lock';}
    catch(e){return {status:'DENY',reason:e.message,contributions:[]};}
    let fd;
    try{fd=fs.openSync(lock,'wx',0o600);}catch(e){return {status:'DENY',reason:'CONDUCTOR_LOCKED: another process or crashed worker owns this run',contributions:[]};}
    try{
      let state=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):null;
      if(state && (state.inputDigest!==digest(inputs)||state.schema!=='octolang.durable-outbox.v0.7'))
        return {status:'DENY',reason:'REPLAY_CONFLICT: changed signed inputs for same nonce',contributions:[]};
      if(state && state.status==='COMPLETED')return {status:'DENY',reason:'DURABLE_REPLAY: completed request already settled',contributions:[]};
      if(state && state.status==='FAILED_CLOSED')return {status:'DENY',reason:'FAILED_CLOSED: operator investigation required',contributions:[]};
      const fixed={...inputs,trusted:this.trusted,usedNonces:new Set()};
      const checked=assess(fixed);
      if(checked.decision.status!=='ALLOW')return {status:checked.decision.status,reason:checked.decision.reason,
        contributions:state?.contributions||[]};
      if(!state){
        state={schema:'octolang.durable-outbox.v0.7',inputDigest:digest(inputs),inputs,
          status:'WAITING_DELIVERY',nextStep:0,contributions:[],wire:[],attempts:[]};
        durableWrite(file,state);
      }
      const save=()=>durableWrite(file,state);
      for(let index=state.nextStep;index<inputs.policy.ensemble.steps.length;index++){
        const step=inputs.policy.ensemble.steps[index],community=inputs.policy.federation.members[index]?.community;
        const member=this.config.directory[community],credential=this.config.credentials[community];
        try{
          if(!member||member.agent!==step.agent||member.capability!==step.capability)fail('Unrecognised peer role');
          verifyCredential({credential,authorityKey:publicKey(this.config.credentialAuthoritySpki),
            revokedIds:loadRevocations(this.dir),expected:member});
          const role=inputs.policy.agents.find(a=>a.name===step.agent);
          if(!role||BigInt(role.limitLovelace)>BigInt(member.maxLovelace)||role.delegate!==false)
            fail('Action exceeds independently credentialled role');
        }catch(e){state.status='FAILED_CLOSED';state.error=e.message;save();
          return {status:'FAILED_CLOSED',reason:e.message,contributions:state.contributions};}
        const previous=state.contributions;
        const payload={schema:'octolang.network-step.v0.6',community,stepId:step.id,stepIndex:index,
          agent:step.agent,capability:step.capability,scoreDigest:inputs.policy.digest,
          requestDigest:digest(inputs.request),contextRoot:checked.snapshot.root,actionNonce:inputs.request.nonce,
          priorDigest:previous.length?digest(previous.at(-1)):null,
          inputs:{policy:inputs.policy,request:inputs.request,claims:inputs.claims,
            approvals:inputs.approvals,review:inputs.review},contributions:previous};
        let delivered=false;
        for(let attempt=0;attempt<maxAttempts;attempt++){
          let outgoing;
          try{
            // Live discovery is NOT authority: pinned OFP identity and local VCC still gate action.
            // Do not persist this short-lived presentation as a permission.
            await this.discover(community);
            // Always sign a FRESH envelope per transport attempt; the peer's exact stage
            // input digest is stable, so its cached signed contribution is reused.
            outgoing=await send(this.endpoint,community,'octolang.step.request.v0.6',payload);
            state.pending={step:index,community,envelope:outgoing};
            state.attempts.push({step:index,community,envelopeId:outgoing.id,createdAt:new Date().toISOString()});save();
            if(onStep)await onStep({index,attempt,community,envelope:outgoing});
            const response=await exchange(this.config,this.dir,community,'POST','/ofp',{envelope:outgoing});
            if(response.status!==200){
              const reason=response.value?.reason||'Rejected';
              if(response.status<500)fail('PERMANENT_PEER_DENIAL: '+reason);
              throw Error('Temporary peer error: '+reason);
            }
            const incoming=response.value?.envelope;
            if(incoming?.senderCommunityId!==community)fail('PERMANENT_PEER_DENIAL: signed response sender mismatched');
            const reply=await receive(this.endpoint,incoming,this.durable,'octolang.step.result.v0.6');
            if(reply?.schema!=='octolang.network-result.v0.6'||reply.community!==community||
              reply.credentialId!==credential.payload.id||reply.scoreDigest!==inputs.policy.digest||
              reply.stepId!==step.id||reply.responseTo!==digest(outgoing)||
              reply.contributionDigest!==digest(reply.contribution))fail('PERMANENT_PEER_DENIAL: response not request-bound');
            const candidate=[...previous,reply.contribution];
            if(index===0)verifyAttestation(reply.contribution?.output?.contextAttestation,
              {inputs,config:this.config,revokedIds:loadRevocations(this.dir)});
            verifyPartialTranscript({inputs:fixed,contributions:candidate,
              trustedAgentKeys:this.trustedAgentKeys,
              receiptSignerPublicKeySpki:this.receiptSignerPublicKeySpki});
            state.contributions=candidate;state.nextStep=index+1;state.pending=null;
            state.wire.push({sender:outgoing.senderCommunityId,recipient:outgoing.recipientCommunityId,
              requestId:outgoing.id,responseId:incoming.id,requestDigest:digest(outgoing),responseDigest:digest(incoming)});
            save();delivered=true;break;
          }catch(e){
            const permanent=/PERMANENT_PEER_DENIAL|signature|credential|replay|revok|policy|attestation|governance|grant|mismatch|invalid/i.test(e.message);
            state.error=e.message;
            if(permanent){state.status='FAILED_CLOSED';save();return {status:'FAILED_CLOSED',reason:e.message,
              contributions:state.contributions,wire:state.wire};}
            state.status='WAITING_DELIVERY';save();
            if(attempt<maxAttempts-1)await sleep(delayMs);
          }
        }
        if(!delivered)return {status:'WAITING_DELIVERY',reason:state.error,contributions:state.contributions,
          nextStep:state.nextStep,attempts:state.attempts.length,
          note:'Persistent outbox saved. Re-run with identical signed inputs or --resume after peer recovery.'};
      }
      verifyAttestation(state.contributions[0]?.output?.contextAttestation,
        {inputs,config:this.config,revokedIds:loadRevocations(this.dir)});
      const verified=verifyTranscript({inputs:fixed,contributions:state.contributions,
        trustedAgentKeys:this.trustedAgentKeys,receiptSignerPublicKeySpki:this.receiptSignerPublicKeySpki});
      state.status='COMPLETED';state.verified=verified;state.pending=null;save();
      return {status:'COMPLETED_DISTRIBUTED_DEMO',verified,contributions:state.contributions,wire:state.wire,
        note:'Independent host identities, mutual TLS and OFP signed steps. Only local intent journal effect.'};
    }finally{fs.closeSync(fd);fs.rmSync(lock,{force:true});}
  }
}
module.exports={DistributedCoordinator};
