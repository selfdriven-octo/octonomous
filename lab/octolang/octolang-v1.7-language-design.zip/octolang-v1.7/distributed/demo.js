'use strict';
const os=require('node:os');
const fs=require('node:fs');
const path=require('node:path');
const net=require('node:net');
const {spawn}=require('node:child_process');
const {initPeer,initCoordinator,enroll,activate,pin}=require('./provision');
const {MEMBERS}=require('../network/identity');
const {fixture}=require('../network/fixture');
const {exchange}=require('../network/transport');
const {readJson}=require('../network/identity');
const {DistributedCoordinator}=require('./coordinator');
function port(){return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(e=>e?reject(e):resolve(p));});});}
async function bootstrap(base){
  fs.mkdirSync(base,{recursive:true,mode:0o700});
  const coordinator=path.join(base,'owner-coordinator');const c=initCoordinator(coordinator);
  const peerHomes={};const regs=[];const pins=[];
  for(const m of MEMBERS){const home=path.join(base,'owner-'+m.id),p=await port();
    const reg=initPeer(home,m.id,`https://127.0.0.1:${p}`);
    peerHomes[m.id]=home;regs.push(reg.registration);pins.push(reg.fingerprint);
  }
  const bundles=enroll(coordinator,regs,{confirmedPins:pins});
  for(const m of MEMBERS)activate(peerHomes[m.id],bundles.bundles[m.id],c.authorityPin);
  return {base,coordinator,peerHomes,identityPins:pins};
}
async function startPeer(f,id,{bind='127.0.0.1'}={}){
  const child=spawn(process.execPath,[path.join(__dirname,'peer.js'),f.peerHomes[id],id],
    {env:{...process.env,OCTOLANG_BIND:bind},stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',d=>stderr+=d.toString());
  let out='';child.stdout.on('data',d=>out+=d.toString());
  const config=readJson(path.join(f.coordinator,'community-coordinator','local.json'));
  for(let i=0;i<60;i++){
    if(child.exitCode!==null)throw Error('Peer exited prematurely: '+stderr);
    try{const r=await exchange(config,path.join(f.coordinator,'community-coordinator'),id,'GET','/health');
      if(r.status===200)return child;}catch{}
    await new Promise(resolve=>setTimeout(resolve,100));
  }
  child.kill();throw Error('Peer did not start: '+stderr+' '+out);
}
async function stopPeer(c){if(!c||c.exitCode!==null)return;
  c.kill('SIGTERM');await Promise.race([new Promise(resolve=>c.once('exit',resolve)),
    new Promise(resolve=>setTimeout(resolve,500))]);if(c.exitCode===null)c.kill('SIGKILL');}
async function demonstration({base=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v07-')),leave=false}={}){
  let f,children=[];
  try{
    f=await bootstrap(base);
    for(const m of MEMBERS)children.push(await startPeer(f,m.id));
    const coordinator=new DistributedCoordinator({root:f.coordinator});
    const discovery=[];
    for(const m of MEMBERS)discovery.push(await coordinator.discover(m.id));
    const first=await coordinator.run(fixture(f.coordinator));
    const journal=path.join(f.peerHomes['community-execution'],'community-execution','state','effects','local-intents.jsonl');
    const effects=fs.existsSync(journal)?fs.readFileSync(journal,'utf8').trim().split('\n').length:0;
    console.log(JSON.stringify({status:first.status,verified:first.verified,
      discoveredAgents:discovery.map(x=>({community:x.community,verified:x.verified,capability:x.capability})),
      independentlyVerifiedContextRoot:first.contributions?.[0]?.output?.contextAttestation?.payload?.contextRoot||null,effects,
      homes:Object.keys(f.peerHomes).map(k=>path.basename(f.peerHomes[k])),
      note:'4 identity homes, 3 independent processes, pinned mTLS, signed discovery and rechecked VCG root. Development credentials only; no purchases.'},null,2));
    return {first,effects,fixture:f};
  }finally{
    for(const c of children)await stopPeer(c);
    if(!leave)fs.rmSync(base,{recursive:true,force:true});
  }
}
if(require.main===module)demonstration({base:process.env.OCTOLANG_DISTRIBUTED_HOME||undefined,
  leave:process.env.OCTOLANG_DEMO_KEEP==='1'}).then(r=>{if(r.first.status!=='COMPLETED_DISTRIBUTED_DEMO')process.exitCode=1;})
  .catch(e=>{console.error(e);process.exitCode=1;});
module.exports={bootstrap,startPeer,stopPeer,demonstration};
