'use strict';
// Public-key exchange for independently managed community homes. Does not copy private keys.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const {MEMBERS,COORDINATOR,spki,publicKey,privateKey,writeJson,readJson,verifyCredential}=require('../network/identity');
const {signed,verifiedSigned,digest}=require('../src/canonical');
const {compile}=require('../src/compiler');
const SOURCE=path.join(__dirname,'../examples/community-federation.octo');
const names=[COORDINATOR,...MEMBERS.map(m=>m.id)];
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const pin=s=>sha(Buffer.from(s,'base64'));
const score=()=>compile(fs.readFileSync(SOURCE,'utf8'));
function deny(m){throw Error(m);}
function mk(home,id){
  home=path.resolve(home);if(fs.existsSync(home))deny('Home already exists; refusing to overwrite identity: '+home);
  fs.mkdirSync(path.join(home,id),{recursive:true,mode:0o700});return path.join(home,id);
}
function key(dir,name){
  const {publicKey:pub,privateKey:priv}=crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(path.join(dir,name+'.pem'),priv.export({format:'pem',type:'pkcs8'}),{mode:0o600,flag:'wx'});
  return spki(pub);
}
function httpsUrl(urlText){
  const u=new URL(urlText);
  if(u.protocol!=='https:'||!u.hostname||!u.port||u.pathname!=='/'||u.search||u.hash||u.username||u.password||
     ['0.0.0.0','[::]','localhost.invalid'].includes(u.hostname))deny('Expected an https://host:port/ endpoint without credentials or path');
  return u;
}
function cert(dir,id,host){
  const ip=require('node:net').isIP(host.replace(/^\[|\]$/g,''));
  const san=(ip?'IP:':'DNS:')+host.replace(/^\[|\]$/g,'');
  execFileSync('openssl',['req','-x509','-nodes','-newkey','rsa:2048','-sha256','-days','30',
    '-subj','/CN='+id,'-addext','subjectAltName='+san,
    '-addext','extendedKeyUsage=serverAuth,clientAuth',
    '-keyout',path.join(dir,'tls-key.pem'),'-out',path.join(dir,'tls-cert.pem')],{stdio:'pipe'});
  fs.chmodSync(path.join(dir,'tls-key.pem'),0o600);
  return fs.readFileSync(path.join(dir,'tls-cert.pem'),'utf8');
}
function registration(dir,id,info){
  const k=privateKey(dir,'community');
  const p=signed({schema:'octolang.peer-registration.v0.7',id, ...info},k);
  writeJson(path.join(dir,'registration.json'),p);
  return {file:path.join(dir,'registration.json'),registration:p};
}
function initPeer(home,id,url){
  const m=MEMBERS.find(m=>m.id===id);if(!m)deny('Unknown peer role');
  const u=httpsUrl(url),dir=mk(home,id);
  const communityKeySpki=key(dir,'community'),agentKeySpki=key(dir,'agent'),governanceKeySpki=key(dir,'governance');
  const tlsCertPem=cert(dir,id,u.hostname);
  const {file}=registration(dir,id,{url:u.origin,agent:m.agent,capability:m.capability,maxLovelace:m.maxLovelace,
    communityKeySpki,agentKeySpki,governanceKeySpki,tlsCertPem});
  return {home:path.resolve(home),registration:file,fingerprint:pin(communityKeySpki),
    tlsFingerprint:new crypto.X509Certificate(tlsCertPem).fingerprint256};
}
function initCoordinator(home){
  const dir=mk(home,COORDINATOR),gov=path.join(home,'governance');fs.mkdirSync(gov,{mode:0o700});
  const communityKeySpki=key(dir,'community');
  for(const k of ['reviewer','issuer','approver'])key(dir,k);
  const authoritySpki=key(gov,'credential-authority');
  const tlsCertPem=cert(dir,COORDINATOR,'127.0.0.1');
  registration(dir,COORDINATOR,{communityKeySpki,tlsCertPem});
  return {home:path.resolve(home),authorityPin:pin(authoritySpki),coordinatorIdentityPin:pin(communityKeySpki)};
}
function confirmPeer(input){
  const reg=readJson(input),p=reg.payload;
  const expected=MEMBERS.find(m=>m.id===p?.id);
  if(!p||p.schema!=='octolang.peer-registration.v0.7'||!expected||
    p.agent!==expected.agent||p.capability!==expected.capability||p.maxLovelace!==expected.maxLovelace)
    deny('Peer registration role not trusted');
  httpsUrl(p.url);
  if(!verifiedSigned(reg,publicKey(p.communityKeySpki)))deny('Peer registration signature invalid');
  const cert=new crypto.X509Certificate(p.tlsCertPem);
  if(cert.subject!==`CN=${p.id}`||!(require('node:net').isIP(new URL(p.url).hostname)?cert.checkIP(new URL(p.url).hostname):cert.checkHost(new URL(p.url).hostname)))deny('Peer TLS identity invalid');
  return p;
}
function enroll(home,paths,{confirmedPins=[]}={}){
  home=path.resolve(home);const coord=path.join(home,COORDINATOR),gov=path.join(home,'governance');
  if(fs.existsSync(path.join(coord,'local.json')))deny('Coordinator already enrolled');
  if(paths.length!==3)deny('Exactly three independently prepared peer registration files required');
  const peers=paths.map(confirmPeer);const ids=peers.map(p=>p.id);
  if(new Set(ids).size!==3||MEMBERS.some(m=>!ids.includes(m.id)))deny('Missing or duplicate community registration');
  for(const p of peers){
    if(!confirmedPins.includes(pin(p.communityKeySpki)))deny('Explicit out-of-band identity fingerprint confirmation required for '+p.id);
  }
  const coordSpki=spki(crypto.createPublicKey(privateKey(coord,'community')));
  const caSpki=spki(crypto.createPublicKey(privateKey(gov,'credential-authority')));
  const coordPem=fs.readFileSync(path.join(coord,'tls-cert.pem'),'utf8');
  const directory={[COORDINATOR]:{id:COORDINATOR,communityKeySpki:coordSpki,tlsCertPem:coordPem}};
  const urls={};for(const p of peers){directory[p.id]=p;urls[p.id]=p.url;}
  const start=Date.now(),notBefore=new Date(start-60000).toISOString(),expiresAt=new Date(start+7*86400000).toISOString();
  const credentials={};
  for(const p of peers){credentials[p.id]=signed({schema:'octolang.demo-community-credential.v0.6',
    id:'cred:'+crypto.randomUUID(),issuer:'demo-governance-root',community:p.id,agent:p.agent,
    capability:p.capability,maxLovelace:p.maxLovelace,communityKeySpki:p.communityKeySpki,
    agentKeySpki:p.agentKeySpki,notBefore,expiresAt},privateKey(gov,'credential-authority'));}
  const trusted={reviewers:{'community-owner':spki(crypto.createPublicKey(privateKey(coord,'reviewer')))},
    issuers:{'community-registry':spki(crypto.createPublicKey(privateKey(coord,'issuer')))},
    approvers:{'project-steward':spki(crypto.createPublicKey(privateKey(coord,'approver')))}};
  const config={role:'coordinator',id:COORDINATOR,directory,urls,credentialAuthoritySpki:caSpki,
    credentials,scoreDigest:score().digest,tls:true,remote:true,trusted};
  writeJson(path.join(coord,'local.json'),config);writeJson(path.join(coord,'revoked.json'),{revokedCredentialIds:[]});
  const bundleDir=path.join(home,'bundles');fs.mkdirSync(bundleDir,{mode:0o700});
  const bundles={};
  for(const p of peers){
    const payload={schema:'octolang.activation-bundle.v0.7',community:p.id,registrationDigest:digest(readJson(paths[peers.indexOf(p)])),
      directory,urls,credentialAuthoritySpki:caSpki,credentials,scoreDigest:score().digest,trusted};
    const bundle={authoritySpki:caSpki,attestation:signed(payload,privateKey(gov,'credential-authority'))};
    const f=path.join(bundleDir,p.id+'.json');writeJson(f,bundle);bundles[p.id]=f;
  }
  return {authorityPin:pin(caSpki),bundles,identityPins:Object.fromEntries(peers.map(p=>[p.id,pin(p.communityKeySpki)]))};
}
function activate(home,bundleFile,authorityPin){
  const bundle=readJson(bundleFile),p=bundle?.attestation?.payload;
  if(!p||p.schema!=='octolang.activation-bundle.v0.7'||pin(bundle.authoritySpki)!==authorityPin||
    p.credentialAuthoritySpki!==bundle.authoritySpki||!verifiedSigned(bundle.attestation,publicKey(bundle.authoritySpki)))
    deny('Bundle not signed by explicitly pinned credential authority');
  const id=p.community,dir=path.join(path.resolve(home),id),reg=readJson(path.join(dir,'registration.json'));
  if(digest(reg)!==p.registrationDigest||reg.payload.id!==id)deny('Activation does not match local peer registration');
  if(fs.existsSync(path.join(dir,'local.json')))deny('Already activated; no implicit trust rotation');
  const d=p.directory[id];if(!d||d.communityKeySpki!==reg.payload.communityKeySpki||
     d.agentKeySpki!==reg.payload.agentKeySpki||d.governanceKeySpki!==reg.payload.governanceKeySpki||
     d.tlsCertPem!==reg.payload.tlsCertPem||p.urls[id]!==reg.payload.url)deny('Bundle substituted local identity');
  const cred=verifyCredential({credential:p.credentials[id],authorityKey:publicKey(bundle.authoritySpki),
    revokedIds:[],expected:d});
  if(p.scoreDigest!==score().digest)deny('Unexpected compiled policy digest');
  if(!p.directory[COORDINATOR]?.tlsCertPem)deny('Missing coordinator TLS pin');
  const now=Date.now(),grant=signed({schema:'octolang.local-governance-grant.v0.6',community:id,
    agent:d.agent,capability:d.capability,maxLovelace:d.maxLovelace,
    credentialId:cred.id,scoreDigest:p.scoreDigest,delegate:false,
    notBefore:new Date(now-60000).toISOString(),expiresAt:new Date(now+7*86400000).toISOString()},privateKey(dir,'governance'));
  const local={role:'peer',id,url:p.urls[id],directory:p.directory,urls:p.urls,
    credentialAuthoritySpki:p.credentialAuthoritySpki,credentials:p.credentials,grant,
    scoreDigest:p.scoreDigest,tls:true,remote:true,trusted:p.trusted};
  writeJson(path.join(dir,'local.json'),local);writeJson(path.join(dir,'revoked.json'),{revokedCredentialIds:[]});
  return {id,identityPin:pin(d.communityKeySpki),grantedCapability:d.capability,scoreDigest:p.scoreDigest};
}
module.exports={initPeer,initCoordinator,enroll,activate,pin,confirmPeer};
if(require.main===module){
  try{
    const [cmd,...args]=process.argv.slice(2);let result;
    if(cmd==='init-peer')result=initPeer(args[0],args[1],args[2]);
    else if(cmd==='init-coordinator')result=initCoordinator(args[0]);
    else if(cmd==='enroll'){const pos=args.indexOf('--trust');
      if(pos<0)deny('Provide --trust <comma-separated confirmed peer public-key fingerprints>');
      result=enroll(args[0],args.slice(1,pos),{confirmedPins:args[pos+1].split(',')});}
    else if(cmd==='activate')result=activate(args[0],args[1],args[2]);
    else deny('Usage: init-coordinator <home> | init-peer <home> <id> <https://host:port> | enroll <coordinator-home> <3 registration.json> --trust <pins CSV> | activate <peer-home> <bundle> <authority-pin>');
    console.log(JSON.stringify(result,null,2));
  }catch(e){console.error(e.message);process.exitCode=1;}
}
