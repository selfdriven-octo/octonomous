'use strict';
// Distinct machine participant. Set OCTOLANG_BIND=0.0.0.0 only on a protected private/VPN interface.
const {createPeer}=require('../network/peer');
const {loadPeer}=require('../network/identity');
if(require.main===module){
  const [home,id]=process.argv.slice(2);
  try{
    const node=loadPeer(home,id);if(!node.local.remote||!node.local.tls)throw Error('Expected activated distributed peer');
    const {server}=createPeer({root:home,id});
    const host=process.env.OCTOLANG_BIND||'127.0.0.1';const port=Number(new URL(node.local.url).port);
    server.listen(port,host,()=>console.log(`[${id}] pinned mTLS + OFP on ${host}:${port}. No payments.`));
  }catch(e){console.error(e);process.exitCode=1;}
}
