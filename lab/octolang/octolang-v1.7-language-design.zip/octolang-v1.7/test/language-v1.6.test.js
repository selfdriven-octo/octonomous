'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const {compileLanguage,verifyArtifact,project,hashIR}=require('../language/v1.6');
const {verifyIR}=require('../language/v1.6/validate');
const {compile}=require('../src/compiler');
const {run}=require('../conformance/v1.6/runner');
const sample=name=>fs.readFileSync(path.join(__dirname,'..','examples',name),'utf8');
const source=sample('community-proofs.octo');
const flip = a=>structuredClone(a);

test('v1.6 conformance manifest: independent frozen positive and negative vectors',()=>{
  assert.equal(run(),22);
});
test('v1.6 type-checked IR: schema, digest, exact source and legacy binding',()=>{
  const a=compileLanguage(source);assert.equal(a.ir.schema,'octolang.typed-ir.v1.6');
  assert.equal(a.irDigest,hashIR(a.ir));
  assert.equal(a.legacyPolicy.digest,compile(source).digest);
  assert.equal(verifyIR(a.ir,a.irDigest).valid,true);
  assert.equal(verifyArtifact(source,a).valid,true);
  assert.equal(verifyArtifact(source+'\n',a).valid,false);
});
test('v1.6 equivalent declaration order and source comments preserve semantic digest',()=>{
  const cases=['mission-comment','mission-dependency-reorder','mission-input-reorder','mission-role-reorder'];
  const base=compileLanguage(sample('community-mission.octo'));
  for(const k of cases){const s=fs.readFileSync(path.join(__dirname,'..','conformance/v1.6/cases',k+'.octo'),'utf8');
    assert.equal(compileLanguage(s).irDigest,base.irDigest,k);
  }
});
test('v1.6 source change to real policy constraint changes IR digest',()=>{
  const variant=source.replace('max 100 ADA','max 101 ADA');
  assert.notEqual(compileLanguage(variant).irDigest,compileLanguage(source).irDigest);
});
test('v1.6 verifier rejects changed IR schedule with recomputed hash',()=>{
  const a=compileLanguage(source);const b=flip(a.ir);b.schedule.reverse();
  assert.equal(verifyIR(b,hashIR(b)).valid,false);
});
test('v1.6 verifier rejects undeclared data disclosure with recomputed hash',()=>{
  const a=compileLanguage(source),b=flip(a.ir);
  b.capabilities[0].disclosedFields[0].name='urgent';
  assert.equal(verifyIR(b,hashIR(b)).valid,false);
});
test('v1.6 verifier rejects wrong-service proof, forged authority field, unknown property',()=>{
  const a=compileLanguage(source);const b=flip(a.ir);
  const service=b.proofs.find(p=>p.kind==='service_receipt');service.serviceIdentity='other-provider';
  assert.equal(verifyIR(b,hashIR(b)).valid,false);
  const c=flip(a.ir);c.governance.grantsImplied=true;assert.equal(verifyIR(c,hashIR(c)).valid,false);
  const d=flip(a.ir);d.unknownPermission='ROOT';assert.equal(verifyIR(d,hashIR(d)).valid,false);
});
test('v1.6 verifier rejects dangling role, cyclic task dependency and missing proof',()=>{
  const a=compileLanguage(source);
  const b=flip(a.ir);b.tasks[0].role='missing';assert.equal(verifyIR(b,hashIR(b)).valid,false);
  const c=flip(a.ir);c.tasks[0].dependencies=['independent_audit'];assert.equal(verifyIR(c,hashIR(c)).valid,false);
  const d=flip(a.ir);d.tasks[0].declaredProofs=[];assert.equal(verifyIR(d,hashIR(d)).valid,false);
});
test('v1.6 verifier rejects modified source or artifact fields even if hashes are recalculated',()=>{
  const a=compileLanguage(source);const b=flip(a);b.diagnostics=[];
  assert.equal(verifyArtifact(source,b).valid,false);
  const c=flip(a);c.ir.name='evil';c.irDigest=hashIR(c.ir);
  assert.equal(verifyArtifact(source,c).valid,false);
  const d=flip(a);d.legacyPolicy.digest=crypto.randomBytes(32).toString('hex');
  assert.equal(verifyArtifact(source,d).valid,false);
});
test('v1.6 legacy score compiler is unchanged; language compiler explicitly rejects score',()=>{
  const original=sample('community-supplies.octo');assert(compile(original).schema.startsWith('octolang.policy.'));
  assert.throws(()=>compileLanguage(original),/expected mission/);
});
test('v1.6 IR includes only declared roles/capabilities and does not invent execution permission',()=>{
  const a=compileLanguage(source);
  assert.equal(a.ir.governance.grantsImplied,false);
  assert.equal(a.ir.roles.find(r=>r.name==='scout').grant,'OUT_OF_BAND_SIGNED_GRANT');
  assert.equal(a.ir.roles.find(r=>r.name==='scout').effect,'EXTERNAL_SERVICE');
  assert.equal(a.ir.capabilities[0].serviceIdentity,'notes-provider');
  assert.equal(a.ir.capabilities[0].disclosedFields.length,1);
});
test('v1.6 static diagnostics explain unused inputs but never authorise or execute',()=>{
  const a=compileLanguage(source);
  assert(a.diagnostics.some(d=>d.code==='OL1602'&&d.where==='input:urgent'));
  assert(a.diagnostics.every(d=>d.severity==='WARNING'));
});
test('v1.6 command line emits artifact which verifies from a separate file',()=>{
  const os=require('node:os'),dir=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-language-'));
  try{const input=path.join(dir,'source.octo'),output=path.join(dir,'artifact.json');fs.writeFileSync(input,source);
    const bin=path.join(__dirname,'../bin/octolang-language.js');
    execFileSync(process.execPath,[bin,'compile',input,output],{encoding:'utf8'});
    const msg=execFileSync(process.execPath,[bin,'verify',input,output],{encoding:'utf8'});
    assert.match(msg,/VERIFIED typed-ir/);
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
