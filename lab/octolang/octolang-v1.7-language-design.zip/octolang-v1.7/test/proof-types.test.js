'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {typedSource}=require('../proofs/demo');
const {compile}=require('../src/compiler');
const {verifyMission,planMission,verifyMissionEvidence}=require('../src/mission');
const {source,setup}=require('../capabilities/demo');
const {fixtures}=require('../mission/demo');
const {signed}=require('../src/canonical');
const {CapabilityRegistry}=require('../capabilities/registry');
const {MissionExecutionController,STATUS_EXT}=require('../mission/executor');
const {verifyBundle,exportPublic}=require('../capabilities/verify');
const {exportPins}=require('../mission/bundle');
const fresh=()=>fs.mkdtempSync(path.join(os.tmpdir(),'octolang-proof-test-'));
async function harness(t){
  const c=setup({missionSource:typedSource,dataDir:fresh()});
  const started=await c.start();
  t.after(()=>new Promise((resolve,reject)=>c.server.close(e=>e?reject(e):resolve())));
  const f=fixtures(c.mission,{inputs:{amount:'25',priority:'2',project:'School',urgent:false,note:'Verified evidence note'}});
  const params={mission:c.mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
  const engine=(registry=started.registry)=>new MissionExecutionController({dataDir:path.join(c.dataDir,'controller'),
    capabilityRegistry:registry,controllerKeyPair:c.controller,
    agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]))});
  const pins={...exportPins(f.trust,c.controller.publicKey),capabilityIssuers:{'community-operator':exportPublic(c.issuer.publicKey)},services:{'notes-provider':exportPublic(c.service.publicKey)}};
  const bundle=out=>({...params,trust:undefined,plan:out.plan,receipts:out.receipts,capabilityManifests:[started.manifest]});
  return {...c,...started,f,params,engine,pins,bundle};
}
const replace=(a,b)=>typedSource.replace(a,b);
test('v1.2: typed capability inputs, service identity and typed proofs are compiled into signed digest',()=>{
  const m=compile(typedSource);
  assert.equal(m.schema,'octolang.mission.v1.2');assert.equal(verifyMission(m),true);
  assert.deepEqual(m.capabilities[0].fields,[{name:'note',type:'text'}]);
  assert.equal(m.proofs.length,4);
  assert.equal(compile(source).schema,'octolang.mission.v0.9');
});
test('v1.2: modification of typed contract changes digest',()=>{
  const m=compile(typedSource),changed=structuredClone(m);changed.proofs[0].service='evil-provider';
  assert.equal(verifyMission(changed),false);
  assert.notEqual(compile(replace('fields "note:text"','fields "amount:ada"')).digest,m.digest);
});
test('v1.2: input type mismatch fails compilation',()=>assert.throws(()=>compile(replace('note:text','note:ada')),/unknown or mismatched/));
test('v1.2: unknown disclosed input fails compilation',()=>assert.throws(()=>compile(replace('note:text','secret:text')),/unknown or mismatched/));
test('v1.2: repeated disclosed input fails compilation',()=>assert.throws(()=>compile(replace('note:text','note:text,note:text')),/duplicate/));
test('v1.2: role capability mismatch fails compilation',()=>assert.throws(()=>compile(replace('name "service.note.record"','name "service.other.record"')),/match role/));
test('v1.2: role mismatch fails compilation',()=>assert.throws(()=>compile(replace('capability note_writer { role scout','capability note_writer { role auditor')),/match role/));
test('v1.2: unknown proof kind fails compilation',()=>assert.throws(()=>compile(replace('kind agent_receipt','kind groth16')),/unknown proof kind/));
test('v1.2: forged service proof declaration fails compilation',()=>assert.throws(()=>compile(replace('service_receipt service "notes-provider"','service_receipt service "evil-provider"')),/match declared capability/));
test('v1.2: absent external service proof fails compilation',()=>assert.throws(()=>compile(replace('kind service_receipt service "notes-provider"','kind controller_receipt')),/external task.*service_receipt/));
test('v1.2: tasks with no proof fail compilation',()=>assert.throws(()=>compile(replace('  proof audit_proof { task independent_audit kind agent_receipt }','')),/task independent_audit requires/));
test('v1.2: declarations must be paired',()=>assert.throws(()=>compile(replace('  proof audit_proof { task independent_audit kind agent_receipt }','').replace(/  proof (supplier_proof|vetted_proof|intent_proof) \{[^\n]*\}\n/g,'')),/typed missions require/));
test('v1.2: signed external service, controller and agent proof types validate independently',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params);
  assert.equal(out.status,'COMPLETED_CAPABILITY_MISSION');
  const v=verifyBundle(h.bundle(out),h.pins);
  assert.equal(v.status,STATUS_EXT);assert.equal(v.typedProofs.length,4);
  assert.deepEqual(v.typedProofs.map(x=>x.kind),['service_receipt','controller_receipt','controller_receipt','agent_receipt']);
  assert.equal(fs.readdirSync(path.join(h.dataDir,'service-notes')).length,1);
});
test('v1.2: signed manifest with extra input disclosure is denied before invoking service',async t=>{
  const h=await harness(t),alt=signed({...h.manifest.payload,inputFields:['note','project']},h.issuer.privateKey);
  const r=new CapabilityRegistry({manifests:[alt],issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'notes-provider':h.service.publicKey},allowLoopbackHttp:true});
  const out=await h.engine(r).execute(h.params);
  assert.equal(out.status,'DENY');assert.match(out.reason,/Typed capability contract/);
  assert.equal(fs.readdirSync(path.join(h.dataDir,'service-notes')).length,0);
});
test('v1.2: signed manifest with missing required input disclosure is denied',async t=>{
  const h=await harness(t),alt=signed({...h.manifest.payload,inputFields:[]},h.issuer.privateKey);
  const r=new CapabilityRegistry({manifests:[alt],issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'notes-provider':h.service.publicKey},allowLoopbackHttp:true});
  assert.equal((await h.engine(r).execute(h.params)).status,'DENY');
});
test('v1.2: validly signed alternate service identity cannot bypass typed source service binding',async t=>{
  const h=await harness(t),alt=signed({...h.manifest.payload,service:'other-provider'},h.issuer.privateKey);
  const r=new CapabilityRegistry({manifests:[alt],issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'other-provider':crypto.generateKeyPairSync('ed25519').publicKey},allowLoopbackHttp:true});
  assert.equal((await h.engine(r).execute(h.params)).status,'DENY');
});
test('v1.2: independent proof verifier denies altered signed service receipt',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params);
  const mutated=structuredClone(h.bundle(out));mutated.receipts[0].result.serviceReceipt.payload.service='other-provider';
  assert.equal(verifyBundle(mutated,h.pins).status,'DENY');
});
test('v1.2: independent proof verifier denies wrong public service signer',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params);
  const wrong={...h.pins,services:{'notes-provider':exportPublic(crypto.generateKeyPairSync('ed25519').publicKey)}};
  assert.equal(verifyBundle(h.bundle(out),wrong).status,'DENY');
});
test('v1.2: typed mission simulation cannot claim proof of execution',async t=>{
  const h=await harness(t),plan=planMission(h.params);
  assert.equal(plan.status,'READY_FOR_SIMULATION');
  assert.equal(verifyMissionEvidence({...h.params,plan:plan.plan,receipts:[]}).status,'DENY');
});
test('v1.2: unsupported declared service without operator manifest fails closed',async t=>{
  const h=await harness(t);
  const registry=new CapabilityRegistry({issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'notes-provider':h.service.publicKey},allowLoopbackHttp:true});
  assert.equal((await h.engine(registry).execute(h.params)).status,'DENY');
});
test('v1.2: repeating signed mission request across controller restart is denied',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params);
  assert.equal(out.status,'COMPLETED_CAPABILITY_MISSION');
  assert.equal((await h.engine().execute(h.params)).status,'DENY');
  assert.equal(fs.readdirSync(path.join(h.dataDir,'service-notes')).length,1);
});
test('v1.2: Studio can draft a typed mission for human review but grants no execution authority',async()=>{
  const {MissionStudio}=require('../studio/mission');
  const studio=new MissionStudio({trusted:{reviewers:{}},dataDir:fresh()});
  const d=await studio.compose('Prepare evidence-based supplier report','offline-typed');
  assert.equal(d.mission.schema,'octolang.mission.v1.2');
  assert.match(d.mission.goal,/Prepare evidence-based supplier report/);
  await assert.rejects(()=>studio.executeDemo(),/human-signed review/);
});
