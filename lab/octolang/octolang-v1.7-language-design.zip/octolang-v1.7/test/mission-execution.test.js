'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {compile}=require('../src/compiler');
const {template,fixtures}=require('../mission/demo');
const {MissionExecutionController,verifyExecutionEvidence}=require('../mission/executor');
const {Studio}=require('../studio/core');const {createServer}=require('../studio/server');
const {signed}=require('../src/canonical');
const mission=compile(template);
const tmp=()=>fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v1-test-'));
const keys=f=>Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]));
const params=f=>({mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust});
const run=async (f=fixtures(mission),dataDir=tmp(),other={})=>{
  const engine=new MissionExecutionController({dataDir,agentPrivateKeys:keys(f),...other});
  return {f,engine,result:await engine.execute(params(f)),dataDir};
};
const rows=root=>fs.readFileSync(path.join(root,'local-intents.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
const check=({f,engine,result,dataDir},extra={})=>verifyExecutionEvidence({...params(f),plan:result.plan,
  receipts:result.receipts,controllerPublicKey:engine.controllerKeys.publicKey,journalEntries:rows(dataDir),...extra});

test('v1 controller: four real Octonomous runtime calls, signed effect and agent evidence',async()=>{
  const r=await run();assert.equal(r.result.status,'COMPLETED_LOCAL_MISSION');
  assert.deepEqual(r.result.receipts.map(x=>x.effectReceipt.payload.tool),
    ['mission.local.research','mission.local.validate','mission.local.record-intent','mission.local.audit']);
  assert.equal(rows(r.dataDir).length,1);
  assert.equal(check(r).status,'VERIFIED_LOCAL_EXECUTION_RECEIPTS');
});
test('v1: durable nonce reservation blocks replay across a new controller instance',async()=>{
  const f=fixtures(mission),root=tmp(),x=await run(f,root);assert.equal(x.result.status,'COMPLETED_LOCAL_MISSION');
  assert.equal((await new MissionExecutionController({dataDir:root,agentPrivateKeys:keys(f)}).execute(params(f))).status,'DENY');
  assert.equal(rows(root).length,1);
});
test('v1: concurrent execution allows no duplicate journal effects',async()=>{
  const f=fixtures(mission),root=tmp(),a=new MissionExecutionController({dataDir:root,agentPrivateKeys:keys(f)}),
    b=new MissionExecutionController({dataDir:root,agentPrivateKeys:keys(f)});
  const results=await Promise.all([a.execute(params(f)),b.execute(params(f))]);
  assert.deepEqual(results.map(x=>x.status).sort(),['COMPLETED_LOCAL_MISSION','DENY']);
  assert.equal(rows(root).length,1);
});
test('v1: signed human approval required before any reservation or side effect',async()=>{
  const f=fixtures(mission),root=tmp(),p={...params(f),review:null};
  const out=await new MissionExecutionController({dataDir:root,agentPrivateKeys:keys(f)}).execute(p);
  assert.equal(out.status,'DENY');assert.equal(fs.readdirSync(path.join(root,'claims')).length,0);
});
test('v1: exceeding typed constraints fails closed without execution',async()=>{
  const f=fixtures(mission,{inputs:{amount:'101',priority:'3',project:'Project',urgent:false}});
  const r=await run(f);assert.equal(r.result.status,'DENY');assert.equal(fs.existsSync(path.join(r.dataDir,'local-intents.jsonl')),false);
});
test('v1: forged capability grants and altered context denied before tool invocation',async()=>{
  const f=fixtures(mission);f.grants[0].payload.capability='wallet.transfer';
  assert.equal((await run(f)).result.status,'DENY');
  const f2=fixtures(mission);f2.claims[0].payload.subject='unknown';
  assert.equal((await run(f2)).result.status,'DENY');
});
test('v1: no arbitrary tool dispatch, even with valid signed role grants',async()=>{
  const source=template.replace('capability "research"','capability "wallet.transfer"');
  const custom=compile(source),f=fixtures(custom),root=tmp();
  const out=await new MissionExecutionController({dataDir:root,agentPrivateKeys:keys(f)}).execute({...params(f),mission:custom});
  assert.equal(out.status,'DENY');assert.match(out.reason,/No enabled local tool/);
});
test('v1: signer private key must correspond to independently trusted agent key',async()=>{
  const f=fixtures(mission),signers=keys(f);signers.scout=crypto.generateKeyPairSync('ed25519').privateKey;
  const root=tmp(),out=await new MissionExecutionController({dataDir:root,agentPrivateKeys:signers}).execute(params(f));
  assert.equal(out.status,'DENY');assert.equal(fs.existsSync(path.join(root,'local-intents.jsonl')),false);
});
test('v1: tampered effect receipt or altered local record fails independent verification',async()=>{
  const r=await run();const a=structuredClone(r.result.receipts);
  a[0].result.outcome='FAKED';assert.equal(check(r,{receipts:a}).status,'DENY');
  const b=structuredClone(r.result.receipts);b[1].effectReceipt.payload.tool='wallet.transfer';
  assert.equal(check(r,{receipts:b}).status,'DENY');
  assert.equal(check(r,{journalEntries:[]}).status,'DENY');
});
test('v1: verifier rejects broken predecessor and non-matching controller trust key',async()=>{
  const r=await run(),bad=structuredClone(r.result.receipts);
  bad[3].agentReceipt.payload.dependencies.record_intent='random';
  assert.equal(check(r,{receipts:bad}).status,'DENY');
  assert.equal(check(r,{controllerPublicKey:crypto.generateKeyPairSync('ed25519').publicKey}).status,'DENY');
});
test('v1: an uncertain failure is sticky and requires reconciliation before retry',async()=>{
  const f=fixtures(mission),root=tmp();
  const broken=await run(f,root,{toolHook:async slot=>{if(slot.step.label==='record_intent')throw Error('simulated uncertain I/O');}});
  assert.equal(broken.result.status,'REQUIRES_RECONCILIATION');
  assert.deepEqual(broken.result.completedSteps,['find_supplier','vet_supplier']);
  const replay=await new MissionExecutionController({dataDir:root,agentPrivateKeys:keys(f)}).execute(params(f));
  assert.equal(replay.status,'DENY');
  assert.equal(fs.existsSync(path.join(root,'local-intents.jsonl')),false);
});
test('v1: signed claim revocation/missing grant at verification time denies completion',async()=>{
  const r=await run();assert.equal(check(r,{grants:[]}).status,'DENY');
  assert.equal(check(r,{claims:[]}).status,'DENY');
  assert.equal(check(r,{review:null}).status,'DENY');
});
test('v1: only recorded intent with correct request binding counts as complete',async()=>{
  const r=await run(),broken=structuredClone(r.result.receipts);
  broken[2].result.record.requestDigest='fake';
  assert.equal(check(r,{receipts:broken}).status,'DENY');
});
test('v1 Studio: human-signed review enables explicit local execution endpoint, source edit revokes',async()=>{
  const root=tmp(),studio=new Studio({pairingCode:'PAIR',dataDir:root}),key=crypto.generateKeyPairSync('ed25519');
  studio.enroll('PAIR',key.publicKey.export({type:'spki',format:'der'}).toString('base64'));
  const {server}=createServer({studio,openAIAdapter:null});
  await new Promise(done=>server.listen(0,'127.0.0.1',done));
  const url=`http://127.0.0.1:${server.address().port}`;
  const call=async(route,body)=>{const res=await fetch(url+'/api/'+route,{method:'POST',headers:{'Content-Type':'application/json','x-octolang-local':'studio'},body:JSON.stringify(body)});return {status:res.status,data:await res.json()};};
  const input={subject:'supplier-42',inputs:{amount:'35',priority:'3',project:'School',urgent:false}};
  try{
    const created=await call('mission/compose',{goal:'Resource research',mode:'offline'});
    assert.equal(created.status,200);
    assert.equal((await call('mission/execute-local',input)).status,403);
    const now=Date.now();const review=signed({schema:'octolang.review.v1',reviewer:'local-reviewer',scoreDigest:created.data.mission.digest,
      issuedAt:new Date(now-1000).toISOString(),expiresAt:new Date(now+240000).toISOString(),nonce:crypto.randomUUID()},key.privateKey);
    assert.equal((await call('mission/review',{review})).status,200);
    const executed=await call('mission/execute-local',input);
    assert.equal(executed.status,200);assert.equal(executed.data.status,'COMPLETED_LOCAL_MISSION');
    assert.equal(rows(path.join(root,'mission-execution-v1')).length,1);
    assert.equal((await call('mission/compile',{source:template.replace('record an intent','record a learning intent')})).status,200);
    assert.equal((await call('mission/execute-local',input)).status,403);
  }finally {await new Promise(done=>server.close(done));}
});

test('v1: exported evidence verifies independently with pinned public keys and journal only',async()=>{
  const {exportPins,importPins,verifyFiles}=require('../mission/bundle');
  const r=await run(),trustPins=exportPins(r.f.trust,r.engine.controllerKeys.publicKey);
  assert.equal(importPins(trustPins).trust.agents.scout.asymmetricKeyType,'ed25519');
  const evidenceFile=path.join(r.dataDir,'bundle.json'),pinsFile=path.join(r.dataDir,'pins.json');
  fs.writeFileSync(evidenceFile,JSON.stringify({...params(r.f),plan:r.result.plan,receipts:r.result.receipts,trust:undefined}));
  fs.writeFileSync(pinsFile,JSON.stringify(trustPins));
  assert.equal(verifyFiles(evidenceFile,pinsFile,path.join(r.dataDir,'local-intents.jsonl')).status,'VERIFIED_LOCAL_EXECUTION_RECEIPTS');
  trustPins.controller=crypto.generateKeyPairSync('ed25519').publicKey.export({type:'spki',format:'der'}).toString('base64');
  fs.writeFileSync(pinsFile,JSON.stringify(trustPins));
  assert.equal(verifyFiles(evidenceFile,pinsFile,path.join(r.dataDir,'local-intents.jsonl')).status,'DENY');
});
