'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { compile } = require('../src/compiler');
const { demoSetup } = require('../src/demo');
const { signed, digest } = require('../src/canonical');
const { EnsembleEngine } = require('../ensemble/engine');
const { verifyTranscript, verifyPartialTranscript } = require('../ensemble/verify');
const { Studio } = require('../studio/core');
const { createServer } = require('../studio/server');
const src = fs.readFileSync(path.join(__dirname,'../examples/community-ensemble.octo'),'utf8');
const newLocal = t => { const dir = fs.mkdtempSync(path.join(os.tmpdir(),'octolang-ensemble-test-')); t.after(() => fs.rmSync(dir,{recursive:true,force:true})); return dir; };
const make = () => { const s = demoSetup(src); const request = s.request('75');
  return { policy:s.policy, request, claims:[s.claim()], approvals:[s.approval(request)], review:s.review, trusted:s.trusted }; };
const keys = result => Object.fromEntries(Object.entries(result.agentPublicKeysSpki).map(([id,spki]) => [id, crypto.createPublicKey({key:Buffer.from(spki,'base64'),format:'der',type:'spki'})]));
const run = async (inputs, dir) => { const engine = new EnsembleEngine({dataDir:dir}); engine.registerDemoAgents(inputs.policy);
  return { engine, result: await engine.run(inputs) }; };

test('compiler binds three agent roles and a sequential dependency graph', () => {
  const p = compile(src);
  assert.equal(p.schema, 'octolang.policy.v0.4');
  assert.deepEqual(p.ensemble.steps.map(x=>x.capability), ['research','purchase','audit']);
  assert.deepEqual(p.ensemble.steps.map(x=>x.depends), ['none','find_supplier','record_purchase_intent']);
  assert.ok(p.agents.filter(a=>a.delegate===false).length===3);
});
test('compiler refuses capability elevation, spending authority and dependency skipping', () => {
  const mutations = [
    src.replace('agent scout {\n    capability "research"','agent scout {\n    capability "purchase"'),
    src.replace('capability "research"\n    limit 0 ADA','capability "research"\n    limit 1 ADA'),
    src.replace('depends find_supplier','depends none'),
    src.replace('depends record_purchase_intent','depends find_supplier'),
    src.replace('agent checker {\n    capability "audit"\n    limit 0 ADA','agent checker {\n    capability "audit"\n    limit 0 ADA\n    delegate true'),
    src.replace('require accredited_provider\n      evidence "signed.audit-summary"','require unknown_issuer\n      evidence "signed.audit-summary"'),
    src.replace('agent checker\n      capability "audit"','agent scout\n      capability "audit"')
  ];
  for (const s of mutations) assert.throws(()=>compile(s));
});
test('approved score executes three signed, independently verifiable stages and one journal append', async t => {
  const dir = newLocal(t), inputs = make(), { result } = await run(inputs,dir);
  assert.equal(result.status, 'COMPLETED_LOCAL_DEMO', result.reason);
  assert.equal(result.contributions.length, 3);
  assert.equal(result.verified.verified, true);
  assert.equal(verifyTranscript({inputs,contributions:result.contributions,trustedAgentKeys:keys(result),receiptSignerPublicKeySpki:result.receiptSignerPublicKeySpki}).verified,true);
  assert.equal(fs.readFileSync(path.join(dir,'local-intents.jsonl'),'utf8').trim().split('\n').length,1);
  assert.equal(result.contributions[1].output.record.supplier,'supplier-42');
  assert.ok(result.verified.chainHead);
});
test('independent verification rejects forged agent key, altered output, invalid ordering and broken chain', async t => {
  const inputs=make(), {result}=await run(inputs,newLocal(t));
  assert.equal(result.status,'COMPLETED_LOCAL_DEMO');
  const common={inputs,contributions:result.contributions,trustedAgentKeys:keys(result),receiptSignerPublicKeySpki:result.receiptSignerPublicKeySpki};
  const wrong={...keys(result),scout:crypto.generateKeyPairSync('ed25519').publicKey};
  assert.throws(()=>verifyTranscript({...common,trustedAgentKeys:wrong}),/untrusted/);
  assert.throws(()=>verifyTranscript({...common, contributions:[...result.contributions].reverse()}));
  assert.throws(()=>verifyTranscript({...common, contributions:result.contributions.slice(0,2)}),/Incomplete/);
  const changed=structuredClone(result.contributions);
  changed[0].output.target='injected-supplier';
  assert.throws(()=>verifyTranscript({...common,contributions:changed}),/not bound/);
  const broken=structuredClone(result.contributions);
  broken[2].attestation.payload.priorDigest='0'.repeat(64);
  assert.throws(()=>verifyTranscript({...common,contributions:broken}),/untrusted|not bound/);
  const reduced=structuredClone(result.contributions);
  reduced[1].output.record.amount='150';
  assert.throws(()=>verifyTranscript({...common,contributions:reduced}),/not bound/);
});
test('partial verifier binds and authenticates first agent before next stage', async t => {
  const inputs=make(), {result}=await run(inputs,newLocal(t));
  const common={inputs,trustedAgentKeys:keys(result),receiptSignerPublicKeySpki:result.receiptSignerPublicKeySpki};
  assert.equal(verifyPartialTranscript({...common,contributions:result.contributions.slice(0,1)}).verified,true);
  assert.equal(verifyPartialTranscript({...common,contributions:result.contributions.slice(0,2)}).verified,true);
});
test('unreviewed, over budget and missing steward cannot produce any contribution or effect', async t => {
  const dir=newLocal(t), setup=make(), engine=new EnsembleEngine({dataDir:dir});engine.registerDemoAgents(setup.policy);
  const denied=await engine.run({...setup,review:null});
  const escalated=await engine.run({...setup,approvals:[]});
  const overpriced=demoSetup(src);const over=overpriced.request('150');
  const overspent=await engine.run({policy:overpriced.policy,request:over,review:overpriced.review,claims:[overpriced.claim()],approvals:[],trusted:overpriced.trusted});
  assert.equal(denied.status,'DENY');assert.equal(escalated.status,'ESCALATE');assert.equal(overspent.status,'DENY');
  assert.deepEqual(denied.contributions,[]);
  assert.equal(fs.existsSync(path.join(dir,'local-intents.jsonl')),false);
});
test('repeated and simultaneous score requests never record twice', async t => {
  const dir=newLocal(t), inputs=make(), engine=new EnsembleEngine({dataDir:dir}); engine.registerDemoAgents(inputs.policy);
  const [a,b]=await Promise.all([engine.run(inputs),engine.run(inputs)]);
  assert.deepEqual([a.status,b.status].sort(), ['COMPLETED_LOCAL_DEMO','DENY']);
  assert.equal((await engine.run(inputs)).status,'DENY');
  assert.equal(fs.readFileSync(path.join(dir,'local-intents.jsonl'),'utf8').trim().split('\n').length,1);
});
test('studio ensemble requires exact human review and mock steward approval', async t => {
  const studio=new Studio({pairingCode:'ensemble-test',dataDir:newLocal(t)});
  studio.compose('Research, record and audit project material purchase', 'offline-ensemble');
  assert.ok(studio.draft.policy.ensemble);
  assert.throws(()=>studio.prepare({amount:'75',target:'supplier-42'}),/review/);
  const reviewer=crypto.generateKeyPairSync('ed25519');
  studio.enroll('ensemble-test',reviewer.publicKey.export({type:'spki',format:'der'}).toString('base64'));
  const now=Date.now();
  studio.acceptReview(signed({schema:'octolang.review.v1',reviewer:'local-reviewer',scoreDigest:studio.draft.policy.digest,
    issuedAt:new Date(now-1000).toISOString(),expiresAt:new Date(now+3600000).toISOString(),nonce:crypto.randomUUID()},reviewer.privateKey));
  const pending=studio.prepare({amount:'75',target:'supplier-42'});
  assert.equal((await studio.runEnsemble(pending.id)).status,'ESCALATE');
  studio.approve(pending.id);
  assert.equal((await studio.runEnsemble(pending.id)).status,'COMPLETED_LOCAL_DEMO');
  assert.equal((await studio.runEnsemble(pending.id)).status,'DENY');
  studio.setSource(src.replace('score community_ensemble','score altered_ensemble'));
  assert.equal(studio.approved(),false);
});
test('studio HTTP ensemble endpoint requires local request header, approval and returns verified chain', async t => {
  const studio=new Studio({pairingCode:'ensemble-http',dataDir:newLocal(t)});
  const {server}=createServer({studio,openAIAdapter:null});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const base=`http://127.0.0.1:${server.address().port}`;
  const post=async(route,body,header='studio')=>{
    const response=await fetch(base+'/api/'+route,{method:'POST',headers:{'content-type':'application/json','x-octolang-local':header},body:JSON.stringify(body)});
    return {status:response.status,body:await response.json()};
  };
  const c=await post('compose',{mode:'offline-ensemble',intent:'Research and purchase project supplies'});
  assert.equal(c.status,200);assert.equal(c.body.policy.ensemble.steps.length,3);
  const reviewer=crypto.generateKeyPairSync('ed25519');
  await post('enroll',{pairingCode:'ensemble-http',publicKeySpki:reviewer.publicKey.export({type:'spki',format:'der'}).toString('base64')});
  const now=Date.now();await post('review',{review:signed({schema:'octolang.review.v1',reviewer:'local-reviewer',scoreDigest:c.body.policy.digest,
    nonce:crypto.randomUUID(),issuedAt:new Date(now-1000).toISOString(),expiresAt:new Date(now+3600000).toISOString()},reviewer.privateKey)});
  const prep=await post('prepare',{amount:'75',target:'supplier-42'});
  assert.equal((await post('ensemble-run',{id:prep.body.id},'bad')).status,403);
  await post('steward-approve',{id:prep.body.id});
  const result=await post('ensemble-run',{id:prep.body.id});
  assert.equal(result.status,200);assert.equal(result.body.status,'COMPLETED_LOCAL_DEMO');
});
