'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const crypto=require('node:crypto');const path=require('node:path');const os=require('node:os');
const {fixtures}=require('../mission/demo');
const {setup}=require('../capabilities/demo');
const {CapabilityRegistry,CAP_SCHEMA,endpointAllowed,ipPublic}=require('../capabilities/registry');
const {MissionExecutionController,verifyExecutionEvidence,STATUS_EXT}=require('../mission/executor');
const {signed,digest}=require('../src/canonical');
const fresh=()=>fs.mkdtempSync(path.join(os.tmpdir(),'octolang-capability-test-'));
async function harness(t){
  const c=setup({dataDir:fresh()});const started=await c.start();
  t.after(()=>new Promise((resolve,reject)=>c.server.close(err=>err?reject(err):resolve())));
  const f=fixtures(c.mission,{inputs:{amount:'30',priority:'2',project:'School',urgent:false,note:'Signed community report'}});
  const params={mission:c.mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
  const keys=Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]));
  const engine=(registry=started.registry)=>new MissionExecutionController({dataDir:path.join(c.dataDir,'controller'),
    agentPrivateKeys:keys,controllerKeyPair:c.controller,capabilityRegistry:registry});
  const verify=(out,registry=started.registry,changes={})=>verifyExecutionEvidence({...params,
    plan:out.plan,receipts:out.receipts,controllerPublicKey:c.controller.publicKey,
    capabilityRegistry:registry,...changes});
  return {...c,...started,f,params,engine,verify,keys};
}
test('v1.1: approved external service writes exactly one note and verifies 2 independent signatures',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params);
  assert.equal(out.status,'COMPLETED_CAPABILITY_MISSION');
  assert.equal(out.externalToolsExecuted,true);
  assert.equal(h.verify(out).status,STATUS_EXT);
  assert.equal(fs.readdirSync(path.join(h.dataDir,'service-notes')).length,1);
  assert.equal(out.receipts[0].result.record.note,'Signed community report');
});
test('v1.1: default registry blocks all external execution',async t=>{
  const h=await harness(t),out=await h.engine(null).execute(h.params);
  assert.equal(out.status,'DENY');
});
test('v1.1: forged manifest cannot register',async t=>{
  const h=await harness(t),manifest=structuredClone(h.manifest);manifest.payload.inputFields=['amount'];
  assert.throws(()=>new CapabilityRegistry({manifests:[manifest],issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'notes-provider':h.service.publicKey},allowLoopbackHttp:true}),/invalid/);
});
test('v1.1: signed manifest cannot be used for a different mission',async t=>{
  const h=await harness(t),untrusted=crypto.generateKeyPairSync('ed25519');
  const r=new CapabilityRegistry({manifests:[h.manifest],issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'notes-provider':untrusted.publicKey},allowLoopbackHttp:true});
  assert.throws(()=>r.resolve('service.note.record','f'.repeat(64)),/mission scope/);
});
test('v1.1: independently pinned wrong service key prevents completion',async t=>{
  const h=await harness(t),wrong=crypto.generateKeyPairSync('ed25519');
  const r=new CapabilityRegistry({manifests:[h.manifest],issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'notes-provider':wrong.publicKey},allowLoopbackHttp:true});
  const out=await h.engine(r).execute(h.params);
  assert.equal(out.status,'REQUIRES_RECONCILIATION');
  assert.equal(h.verify(out,r).status,'DENY');
});
test('v1.1: direct unauthorised caller cannot request service effect',async t=>{
  const h=await harness(t);
  const res=await fetch(h.endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({request:{schema:'octolang.capability-request.v1'},authorization:{}})});
  assert.equal(res.status,403);assert.equal(fs.readdirSync(path.join(h.dataDir,'service-notes')).length,0);
});
test('v1.1: completed mission cannot repeat external side effect across restarts',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params);
  assert.equal(out.status,'COMPLETED_CAPABILITY_MISSION');
  const again=await h.engine().execute(h.params);
  assert.equal(again.status,'DENY');assert.equal(fs.readdirSync(path.join(h.dataDir,'service-notes')).length,1);
});
test('v1.1: tampered external service record or receipt fails independent verification',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params);
  assert.equal(out.status,'COMPLETED_CAPABILITY_MISSION');
  const a=structuredClone(out.receipts);a[0].result.record.note='Forged';
  assert.equal(h.verify(out,h.registry,{receipts:a}).status,'DENY');
  const b=structuredClone(out.receipts);b[0].result.serviceReceipt.payload.status='DENIED';
  assert.equal(h.verify(out,h.registry,{receipts:b}).status,'DENY');
  const c=structuredClone(out.receipts);c[0].result.authorization.signature='A'.repeat(88);
  assert.equal(h.verify(out,h.registry,{receipts:c}).status,'DENY');
});
test('v1.1: altered approval or grant stops operation before external service',async t=>{
  const h=await harness(t);h.params.review=null;
  assert.equal((await h.engine().execute(h.params)).status,'DENY');
  assert.equal(fs.readdirSync(path.join(h.dataDir,'service-notes')).length,0);
});
test('v1.1: manifest expiration checked on each invocation',async t=>{
  const h=await harness(t),past=Date.now()-1000,old=signed({...h.manifest.payload,issuedAt:new Date(past-1000).toISOString(),expiresAt:new Date(past).toISOString()},h.issuer.privateKey);
  assert.throws(()=>new CapabilityRegistry({manifests:[old],issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'notes-provider':h.service.publicKey},allowLoopbackHttp:true}),/invalid/);
});
test('v1.1: network access deny by default; no arbitrary hostname, localhost or metadata IP',()=>{
  assert.equal(endpointAllowed('http://127.0.0.1:1234/v1/execute'),false);
  assert.equal(endpointAllowed('http://127.0.0.1:1234/v1/execute',{allowLoopbackHttp:true}),true);
  assert.equal(endpointAllowed('http://169.254.169.254/v1/execute',{allowLoopbackHttp:true}),false);
  assert.equal(endpointAllowed('http://localhost:1234/v1/execute',{allowLoopbackHttp:true}),false);
  assert.equal(endpointAllowed('https://services.example.com/v1/execute',{allowRemoteHttps:true}),true);
  assert.equal(endpointAllowed('https://services.example.internal/v1/execute',{allowRemoteHttps:true}),false);
  assert.equal(endpointAllowed('https://services.example.com/v1/execute?to=evil',{allowRemoteHttps:true}),false);
  assert.equal(ipPublic('10.0.0.1'),false);assert.equal(ipPublic('127.0.0.1'),false);
  assert.equal(ipPublic('169.254.169.254'),false);assert.equal(ipPublic('8.8.8.8'),true);
});
test('v1.1: no runtime tool may execute when capability is not in signed manifest',async t=>{
  const h=await harness(t);
  const plain=new CapabilityRegistry({issuerKeys:{'community-operator':h.issuer.publicKey},
    serviceKeys:{'notes-provider':h.service.publicKey},allowLoopbackHttp:true});
  assert.equal((await h.engine(plain).execute(h.params)).status,'DENY');
});
test('v1.1: independent exported proof verifies with out-of-band pins and fails on wrong signer',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params);
  assert.equal(out.status,'COMPLETED_CAPABILITY_MISSION');
  const {exportPins}=require('../mission/bundle');
  const {verifyBundle,exportPublic}=require('../capabilities/verify');
  const pins={...exportPins(h.f.trust,h.controller.publicKey),
    capabilityIssuers:{'community-operator':exportPublic(h.issuer.publicKey)},
    services:{'notes-provider':exportPublic(h.service.publicKey)}};
  const bundle={...h.params,trust:undefined,plan:out.plan,receipts:out.receipts,capabilityManifests:[h.manifest]};
  assert.equal(verifyBundle(bundle,pins).status,STATUS_EXT);
  const wrong={...pins,services:{'notes-provider':exportPublic(crypto.generateKeyPairSync('ed25519').publicKey)}};
  assert.equal(verifyBundle(bundle,wrong).status,'DENY');
});
test('v1.1: remote service idempotency returns one identical signed result for repeated authorised request',async t=>{
  const h=await harness(t),out=await h.engine().execute(h.params),first=out.receipts[0].result;
  assert.equal(out.status,'COMPLETED_CAPABILITY_MISSION');
  const result=await fetch(h.endpoint,{method:'POST',headers:{'content-type':'application/json'},
    body:JSON.stringify({request:first.serviceRequest,authorization:first.authorization})});
  assert.equal(result.status,200);
  const retry=await result.json();
  assert.equal(digest(retry.serviceReceipt),digest(first.serviceReceipt));
  assert.equal(fs.readdirSync(path.join(h.dataDir,'service-notes')).length,1);
});
