'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { demoSetup } = require('../src/demo');
const { signed } = require('../src/canonical');
const { OctonomousBridge, Octonomous } = require('../integration/bridge');
const { buildSnapshot } = require('../integration/vcg');
const { assess } = require('../integration/vcc');
const { verifyLocalReceipt } = require('../integration/verify');
const { Studio, makeOfflineDraft } = require('../studio/core');
const { createServer } = require('../studio/server');
const SOURCE = fs.readFileSync(path.join(__dirname, '../examples/community-supplies.octo'), 'utf8');
function inputs(amount = '75') {
  const setup = demoSetup(SOURCE), request = setup.request(amount);
  return { policy: setup.policy, request, review: setup.review, claims: [setup.claim()],
    approvals: [setup.approval(request)], trusted: setup.trusted };
}
const local = t => { const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octolang-test-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true })); return dir; };
const journal = dir => path.join(dir, 'local-intents.jsonl');

test('bridge uses original Octonomous 1.0 Runtime, Policy and ToolRegistry with actual local journal effect', async t => {
  const dir = local(t), bridge = new OctonomousBridge({ dataDir: dir });
  assert.ok(bridge.runtime instanceof Octonomous.Runtime);
  assert.ok(bridge.tools instanceof Octonomous.ToolRegistry);
  const result = await bridge.dispatch(inputs());
  assert.equal(result.decision.status, 'ALLOW');
  assert.equal(result.runtime.governance.status, 'authorised');
  assert.equal(result.status, 'RECORDED_LOCAL_INTENT');
  assert.equal(result.effect.record.outcome, 'RECORDED_LOCAL_INTENT');
  assert.ok(fs.existsSync(journal(dir)));
  assert.equal(fs.readFileSync(journal(dir), 'utf8').trim().split('\n').length, 1);
  assert.equal(verifyLocalReceipt({ record: result.effect.record, receipt: result.effect.receipt,
    receiptSignerPublicKeySpki: result.receiptPublicKeySpki }), true);
  const stored = await bridge.fileStore.loadBeing(result.runtime.beingId);
  assert.equal(stored.memory.reflections.length, 1);
  assert.equal(stored.memory.reflections[0].governance.allowed, true);
});

test('no human review or no steward approval means zero effect', async t => {
  const dir = local(t), bridge = new OctonomousBridge({ dataDir: dir });
  const i = inputs();
  const unsigned = await bridge.dispatch({ ...i, review: null });
  const unstewarded = await bridge.dispatch({ ...i, approvals: [] });
  assert.equal(unsigned.decision.status, 'DENY');
  assert.equal(unstewarded.decision.status, 'ESCALATE');
  assert.equal(fs.existsSync(journal(dir)), false);
});

test('invalid or contradictory VCG evidence cannot produce a local effect', async t => {
  const dir = local(t), bridge = new OctonomousBridge({ dataDir: dir });
  const i = inputs('10');
  const conflict = { ...i.claims[0], payload: { ...i.claims[0].payload, status: 'CONFLICTED' } };
  const issuer = crypto.generateKeyPairSync('ed25519');
  const revoked = signed({ ...i.claims[0].payload, status: 'REVOKED' }, issuer.privateKey);
  const signedInput = { ...i, claims: [revoked], trusted: { ...i.trusted, issuers: { 'community-registry': issuer.publicKey } } };
  assert.throws(() => buildSnapshot(signedInput), /contradictory or revoked/);
  assert.equal((await bridge.dispatch({ ...i, claims: [conflict] })).decision.status, 'DENY');
  const invalid = await bridge.dispatch(signedInput);
  assert.equal(invalid.decision.status, 'DENY');
  assert.equal(fs.existsSync(journal(dir)), false);
});

test('replay is denied even across concurrent duplicate dispatch calls', async t => {
  const dir = local(t), bridge = new OctonomousBridge({ dataDir: dir });
  const i = inputs('10');
  const [a, b] = await Promise.all([bridge.dispatch(i), bridge.dispatch(i)]);
  assert.deepEqual([a, b].map(x => x.decision.status).sort(), ['ALLOW', 'DENY']);
  assert.equal(fs.readFileSync(journal(dir), 'utf8').trim().split('\n').length, 1);
});

test('unverified injected runtime event cannot directly call the confined tool', async t => {
  const dir = local(t), bridge = new OctonomousBridge({ dataDir: dir });
  await bridge.runtime.registerBeing({ id:'untrusted-demo', identity:{},
    authority:{ allowedTools:['record.purchase.intent'] }, subscriptions:['octolang.authorised-action'] });
  const result = await bridge.runtime.handleEventForBeing('untrusted-demo', { id:'injected',
    type:'octolang.authorised-action', payload: { grantId:'not-issued', requestDigest:'fake' } });
  assert.equal(result.actionResult.skipped, true);
  await assert.rejects(bridge.tools.execute('record.purchase.intent', { grantId:'fake' }, {}), /one-use grant/);
  assert.equal(fs.existsSync(journal(dir)), false);
});

test('local receipt verification checks exact record digest and trusted key', async t => {
  const bridge = new OctonomousBridge({ dataDir: local(t) });
  const result = await bridge.dispatch(inputs('10'));
  const altered = { ...result.effect.record, amount: '11' };
  const params = { record: altered, receipt: result.effect.receipt, receiptSignerPublicKeySpki: result.receiptPublicKeySpki };
  assert.equal(verifyLocalReceipt(params), false);
  assert.equal(verifyLocalReceipt({ ...params, record: result.effect.record, receiptSignerPublicKeySpki: 'bad' }), false);
});

test('studio supports browser-approved local intent recording and shares nonce replay state with simulator', async t => {
  const studio = new Studio({ pairingCode:'pair-here', dataDir:local(t) });
  studio.setSource(makeOfflineDraft('Purchase notebooks'));
  const human = crypto.generateKeyPairSync('ed25519');
  studio.enroll('pair-here', human.publicKey.export({ type:'spki', format:'der' }).toString('base64'));
  const now = Date.now();
  studio.acceptReview(signed({ schema: 'octolang.review.v1', reviewer: 'local-reviewer',
    scoreDigest: studio.draft.policy.digest, nonce:crypto.randomUUID(),
    issuedAt: new Date(now - 1000).toISOString(), expiresAt: new Date(now + 3600000).toISOString() }, human.privateKey));
  const prepared = studio.prepare({ amount:'75', target:'supplier-42' });
  assert.equal(prepared.decision.status, 'ESCALATE');
  assert.equal((await studio.recordLocalIntent(prepared.id)).decision.status, 'ESCALATE');
  studio.approve(prepared.id);
  const result = await studio.recordLocalIntent(prepared.id);
  assert.equal(result.status, 'RECORDED_LOCAL_INTENT');
  assert.equal((await studio.simulate(prepared.id)).decision.status, 'DENY');
  const next = studio.prepare({ amount:'10', target:'supplier-42' });
  assert.equal((await studio.simulate(next.id)).decision.status, 'ALLOW');
  assert.equal((await studio.recordLocalIntent(next.id)).decision.status, 'DENY');
});

test('HTTP studio record-local endpoint is guarded and records after approval', async t => {
  const studio = new Studio({ pairingCode:'pair-http', dataDir:local(t) });
  const { server } = createServer({ studio, openAIAdapter:null });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  t.after(() => new Promise(r => server.close(r)));
  const base = `http://127.0.0.1:${server.address().port}`;
  const post = async (route, value, headers = {}) => {
    const res = await fetch(base+'/api/'+route, { method:'POST', headers:{ 'content-type':'application/json',
      'x-octolang-local':'studio', ...headers }, body:JSON.stringify(value) });
    return { status: res.status, body:await res.json() };
  };
  await post('compose', { intent:'Purchase notebooks', mode:'offline' });
  const signer = crypto.generateKeyPairSync('ed25519');
  await post('enroll', { pairingCode:'pair-http', publicKeySpki:signer.publicKey.export({ type:'spki', format:'der' }).toString('base64') });
  const now = Date.now();
  await post('review', { review:signed({ schema:'octolang.review.v1', reviewer:'local-reviewer', scoreDigest:studio.draft.policy.digest,
    nonce:crypto.randomUUID(), issuedAt:new Date(now-1000).toISOString(), expiresAt:new Date(now+3600000).toISOString() }, signer.privateKey) });
  const p = await post('prepare', { amount:'10', target:'supplier-42' });
  assert.equal((await post('record-local', { id:p.body.id }, { 'x-octolang-local':'bad' })).status, 403);
  const done = await post('record-local', { id:p.body.id });
  assert.equal(done.status, 200);
  assert.equal(done.body.status, 'RECORDED_LOCAL_INTENT');
});
