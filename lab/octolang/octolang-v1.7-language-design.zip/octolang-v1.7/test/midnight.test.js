'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const crypto=require('node:crypto');const path=require('node:path');
const fs=require('node:fs');const os=require('node:os');
const {compile}=require('../src/compiler');const {verifyMission}=require('../src/mission');
const {missionSource}=require('../midnight/demo');const {setup}=require('../capabilities/demo');const {fixtures}=require('../mission/demo');
const {MissionExecutionController}=require('../mission/executor');const {exportPins}=require('../mission/bundle');const {exportPublic}=require('../capabilities/verify');
const {LocalMidnightFixture}=require('../midnight/local-adapter');
const B=require('../midnight/bridge');
const sampleSalt='7f'.repeat(32);
async function harness(t){
  const h=setup({missionSource,dataDir:fs.mkdtempSync(path.join(os.tmpdir(),'octolang-midnight-test-'))});
  const s=await h.start();t.after(()=>new Promise(resolve=>h.server.close(resolve)));
  const f=fixtures(h.mission,{inputs:{amount:'25',priority:'2',project:'School',urgent:false,note:'Signed test note'}});
  const params={mission:h.mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
  const engine=new MissionExecutionController({dataDir:path.join(h.dataDir,'controller'),controllerKeyPair:h.controller,capabilityRegistry:s.registry,
    agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]))});
  const out=await engine.execute(params);
  assert.equal(out.status,'COMPLETED_CAPABILITY_MISSION',out.reason);
  const bundle={...params,trust:undefined,plan:out.plan,receipts:out.receipts,capabilityManifests:[s.manifest]};
  const pins={...exportPins(f.trust,h.controller.publicKey),capabilityIssuers:{'community-operator':exportPublic(h.issuer.publicKey)},services:{'notes-provider':exportPublic(h.service.publicKey)}};
  const prepared=B.prepareAnchor(bundle,pins,{salt:sampleSalt});
  const operator=crypto.generateKeyPairSync('ed25519'),observer=crypto.generateKeyPairSync('ed25519');
  const approval=B.signApproval(prepared,operator.privateKey);
  return {h,bundle,pins,prepared,operator,observer,approval};
}
test('v1.3: Midnight anchor is explicitly compiled into the human-reviewed mission digest',()=>{
  const mission=compile(missionSource);
  assert.equal(mission.schema,'octolang.mission.v1.3');assert.equal(mission.anchors.length,1);
  assert.equal(mission.anchors[0].phase,'post_execution');assert.equal(verifyMission(mission),true);
  const changed=structuredClone(mission);changed.anchors[0].contract='differentcontract99';assert.equal(verifyMission(changed),false);
  assert.notEqual(compile(missionSource.replace('octolang_demo_contract_0001','octolang_other_contract_0001')).digest,mission.digest);
});
test('v1.3: rejects unsupported anchor backend, short target, missing typed requirements, duplicate anchors',()=>{
  assert.throws(()=>compile(missionSource.replace('backend midnight','backend other')),/midnight backend/);
  assert.throws(()=>compile(missionSource.replace('octolang_demo_contract_0001','bad')),/contract identifier/);
  assert.throws(()=>compile(missionSource.replace('network "local-devnet"','network "x"')),/network identifier/);
  assert.throws(()=>compile(missionSource.replace('  on violation DENY','  anchor another { backend midnight network "local-devnet" contract "different-contract" }\n  on violation DENY')),/declaration limit/);
  assert.throws(()=>compile(missionSource.replace(/  proof .*\n/g,'')),/typed missions require/);
});
test('v1.3: produces salted and target-specific commitments from independently checked signed evidence',async t=>{
  const a=await harness(t);
  assert.equal(B.verifyPrepared(a.prepared,a.bundle,a.pins),true);
  const b=B.prepareAnchor(a.bundle,a.pins,{salt:'03'.repeat(32)});
  assert.notEqual(b.commitment,a.prepared.commitment);
  assert.equal(B.prepareAnchor(a.bundle,a.pins,{salt:sampleSalt}).commitment,a.prepared.commitment);
  assert.equal(a.prepared.private.statement.evidenceRoot.length,64);
  assert.equal(a.prepared.commitment.length,64);
  assert.equal(JSON.stringify({commitment:a.prepared.commitment}).includes(sampleSalt),false);
});
test('v1.3: tampered service receipt and altered private statement are rejected before anchoring',async t=>{
  const a=await harness(t);
  const bad=structuredClone(a.bundle);bad.receipts[0].result.serviceReceipt.payload.service='other-provider';
  assert.throws(()=>B.prepareAnchor(bad,a.pins,{salt:sampleSalt}),/verification failed/);
  const changed=structuredClone(a.prepared);changed.private.statement.evidenceRoot='00'.repeat(32);
  assert.equal(B.verifyPrepared(changed,a.bundle,a.pins),false);
  const changedTarget=structuredClone(a.prepared);changedTarget.contract='other-contract';
  assert.equal(B.verifyPrepared(changedTarget,a.bundle,a.pins),false);
});
test('v1.3: exact signed human anchor approval required, separate from mission review',async t=>{
  const a=await harness(t);const fake=crypto.generateKeyPairSync('ed25519');
  assert.equal(B.verifyApproval(a.prepared,a.approval,a.operator.publicKey),true);
  assert.equal(B.verifyApproval(a.prepared,a.approval,fake.publicKey),false);
  const changed=structuredClone(a.approval);changed.payload.contract='different_contract';
  assert.equal(B.verifyApproval(a.prepared,changed,a.operator.publicKey),false);
  const old=B.signApproval(a.prepared,a.operator.privateKey,{now:Date.now()-600000,minutes:1});
  assert.equal(B.verifyApproval(a.prepared,old,a.operator.publicKey),false);
});
test('v1.3: no automatic network submission; missing or forged authorisation fails closed',async t=>{
  const a=await harness(t);const adapter=new LocalMidnightFixture();
  await assert.rejects(()=>B.submitAnchor({...a,pinnedReviewerKey:a.operator.publicKey,adapter,approval:undefined}),/human authorisation/);
  await assert.rejects(()=>B.submitAnchor({...a,pinnedReviewerKey:a.operator.publicKey,adapter:undefined}),/adapter is required/);
  await assert.rejects(()=>B.submitAnchor({...a,pinnedReviewerKey:a.observer.publicKey,adapter}),/human authorisation/);
  assert.equal(adapter.calls,0);
});
test('v1.3: signed observer attestation plus independent state reader verifies exact committed root',async t=>{
  const a=await harness(t);const adapter=new LocalMidnightFixture();
  const submission=await B.submitAnchor({...a,pinnedReviewerKey:a.operator.publicKey,adapter});
  const observation=B.signObservation(submission,a.observer.privateKey);
  assert.equal(B.verifyObservation(a.prepared,submission,observation,a.observer.publicKey).status,'VERIFIED_OBSERVER_ATTESTATION');
  const verified=await B.verifyObservedState({...a,pinnedObserverKey:a.observer.publicKey,adapter,submission,observation});
  assert.equal(verified.status,'MATCHED_TRUSTED_MIDNIGHT_STATE_READER');assert.equal(adapter.calls,1);
  // Fixture's deterministic duplicate is not a real-chain idempotency guarantee.
  assert.equal((await B.submitAnchor({...a,pinnedReviewerKey:a.operator.publicKey,adapter})).transactionId,submission.transactionId);
  assert.equal(adapter.calls,1);
});
test('v1.3: forged observer, wrong transaction, missing state reader, mismatched state fail closed',async t=>{
  const a=await harness(t);const adapter=new LocalMidnightFixture();
  const submission=await B.submitAnchor({...a,pinnedReviewerKey:a.operator.publicKey,adapter});
  const observation=B.signObservation(submission,a.observer.privateKey);
  const wrong=crypto.generateKeyPairSync('ed25519');
  assert.equal(B.verifyObservation(a.prepared,submission,observation,wrong.publicKey).status,'DENY');
  const altered=structuredClone(observation);altered.payload.transactionId='SPOOFED_TRANSACTION_ID_12345';
  assert.equal(B.verifyObservation(a.prepared,submission,altered,a.observer.publicKey).status,'DENY');
  const noRead=await B.verifyObservedState({...a,submission,observation,pinnedObserverKey:a.observer.publicKey});
  assert.equal(noRead.status,'DENY');
  const fakeReader={readCommitment:async()=>({finalized:true,commitment:'aa'.repeat(32)})};
  assert.equal((await B.verifyObservedState({...a,submission,observation,pinnedObserverKey:a.observer.publicKey,adapter:fakeReader})).status,'DENY');
});
test('v1.3: an unverified fixture observation never becomes a Midnight ZK proof',async t=>{
  const a=await harness(t);const adapter=new LocalMidnightFixture();
  const submission=await B.submitAnchor({...a,pinnedReviewerKey:a.operator.publicKey,adapter});
  const observation=B.signObservation(submission,a.observer.privateKey);
  const status=await B.verifyObservedState({...a,submission,observation,pinnedObserverKey:a.observer.publicKey,adapter});
  assert.equal(/ZK|GROTH16|PROOF/.test(status.status),false);assert.match(status.warning,/not a local Groth16 proof/);
});
