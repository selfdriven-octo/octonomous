'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os');
const {execFileSync}=require('node:child_process');
const {compileLanguage}=require('../language/v1.6');
const {compileComposition,verifyComposition,digestIR}=require('../language/v1.7');
const {verifyIR}=require('../language/v1.7/validate');
const {SCHEMA,GRANT,REVISION,admit,verifyRevision}=require('../language/v1.7/authority');
const {signed,digest}=require('../src/canonical');
const rootDir=path.join(__dirname,'..');const sample=n=>fs.readFileSync(path.join(rootDir,'examples',n),'utf8');
const mission=sample('community-proofs.octo'),original=sample('community-adaptive.octo'),updated=sample('community-adaptive-revised.octo');
const root=compileLanguage(mission);const copy=x=>structuredClone(x);
function setup(now=Date.now()){
  const council=crypto.generateKeyPairSync('ed25519'),registry=crypto.generateKeyPairSync('ed25519'),composer=crypto.generateKeyPairSync('ed25519');
  const trust={mandateIssuers:{council:council.publicKey},grantIssuers:{registry:registry.publicKey},revisionProposers:{composer:composer.publicKey}};
  const payload={schema:SCHEMA,issuer:'council',missionIRDigest:root.irDigest,subject:'community',validFrom:now-5000,expiresAt:now+600000,nonce:crypto.randomBytes(16).toString('hex'),allowRevision:true,maxNodes:6,maxDepth:3,maxTotalBudgetUnits:10,
   allowedTasks:root.ir.tasks.map(t=>({task:t.name,maxInstances:t.name==='find_supplier'?2:1,maxRunsPerInstance:1,maxBudgetUnitsPerRun:4}))};
  const signedMandate=signed(payload,council.privateKey);
  const signedGrants=root.ir.roles.map(r=>signed({schema:GRANT,issuer:'registry',missionIRDigest:root.irDigest,subject:'community',agentId:'agent_'+r.name,role:r.name,capability:r.capability,validFrom:now-5000,expiresAt:now+600000,maxRuns:r.name==='scout'?2:1,maxBudgetUnits:8},registry.privateKey));
  const args={rootIR:root.ir,missionIRDigest:root.irDigest,signedMandate,signedGrants,trust,expectedSubject:'community',now};
  const oldArtifact=compileComposition(original,mission),newArtifact=compileComposition(updated,mission);
  const revisionPayload={schema:REVISION,issuer:'composer',fromIRDigest:oldArtifact.irDigest,toIRDigest:newArtifact.irDigest,mandateDigest:digest(signedMandate),sequence:1,nonce:crypto.randomBytes(16).toString('hex'),reason:'Supplier fallback'};
  const revision=signed(revisionPayload,composer.privateKey);
  return {args,oldArtifact,newArtifact,revision,keys:{council,registry,composer}};
}
const replace=(s,from,to)=>{assert(s.includes(from),`source must contain ${from}`);return s.replace(from,to);};
test('v1.7 canonical composition IR is independently verified',()=>{
 const a=compileComposition(original,mission);assert.equal(a.ir.schema,'octolang.composition-ir.v1.7');assert.equal(a.irDigest,digestIR(a.ir));
 assert.equal(a.ir.maxDepth,3);assert.equal(a.ir.worstCaseBudgetUnits,7);
 assert.equal(verifyIR(a.ir,root.ir,a.irDigest).valid,true);assert.equal(verifyComposition(original,mission,a).valid,true);
 assert.equal(verifyComposition(original+'\n',mission,a).valid,false);
});
test('v1.7 comments and declaration reordering retain same composition semantics',()=>{
 const lines=original.replace(/\n  node find_primary \{[\s\S]*?\n  \}/,'');
 const block=original.match(/\n  node find_primary \{[\s\S]*?\n  \}/)[0];
 const variant=lines.replace('  mission learning_materials','  mission learning_materials'+block)+'\n// different comment\n';
 // source formatting/comments don't affect the canonical digest
 assert.equal(compileComposition(original,mission).irDigest,compileComposition(variant,mission).irDigest);
});
test('v1.7 changes in nested plan change digest',()=>{
 assert.notEqual(compileComposition(original,mission).irDigest,compileComposition(updated,mission).irDigest);
});
test('v1.7 rejects unknown root mission task, capability cannot be invented',()=>{
 assert.throws(()=>compileComposition(replace(original,'task find_supplier','task wallet_transfer'),mission),/Undeclared root task/);
});
test('v1.7 rejects missing required task dependency despite declared parent',()=>{
 const changed=replace(original,'parent find_primary\n    task vet_supplier\n    after find_primary','parent root\n    task vet_supplier\n    after none');
 assert.throws(()=>compileComposition(changed,mission),/Missing required task dependency/);
});
test('v1.7 rejects cyclic nesting or dependency graph',()=>{
 assert.throws(()=>compileComposition(replace(original,'parent root','parent independent_check'),mission),/cycle|Cycle/i);
});
test('v1.7 rejects malformed fields, missing node fields and unknown tokens',()=>{
 assert.throws(()=>compileComposition(replace(original,'max_runs 1','max_runs 2\n    max_runs 2'),mission),/Duplicate field/);
 assert.throws(()=>compileComposition(replace(original,'budget 2','budget -1'),mission),/Unknown token/);
 assert.throws(()=>compileComposition(replace(original,'mission learning_materials','mission unknown'),mission),/must name mission/);
 assert.throws(()=>compileComposition(original+' garbage',mission),/Trailing/);
});
test('v1.7 independent verifier rejects recomputed hash of altered role/proof/dependency',()=>{
 const a=compileComposition(original,mission);
 for(const mutate of [ir=>ir.nodes[0].capability='wallet.send',ir=>ir.nodes[0].requiredProofs=[],ir=>ir.nodes[1].after=['ghost'],ir=>ir.schedule.reverse(),ir=>ir.authority='TRUST_AI']){
  const b=copy(a.ir);mutate(b);assert.equal(verifyIR(b,root.ir,digestIR(b)).valid,false);
 }
});
test('v1.7 independently signed mandate and scoped role grants admit within ceilings',()=>{
 const {args,oldArtifact,newArtifact}=setup();assert.equal(admit({artifact:oldArtifact,...args}).status,'ADMISSIBLE_PROPOSAL');assert.equal(admit({artifact:newArtifact,...args}).status,'ADMISSIBLE_PROPOSAL');
});
test('v1.7 forged governance signature, wrong pinned key, and expiration deny',()=>{
 const {args,oldArtifact}=setup();const altered=copy(args.signedMandate);altered.payload.maxNodes=32;
 assert.equal(admit({artifact:oldArtifact,...args,signedMandate:altered}).status,'DENY');
 const unrelated=crypto.generateKeyPairSync('ed25519');
 assert.equal(admit({artifact:oldArtifact,...args,trust:{...args.trust,mandateIssuers:{council:unrelated.publicKey}}}).status,'DENY');
 assert.equal(admit({artifact:oldArtifact,...args,now:args.now+700000}).status,'DENY');
});
test('v1.7 missing role grant and forged role capability deny',()=>{
 const {args,oldArtifact}=setup();assert.equal(admit({artifact:oldArtifact,...args,signedGrants:args.signedGrants.slice(1)}).status,'DENY');
 const spoof=copy(args.signedGrants);spoof[0].payload.capability='wallet.send';assert.equal(admit({artifact:oldArtifact,...args,signedGrants:spoof}).status,'DENY');
});
test('v1.7 mandate node, depth, budget and task-instance ceilings are binding',()=>{
 const {args,newArtifact,keys}=setup();
 for(const changes of [{maxNodes:4},{maxDepth:2},{maxTotalBudgetUnits:8},{allowedTasks:args.signedMandate.payload.allowedTasks.map(t=>t.task==='find_supplier'?{...t,maxInstances:1}:t)}]){
  const obj=signed({...args.signedMandate.payload,...changes},keys.council.privateKey);
  assert.equal(admit({artifact:newArtifact,...args,signedMandate:obj}).status,'DENY',JSON.stringify(changes));
 }
});
test('v1.7 grants prevent cumulative role run and budget escalation',()=>{
 const {args,newArtifact,keys}=setup();
 const grants=args.signedGrants.map(g=>g.payload.role==='scout'?signed({...g.payload,maxRuns:1},keys.registry.privateKey):g);
 assert.equal(admit({artifact:newArtifact,...args,signedGrants:grants}).status,'DENY');
});
test('v1.7 revision binds old/new IR and externally signed mandate',()=>{
 const {args,oldArtifact,newArtifact,revision}=setup();
 assert.equal(verifyRevision({oldArtifact,newArtifact,revision,...args}).status,'ADMISSIBLE_REVISION');
 const tampered=copy(revision);tampered.payload.toIRDigest='1'.repeat(64);
 assert.equal(verifyRevision({oldArtifact,newArtifact,revision:tampered,...args}).status,'DENY');
});
test('v1.7 revision cannot silently repurpose existing node or increase its ceiling',()=>{
 const {args,oldArtifact,keys}=setup();
 for(const text of [replace(original,'budget 2','budget 3'),replace(original,'task find_supplier','task independent_audit')]){
  try{
   const next=compileComposition(text,mission);
   const revised=signed({schema:REVISION,issuer:'composer',fromIRDigest:oldArtifact.irDigest,toIRDigest:next.irDigest,mandateDigest:digest(args.signedMandate),sequence:1,nonce:crypto.randomBytes(16).toString('hex'),reason:'attempt'},keys.composer.privateKey);
   assert.equal(verifyRevision({oldArtifact,newArtifact:next,revision:revised,...args}).status,'DENY');
  }catch(e){assert.match(e.message,/required task dependency|Missing required|cycle|Composition/);}
 }
});
test('v1.7 revision requires explicit signed adaptation permission and proposer pin',()=>{
 const {args,oldArtifact,newArtifact,revision,keys}=setup();
 const denied=signed({...args.signedMandate.payload,allowRevision:false},keys.council.privateKey);
 assert.equal(verifyRevision({oldArtifact,newArtifact,revision,...args,signedMandate:denied}).status,'DENY');
 assert.equal(verifyRevision({oldArtifact,newArtifact,revision,...args,trust:{...args.trust,revisionProposers:{}}}).status,'DENY');
});
test('v1.7 CLI compile -> source-bound independent verify',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'octo-compose-'));
 try{const bin=path.join(rootDir,'bin/octolang-compose.js'),o=path.join(dir,'composition.json');
  const p=path.join(dir,'composition.octo'),m=path.join(dir,'mission.octo');fs.writeFileSync(p,original);fs.writeFileSync(m,mission);
  execFileSync(process.execPath,[bin,'compile',p,m,o]);
  assert.match(execFileSync(process.execPath,[bin,'verify',p,m,o],{encoding:'utf8'}),/VERIFIED composition/);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('v1.7 frozen cross-implementation conformance vectors',()=>{const {run}=require('../conformance/v1.7/runner');assert.equal(run(),19);});

test('v1.7 mandate and role grants are pinned to the exact community subject',()=>{
 const {args,oldArtifact,keys}=setup();
 assert.equal(admit({artifact:oldArtifact,...args,expectedSubject:'different_community'}).status,'DENY');
 const fakeGrant=args.signedGrants.map(g=>g.payload.role==='scout'?signed({...g.payload,subject:'other_community'},keys.registry.privateKey):g);
 assert.equal(admit({artifact:oldArtifact,...args,signedGrants:fakeGrant}).status,'DENY');
 assert.equal(admit({artifact:oldArtifact,...args,expectedSubject:undefined}).status,'DENY');
});
