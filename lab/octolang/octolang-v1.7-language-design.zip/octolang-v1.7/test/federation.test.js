'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const { compile }=require('../src/compiler');
const { demoSetup }=require('../src/demo');
const { signed }=require('../src/canonical');
const { verifyTranscript }=require('../ensemble/verify');
const { FederatedEngine, DEMO_GRANTS }=require('../federation/engine');
const { Studio }=require('../studio/core');
const { createServer }=require('../studio/server');
const src=fs.readFileSync(path.join(__dirname,'../examples/community-federation.octo'),'utf8');
function local(t) { const dir=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-fed-test-')); t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir; }
function setup() { const s=demoSetup(src), request=s.request('75');
  return {policy:s.policy,request,review:s.review,trusted:s.trusted,claims:[s.claim()],approvals:[s.approval(request)]}; }
const pub = text=>crypto.createPublicKey({key:Buffer.from(text,'base64'),format:'der',type:'spki'});
const journalCount=dir=>fs.existsSync(path.join(dir,'local-intents.jsonl')) ? fs.readFileSync(path.join(dir,'local-intents.jsonl'),'utf8').trim().split('\n').length : 0;

test('compiler binds three distinct communities to ordered zero-delegation agent roles',()=>{
  const p=compile(src);
  assert.equal(p.schema,'octolang.policy.v0.5');
  assert.deepEqual(p.federation.members.map(m=>m.agent),['scout','buyer','checker']);
  for(const change of [
    src.replace('member checker { community "community-audit" }','member checker { community "community-research" }'),
    src.replace('member buyer { community "community-execution" }','member buyer { community "community-coordinator" }'),
    src.replace('member checker { community "community-audit" }','member other { community "community-audit" }'),
    src.replace('member scout { community "community-research" }','member scout { community "community-research" }\n    member scout { community "community-wrong" }'),
    src.replace('  federation community_supplies {','  federation community_supplies {\n member extra { community "other" }')
  ]) assert.throws(()=>compile(change));
});

test('real OFP envelopes, out-of-band peer grants, signed chain and native journal; no duplicate after restart',async t=>{
  const dir=local(t),inputs=setup();
  const one=await new FederatedEngine({dataDir:dir}).run(inputs);
  assert.equal(one.status,'COMPLETED_FEDERATED_LOCAL_DEMO',one.reason);
  assert.equal(one.wire.length,3);
  assert.equal(journalCount(dir),1);
  const keys=Object.fromEntries(Object.entries(one.agentPublicKeysSpki).map(([id,k])=>[id,pub(k)]));
  // The pinned keys here are captured from the local test harness, NOT trusted from wire payload.
  assert.equal(verifyTranscript({inputs,contributions:one.contributions,
    trustedAgentKeys:keys,receiptSignerPublicKeySpki:pub(one.agentPublicKeysSpki.buyer).export({type:'spki',format:'der'}).toString('base64')}).verified,true);
  const two=await new FederatedEngine({dataDir:dir}).run(inputs);
  assert.equal(two.status,'DENY');assert.match(two.reason,/DURABLE_REPLAY/);
  assert.equal(journalCount(dir),1);
});

test('concurrent separate engines sharing durable directory can record only once',async t=>{
  const dir=local(t),inputs=setup();
  const [a,b]=await Promise.all([new FederatedEngine({dataDir:dir}).run(inputs), new FederatedEngine({dataDir:dir}).run(inputs)]);
  assert.deepEqual([a.status,b.status].sort(),['COMPLETED_FEDERATED_LOCAL_DEMO','DENY']);
  assert.equal(journalCount(dir),1);
});

test('no peer effects without exact signed human review, valid evidence and steward approval',async t=>{
  const dir=local(t), inputs=setup();
  const denied=await new FederatedEngine({dataDir:dir}).run({...inputs,review:null});
  const escalated=await new FederatedEngine({dataDir:dir}).run({...inputs,approvals:[]});
  const altered=structuredClone(inputs.policy); altered.agents[1].limitLovelace='999000000';
  const tampered=await new FederatedEngine({dataDir:dir}).run({...inputs,policy:altered});
  assert.equal(denied.status,'DENY');assert.equal(escalated.status,'ESCALATE');assert.equal(tampered.status,'DENY');
  assert.equal(journalCount(dir),0);
  assert.equal(fs.existsSync(path.join(dir,'runs')),false);
});

test('envelope tampering and incorrect recipient are rejected by original OFP verifier',async t=>{
  const dir=local(t), inputs=setup();
  const result=await new FederatedEngine({dataDir:dir}).run(inputs,{ onEnvelope(env,idx) { if (idx===0) env.payload.stepId='forged'; } });
  assert.equal(result.status,'FAILED_CLOSED');assert.equal(result.contributions.length,0);
  assert.equal(journalCount(dir),0);
  const refused=await new FederatedEngine({dataDir:dir}).run(inputs);
  assert.equal(refused.status,'DENY');
  assert.equal(journalCount(dir),0);
});

test('sender spoofing and peer-local governance mismatch fail closed before any native tool',async t=>{
  const dir=local(t),inputs=setup();
  const grants={...DEMO_GRANTS,'community-research':{agent:'checker',capability:'audit',maxLovelace:'0'}};
  const refused=await new FederatedEngine({dataDir:dir,grants}).run(inputs);
  assert.equal(refused.status,'FAILED_CLOSED');assert.match(refused.reason,/governance grant/);
  assert.equal(journalCount(dir),0);
});

test('durable envelope ID and nonce protect against repeated OFP dispatch',async t=>{
  const dir=local(t), inputs=setup(),engine=new FederatedEngine({dataDir:dir});
  const network=engine._network(inputs.policy);
  const sender=network.endpoints.get('community-coordinator'),receiver=network.endpoints.get('community-research');
  const env=await engine._send(sender,'community-research','octolang.step.request.v0.5',{ scoreDigest:inputs.policy.digest });
  assert.ok((await engine._receive(receiver,env)).scoreDigest);
  await assert.rejects(engine._receive(receiver,env),/DURABLE_REPLAY/);
  const sameNonceDifferentId=structuredClone(env);sameNonceDifferentId.id=crypto.randomUUID();
  // Re-sign appropriately to ensure replay, not signature rejection, blocks it.
  sameNonceDifferentId.receipt=await sender.envelopes.signing.sign({id:'community-coordinator'},'federation.envelope.signed',sender.envelopes._unsigned(sameNonceDifferentId),{
    recipientCommunityId:'community-research',messageType:sameNonceDifferentId.messageType });
  await assert.rejects(engine._receive(receiver,sameNonceDifferentId),/DURABLE_REPLAY/);
});

test('studio federation path demands signed review and approval, with HTTP route',async t=>{
  const dir=local(t),studio=new Studio({pairingCode:'fed-test-pair',dataDir:dir});
  const {server}=createServer({studio,openAIAdapter:null});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const base=`http://127.0.0.1:${server.address().port}`;
  const post=async (route, body, header='studio')=>{
    const r=await fetch(base+'/api/'+route,{method:'POST',headers:{'content-type':'application/json','x-octolang-local':header},body:JSON.stringify(body)});
    return { status:r.status, value:await r.json() };
  };
  const draft=await post('compose',{intent:'Purchase classroom project resources',mode:'offline-federation'});
  assert.equal(draft.status,200);assert.equal(draft.value.policy.schema,'octolang.policy.v0.5');
  assert.equal((await post('prepare',{amount:'75',target:'supplier-42'})).status,403);
  const reviewer=crypto.generateKeyPairSync('ed25519');
  await post('enroll',{pairingCode:'fed-test-pair',publicKeySpki:reviewer.publicKey.export({type:'spki',format:'der'}).toString('base64')});
  const now=Date.now();
  assert.equal((await post('review',{review:signed({schema:'octolang.review.v1',reviewer:'local-reviewer',scoreDigest:draft.value.policy.digest,
    issuedAt:new Date(now-1000).toISOString(),expiresAt:new Date(now+3600000).toISOString(),nonce:crypto.randomUUID()},reviewer.privateKey)})).status,200);
  const request=await post('prepare',{amount:'75',target:'supplier-42'});
  const unauthorised=await post('federation-run',{id:request.value.id},'not-studio');
  assert.equal(unauthorised.status,403);
  assert.equal((await post('federation-run',{id:request.value.id})).value.status,'ESCALATE');
  await post('steward-approve',{id:request.value.id});
  const success=await post('federation-run',{id:request.value.id});
  assert.equal(success.status,200);assert.equal(success.value.status,'COMPLETED_FEDERATED_LOCAL_DEMO',success.value.reason);
  assert.equal((await post('federation-run',{id:request.value.id})).value.status,'DENY');
  assert.equal(journalCount(dir),1);
});
