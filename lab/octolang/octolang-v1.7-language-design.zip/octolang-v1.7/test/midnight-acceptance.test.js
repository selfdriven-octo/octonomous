'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const {collect}=require('../midnight/acceptance/preflight.cjs');
const {assertDocumentBinding,assessIndexerMembership}=require('../midnight/acceptance/core.cjs');
const {signApproval}=require('../midnight/bridge');
const crypto=require('node:crypto');
const {queryMembership}=import('../midnight/acceptance/observe.mjs');
const commitment='ab'.repeat(32);
const timestamp=Date.now();
const reviewer=crypto.generateKeyPairSync('ed25519');
const prepared={network:'local-devnet',contract:'contract123',commitment,
 private:{statement:{missionDigest:'cd'.repeat(32),requestDigest:'ef'.repeat(32)}}};
function fakeDoc(){
 const approval=signApproval(prepared,reviewer.privateKey,{now:timestamp});
 return {bundle:{},pins:{},prepared,approval,reviewerPublicKey:reviewer.publicKey,
 deployment:{schema:'octolang.midnight-deployment.v1',network:'local-devnet',contract:prepared.contract},
 result:{schema:'octolang.midnight-local-devnet-result.v1',status:'SDK_FINALIZED_AND_INDEXER_OBSERVED',
 network:'local-devnet',contract:prepared.contract,commitment,transactionId:'12'.repeat(32),
 submittedAt:new Date(timestamp+2000).toISOString(),observedAt:new Date(timestamp+3000).toISOString(),
 evidenceTruthProven:false,policyZkProofProven:false}};
}
test('v1.5 preflight is read-only, reports blockers and does not disclose wallet secret',async()=>{
 const r=await collect({bin:()=>({available:false,version:''}),port:async()=>false,exists:()=>false,
 env:{WALLET_SEED:'deadbeef',PRIVATE_STATE_PASSWORD:'SUPER_SECRET_FOR_TEST'}});
 assert.equal(r.readyForOperatorLiveAttempt,false);
 assert.equal(r.performedLiveProof,false);assert.equal(r.transactionSubmitted,false);
 assert.ok(r.blockers.length>=3);
 assert.equal(JSON.stringify(r).includes('SUPER_SECRET_FOR_TEST'),false);
});
test('v1.5 preflight works with injected healthy dependencies',async()=>{
 const r=await collect({bin:(n)=>({available:true,version:n==='compact'?'0.31.1':'2.5.0'}),
  port:async()=>true,exists:()=>true,env:{WALLET_SEED:'ff'.repeat(32),PRIVATE_STATE_PASSWORD:'example'}});
 assert.equal(r.readyForOperatorLiveAttempt,true);
});
test('v1.5 rejects invalid synthetic evidence regardless of correctly signed reviewer',()=>{
 const r=assertDocumentBinding(fakeDoc());assert.equal(r.status,'DENY');
 assert.match(r.reason,/mission evidence/);
});
test('v1.5 indexer observation rejects unverifiable source and false membership',()=>{
 assert.equal(assessIndexerMembership(fakeDoc(),true).status,'DENY');
 assert.equal(assessIndexerMembership(fakeDoc(),false).ok,false);
});
test('v1.5 fresh indexer membership helper matches only exact commitment',async()=>{
 const {queryMembership}=await import('../midnight/acceptance/observe.mjs');
 const provider={queryContractState:async()=>({data:{values:new Set([commitment])}})};
 const ledger=data=>({evidenceCommitments:{member:bytes=>data.values.has(Buffer.from(bytes).toString('hex'))}});
 assert.equal(await queryMembership({address:'contract123',commitment,provider,generatedLedger:ledger}),true);
 assert.equal(await queryMembership({address:'contract123',commitment:'ee'.repeat(32),provider,generatedLedger:ledger}),false);
 await assert.rejects(()=>queryMembership({address:'contract123',commitment:'bad',provider,generatedLedger:ledger}),/Malformed/);
});

test('v1.5 full genuine-signed fixture passes document binding, changed results fail closed',async(t)=>{
 const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
 const {setup}=require('../capabilities/demo');const {fixtures}=require('../mission/demo');
 const {MissionExecutionController}=require('../mission/executor');
 const {exportPins}=require('../mission/bundle');const {exportPublic}=require('../capabilities/verify');
 const {prepareAnchor,signApproval}=require('../midnight/bridge');
 const {missionSource}=require('../midnight/demo');
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v15-'));
 t.after(()=>fs.rmSync(d,{recursive:true,force:true}));
 const h=setup({missionSource,dataDir:d});const {registry,manifest}=await h.start();
 t.after(()=>new Promise(resolve=>h.server.close(resolve)));
 const f=fixtures(h.mission,{inputs:{amount:'25',priority:'2',project:'Community',urgent:false,note:'Signed v1.5 acceptance fixture'}});
 const p={mission:h.mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
 const engine=new MissionExecutionController({dataDir:path.join(d,'controller'),controllerKeyPair:h.controller,capabilityRegistry:registry,
  agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]))});
 const run=await engine.execute(p);assert.equal(run.status,'COMPLETED_CAPABILITY_MISSION');
 const bundle={...p,trust:undefined,plan:run.plan,receipts:run.receipts,capabilityManifests:[manifest]};
 const pins={...exportPins(f.trust,h.controller.publicKey),capabilityIssuers:{'community-operator':exportPublic(h.issuer.publicKey)},
  services:{'notes-provider':exportPublic(h.service.publicKey)}};
 const preparation=prepareAnchor(bundle,pins);
 const approval=signApproval(preparation,reviewer.privateKey,{now:timestamp});
 const doc={bundle,pins,prepared:preparation,approval,reviewerPublicKey:reviewer.publicKey,
  deployment:{schema:'octolang.midnight-deployment.v1',network:'local-devnet',contract:preparation.contract},
  result:{schema:'octolang.midnight-local-devnet-result.v1',status:'SDK_FINALIZED_AND_INDEXER_OBSERVED',
   contract:preparation.contract,network:'local-devnet',commitment:preparation.commitment,
   transactionId:'12'.repeat(32),submittedAt:new Date(timestamp+2000).toISOString(),observedAt:new Date(timestamp+3000).toISOString(),
   evidenceTruthProven:false,policyZkProofProven:false}};
 assert.equal(assertDocumentBinding(doc).ok,true);
 assert.equal(assessIndexerMembership(doc,true).status,'INDEXER_MEMBERSHIP_CONFIRMED');
 const changed=structuredClone(doc);changed.result.commitment='ab'.repeat(32);
 assert.equal(assessIndexerMembership(changed,true).status,'DENY');
 const forged=structuredClone(doc);forged.result.transactionId='??';
 assert.equal(assessIndexerMembership(forged,true).status,'DENY');
 const missing=structuredClone(doc);delete missing.result.submittedAt;
 assert.equal(assertDocumentBinding(missing).ok,false);
 const falseClaim=structuredClone(doc);falseClaim.result.policyZkProofProven=true;
 assert.equal(assertDocumentBinding(falseClaim).ok,false);
 const expired=structuredClone(doc);expired.result.submittedAt=new Date(timestamp+600000).toISOString();
 assert.equal(assertDocumentBinding(expired).ok,false);
});
