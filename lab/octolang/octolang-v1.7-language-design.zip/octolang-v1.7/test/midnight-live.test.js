'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {approve}=require('../midnight/live/approve.cjs');
const {signApproval,verifyApproval}=require('../midnight/bridge');
let sdk;
const setup=async()=>sdk??=await import('../midnight/live/sdk.mjs');
const hex='ab'.repeat(32);
function fake(){
 const memory=new Set();const calls=[];
 const providers={publicDataProvider:{queryContractState:async()=>({data:{commitments:[...memory]}})}};
 const fakeSdk={compiled:{},
  findDeployedContract:async(_providers,{contractAddress})=>({callTx:{anchorEvidence:async(bytes)=>{
   assert.equal(contractAddress,'contract_123');
   const h=Buffer.from(bytes).toString('hex');
   if(memory.has(h))throw Error('duplicate commitment');
   memory.add(h);calls.push(h);
   return {public:{txId:'ef'.repeat(32),blockHeight:12}};
  }}}),
  ledger:(data)=>({evidenceCommitments:{member:(bytes)=>data.commitments.includes(Buffer.from(bytes).toString('hex'))}})
 };
 return {providers,fakeSdk,memory,calls};
}
test('v1.4 wallet config rejects implicit or missing secrets',async()=>{
 const {walletEnvironment}=await import('../midnight/live/wallet.mjs');
 assert.throws(()=>walletEnvironment({PRIVATE_STATE_PASSWORD:'VeryGood$Password1'}),/exactly one/);
 assert.throws(()=>walletEnvironment({WALLET_SEED:'a'.repeat(64),PRIVATE_STATE_PASSWORD:'short'}),/16\+/);
 assert.throws(()=>walletEnvironment({WALLET_SEED:'zz'.repeat(32),PRIVATE_STATE_PASSWORD:'VeryGood$Password1'}),/Invalid wallet/);
 assert.throws(()=>walletEnvironment({WALLET_SEED:'aa'.repeat(32),PRIVATE_STATE_PASSWORD:'VeryGood$Password1',MIDNIGHT_NETWORK:'mainnet'}),/local/);
 assert.equal(walletEnvironment({WALLET_SEED:'aa'.repeat(32),PRIVATE_STATE_PASSWORD:'VeryGood$Password1'}).seed.length,64);
});
test('strict bytes and pinned contract target',async()=>{
 const {requireCommitment,assertTarget}=await setup();
 assert.equal(requireCommitment(hex).length,32);
 for(const h of [hex.toUpperCase(),'gg'.repeat(32),'01'.repeat(31),null])assert.throws(()=>requireCommitment(h));
 assertTarget({network:'local-devnet',contract:'abc'},{network:'local-devnet',contract:'abc'});
 for(const x of [{network:'mainnet',contract:'abc'},{network:'local-devnet',contract:'changed'}])assert.throws(()=>assertTarget(x,{network:'local-devnet',contract:'abc'}));
});
test('real SDK seam uses circuit call and checks state through indexer',async()=>{
 const {makeSdkAdapter}=await setup();
 const {providers,fakeSdk,calls}=fake();
 const a=makeSdkAdapter({providers,sdk:fakeSdk,contractAddress:'contract_123'});
 const submission=await a.submitCommitment({network:'local-devnet',contract:'contract_123',commitment:hex});
 assert.match(submission.transactionId,/^[a-f0-9]{64}$/);
 assert.deepEqual(calls,[hex]);
 assert.deepEqual(await a.readCommitment({network:'local-devnet',contract:'contract_123',transactionId:submission.transactionId}),
   {commitment:hex,finalized:true,blockHeight:12,assurance:'SDK_FINALIZED_CALL_AND_INDEXER_MEMBERSHIP'});
 await assert.rejects(()=>a.submitCommitment({network:'local-devnet',contract:'contract_123',commitment:hex}),/duplicate/);
});
test('chain read refuses invented transaction identifier',async()=>{
 const {makeSdkAdapter}=await setup();const {providers,fakeSdk}=fake();
 const a=makeSdkAdapter({providers,sdk:fakeSdk,contractAddress:'contract_123'});
 await assert.rejects(()=>a.readCommitment({network:'local-devnet',contract:'contract_123',transactionId:'fake'}),/no locally observed/);
});
test('target substitution is refused before calling prover',async()=>{
 const {makeSdkAdapter}=await setup();const f=fake();
 const a=makeSdkAdapter({providers:f.providers,sdk:f.fakeSdk,contractAddress:'contract_123'});
 await assert.rejects(()=>a.submitCommitment({network:'local-devnet',contract:'another',commitment:hex}),/not the pinned/);
 await assert.rejects(()=>a.submitCommitment({network:'preprod',contract:'contract_123',commitment:hex}),/local-devnet/);
 assert.equal(f.calls.length,0);
});
test('indexer absence fails closed',async()=>{
 const {makeSdkAdapter}=await setup();const f=fake();
 const a=makeSdkAdapter({providers:f.providers,sdk:f.fakeSdk,contractAddress:'contract_123'});
 const sub=await a.submitCommitment({network:'local-devnet',contract:'contract_123',commitment:hex});
 f.memory.clear();
 assert.equal((await a.readCommitment({network:'local-devnet',contract:'contract_123',transactionId:sub.transactionId})).finalized,false);
});
test('indexer shape mismatch fails closed',async()=>{
 const {commitmentMember}=await setup();
 assert.throws(()=>commitmentMember({},hex),/did not return/);
 assert.throws(()=>commitmentMember({evidenceCommitments:{}},hex),/Unsupported/);
});
test('generated contract and SDK calls blocked if compiler artifacts missing',async()=>{
 const {loadSdk}=await setup();
 await assert.rejects(()=>loadSdk({managedDir:'/nonexistent/octolang/compact'}),/Missing Compact compiler output/);
});
test('deploy uses real deployContract API and refuses missing chain address',async()=>{
 const {deployLive}=await setup();
 const x=await deployLive({providers:{},sdk:{compiled:{},deployContract:async()=>({deployTxData:{public:{contractAddress:'abc',txId:'def'}}})}});
 assert.equal(x.contractAddress,'abc');
 await assert.rejects(()=>deployLive({providers:{},sdk:{compiled:{},deployContract:async()=>({deployTxData:{public:{}}})}}),/no contract address/);
});
test('approval CLI verifies independent bundle instead of blindly signing',()=>{
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-approval-'));
 try{
  const kp=crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(path.join(tmp,'private.pem'),kp.privateKey.export({type:'pkcs8',format:'pem'}),{mode:0o600});
  for(const [name,data] of [['prepared',{}],['bundle',{}],['pins',{}]])fs.writeFileSync(path.join(tmp,name+'.json'),JSON.stringify(data));
  assert.throws(()=>approve(path.join(tmp,'prepared.json'),path.join(tmp,'bundle.json'),path.join(tmp,'pins.json'),path.join(tmp,'private.pem'),path.join(tmp,'signature.json')),/independently invalid/);
  assert.equal(fs.existsSync(path.join(tmp,'signature.json')),false);
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});
test('human approval binds commitment exactly',()=>{
 const kp=crypto.generateKeyPairSync('ed25519');
 const prepared={commitment:hex,network:'local-devnet',contract:'contract_123',private:{statement:{missionDigest:hex,requestDigest:'12'.repeat(32)}}};
 const signature=signApproval(prepared,kp.privateKey);
 assert.equal(verifyApproval(prepared,signature,kp.publicKey),true);
 assert.equal(verifyApproval({...prepared,commitment:'bb'.repeat(32)},signature,kp.publicKey),false);
});
