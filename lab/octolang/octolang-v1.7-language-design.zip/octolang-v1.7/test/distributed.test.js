'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {bootstrap,startPeer,stopPeer}=require('../distributed/demo');
const {initPeer,initCoordinator,enroll,activate}=require('../distributed/provision');
const {DistributedCoordinator}=require('../distributed/coordinator');
const {fixture}=require('../network/fixture');
const {readJson,writeJson,MEMBERS,loadCoordinator}=require('../network/identity');
const {assess}=require('../integration/vcc');
const {send,endpoint}=require('../network/common');
const {exchange}=require('../network/transport');
const {digest}=require('../src/canonical');
function dir(t){const home=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-distributed-'));
  t.after(()=>fs.rmSync(home,{recursive:true,force:true}));return home;}
async function setup(t){
  const f=await bootstrap(dir(t));const children=new Map();
  t.after(async()=>{for(const child of children.values())await stopPeer(child);});
  const start=async(id)=>{const child=await startPeer(f,id);children.set(id,child);return child;};
  const stop=async(id)=>{await stopPeer(children.get(id));children.delete(id);};
  return {f,start,stop,all:async()=>{for(const m of MEMBERS)await start(m.id);}};
}
function count(f){const file=path.join(f.peerHomes['community-execution'],'community-execution','state','effects','local-intents.jsonl');
  return fs.existsSync(file)?fs.readFileSync(file,'utf8').trim().split('\n').filter(Boolean).length:0;}

test('v0.7: independent host key creation, explicit trust pins and own signed governance',async t=>{
  const {f}=await setup(t);
  assert.notEqual(f.peerHomes['community-audit'],f.coordinator);
  for(const m of MEMBERS){
    const home=f.peerHomes[m.id],local=readJson(path.join(home,m.id,'local.json'));
    assert.equal(local.remote,true);assert.equal(local.tls,true);
    assert.ok(fs.existsSync(path.join(home,m.id,'governance.pem')));
    assert.ok(!fs.existsSync(path.join(f.coordinator,m.id,'community.pem')));
    assert.equal(local.directory[m.id].capability,m.capability);
    const stat=fs.statSync(path.join(home,m.id,'governance.pem'));
    assert.equal(stat.mode & 0o077,0);
    assert.equal(fs.readFileSync(path.join(f.coordinator,'bundles',m.id+'.json'),'utf8').includes('PRIVATE KEY'),false);
  }
});

test('v0.7: mutually authenticated OFP across 3 independent peer processes',async t=>{
  const {f,all}=await setup(t);await all();
  const inputs=fixture(f.coordinator),result=await new DistributedCoordinator({root:f.coordinator}).run(inputs);
  assert.equal(result.status,'COMPLETED_DISTRIBUTED_DEMO',result.reason);
  assert.equal(result.verified.verified,true);assert.equal(result.contributions.length,3);assert.equal(count(f),1);
  const replay=await new DistributedCoordinator({root:f.coordinator}).run(inputs);
  assert.equal(replay.status,'DENY');assert.match(replay.reason,/DURABLE_REPLAY/);assert.equal(count(f),1);
});

test('v0.7: durable outbox resumes after unavailable audit peer, with only one buyer effect',async t=>{
  const {f,start}=await setup(t);
  await start('community-research');await start('community-execution');
  const inputs=fixture(f.coordinator);
  const initial=await new DistributedCoordinator({root:f.coordinator}).run(inputs,{maxAttempts:1});
  assert.equal(initial.status,'WAITING_DELIVERY',initial.reason);
  assert.equal(initial.nextStep,2);assert.equal(initial.contributions.length,2);assert.equal(count(f),1);
  const next=new DistributedCoordinator({root:f.coordinator});
  assert.equal(next.pending().length,1);
  await start('community-audit');
  const result=await next.run(next.pending()[0].inputs,{maxAttempts:2});
  assert.equal(result.status,'COMPLETED_DISTRIBUTED_DEMO',result.reason);
  assert.equal(result.verified.verified,true);assert.equal(count(f),1);
});

test('v0.7: repeated signed OFP requests recover existing receipt without duplicate effect',async t=>{
  const {f,all,stop,start}=await setup(t);await all();
  const inputs=fixture(f.coordinator),coord=new DistributedCoordinator({root:f.coordinator});
  const out=await coord.run(inputs);assert.equal(out.status,'COMPLETED_DISTRIBUTED_DEMO',out.reason);
  await stop('community-execution');await start('community-execution');
  const index=1,step=inputs.policy.ensemble.steps[index],previous=out.contributions.slice(0,index);
  const context=assess({...inputs,trusted:coord.trusted,usedNonces:new Set()}).snapshot;
  const payload={schema:'octolang.network-step.v0.6',community:'community-execution',stepId:step.id,
    stepIndex:index,agent:step.agent,capability:step.capability,scoreDigest:inputs.policy.digest,
    requestDigest:digest(inputs.request),contextRoot:context.root,actionNonce:inputs.request.nonce,
    priorDigest:digest(previous.at(-1)),
    inputs:{policy:inputs.policy,request:inputs.request,claims:inputs.claims,approvals:inputs.approvals,review:inputs.review},
    contributions:previous};
  const conf=loadCoordinator(f.coordinator),ep=endpoint(conf.local,conf.identity);
  for(let i=0;i<2;i++){
    const envelope=await send(ep,'community-execution','octolang.step.request.v0.6',payload);
    const resp=await exchange(conf.local,conf.dir,'community-execution','POST','/ofp',{envelope});
    assert.equal(resp.status,200,resp.value?.reason);
    assert.equal(resp.value.envelope.payload.responseTo,digest(envelope));
    assert.equal(digest(resp.value.envelope.payload.contribution),digest(out.contributions[index]));
  }
  assert.equal(count(f),1);
});

test('v0.7: explicit out-of-band identity pin confirmation required',async t=>{
  const home=dir(t),c=initCoordinator(path.join(home,'coordinator'));
  const regs=[],pins=[];
  for(const m of MEMBERS){const o=initPeer(path.join(home,m.id),m.id,'https://127.0.0.1:9823');
    regs.push(o.registration);pins.push(o.fingerprint);}
  assert.throws(()=>enroll(path.join(home,'coordinator'),regs,{confirmedPins:pins.slice(0,2)}),/Explicit out-of-band/);
  const issued=enroll(path.join(home,'coordinator'),regs,{confirmedPins:pins});
  assert.throws(()=>activate(path.join(home,'community-audit'),issued.bundles['community-audit'],'bad-pin'),/explicitly pinned/);
  assert.equal(activate(path.join(home,'community-audit'),issued.bundles['community-audit'],c.authorityPin).id,'community-audit');
});

test('v0.7: tampering with signed public registration rejected',async t=>{
  const home=dir(t);initCoordinator(path.join(home,'coord'));
  const regs=[],pins=[];
  for(const m of MEMBERS){const o=initPeer(path.join(home,m.id),m.id,'https://127.0.0.1:9823');regs.push(o.registration);pins.push(o.fingerprint);}
  const p=readJson(regs[0]);p.payload.maxLovelace='999999';fs.writeFileSync(regs[0],JSON.stringify(p));
  assert.throws(()=>enroll(path.join(home,'coord'),regs,{confirmedPins:pins}),/role not trusted|signature invalid/);
});

test('v0.7: dynamic peer revocation denies action regardless of signed request',async t=>{
  const {f,all}=await setup(t);await all();
  const p=path.join(f.peerHomes['community-research'],'community-research');
  const conf=readJson(path.join(p,'local.json'));
  fs.writeFileSync(path.join(p,'revoked.json'),JSON.stringify({revokedCredentialIds:[conf.credentials['community-research'].payload.id]}));
  const r=await new DistributedCoordinator({root:f.coordinator}).run(fixture(f.coordinator),{maxAttempts:1});
  assert.equal(r.status,'FAILED_CLOSED');assert.match(r.reason,/Credential invalid/);assert.equal(count(f),0);
});

test('v0.7: modified peer-local governance grant invalidates signed grant',async t=>{
  const {f,all}=await setup(t);
  const file=path.join(f.peerHomes['community-research'],'community-research','local.json');
  const local=readJson(file);local.grant.payload.maxLovelace='200';fs.writeFileSync(file,JSON.stringify(local));
  await all();
  const r=await new DistributedCoordinator({root:f.coordinator}).run(fixture(f.coordinator),{maxAttempts:1});
  assert.equal(r.status,'FAILED_CLOSED');assert.match(r.reason,/governance grant/);assert.equal(count(f),0);
});

test('v0.7: concurrent/stale conductor lock denies without contacting peers',async t=>{
  const {f}=await setup(t),inputs=fixture(f.coordinator),coord=new DistributedCoordinator({root:f.coordinator});
  const lock=coord._file(inputs)+'.lock';fs.writeFileSync(lock,'test');
  const r=await coord.run(inputs);assert.equal(r.status,'DENY');assert.match(r.reason,/CONDUCTOR_LOCKED/);
  fs.rmSync(lock);assert.equal(count(f),0);
});

test('v0.7: strict reviewed policy and missing approval block network delivery',async t=>{
  const {f,all}=await setup(t);await all();
  const coord=new DistributedCoordinator({root:f.coordinator});const inputs=fixture(f.coordinator);
  assert.equal((await coord.run({...inputs,review:null})).status,'DENY');
  assert.equal((await coord.run({...inputs,approvals:[]})).status,'ESCALATE');
  assert.equal((await coord.run({...inputs,claims:[]})).status,'DENY');
  assert.equal((await coord.run(fixture(f.coordinator,{amount:'110'}))).status,'DENY');
  assert.equal(count(f),0);
});

test('v0.7: empty client certificate rejected during distributed peer TLS handshake',async t=>{
  const {f,start}=await setup(t);await start('community-research');
  const https=require('node:https');
  const config=readJson(path.join(f.coordinator,'community-coordinator','local.json'));
  await assert.rejects(new Promise((resolve,reject)=>{
    https.get(config.urls['community-research']+'/health',{
      ca:config.directory['community-research'].tlsCertPem,rejectUnauthorized:true},res=>{
      res.resume();res.on('end',()=>resolve(res.statusCode));
    }).on('error',reject);
  }), /certificate|required|alert|reset|closed|socket|handshake/i);
});
