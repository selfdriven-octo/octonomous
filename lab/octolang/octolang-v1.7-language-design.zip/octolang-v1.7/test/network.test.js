'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const net=require('node:net');
const crypto=require('node:crypto');
const {provision,readJson,COORDINATOR}=require('../network/identity');
const {fixture}=require('../network/fixture');
const {NetworkCoordinator}=require('../network/coordinator');
const {spawnPeers,stopPeers}=require('../network/demo');
const {send,endpoint}=require('../network/common');
const {loadCoordinator,writeJson}=require('../network/identity');
const {digest}=require('../src/canonical');
const {assess}=require('../integration/vcc');
async function port() {
  const server=net.createServer();
  return new Promise((resolve,reject)=>{
    server.once('error',reject);server.listen(0,'127.0.0.1',()=>{
      const p=server.address().port;server.close(err=>err?reject(err):resolve(p));
    });
  });
}
async function isolated(t,{tls=false}={}) {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-network-test-'));
  fs.rmSync(dir,{recursive:true,force:true});
  const ports=await Promise.all([port(),port(),port()]);
  provision(dir,{ports,tls});
  let running=null;
  t.after(async()=>{if(running)await stopPeers(running.children);fs.rmSync(dir,{recursive:true,force:true});});
  return {dir,launch:async()=>{running=await spawnPeers(dir);return running;},ports};
}
function journal(dir){const file=path.join(dir,'community-execution','state','effects','local-intents.jsonl');
  return fs.existsSync(file)?fs.readFileSync(file,'utf8').trim().split('\n').filter(Boolean).length:0;
}
async function sendUnsigned(root,community,messageType,payload,mutate) {
  const config=loadCoordinator(root),ep=endpoint(config.local,config.identity);
  const envelope=await send(ep,community,messageType,payload);
  if(mutate)mutate(envelope);
  const res=await fetch(config.local.urls[community]+'/ofp',{method:'POST',headers:{'content-type':'application/json'},
    body:JSON.stringify({envelope}),redirect:'error'});
  return {status:res.status,result:await res.json(),envelope};
}

test('v0.6: separate OS peer processes, signed transcript, pinned credentials and persistent replay',async t=>{
  const {dir,launch}=await isolated(t);const running=await launch();
  assert.equal(new Set(running.children.map(c=>c.pid)).size,3);
  const inputs=fixture(dir),outcome=await new NetworkCoordinator({root:dir}).run(inputs);
  assert.equal(outcome.status,'COMPLETED_NETWORK_LOOPBACK_DEMO',outcome.reason);
  assert.equal(outcome.wire.length,3);assert.equal(outcome.verified.verified,true);assert.equal(journal(dir),1);
  const replay=await new NetworkCoordinator({root:dir}).run(inputs);
  assert.equal(replay.status,'DENY');assert.match(replay.reason,/DURABLE_REPLAY/);assert.equal(journal(dir),1);
});

test('v0.6: missing review, invalid registry context, absent approval and over-limit all fail before network effects',async t=>{
  const {dir,launch}=await isolated(t);await launch();const inputs=fixture(dir);
  const coordinator=new NetworkCoordinator({root:dir});
  assert.equal((await coordinator.run({...inputs,review:null})).status,'DENY');
  assert.equal((await coordinator.run({...inputs,claims:[]})).status,'DENY');
  assert.equal((await coordinator.run({...inputs,approvals:[]})).status,'ESCALATE');
  assert.equal((await coordinator.run(fixture(dir,{amount:'110'}))).status,'DENY');
  assert.equal(journal(dir),0);
});

test('v0.6: invalid message signature and unpinned sender are rejected at peer boundary',async t=>{
  const {dir,launch}=await isolated(t);await launch();
  const bad=await sendUnsigned(dir,'community-research','octolang.step.request.v0.6',{hello:'world'},envelope=>{
    envelope.payload.hello='tampered';
  });
  assert.equal(bad.status,403);assert.equal(journal(dir),0);
  const badSender=await sendUnsigned(dir,'community-research','octolang.step.request.v0.6',{hello:'world'},envelope=>{
    envelope.senderCommunityId='community-execution';
  });
  assert.equal(badSender.status,403);assert.equal(journal(dir),0);
});

test('v0.6: compromised credential payload cannot self-grant new capabilities',async t=>{
  const {dir,launch}=await isolated(t);
  const p=path.join(dir,'community-research','local.json'),config=readJson(p);
  config.credentials['community-research'].payload.maxLovelace='999999999999';
  fs.writeFileSync(p,JSON.stringify(config),{mode:0o600});
  await launch();
  const result=await new NetworkCoordinator({root:dir}).run(fixture(dir));
  assert.equal(result.status,'FAILED_CLOSED');assert.match(result.reason,/Credential invalid/);
  assert.equal(journal(dir),0);
});

test('v0.6: local dynamic revocation prevents a peer executing even after it starts',async t=>{
  const {dir,launch}=await isolated(t);await launch();
  const config=readJson(path.join(dir,'community-research','local.json'));
  const revocation=path.join(dir,'community-research','revoked.json');
  fs.writeFileSync(revocation,JSON.stringify({revokedCredentialIds:[config.credentials['community-research'].payload.id]}));
  const result=await new NetworkCoordinator({root:dir}).run(fixture(dir));
  assert.equal(result.status,'FAILED_CLOSED');assert.match(result.reason,/Credential invalid/);assert.equal(journal(dir),0);
});

test('v0.6: peer-local governance grant denies score even when coordinator signed an envelope',async t=>{
  const {dir,launch}=await isolated(t);
  const file=path.join(dir,'community-research','local.json'),config=readJson(file);
  config.grant.payload.maxLovelace='1'; // invalidates governance signature
  fs.writeFileSync(file,JSON.stringify(config));
  await launch();
  const result=await new NetworkCoordinator({root:dir}).run(fixture(dir));
  assert.equal(result.status,'FAILED_CLOSED');assert.match(result.reason,/governance grant/);assert.equal(journal(dir),0);
});

test('v0.6: same signed action with fresh OFP envelopes cannot double-execute buyer stage',async t=>{
  const {dir,launch}=await isolated(t);await launch();
  const inputs=fixture(dir),coordinator=new NetworkCoordinator({root:dir});
  const full=await coordinator.run(inputs);assert.equal(full.status,'COMPLETED_NETWORK_LOOPBACK_DEMO',full.reason);
  const secondStep=inputs.policy.ensemble.steps[1];
  const previous=[full.contributions[0]];
  const snapshot=assess({...inputs,trusted:coordinator.trusted,usedNonces:new Set()}).snapshot;
  const payload={schema:'octolang.network-step.v0.6',community:'community-execution',stepId:secondStep.id,
    stepIndex:1,agent:'buyer',capability:'purchase',scoreDigest:inputs.policy.digest,
    requestDigest:digest(inputs.request),contextRoot:snapshot.root,actionNonce:inputs.request.nonce,
    priorDigest:digest(previous[0]),inputs:{policy:inputs.policy,request:inputs.request,review:inputs.review,
      claims:inputs.claims,approvals:inputs.approvals},contributions:previous};
  const fresh=await sendUnsigned(dir,'community-execution','octolang.step.request.v0.6',payload);
  assert.equal(fresh.status,403);assert.match(fresh.result.reason,/DURABLE_REPLAY/);assert.equal(journal(dir),1);
});

test('v0.6: peer cannot substitute an unreviewed score digest by editing request inputs',async t=>{
  const {dir,launch}=await isolated(t);await launch();
  const inputs=fixture(dir);inputs.policy.intent='Hidden permission change';
  const outcome=await new NetworkCoordinator({root:dir}).run(inputs);
  assert.equal(outcome.status,'DENY');assert.equal(journal(dir),0);
});

test('v0.6: identity survives peer restart, replay protection survives and no payment occurs',async t=>{
  const {dir,launch}=await isolated(t);let first=await launch();const inputs=fixture(dir);
  const before=readJson(path.join(dir,'community-execution','local.json')).directory['community-execution'].communityKeySpki;
  const result=await new NetworkCoordinator({root:dir}).run(inputs);
  assert.equal(result.status,'COMPLETED_NETWORK_LOOPBACK_DEMO',result.reason);
  await stopPeers(first.children);first=await launch();
  const after=readJson(path.join(dir,'community-execution','local.json')).directory['community-execution'].communityKeySpki;
  assert.equal(before,after);
  const replay=await new NetworkCoordinator({root:dir}).run(inputs);
  assert.equal(replay.status,'DENY');assert.equal(journal(dir),1);
});


test('v0.6: independent peer processes work over mutual TLS and reject non-client-authenticated callers',async t=>{
  const {dir,launch}=await isolated(t,{tls:true});await launch();
  const inputs=fixture(dir),result=await new NetworkCoordinator({root:dir}).run(inputs);
  assert.equal(result.status,'COMPLETED_NETWORK_LOOPBACK_DEMO',result.reason);
  assert.equal(journal(dir),1);
  const https=require('node:https');
  const config=readJson(path.join(dir,'community-coordinator','local.json'));
  const target=config.urls['community-research']+'/health';
  await assert.rejects(new Promise((resolve,reject)=>{
    https.get(target,{ca:fs.readFileSync(path.join(dir,'governance','demo-ca.pem')),rejectUnauthorized:true},res=>{
      res.resume();res.on('end',()=>res.statusCode===200?resolve():reject(new Error('Rejected')));
    }).on('error',reject);
  }), /certificate|required|alert|reset|closed|socket|handshake/i);
});
