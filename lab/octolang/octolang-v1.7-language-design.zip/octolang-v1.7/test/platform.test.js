'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {bootstrap,startPeer,stopPeer}=require('../distributed/demo');
const {DistributedCoordinator}=require('../distributed/coordinator');
const {loadPeer,loadRevocations,readJson,MEMBERS}=require('../network/identity');
const {present,verifyPresentation}=require('../platform/discovery');
const {makeAttestation,verifyAttestation}=require('../platform/context');
const {status}=require('../platform/monitor');
const {fixture}=require('../network/fixture');
const {digest,signed}=require('../src/canonical');
async function setup(t,{all=false}={}){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-platform-'));
  const f=await bootstrap(dir),children=[];
  t.after(async()=>{for(const c of children)await stopPeer(c);fs.rmSync(dir,{recursive:true,force:true});});
  const start=async id=>{children.push(await startPeer(f,id));};
  if(all)for(const m of MEMBERS)await start(m.id);
  return {f,start};
}
test('v0.8: independently signed discovery is pinned, scoped and never authority',async t=>{
  const {f,start}=await setup(t);await start('community-research');
  const coordinator=new DistributedCoordinator({root:f.coordinator});
  const remote=await coordinator.discover('community-research');
  assert.equal(remote.verified,true);assert.equal(remote.capability,'research');
  assert.match(remote.note,/not authorisation/i);
  await assert.rejects(()=>coordinator.discover('unknown'),/Unknown peer/);
  const peer=loadPeer(f.peerHomes['community-research'],'community-research');
  const presentation=present(peer),config=coordinator.config;
  assert.equal(verifyPresentation(presentation,{config,community:'community-research'}).verified,true);
  const tampered=structuredClone(presentation);tampered.payload.capability='purchase';
  assert.throws(()=>verifyPresentation(tampered,{config,community:'community-research'}),/DISCOVERY/);
  const expired=signed({...presentation.payload,issuedAt:new Date(Date.now()-10*60000).toISOString(),
    expiresAt:new Date(Date.now()-7*60000).toISOString()},peer.identity);
  assert.throws(()=>verifyPresentation(expired,{config,community:'community-research'}),/expired/);
  const forgedGrant=signed({...presentation.payload, grant:{...presentation.payload.grant,signature:'x'.repeat(88)}},peer.identity);
  assert.throws(()=>verifyPresentation(forgedGrant,{config,community:'community-research'}),/governance grant/);
  const revoked=[config.credentials['community-research'].payload.id];
  assert.throws(()=>verifyPresentation(presentation,{config,community:'community-research',revokedIds:revoked}),/Credential invalid/);
});
test('v0.8: pinned discovery rejects substitution and credential revocation at peer',async t=>{
  const {f,start}=await setup(t);await start('community-audit');
  const coordinator=new DistributedCoordinator({root:f.coordinator});
  assert.equal((await coordinator.discover('community-audit')).agent,'checker');
  const peerHome=path.join(f.peerHomes['community-audit'],'community-audit');
  const config=readJson(path.join(peerHome,'local.json'));
  fs.writeFileSync(path.join(peerHome,'revoked.json'),JSON.stringify({revokedCredentialIds:[config.credentials['community-audit'].payload.id]}));
  // Live process reads revocations afresh on each discovery.
  await assert.rejects(()=>coordinator.discover('community-audit'),/Credential invalid/);
});
test('v0.8: independent VCG attestation revalidates signatures, claims, expiry and roots',async t=>{
  const {f}=await setup(t);
  const peer=loadPeer(f.peerHomes['community-research'],'community-research');
  const coordinator=new DistributedCoordinator({root:f.coordinator}),inputs=fixture(f.coordinator);
  const proof=makeAttestation({peer,inputs});
  assert.equal(verifyAttestation(proof,{inputs,config:coordinator.config}).verified,true);
  const modified=structuredClone(proof);modified.payload.contextRoot='0'.repeat(64);
  assert.throws(()=>verifyAttestation(modified,{inputs,config:coordinator.config}),/CONTEXT/);
  assert.throws(()=>verifyAttestation(proof,{inputs:{...inputs,claims:[]},config:coordinator.config}),/CONTEXT/);
  assert.throws(()=>verifyAttestation(proof,{inputs,config:coordinator.config,now:Date.now()+130000}),/stale/);
  assert.throws(()=>verifyAttestation(proof,{inputs,config:coordinator.config,
    revokedIds:[coordinator.config.credentials['community-research'].payload.id]}),/Credential invalid/);
});
test('v0.8: distributed score checks online discovery and independently verified context',async t=>{
  const {f}=await setup(t,{all:true});
  const coordinator=new DistributedCoordinator({root:f.coordinator}),inputs=fixture(f.coordinator);
  const result=await coordinator.run(inputs);
  assert.equal(result.status,'COMPLETED_DISTRIBUTED_DEMO',result.reason);
  assert.equal(result.contributions.length,3);
  const proof=result.contributions[0].output.contextAttestation;
  assert.equal(verifyAttestation(proof,{inputs,config:coordinator.config}).contextRoot,proof.payload.contextRoot);
  assert.equal(coordinator.pending().length,0);
});
test('v0.8: studio monitor redacts sensitive inputs and reverifies saved runs',async t=>{
  assert.equal(status().configured,false);
  const {f}=await setup(t,{all:true});
  const coordinator=new DistributedCoordinator({root:f.coordinator}),inputs=fixture(f.coordinator);
  const result=await coordinator.run(inputs);assert.equal(result.status,'COMPLETED_DISTRIBUTED_DEMO',result.reason);
  const out=status(f.coordinator);
  assert.equal(out.configured,true);assert.equal(out.agents.length,3);
  assert.equal(out.runs.length,1);assert.equal(out.runs[0].verification,'REVERIFIED');
  const json=JSON.stringify(out);
  assert.ok(!json.includes('supplier-42'));assert.ok(!json.includes('BEGIN PRIVATE KEY'));
  assert.ok(!json.includes(inputs.request.nonce));assert.ok(!json.includes(inputs.claims[0].signature));
  const outboxFile=coordinator._file(inputs),saved=readJson(outboxFile);
  saved.contributions[0].output.contextAttestation.signature='x'.repeat(88);
  fs.writeFileSync(outboxFile,JSON.stringify(saved));
  assert.equal(status(f.coordinator).runs[0].verification,'FAILED_OR_EXPIRED');
});

test('v0.8: studio distributed API is read-only and local-host guarded',async t=>{
  const {createServer}=require('../studio/server');
  const {server}=createServer();
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const addr='http://127.0.0.1:'+server.address().port;
  const r=await fetch(addr+'/api/distributed/status');
  assert.equal(r.status,200);
  const result=await r.json();
  assert.equal(result.readOnly,undefined);assert.equal(result.configured,false);
  const discovery=await fetch(addr+'/api/distributed/discover').then(x=>x.json());
  assert.equal(discovery.configured,false);
  const reject=await fetch(addr+'/api/distributed/status',{headers:{origin:'https://evil.invalid'}});
  assert.equal(reject.status,403);
  const execute=await fetch(addr+'/api/distributed/run',{method:'POST',headers:{'content-type':'application/json','x-octolang-local':'studio'},body:'{}'});
  assert.equal(execute.status,404);
});
