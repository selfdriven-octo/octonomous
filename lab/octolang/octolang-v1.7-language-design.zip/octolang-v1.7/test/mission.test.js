'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const crypto=require('node:crypto');const {compile}=require('../src/compiler');
const {signed,digest}=require('../src/canonical');
const {planMission,verifyMissionEvidence}=require('../src/mission');
const {template,fixtures}=require('../mission/demo');
const {Studio}=require('../studio/core');const {createServer}=require('../studio/server');
const mission=compile(template);
const go=(f=fixtures(mission),m=mission)=>planMission({mission:m,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust});
const evidence=(f,r,m=mission,extra={})=>verifyMissionEvidence({mission:m,request:f.request,plan:r.plan,
  receipts:f.simulate(r.plan),review:f.review,claims:f.claims,grants:f.grants,trust:f.trust,...extra});
const mutate=(s,a,b)=>s.replace(a,b);
test('v0.9 compiler: stable digest, four dynamic roles and DAG with two dependencies',()=>{
  assert.equal(compile(template).digest,compile('// comment\n'+template).digest);
  assert.equal(mission.schema,'octolang.mission.v0.9');
  assert.equal(mission.roles.length,4);
  assert.deepEqual(mission.order,['find_supplier','vet_supplier','record_intent','independent_audit']);
  assert.deepEqual(mission.tasks.at(-1).dependencies,['find_supplier','record_intent']);
  assert.equal(mission.constraints.find(c=>c.label==='spending').max,'100000000');
});
test('v0.9 compiler: type safety and explicit fail-closed semantics',()=>{
  assert.throws(()=>compile(mutate(template,'on violation DENY','on violation ALLOW')),/mission error/);
  assert.throws(()=>compile(mutate(template,'type boolean','type javascript')),/input type/);
  assert.throws(()=>compile(mutate(template,'100 ADA','100 BTC')),/ADA/);
  assert.throws(()=>compile(mutate(template,'max 10 count','max 10 ADA')),/count/);
  assert.throws(()=>compile(mutate(template,'role scout { capability "research" }','role scout { capability "research" delegate true }')),/unknown/);
  assert.throws(()=>compile(template+'\nrequire("fs")'),/Trailing|Unexpected|trailing/i);
  assert.throws(()=>compile(mutate(template,'claim "supplier.accredited"','claim "supplier.accredited" claim "extra"')),/repeated/);
});
test('v0.9 compiler: cycles, missing deps, wrong outcomes and undeclared roles denied',()=>{
  assert.throws(()=>compile(mutate(template,'role scout depends none','role scout depends independent_audit')),/cyclic/);
  assert.throws(()=>compile(mutate(template,'role scout depends none','role scout depends unknown')),/invalid dependencies/);
  assert.throws(()=>compile(mutate(template,'role scout depends none','role missing depends none')),/unknown role/);
  assert.throws(()=>compile(mutate(template,'task record_intent evidence "intent.recorded"','task record_intent evidence "different"')),/outcome/);
});
test('v0.9 planner: requires independently signed human review',()=>{
  const f=fixtures(mission);
  assert.equal(go(f).status,'READY_FOR_SIMULATION');
  assert.equal(planMission({mission,request:f.request,review:null,claims:f.claims,grants:f.grants,trust:f.trust}).status,'DENY');
  const bad={...mission,goal:'Unlimited everything'};
  assert.equal(go(f,bad).status,'DENY');
});
test('v0.9 planner: trusted agent grants cannot be forged, omitted or capability-escalated',()=>{
  const f=fixtures(mission);
  assert.equal(planMission({mission,request:f.request,review:f.review,claims:f.claims,grants:[],trust:f.trust}).status,'DENY');
  const stolen=structuredClone(f.grants[0]);stolen.payload.capability='wallet.transfer';
  assert.equal(planMission({mission,request:f.request,review:f.review,claims:f.claims,grants:[stolen,...f.grants.slice(1)],trust:f.trust}).status,'DENY');
  const swapped=structuredClone(f.grants[0]);swapped.payload.agent='buyer';
  assert.equal(planMission({mission,request:f.request,review:f.review,claims:f.claims,grants:[swapped,...f.grants.slice(1)],trust:f.trust}).status,'DENY');
});
test('v0.9 planner: independently signed context mandatory and subject-bound',()=>{
  const f=fixtures(mission);
  assert.equal(planMission({mission,request:f.request,review:f.review,claims:[],grants:f.grants,trust:f.trust}).status,'DENY');
  const tampered=structuredClone(f.claims[0]);tampered.payload.subject='other-target';
  assert.equal(planMission({mission,request:f.request,review:f.review,claims:[tampered],grants:f.grants,trust:f.trust}).status,'DENY');
});
test('v0.9 planner: all typed inputs and numeric constraints apply',()=>{
  for(const updates of [{amount:'101'},{amount:'100.000001'},{priority:'11'},{priority:'3.7'},{project:''},{urgent:'yes'}]){
    const f=fixtures(mission,{inputs:{amount:'75',priority:'3',project:'Project',urgent:false,...updates}});
    assert.equal(go(f).status,'DENY',JSON.stringify(updates));
  }
  const f=fixtures(mission,{inputs:{amount:'100',priority:'10',project:'Project',urgent:false}});
  assert.equal(go(f).status,'READY_FOR_SIMULATION');
});
test('v0.9: four-agent simulated outcomes independently verify exact chained evidence',()=>{
  const f=fixtures(mission),r=go(f);assert.equal(r.status,'READY_FOR_SIMULATION');
  const out=evidence(f,r);assert.equal(out.status,'VERIFIED_SIMULATION');assert.equal(out.outcomes.length,2);
});
test('v0.9 outcome verification: forged, tampered, missing and reordered receipts denied',()=>{
  const f=fixtures(mission),r=go(f),receipts=f.simulate(r.plan);
  const verify=a=>verifyMissionEvidence({mission,request:f.request,plan:r.plan,receipts:a,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust});
  assert.equal(verify([...receipts].reverse()).status,'DENY');
  assert.equal(verify(receipts.slice(0,3)).status,'DENY');
  const changed=structuredClone(receipts);changed[2].payload.dependencies.vet_supplier='forged';
  assert.equal(verify(changed).status,'DENY');
  const fake=structuredClone(receipts);fake[3].signature='X'.repeat(88);
  assert.equal(verify(fake).status,'DENY');
  const orphan=structuredClone(receipts);orphan[1].payload.evidence='other.result';
  assert.equal(verify(orphan).status,'DENY');
});
test('v0.9 outcome verification: cannot skip policy review, grants or reverified context',()=>{
  const f=fixtures(mission),r=go(f);assert.equal(evidence(f,r,mission,{review:null}).status,'DENY');
  assert.equal(evidence(f,r,mission,{grants:[]}).status,'DENY');
  assert.equal(evidence(f,r,mission,{claims:[]}).status,'DENY');
  assert.equal(evidence(f,r,mission,{request:{...f.request,inputs:{...f.request.inputs,amount:'101'}}}).status,'DENY');
});
test('v0.9 dynamic role selection: lexicographic agent choice from independently signed grants',()=>{
  const f=fixtures(mission),governance=crypto.generateKeyPairSync('ed25519'),extra=crypto.generateKeyPairSync('ed25519');
  f.trust.grantIssuers['new-governance']=governance.publicKey;
  f.trust.agents['aaa-scout']=extra.publicKey;
  f.grants.push(signed({schema:'octolang.agent-grant.v0.9',missionDigest:mission.digest,role:'scout',agent:'aaa-scout',
    capability:'research',issuer:'new-governance',nonce:crypto.randomUUID(),
    issuedAt:new Date(Date.now()-1000).toISOString(),expiresAt:new Date(Date.now()+200000).toISOString()},governance.privateKey));
  const result=go(f);
  assert.equal(result.status,'READY_FOR_SIMULATION');
  assert.equal(result.plan.assignments.scout.agent,'aaa-scout');
  assert.equal(result.plan.assignments.buyer.agent,'buyer');
});
test('v0.9 HTTP Studio: compose/compile/review, deny unapproved, verify simulated outcomes',async()=>{
  const studio=new Studio({pairingCode:'TESTPAIR'}), reviewer=crypto.generateKeyPairSync('ed25519');
  studio.enroll('TESTPAIR',reviewer.publicKey.export({type:'spki',format:'der'}).toString('base64'));
  const {server}=createServer({studio,openAIAdapter:null});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const addr=`http://127.0.0.1:${server.address().port}`;
  const post=async(route,body)=>{const r=await fetch(addr+'/api/'+route,{method:'POST',headers:{'Content-Type':'application/json','x-octolang-local':'studio'},body:JSON.stringify(body)});return {status:r.status,body:await r.json()};};
  try{
    const created=await post('mission/compose',{goal:'Organise school resources',mode:'offline'});
    assert.equal(created.status,200);const m=created.body.mission;
    assert.equal((await post('mission/verify-demo',{subject:'supplier-42',inputs:{amount:'25',priority:'3',project:'School',urgent:false}})).status,403);
    const p={schema:'octolang.review.v1',reviewer:'local-reviewer',scoreDigest:m.digest,nonce:crypto.randomUUID(),issuedAt:new Date(Date.now()-1000).toISOString(),expiresAt:new Date(Date.now()+600000).toISOString()};
    assert.equal((await post('mission/review',{review:signed(p,reviewer.privateKey)})).status,200);
    const allowed=await post('mission/verify-demo',{subject:'supplier-42',inputs:{amount:'25',priority:'3',project:'School',urgent:false}});
    assert.equal(allowed.status,200);assert.equal(allowed.body.verified.status,'VERIFIED_SIMULATION');
    const invalid=await post('mission/verify-demo',{subject:'supplier-42',inputs:{amount:'101',priority:'3',project:'School',urgent:false}});
    assert.equal(invalid.body.decision.status,'DENY');
    const edited=await post('mission/compile',{source:template.replace('record an intent','record a research intent')});
    assert.equal(edited.status,200);
    assert.equal((await post('mission/verify-demo',{subject:'supplier-42',inputs:{amount:'25',priority:'3',project:'School',urgent:false}})).status,403);
  } finally {await new Promise(resolve=>server.close(resolve));}
});
