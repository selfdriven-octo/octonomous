'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { demoSetup } = require('../src/demo');
const { FederatedEngine } = require('./engine');
async function demo() {
  const source=fs.readFileSync(path.join(__dirname,'../examples/community-federation.octo'),'utf8');
  const s=demoSetup(source), request=s.request('75');
  const inputs={policy:s.policy,request,claims:[s.claim()],approvals:[s.approval(request)],review:s.review,trusted:s.trusted};
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-federation-'));
  const result=await new FederatedEngine({dataDir:directory}).run(inputs);
  if (result.status !== 'COMPLETED_FEDERATED_LOCAL_DEMO') throw new Error(result.reason||result.status);
  const retry=await new FederatedEngine({dataDir:directory}).run(inputs);
  if (retry.status !== 'DENY') throw new Error('Durable replay unexpectedly succeeded');
  console.log(JSON.stringify({status:result.status,peers:inputs.policy.federation.members,
    messages:result.wire.length*2,chainHead:result.verified.chainHead,replayAfterRestart:retry.status,
    localJournal:path.join(directory,'local-intents.jsonl'),
    note:'Local protocol demonstration only: authentic OFP signed envelopes, no cross-process delivery, no payments.'},null,2));
}
if (require.main === module) demo().catch(e=>{console.error(e);process.exitCode=1});
module.exports={demo};
