'use strict';
// Local transport with distinct simulated sovereign community endpoints, authentic OFP v1.0 envelopes.
// No HTTP delivery, community KERI identity, independent custody, or actual external actors.
const crypto = require('node:crypto');
const path = require('node:path');
const { digest, signed, verifiedSigned } = require('../src/canonical');
const { assess } = require('../integration/vcc');
const { OctonomousBridge } = require('../integration/bridge');
const { verifyLocalReceipt } = require('../integration/verify');
const { verifyPartialTranscript, verifyTranscript } = require('../ensemble/verify');
const OFP = require('../vendor/octonomous-federation');
const { DurableClaims } = require('./durable');
const { FederationProtocolService, FederationEnvelopeService } = OFP.protocol;
const { CommunitySigningService } = OFP.society;
const MAX_ENVELOPE_MS = 5 * 60000;
const COORDINATOR = 'community-coordinator';
// Out-of-band DEMO grants. Peer must never derive these privileges from the request envelope.
const DEMO_GRANTS = Object.freeze({
  'community-research': Object.freeze({agent:'scout', capability:'research', maxLovelace:'0'}),
  'community-execution': Object.freeze({agent:'buyer', capability:'purchase', maxLovelace:'100000000'}),
  'community-audit': Object.freeze({agent:'checker', capability:'audit', maxLovelace:'0'})
});
function spki(key) { return key.export({ format:'der', type:'spki' }).toString('base64'); }
function requireValid(condition, text) { if (!condition) throw new Error(text); }

function createEndpoint(id, keyPair, publicDirectory) {
  const signing = new CommunitySigningService({ provider: {
    signCommunity: ({ community, kind, subject, evidence }) => {
      if (community.id !== id) throw new Error(`Sender ${id} cannot sign for ${community.id}`);
      return signed({ kind, subject, evidence }, keyPair.privateKey);
    },
    verifyCommunity: ({ community, receipt }) => {
      // Pinned directory, never accept a key from a message itself.
      const key = publicDirectory.get(community.id);
      return { valid: !!key && receipt?.payload?.kind === 'federation.envelope.signed' && verifiedSigned(receipt, key) };
    }
  } });
  const communities = { load: community => Promise.resolve(publicDirectory.has(community) ? { id:community } : null) };
  const envelopes = new FederationEnvelopeService({ communities, signing, protocol:new FederationProtocolService(), replay:null,
    maxLifetimeSeconds: 300, clockSkewSeconds: 0 });
  return { id, envelopes, keyPair };
}
class FederatedEngine {
  constructor({ dataDir, bridge, durable, grants } = {}) {
    this.dataDir = path.resolve(dataDir || path.join(process.cwd(), '.octolang-local', 'federation'));
    this.durable = durable || new DurableClaims(this.dataDir);
    this.bridge = bridge || new OctonomousBridge({ dataDir:this.dataDir });
    this.grants = grants || DEMO_GRANTS; // demo-grants only; replace via independently managed peer policy
    this.demoOnly = true;
  }
  // Test fixture identities are created for this local run, not exported/accepted as runtime authority.
  _network(policy) {
    const coordinator = crypto.generateKeyPairSync('ed25519');
    const communityNames = [COORDINATOR, ...policy.federation.members.map(m => m.community)];
    const signers = new Map(communityNames.map(name => [name, crypto.generateKeyPairSync('ed25519')]));
    const directory = new Map([...signers].map(([name,k]) => [name,k.publicKey]));
    const endpoints = new Map([...signers].map(([name,key]) => [name,createEndpoint(name,key,directory)]));
    const agents = new Map(policy.ensemble.steps.map(step => [step.agent,
      step.capability === 'purchase' ? this.bridge.signer : crypto.generateKeyPairSync('ed25519')]));
    const trustedAgentKeys = Object.fromEntries([...agents].map(([agent,keys]) => [agent, keys.publicKey]));
    return { endpoints, directory, agents, trustedAgentKeys, receiptSignerPublicKeySpki:spki(this.bridge.signer.publicKey) };
  }
  async _send(endpoint, recipientId, messageType, payload) {
    const { envelope } = await endpoint.envelopes.create({ input: {
      senderCommunityId:endpoint.id, recipientCommunityId:recipientId, messageType, payload,
      lifetimeSeconds:240
    } });
    return envelope;
  }
  async _receive(endpoint, envelope) {
    requireValid(envelope.recipientCommunityId === endpoint.id, 'OFP recipient mismatch');
    await endpoint.envelopes.verify({ envelope, expectedRecipientCommunityId:endpoint.id });
    // Treat expiry as strict despite native protocol skew allowances; forbid oversized payloads.
    requireValid(Date.parse(envelope.expiresAt) > Date.now() &&
      Date.parse(envelope.expiresAt)-Date.parse(envelope.issuedAt) <= MAX_ENVELOPE_MS, 'Expired or oversized OFP envelope');
    requireValid(JSON.stringify(envelope).length <= 45000, 'OFP envelope too large');
    this.durable.reserveEnvelope(envelope); // BEFORE handler or any local effect
    return envelope.payload;
  }
  async _handleStep({ step, index, inputs, contributions, network, envelope }) {
    const recipient = inputs.policy.federation.members.find(x => x.agent === step.agent)?.community;
    requireValid(recipient && envelope.recipientCommunityId === recipient, 'Peer community does not own this agent');
    requireValid(envelope.senderCommunityId === COORDINATOR && envelope.messageType === 'octolang.step.request.v0.5', 'Unauthorised federation sender or message type');
    const payload = await this._receive(network.endpoints.get(recipient), envelope);
    const { policy, request } = inputs;
    const previous = contributions.length ? contributions.at(-1) : null;
    const decision = assess({ ...inputs, usedNonces:new Set() }); // fresh local VCC check
    requireValid(decision.decision.status === 'ALLOW', `Peer VCC denied: ${decision.decision.reason}`);
    requireValid(payload.schema === 'octolang.federation-step.v0.5' && payload.scoreDigest === policy.digest &&
      payload.requestDigest === digest(request) && payload.contextRoot === decision.snapshot.root &&
      payload.stepId === step.id && payload.agent === step.agent && payload.capability === step.capability &&
      payload.actionNonce === request.nonce && payload.expectedPredecessor === (previous ? digest(previous) : null),
    'OFP payload does not bind to approved score, request, step, context and predecessor');
    if (index > 0) verifyPartialTranscript({ inputs, contributions, trustedAgentKeys:network.trustedAgentKeys,
      receiptSignerPublicKeySpki:network.receiptSignerPublicKeySpki });
    const grant = this.grants[recipient];
    const governedAgent = policy.agents.find(a => a.name === step.agent);
    requireValid(grant?.agent === step.agent && grant.capability === step.capability &&
      grant.maxLovelace !== undefined && governedAgent &&
      BigInt(governedAgent.limitLovelace) <= BigInt(grant.maxLovelace) &&
      (grant.scoreDigest === undefined || grant.scoreDigest === policy.digest) &&
      (grant.expiresAt === undefined || Date.parse(grant.expiresAt) > Date.now()),
      'Peer-local governance grant denies requested authority');
    requireValid(governedAgent?.capability === step.capability && governedAgent.delegate === false,
      'Community governance capability mismatch or delegation forbidden');
    const privateKey = network.agents.get(step.agent)?.privateKey;
    requireValid(privateKey, 'Peer signer absent');
    let output;
    if (step.capability === 'research') {
      requireValid(BigInt(governedAgent.limitLovelace) === 0n, 'Research community cannot spend');
      output = { schema:'octolang.step-output.v0.4', kind:'DEMO_SUPPLIER_RESEARCH', target:request.target,
        claimDigest:digest(inputs.claims[0]), note:'Remote in-memory demo peer verifies signed registry claim; not an independent supplier assessment' };
    } else if (step.capability === 'purchase') {
      const result = await this.bridge.dispatch(inputs);
      requireValid(result.status === 'RECORDED_LOCAL_INTENT' && result.effect?.ok === true, 'Native Octonomous Runtime refused local intent');
      requireValid(verifyLocalReceipt({ record:result.effect.record, receipt:result.effect.receipt,
        receiptSignerPublicKeySpki:network.receiptSignerPublicKeySpki }), 'Unverified local journal receipt');
      output = { schema:'octolang.step-output.v0.4', kind:'RECORDED_LOCAL_INTENT', record:result.effect.record, receipt:result.effect.receipt };
    } else if (step.capability === 'audit') {
      requireValid(BigInt(governedAgent.limitLovelace) === 0n, 'Audit community cannot spend');
      output = { schema:'octolang.step-output.v0.4', kind:'DEMO_AUDIT', subjectContributionDigest:digest(previous),
        localReceiptValid:true, note:'Mock audit peer checks independently pinned signatures; not a real financial audit' };
    } else throw new Error('Unrecognised capability');
    const now=Date.now();
    const claim = { schema:'octolang.agent-contribution.v0.4', scoreDigest:policy.digest,
      requestDigest:digest(request), contextRoot:decision.snapshot.root, ensemble:policy.ensemble.name,
      stepId:step.id, agent:step.agent, capability:step.capability, evidence:step.evidence,
      outputDigest:digest(output), priorDigest:previous ? digest(previous) : null,
      issuedAt:new Date(now).toISOString(), expiresAt:new Date(now+240000).toISOString(), nonce:crypto.randomUUID() };
    const contribution = { output, attestation:signed(claim,privateKey) };
    verifyPartialTranscript({ inputs, contributions:[...contributions,contribution],
      trustedAgentKeys:network.trustedAgentKeys, receiptSignerPublicKeySpki:network.receiptSignerPublicKeySpki });
    const reply = await this._send(network.endpoints.get(recipient), COORDINATOR, 'octolang.step.result.v0.5', {
      schema:'octolang.federation-result.v0.5', scoreDigest:policy.digest, stepId:step.id,
      responseTo:digest(envelope), contributionDigest:digest(contribution), contribution
    });
    return reply;
  }
  async run(inputs, hooks = {}) {
    const { policy, request } = inputs || {};
    if (!policy?.ensemble || !policy.federation || policy.schema !== 'octolang.policy.v0.5')
      return { status:'DENY', reason:'Reviewed v0.5 federation score required', contributions:[] };
    const stage = assess({ ...inputs, usedNonces:new Set() });
    if (stage.decision.status !== 'ALLOW') return { status:stage.decision.status, reason:stage.decision.reason, contributions:[] };
    try { this.durable.reserveRun(request); }
    catch(e) { return { status:'DENY', reason:e.message, contributions:[] }; }
    const network = this._network(policy), contributions = [], wire = [];
    try {
      for (const [index,step] of policy.ensemble.steps.entries()) {
        const community = policy.federation.members.find(m => m.agent === step.agent).community;
        const payload = { schema:'octolang.federation-step.v0.5', scoreDigest:policy.digest,
          requestDigest:digest(request), contextRoot:stage.snapshot.root, stepId:step.id,
          agent:step.agent, capability:step.capability, actionNonce:request.nonce,
          expectedPredecessor:contributions.length ? digest(contributions.at(-1)) : null };
        const envelope = await this._send(network.endpoints.get(COORDINATOR),community,'octolang.step.request.v0.5',payload);
        if (hooks.onEnvelope) await hooks.onEnvelope(envelope, index);
        const reply = await this._handleStep({ step,index,inputs,contributions,network,envelope });
        const returned = await this._receive(network.endpoints.get(COORDINATOR),reply);
        requireValid(reply.senderCommunityId === community && reply.messageType === 'octolang.step.result.v0.5' &&
          returned.schema === 'octolang.federation-result.v0.5' && returned.scoreDigest === policy.digest &&
          returned.stepId === step.id && returned.responseTo === digest(envelope) &&
          returned.contributionDigest === digest(returned.contribution), 'Peer response is not bound to authorised request');
        contributions.push(returned.contribution);
        verifyPartialTranscript({ inputs, contributions, trustedAgentKeys:network.trustedAgentKeys,
          receiptSignerPublicKeySpki:network.receiptSignerPublicKeySpki });
        wire.push({ sender:COORDINATOR, recipient:community, requestId:envelope.id, responseId:reply.id,
          requestDigest:digest(envelope), responseDigest:digest(reply) });
      }
      const verified=verifyTranscript({ inputs, contributions, trustedAgentKeys:network.trustedAgentKeys,
        receiptSignerPublicKeySpki:network.receiptSignerPublicKeySpki });
      return { status:'COMPLETED_FEDERATED_LOCAL_DEMO', verified, contributions, wire,
        communityPublicKeysSpki:Object.fromEntries([...network.directory].map(([k,v])=>[k,spki(v)])),
        agentPublicKeysSpki:Object.fromEntries(Object.entries(network.trustedAgentKeys).map(([k,v])=>[k,spki(v)])),
        note:'OFP envelope exchanges performed locally across simulated community endpoints. Only the purchase INTENT was written to local journal; no payment/network delivery.' };
    } catch(e) { return { status:'FAILED_CLOSED', reason:e.message, contributions, wire,
      note:'Replay claims remain consumed. An earlier local intent may have been recorded. Manual reconciliation required.' }; }
  }
}
module.exports = { FederatedEngine, COORDINATOR, createEndpoint, DEMO_GRANTS };
