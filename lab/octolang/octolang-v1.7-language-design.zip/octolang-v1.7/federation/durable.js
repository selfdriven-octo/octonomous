'use strict';
// Experimental crash-sticky, cross-process local filesystem claims. NOT a clustered transactional store.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const safeHash = value => crypto.createHash('sha256').update(value).digest('hex');
class DurableClaims {
  constructor(directory) {
    this.dir = path.resolve(directory);
    fs.mkdirSync(this.dir, { recursive:true, mode:0o700 });
  }
  _claim(namespace, key, digest) {
    const dir = path.join(this.dir, namespace);
    fs.mkdirSync(dir, { recursive:true, mode:0o700 });
    const file = path.join(dir, safeHash(key) + '.json');
    const fd = fs.openSync(file, 'wx', 0o600); // atomic on one local filesystem; no TTL/retry
    try { fs.writeFileSync(fd, JSON.stringify({ keyDigest:safeHash(key), digest, state:'CLAIMED', at:new Date().toISOString() })); fs.fsyncSync(fd); }
    finally { fs.closeSync(fd); }
    return file;
  }
  reserveRun(request) {
    const key = `${request.scoreDigest}:${request.nonce}`;
    try { return this._claim('runs', key, safeHash(JSON.stringify(request))); }
    catch (e) { if (e.code === 'EEXIST') throw new Error('DURABLE_REPLAY: score request already reserved (manual reconciliation required)'); throw e; }
  }
  reserveEnvelope(envelope) {
    // Two atomic claims are intentionally crash-sticky: if a crash occurs between them,
    // either reservation still prevents repeat execution. No lock-stealing or TTL.
    const recipient = envelope.recipientCommunityId, sender = envelope.senderCommunityId;
    for (const [namespace, key] of [
      ['envelope-ids', `${recipient}:${sender}:${envelope.id}`],
      ['envelope-nonces', `${recipient}:${sender}:${envelope.nonce}`]
    ]) {
      try { this._claim(namespace, key, safeHash(JSON.stringify(envelope))); }
      catch (e) { if (e.code === 'EEXIST') throw new Error('DURABLE_REPLAY: previously observed envelope ID or nonce'); throw e; }
    }
  }
}
module.exports = { DurableClaims };
