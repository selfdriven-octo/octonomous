'use strict';
// Community-authored agent presentations. These are NOT W3C VC Data Model / DID-compliant.
// Discovery supplies candidate endpoints only; never grants execution rights.
const crypto=require('node:crypto');
const {signed,verifiedSigned,digest}=require('../src/canonical');
const {publicKey,verifyCredential,verifyGrant}=require('../network/identity');
const TTL_MS=3*60*1000;
function deny(s){throw new Error('AGENT_DISCOVERY: '+s);}
function present(peer,{now=Date.now()}={}){
  const {local,identity,dir}=peer;
  const id=local.id, member=local.directory[id];
  const credential=verifyCredential({credential:local.credentials[id],authorityKey:publicKey(local.credentialAuthoritySpki),
    revokedIds:require('../network/identity').loadRevocations(dir),expected:member,now});
  verifyGrant({grant:local.grant,governanceKey:publicKey(member.governanceKeySpki),credential,
    scoreDigest:local.scoreDigest,now});
  const payload={schema:'octolang.agent-presentation.v0.8',version:'0.8',
    proofPurpose:'agentDiscovery',issuer:id,subject:{community:id,agent:member.agent},
    endpoint:local.url,capability:member.capability,maxLovelace:member.maxLovelace,
    policyDigest:local.scoreDigest,credentialId:credential.id,
    credentialDigest:digest(local.credentials[id]),grantDigest:digest(local.grant),grant:local.grant,
    issuedAt:new Date(now).toISOString(),expiresAt:new Date(now+TTL_MS).toISOString(),
    nonce:crypto.randomUUID()};
  return signed(payload,identity);
}
function verifyPresentation(presentation,{config,community,revokedIds=[],now=Date.now()}={}){
  const p=presentation?.payload, member=config?.directory?.[community];
  if(!member||!p||p.schema!=='octolang.agent-presentation.v0.8'||
     p.version!=='0.8'||p.proofPurpose!=='agentDiscovery'||p.issuer!==community||
     p.subject?.community!==community||p.subject?.agent!==member.agent||
     p.endpoint!==config.urls?.[community]||p.capability!==member.capability||
     p.maxLovelace!==member.maxLovelace||p.policyDigest!==config.scoreDigest||
     !verifiedSigned(presentation,publicKey(member.communityKeySpki)))deny('invalid presentation or identity');
  const from=Date.parse(p.issuedAt),to=Date.parse(p.expiresAt);
  if(!Number.isFinite(from)||!Number.isFinite(to)||from>now+30000||to<=now||
    to<=from||to-from>TTL_MS+30000||typeof p.nonce!=='string'||p.nonce.length<16)deny('expired or future presentation');
  const credential=verifyCredential({credential:config.credentials[community],
    authorityKey:publicKey(config.credentialAuthoritySpki),revokedIds,expected:member,now});
  if(p.credentialId!==credential.id||p.credentialDigest!==digest(config.credentials[community]))deny('credential not bound');
  // Verify authority independently: do not trust a remote assertion that governance approved it.
  verifyGrant({grant:p.grant,governanceKey:publicKey(member.governanceKeySpki),credential,
    scoreDigest:config.scoreDigest,now});
  if(p.grantDigest!==digest(p.grant))deny('governance grant digest mismatch');
  return {community,agent:member.agent,capability:member.capability,endpoint:p.endpoint,
    credentialId:credential.id,policyDigest:p.policyDigest,expiresAt:p.expiresAt,
    communityFingerprint:crypto.createHash('sha256').update(Buffer.from(member.communityKeySpki,'base64')).digest('hex'),
    presentationDigest:digest(presentation),verified:true,
    note:'Discovery is not authorisation. Peer governance and VCC recheck at execution.'};
}
module.exports={present,verifyPresentation};
