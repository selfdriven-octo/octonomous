'use strict';
// Read-only status projection. Deliberately omits raw requests, evidence, identifiers,
// credentials, private keys, and outbox file paths from browser responses.
const fs=require('node:fs');
const path=require('node:path');
const {loadCoordinator,loadRevocations}=require('../network/identity');
const {publicAnchors,actorKeys}=require('../network/common');
const {assess}=require('../integration/vcc');
const {verifyPartialTranscript,verifyTranscript}=require('../ensemble/verify');
const {verifyAttestation}=require('./context');
function status(home){
  if(!home)return {configured:false,message:'Set OCTOLANG_DISTRIBUTED_HOME to a provisioned coordinator home; monitor is read-only.'};
  const node=loadCoordinator(home), conf=node.local;
  if(!conf.remote||!conf.tls)throw Error('The selected home is not a distributed pinned-TLS coordinator');
  const outbox=path.join(node.dir,'state','outbox');
  const runs=[];
  for(const name of (fs.existsSync(outbox)?fs.readdirSync(outbox):[]).filter(x=>/^[0-9a-f]{64}\.json$/.test(x)).sort().slice(-100)){
    const file=path.join(outbox,name);
    const stat=fs.lstatSync(file);
    if(!stat.isFile()||stat.size>300000)continue;
    let entry;
    try{entry=JSON.parse(fs.readFileSync(file,'utf8'));}catch{continue;}
    if(entry?.schema!=='octolang.durable-outbox.v0.7')continue;
    const inputs=entry.inputs, steps=inputs?.policy?.ensemble?.steps?.length||0;
    let verification='NOT_CHECKED';
    try {
      const fixed={...inputs,trusted:publicAnchors(conf),usedNonces:new Set()};
      const check=assess(fixed);
      if(check.decision.status!=='ALLOW')throw Error('Current VCC denies: '+check.decision.status);
      if(inputs.policy.digest!==conf.scoreDigest)throw Error('Ungoverned score');
      const contributions=entry.contributions||[];
      if(contributions.length){
        verifyAttestation(contributions[0]?.output?.contextAttestation,
          {inputs,config:conf,revokedIds:loadRevocations(node.dir)});
        const args={inputs:fixed,contributions,trustedAgentKeys:actorKeys(conf),
          receiptSignerPublicKeySpki:conf.directory['community-execution'].agentKeySpki};
        if(entry.status==='COMPLETED')verifyTranscript(args);
        else verifyPartialTranscript(args);
      }
      verification=entry.status==='COMPLETED'?'REVERIFIED':'PARTIAL_REVERIFIED';
    }catch{verification='FAILED_OR_EXPIRED';}
    runs.push({runId:name.slice(0,16),status:entry.status,
      completedSteps:Array.isArray(entry.contributions)?entry.contributions.length:0,
      totalSteps:steps,attempts:Array.isArray(entry.attempts)?entry.attempts.length:0,
      verification});
  }
  const agents=Object.values(conf.directory).filter(x=>x.agent).map(x=>({
    community:x.id,agent:x.agent,capability:x.capability,endpoint:conf.urls[x.id],
    provisioned:true,discovery:'CHECK_WITH_PEER'}));
  return {configured:true,readOnly:true,mode:'PINNED_MTLS_OFP',scoreDigest:conf.scoreDigest,
    note:'Discovered endpoints and signed context require live independent verification. No execution via Studio.',
    agents,runs};
}
module.exports={status};
