'use strict';
const {DistributedCoordinator}=require('../distributed/coordinator');
const {MEMBERS}=require('../network/identity');
async function main(root){
  const coordinator=new DistributedCoordinator({root});
  const results=[];
  for(const m of MEMBERS){
    try{results.push(await coordinator.discover(m.id));}
    catch(e){results.push({community:m.id,verified:false,reason:e.message});}
  }
  console.log(JSON.stringify({schema:'octolang.discovery-results.v0.8',results,
    note:'Independent verification against configured pinned identities, credentials and revocation list; NOT authority to execute.'},null,2));
  if(results.some(x=>!x.verified))process.exitCode=1;
  return results;
}
if(require.main===module)main(process.argv[2]||process.env.OCTOLANG_DISTRIBUTED_HOME||'.octolang-distributed-coordinator')
  .catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={main};
