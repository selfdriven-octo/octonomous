'use strict';
// A separately governed community attests the exact VCG check it performed.
// Never substitutes an attestation for independently revalidating the underlying claims.
const crypto=require('node:crypto');
const {signed,verifiedSigned,digest}=require('../src/canonical');
const {buildSnapshot}=require('../integration/vcg');
const {publicKey,verifyCredential}=require('../network/identity');
const {publicAnchors}=require('../network/common');
function fail(s){throw new Error('DISTRIBUTED_CONTEXT: '+s);}
function makeAttestation({peer,inputs,now=Date.now()}){
  const {local,identity,dir}=peer,id=local.id;
  if(id!=='community-research')fail('only research peer may originate this context attestation');
  const credential=verifyCredential({credential:local.credentials[id],authorityKey:publicKey(local.credentialAuthoritySpki),
    expected:local.directory[id],revokedIds:require('../network/identity').loadRevocations(dir),now});
  const snapshot=buildSnapshot({...inputs,trusted:publicAnchors(local),now});
  const payload={schema:'octolang.context-attestation.v0.8',proofPurpose:'verifiedContext',
    community:id,agent:local.directory[id].agent,credentialId:credential.id,
    policyDigest:inputs.policy.digest,requestDigest:digest(inputs.request),
    contextRoot:snapshot.root,claimDigests:inputs.claims.map(digest).sort(),
    issuedAt:new Date(now).toISOString(),expiresAt:new Date(now+120000).toISOString()};
  return signed(payload,identity);
}
function verifyAttestation(attestation,{inputs,config,community='community-research',revokedIds=[],now=Date.now()}={}){
  const p=attestation?.payload,member=config?.directory?.[community];
  if(!member||!p||p.schema!=='octolang.context-attestation.v0.8'||
    p.proofPurpose!=='verifiedContext'||p.community!==community||p.agent!==member.agent||
    !verifiedSigned(attestation,publicKey(member.communityKeySpki)))fail('untrusted context signer');
  const from=Date.parse(p.issuedAt),to=Date.parse(p.expiresAt);
  if(!Number.isFinite(from)||!Number.isFinite(to)||from>now+30000||to<=now||
    to<=from||to-from>150000)fail('stale/invalid context statement');
  const credential=verifyCredential({credential:config.credentials[community],
    authorityKey:publicKey(config.credentialAuthoritySpki),revokedIds,expected:member,now});
  if(p.credentialId!==credential.id||p.policyDigest!==inputs.policy.digest||
    p.requestDigest!==digest(inputs.request)||
    JSON.stringify(p.claimDigests)!==JSON.stringify(inputs.claims.map(digest).sort()))fail('context binding mismatch');
  const expected=buildSnapshot({...inputs,trusted:publicAnchors(config),now});
  if(expected.root!==p.contextRoot)fail('independent VCG root mismatch');
  return {verified:true,community,contextRoot:expected.root,claimCount:expected.nodes.length,
    attestationDigest:digest(attestation)};
}
module.exports={makeAttestation,verifyAttestation};
