# OctoLang v1.7 — Adaptive and Recursive Composition

**AI proposes · Humans govern · Agents adapt within mandates · Evidence remains independently checkable.**

v1.7 adds an **opt-in composition language** over the v1.6 typed mission IR. An AI may describe nested subplans and propose adaptive revisions, but cannot introduce an undeclared capability, transfer a parent agent's authority or exceed an independently signed mandate. The new release is **compile/admission-only**: it does **not** expand the existing runtime's executable permissions, provide a durable budget ledger or make a blockchain transaction.

## Quick start (Node.js 22+)

```bash
npm test
npm run compose:check
npm run compose:demo
npm run compose:conformance
node bin/octolang-compose.js compile examples/community-adaptive.octo examples/community-proofs.octo composition.json
node bin/octolang-compose.js verify examples/community-adaptive.octo examples/community-proofs.octo composition.json
```

`compose:demo` generates ephemeral Ed25519 governance, grant-issuer and proposer keys, then checks the original and revised composition under a signed mandate. It executes **no** service calls or autonomous tasks.

## Composition source

```text
composition learning_supplies {
  mission learning_materials
  node find_primary {
    parent root
    task find_supplier
    after none
    max_runs 1
    budget 2
  }
  node validate_supplier {
    parent find_primary
    task vet_supplier
    after find_primary
    max_runs 1
    budget 1
  }
}
```

This excerpt illustrates syntax but is **not a complete valid plan** for the existing source mission. See `examples/community-adaptive.octo` for the complete four-node plan and `examples/community-adaptive-revised.octo` for a bounded alternative.

## Release documents

- `docs/COMPOSITION-FORMAL-v1.7.md`: grammar, typed task inheritance, graph semantics, signed mandate, role grants, revision requirements, non-goals and production gaps.
- `docs/CONFORMANCE-v1.7.md`: frozen reference acceptance vectors.
- `language/v1.7/index.js`: pure parser/compiler/source-bound verifier.
- `language/v1.7/validate.js`: independent typed composition IR verifier.
- `language/v1.7/authority.js`: signature-verified **preflight** for mandates, grants and revision proposals.
- `bin/octolang-compose.js`: compile/check/verify commands.

**Security boundary:** an admitted composition is **not** approved for execution. The existing VCC must enforce the actual, up-to-date human approvals, signed role grants, context freshness, revocation, effect-time budgets and durable replay protection. A signed plan revision is not a replacement for an accepted-revision state machine.

---

# OctoLang v1.6 — Formal Language Core

**AI proposes · Humans govern · Deterministic controllers authorise · Evidence is checked.**

OctoLang v1.6 is a language-design release layered on top of the v1.5 implementation. It **does not expand what agents may execute**; the existing Octonomous/Midnight demos and interfaces are retained. The aim is to make the meaning of human-reviewed `.octo` missions reproducible for a second compiler/verifier.

## Quick start

Node.js 22+ required. No new runtime dependencies.

```bash
npm test
npm run language:check
npm run language:conformance
node bin/octolang-language.js compile examples/community-proofs.octo ./mission.artifact.json
node bin/octolang-language.js verify examples/community-proofs.octo ./mission.artifact.json
npm run studio  # optional legacy Studio, unchanged
```

`compile` writes a JSON language artifact containing (a) the original legacy mission policy, (b) the new canonical typed IR and independently checkable digest, and (c) static diagnostics. It does **not** generate an approval signature, wallet transaction, capability grant, proof, or executable token.

## Key files

- `docs/LANGUAGE-FORMAL-v1.6.md` — syntax, type/effect model, graph ordering, failure semantics and non-goals.
- `docs/TYPED-IR-v1.6.md` — IR schema, canonicalisation, domain separation and verification contract.
- `docs/CONFORMANCE-v1.6.md` — frozen cross-implementation acceptance requirements.
- `language/v1.6/index.js` — reference compiler and source-bound artifact verifier.
- `language/v1.6/validate.js` — separate structural/semantic typed IR verifier.
- `language/v1.6/*.schema.json` — portable JSON Schema structure definitions (not a replacement for semantic checks).
- `conformance/v1.6/manifest.json` — frozen positive/negative examples.
- `bin/octolang-language.js` — new language-design-only command line tool.

**Version boundary:** v1.6's `irDigest` and the earlier `legacyPolicy.digest` are intentionally different and **not interchangeable for human approval or execution**. This version does not prove any claimed outcome happened; it exposes requirements for evidence that separate runtime controls must validate.

---

# OctoLang v1.5 — Midnight acceptance toolkit

This release preserves OctoLang v1.4 and adds **operator-gated local Midnight Devnet acceptance tooling**. It does not certify that a live proof or ledger transaction was executed here.

**Start here:** [docs/MIDNIGHT-ACCEPTANCE-v1.5.md](docs/MIDNIGHT-ACCEPTANCE-v1.5.md).

```bash
npm test
npm run midnight:acceptance:preflight
# Only after a real local Midnight Devnet is running, Compact artifacts are compiled, and the wallet is funded:
# npm run midnight:acceptance:observe -- <bundle> <pins> <prepared> <approval> <reviewer-public.pem> <deployment> <sdk-result> <new-observation.json>
```

A successful independent indexer observation confirms membership of the **exact 32-byte salted commitment** in the configured local contract ledger; it does not prove off-chain truth, transaction causality, or independent network finality.

---

# OctoLang v1.5 — Midnight local Devnet SDK integration

**New in v1.4:** Concrete operator-side Midnight.js 4.1.1 local-Devnet wallet, Compact contract deployment and circuit invocation, indexer read, explicit human anchor approval, local evidence bundle generator, `midnight:doctor` and security-focused tests. The live circuit has **not been executed in this build environment** (Docker and Compact compiler unavailable). The inherited in-memory fixture is not a blockchain test.

**Start here:** [docs/MIDNIGHT-LIVE-v1.4.md](docs/MIDNIGHT-LIVE-v1.4.md).

Quick offline checks:

```bash
npm test
npm run midnight:demo         # IN-MEMORY ONLY
npm run midnight:doctor       # reports local Devnet prerequisites
```

**Never publish a commitment, export wallet keys, or approve a transaction based solely on an AI-authored OctoLang score.**

---

# OctoLang v1.2 — Declarative Capability and Proof Types

**Experimental Node.js 22+ CommonJS language/runtime release, based on v1.1.** An AI-authored mission may declare **what exact typed inputs** an independently approved external capability can receive, **which pinned service identity** must receive them, and **which kinds of independently verifiable signed receipts** each task must supply. These declarations are constraints, not permissions; the human signs the exact compiled mission, and the controller checks against independently signed service manifests and agent grants before effect.

```sh
npm test                 # 130 tests including 22 new v1.2 tests
npm run proofs:check     # parse/type-check v1.2 .octo example
npm run proofs:demo      # loopback signed service + offline verification
npm run capability:demo  # v1.1 example still supported
npm run studio           # browser Studio, compose/review only for v1.2 external capabilities
```

Read **[v1.2 language and proof assurance guide](docs/PROOF-TYPES-v1.2.md)** and **[v1.2 example mission](examples/community-proofs.octo)**. The demo writes `typed-bundle.json` and `public-demo-pins.json` in a temporary folder printed on completion; verify independently:

```sh
npm run capability:verify -- /tmp/<demo-folder>/typed-bundle.json /tmp/<demo-folder>/public-demo-pins.json
```

**Precisely what is proved:** valid Ed25519 signatures bound to a reviewed mission, operator-approved service manifest, exact request, completed local tool result, service-signed receipt and dependency-linked agent result. This is **proof-carrying evidence**, not mathematical proof of physical outcomes, formal program verification, a W3C VC, or a Groth16/ZK proof. The demo issuer and trust pins are generated locally, not production trust anchors. No actual remote Internet integration, payments or wallet access are exercised. The browser Studio does not automatically trust an externally provisioned capability.

---

# OctoLang v1.1 — Secure, Signed Capability Services

**Runnable Node.js 22+ CommonJS research prototype, extending v1.0.** Reviewed missions can now call an operator-approved external service through the actual Octonomous Runtime. A separately signed, mission-scoped manifest fixes the endpoint and disclosed input fields; the controller signs an exact, short-lived request; the service signs its result; the agent and controller produce independently verifiable evidence. **AI-generated source never grants authority.**

**[v1.1 capability guide](docs/CAPABILITIES-v1.1.md)** · [v1.0 mission execution](docs/MISSION-EXECUTION-v1.0.md) · [mission syntax](docs/MISSION-v0.9.md)

```sh
npm test                   # 108 tests: original 94 + 14 v1.1 tests
npm run capability:demo    # separate loopback HTTP service records one note and signs it
npm run mission:execute    # original bounded-local execution remains available
npm run studio             # existing Studio; external services NOT browser-enabled
```

The capability demo creates a temporary directory containing an exported evidence bundle and public-key pins. Verify offline with `npm run capability:verify -- <bundle.json> <independently-trusted-pins.json>`. The sample pins are self-generated demo artifacts; production trust pins must be distributed out of band.

**Safety boundary:** The new real side effect is **one note written to a local HTTP service on 127.0.0.1**. No payments, ADA transfers, arbitrary web browsing, external vendor APIs, wallet keys or shell operations. HTTPS remote service transport is explicitly opt-in but **not production-tested**. Manifest and credential formats are proprietary experimental formats; cryptographic signatures do not prove real-world truth. See the capability guide for trust, TLS, replay and recovery limitations.

---

# OctoLang v1.0 — Verified Local Mission Execution Controller

**Runnable, research-only Node.js 22+ CommonJS release** extending v0.9. The mission language can now run a **fixed allowlist of four local tool capabilities** through **actual Octonomous Runtime 1.0**, after deterministic VCC checks and human-signed approval. Each completed task produces a signed controller tool-result receipt plus an agent-signed, dependency-bound evidence receipt. A separate CLI verifier rechecks these against independently provided trust pins and an optional local journal.

**This is bounded local execution, NOT general autonomous task execution.** Research/validation/audit tools return deterministic local checks, not real supplier research or audits. The only side effect is recording a purchase *intent* to a JSONL file. No external network, payment, ADA transfer, Cardano, Groth16, wallet, or actual purchase. All supplied identity/context/credential fixtures are synthetic demonstration values.

[**v1.0 execution and assurance guide**](docs/MISSION-EXECUTION-v1.0.md) · [v0.9 language guide](docs/MISSION-v0.9.md) · [example `.octo` mission](examples/community-mission.octo)

```sh
npm test                # 94 tests (79 prior + 15 new controller/security/Studio tests)
npm run mission         # v0.9 simulation, preserved
npm run mission:execute # v1.0 local execution via actual Octonomous Runtime
npm run studio          # http://127.0.0.1:8787, new explicit local execution button
```

An executed demo prints its data directory. Independently recheck its receipts using its **public-key pins** (these are synthetic demo pins: never accept self-supplied pins from an untrusted sender):

```sh
npm run mission:verify -- <evidence-bundle.json> <trusted-public-keys.json> <local-intents.jsonl>
```

Security guarantees exercised: human-signature binding, typed limits, independently signed context/grants, signer-to-agent binding, allowlisted tools, runtime policy gates, effect-time revalidation, one-use tokens, atomic local replay reservation, sticky ambiguous failures, separate signatures on tool/agent evidence, dependency proof verification, journal-record check. **No claim of network-wide exactly-once delivery or real-world truth verification.**

---

# OctoLang v0.9 — Language of Verifiable Autonomous Composition

**Runnable Node.js 22+ / CommonJS research prototype** built on v0.8. The new `mission` construct describes typed inputs, named roles, independent capability requirements, bounded constraints, a multi-task dependency DAG, and exact evidence-backed outcomes. **An AI may draft source, but its draft is never authority.** A human must inspect and sign the exact compiled mission digest before planning even a *mock simulation*.

[**v0.9 language & assurance guide**](docs/MISSION-v0.9.md) · [Example mission](examples/community-mission.octo) · [Original language](docs/LANGUAGE.md)

```bash
npm test                   # 79 automated tests, including 12 new v0.9 tests
npm run mission-check      # Compile static checks only
npm run mission            # Four synthetic signers, DAG planning, mock evidence verification; no external actions
npm run studio             # http://127.0.0.1:8787; v0.9 Mission panel plus prior Studio
npm run distributed:demo   # Preserved v0.8 networked federation pilot
```

New mission features:

- **Typed inputs:** `ada` (exact decimal string), `integer` (safe nonnegative decimal string), `text`, `boolean`.
- **Constraints:** exact lovelace/integer maxima and signed, subject-bound required context.
- **Roles are requirements, not identities.** Role selection happens after compilation against issuer-signed, expiring grants pinned to the exact mission digest and capability. Deterministic selection cannot increase scope.
- **Task DAG:** up to 32 tasks with zero, one, or multiple predecessors, cycle rejection and deterministic ordering.
- **Outcomes:** evidence names bound to declared tasks; independent verification rechecks human review, typed constraints, signed grants, context and each task's own signed, dependency-bound receipt.
- **Studio:** offline or optional AI mission drafting; compile and inspect; sign using paired Ed25519 browser reviewer; verify synthetic local results. This is a **separate, non-executing** mission workflow. Earlier Studio execution demos are unchanged.

**Safety / readiness:** v0.9 missions currently **plan and verify mocked results only**. They do not dispatch general-purpose tools, move ADA, use real Cardano/Midnight/ZK, contact production agents, or replace OFP controls. Demo credentials, claimed supplier facts, grants and outcome receipts are synthetic local fixtures — cryptographic verification of them does not prove real-world truth. Mission-specific revocation, durable workflow state, production identity governance and integration with remote agent operations remain future work. v0.8 federation is maintained unchanged in this release.

---

# OctoLang v0.8 — Verifiable Agent Development Platform

A **Node.js 22+ / CommonJS** research implementation. Builds on all v0.7 functionality with remotely signed agent discovery, proof-bound peer governance, independently verified distributed context attestations, and a read-only federated run monitor inside the browser Studio.

**[v0.8 platform guide](docs/PLATFORM-v0.8.md) · [v0.7 multi-host runbook](docs/DISTRIBUTED-v0.7.md) · [Language](docs/LANGUAGE.md)**

```bash
npm test
npm run distributed:demo             # 3 independent OFP peers, pinned mTLS and extra discovery/context checks
npm run studio                       # http://127.0.0.1:8787
npm run distributed:discover -- ./coordinator-home  # when peers are running
```

Studio **Compose → Inspect → Human-sign** applies to its local prototype. Studio **Observe** displays a separately provisioned distributed coordinator's redacted, read-only run status with independent proof re-verification. It does *not* turn a browser approval into remote execution authority. For a retained coordinator home, set `OCTOLANG_DISTRIBUTED_HOME` before `npm run studio` (details in v0.8 guide).

**Security boundaries:** published agent presentations never grant permissions, only pinned identities and signed governance grants are accepted; each community independently checks context and authorisation before acting. Demo signer, issuer and steward remain synthetic. Custom signed attestations are **not** W3C Verifiable Credentials. No Groth16, Midnight, Cardano, payment or wallet integration. Tested as separate processes on one machine, **not** on separate physical hosts. Only effect is writing a purchase **intent** to a local Octonomous Runtime journal.

---

# OctoLang v0.7 — Distributed Federated Pilot

**Runnable Node.js 22+ CommonJS prototype for independently governed network participants and durable OFP delivery.** Extends OctoLang v0.6, preserving the previous browser Studio and all earlier functionality.

**[Separate-machine deployment runbook](docs/DISTRIBUTED-v0.7.md) · [v0.6 network guide](docs/NETWORK-v0.6.md) · [Language](docs/LANGUAGE.md)**

## Quick start

```sh
node --version             # Node.js 22+
openssl version            # OpenSSL required for v0.7 self-signed demo certificates
npm test                   # 61 tests, including 11 new multi-host trust and recovery tests
npm run distributed:demo   # Four distinct identity homes / three peer processes on one developer machine
npm run network:mtls       # Unchanged v0.6 localhost/mTLS demonstration
npm run studio             # Unchanged, local browser Studio at http://127.0.0.1:8787
```

**v0.7 key differences:** a peer now generates its own long-lived community, agent and governance keys; only its signed public registration is exchanged. The coordinator issues scoped demo credentials after explicit trust-pin confirmation. Each peer independently signs its own grant and validates an issuer-signed public activation bundle. Network connections require mutual TLS and pinned exact certificates, plus signed OFP payloads. A crash-durable coordinator outbox can resume delivery; peers reuse cached, signed completed-step receipts rather than repeating side effects.

This release was **tested with separate Node.js processes and separate filesystem homes on one machine**. The deployment runbook supports configured remote private/VPN host addresses, but no actual deployment on physically separate machines has been verified. It is not Internet-ready or a production custody system.

**Only effect:** the execution community writes one local purchase *intent* to its Octonomous Runtime 1.0 journal. The reviewer, supplier registry and steward attestations are labelled **synthetic demo fixtures**; no ADA, Cardano transaction, third-party purchase or privileged tool is involved. In-process browser Studio remains separate from this distributed command-line pilot.

The delivery model is **bounded at-least-once messaging with idempotent completed receipts**, not exactly-once transactions. If a peer crashes between reserving an operation and saving its receipt, it must be reconciled manually before further execution. Example request/attestation expiry windows are short (~4 / ~2 minutes). Unresolved offline delivery does not renew authority automatically.

---

# OctoLang v0.6 — Networked Federated Agents

**Runnable Node.js 22+ CommonJS research implementation, with independently running OFP peer processes, locally pinned cryptographic identities, per-community signed authority and optional mutual TLS.** Uses the original Octonomous Federation Protocol 1.0 and Octonomous Runtime 1.0.0 packages.

**[New network guide](docs/NETWORK-v0.6.md) · [Earlier in-process federation](docs/FEDERATION.md) · [Language](docs/LANGUAGE.md)**

## Try the new v0.6 workflow

```bash
node --version        # Node 22 or newer
npm test              # 50 tests: prior 40 + 10 cross-process/adversarial network tests
npm run network:mtls  # 3 distinct child processes; OpenSSL demo CA + client/server certs; OFP signing
npm run network       # fallback: signed OFP on loopback HTTP, no transport encryption
npm run studio        # existing browser human-review Studio, http://127.0.0.1:8787
```

`npm install` is unnecessary. `npm run network:mtls` uses `openssl` installed locally. **No ADA is spent:** the only effect is a signed local **intent-record** in the buyer community's journal, which is reported by the CLI. The demonstrator provisions synthetic reviewer, evidence issuer, steward and community credentials rather than querying the real world.

To reuse stable identities and run the communities from four manually started terminals (including the coordinator), see [docs/NETWORK-v0.6.md](docs/NETWORK-v0.6.md). The default `npm run network:mtls` makes a new temporary provisioning root every invocation. A real, independently hosted Internet federation is not supported yet; both demo modes bind strictly to loopback.

## Security model at a glance

- **AI output is a proposal, not a permission.** The exact compiled federation score digest requires a human review signature, valid signed VCG claims, and separate steward approval for larger amounts.
- **Trust does not arrive in a message.** Peers use only their locally provisioned signing identities, authority public keys, community credential, governance grant and revocation file. Modified grants, fake credentials, unknown senders and capability escalation fail closed.
- **Two authentication layers.** Real OFP signed messages with pinned Ed25519 community keys; optional mutual TLS using a throwaway development CA and role-specific client/server certificates.
- **Distributed process boundary.** Research, execution and audit peers each have their own event loop, isolated key files, local replay records and evidence signing keys. The coordinator does not read remote signing keys during runs.
- **Replays fail closed after restart.** Exclusive-create local claim files reserve envelope and action nonces before actions. This is deliberately not an exactly-once distributed transaction protocol.
- **No unbounded agent tools.** The only executable capability is the original Octonomous Runtime 1.0 demo tool that appends a local intent; no wallet signing, Cardano settlement, payment keys or user data sent to an external provider.

**Limitations:** The credentials are **custom experimental signed attestations**, not standards-compliant W3C Verifiable Credentials or proof-carrying data. All identities are provisioned under one development operator; the facts and steward signatures in the demo are mock fixtures. Browser Studio's v0.5 federation mode is still **in-process** and deliberately not linked to network peer trust. Do not expose the demo on the public Internet or use it to manage real funds.

---

# OctoLang v0.5 — Signed Federation Pilot

**Runnable reference implementation (Node.js 22+, CommonJS, no npm install needed).** Extends v0.4 with original Octonomous Federation Protocol 1.0 signed envelopes, constrained local cross-community composition, peer-local role grants and durable filesystem replay reservations. **Not a production or remotely distributed agent network.**

## Quick start

```bash
node --version             # 22+
npm test                   # 40 regression + adversarial tests
npm run federation-check   # Check .octo community role assignments
npm run federation         # CLI: signed OFP requests / replies among three mock communities
npm run studio             # Browser studio: http://127.0.0.1:8787
```

Unzip the directory first, then run the commands from `octolang-v0.5/`.

### Browser federation walkthrough

1. Choose **Offline federated score (three communities)** or the optional AI-based mode with an explicit `OPENAI_API_KEY` server configuration.
2. Inspect every scoped agent, capability, issuer, threshold, step and **community assignment** in the compiled score. Model-authored source has no authority by itself.
3. Pair your browser's Ed25519 reviewer key with the one-time code from Terminal and sign the exact compiled policy digest.
4. Prepare a 75 ADA action for `supplier-42`, then click **Mock steward approval** (the approved threshold is 50 ADA).
5. Click **Conduct signed federation (v0.5)**. The research, buyer and audit endpoint logic verifies OFP signed envelopes and distinct peer-local grants; buyer records only an INTENT in a local JSONL journal.
6. Attempt the same request again: the durable per-run claim prevents replay, including after restarting the server with the same data directory.

**All peer identities, registry claims, steward approval and audit statements are locally generated DEMO fixtures. There is NO money transfer or external network delivery.** The journal append is the only real side effect. Ephemeral community signing keys are not durable production identities.

### Components added in v0.5

- `examples/community-federation.octo`: full v0.5 federated score with fixed research/execution/audit communities.
- `federation/engine.js`: native OFP envelope creation/verification, logical recipient endpoint checks, local governance grants, transcript chain.
- `federation/durable.js`: cross-process exclusive-create, crash-sticky run and envelope nonce reservations.
- `federation/demo.js`: CLI demonstration with a restart/replay check.
- `test/federation.test.js`: eight new scenarios, including signature tampering and persisted replay.
- `docs/FEDERATION.md`: complete trust model, capabilities, limitations and roadmap.
- `vendor/octonomous-federation/`: unmodified, MIT-licensed **Octonomous Federation 1.0.0** package alongside the existing Octonomous Runtime 1.0.0.

**Key limitation:** Communities are logically isolated endpoints **within one process** with pinned test signing keys. This uses authentic OFP wire envelopes, but does not yet deploy federation gateways across real sovereign hosts. It exercises OFP envelope verification rather than the full OFP gateway/retry/governance service suite. Persistent reservations prevent replay, but there is no exactly-once distributed transaction protocol; crashes after an effect require manual reconciliation.

See [docs/FEDERATION.md](docs/FEDERATION.md) for precise boundaries and the next independently deployed version.

---

## Earlier v0.4 capabilities (preserved)

**Earlier v0.4 local agent reference.** Node.js **22+**, CommonJS, no external npm dependencies. Extends v0.3 with an **AI-authorable, human-reviewable three-agent score** whose contributions are individually Ed25519-signed, capability-scoped and linked to the previous step.

> **This is a prototype, not a secure production agent system.** The scout and checker use locally generated **mock identities**. The buyer invokes only the existing Octonomous Runtime 1.0 `record.purchase.intent` tool, which appends a **local journal line**. No ADA transfer, purchase, third-party API call, Midnight proof, Groth16 verification or OFP federation message occurs.

## Quick start

Unzip, then run from the `octolang-v0.4` directory:

```bash
node --version              # Node 22+
npm test                    # 32 tests: 23 existing + 9 multi-agent tests
npm run ensemble-check      # Validate the new .octo example
npm run ensemble            # Execute a full three-agent CLI demo
npm run studio              # Browser UI at http://127.0.0.1:8787
npm run integration         # Original v0.3 one-agent Runtime bridge demo
```

No `npm install` required. The original MIT-licensed Octonomous Runtime 1.0.0 code is vendored unchanged under `vendor/octonomous-runtime/`. The local studio listens only on loopback. Keep it off shared/public networks. Avoid providing real credentials, wallets or signing secrets.

### Studio walkthrough

1. Describe a goal, then choose **Offline multi-agent template (no AI)**, or optionally choose **OpenAI multi-agent** if you explicitly configure `OPENAI_API_KEY` on the local server.
2. Read the score and its compiled explanation: three separate agents (`scout`, `buyer`, `checker`), their fixed capabilities, required evidence and dependency chain.
3. Enter the one-time pairing code from the terminal. Browser creates a local non-exportable Ed25519 reviewer key and signs the exact compiled policy digest.
4. Prepare an action (e.g. `75 ADA` at `supplier-42`). Studio creates a clearly identified **mock supplier claim**; for amounts above 50 ADA choose **Mock steward approval**.
5. Choose **Conduct 3-agent score**. The scout checks the signed mock claim; the buyer invokes the native Octonomous Runtime to record one intent to `.octolang-local/local-intents.jsonl`; the checker signs a demo audit assertion. The verifier checks each signature and dependency before moving to the next step.
6. Inspect the result: `COMPLETED_LOCAL_DEMO`, each signed contribution, VCG root, chain-head SHA-256 digest and receipt. A second run with the same nonce is rejected during the running process.

**Remember:** Studio's `Simulate execution`, `Record local intent`, and `Conduct 3-agent score` share an in-process replay set. Prepare a **fresh action** when switching execution modes.

## How v0.4 differs from v0.3

| Area | v0.3 | v0.4 |
|---|---|---|
| Score | One action/capability | Bounded three-agent `ensemble` declaration |
| Composer | AI/offline single-agent | AI/offline multi-agent choice; output remains an unapproved draft |
| Governance | Browser Ed25519 score approval | Same approval binds complete multi-agent graph |
| Context | Signed local VCG snapshot | Same root bound to each contribution |
| Runtime | Octonomous Runtime 1.0 journal tool | Buyer step uses same tool, scout and checker are local mock signers |
| Verification | Local signed receipt | Per-step Ed25519 proof, predecessor binding, complete transcript verification |
| Effects | Append one local intent | Append one local intent, **no** networked agent or payment actions |
| Tests | 23 | 32 |

## Score example

See `examples/community-ensemble.octo`:

```octolang
ensemble supplies {
  step find_supplier {
    agent scout
    capability "research"
    depends none
    require accredited_provider
    evidence "signed.supplier-shortlist"
  }
  step record_purchase_intent {
    agent buyer
    capability "purchase"
    depends find_supplier
    require accredited_provider
    evidence "signed.local-intent"
  }
  step verify_receipt {
    agent checker
    capability "audit"
    depends record_purchase_intent
    require accredited_provider
    evidence "signed.audit-summary"
  }
}
```

These declarations live inside the normal `score` alongside existing `intent`, `context`, `agent`, `before`, `after`, and `on violation DENY` declarations. The compiler only accepts a **strict three-step linear chain (research → purchase → audit)**, with three distinct agents, no delegation and **zero ADA** authority for scout and checker. General DAGs and arbitrary agent tools remain future work.

## Control and trust model

- **Source is not authority.** Compiler produces a canonical `.v0.4` policy digest; human reviewer signs it; edits invalidate the signature.
- **Context matters.** A bounded signed-claim graph is reverified before each stage; every contribution binds to its root, score digest and request digest.
- **Capabilities do not transfer.** Each declared agent must match a single scoped capability; only `buyer` can invoke the native local journal tool; the bridge independently checks the VCC and native Octonomous Policy.
- **Evidence is explicit.** The signer authenticates a specific canonical contribution and its predecessor digest. Verification requires **independently pinned** agent public keys and journal signer key. A key included inside the transcript is not automatically trustworthy.
- **No real independent agent organisations.** The demonstration's identities and claims are generated locally. This does **not** certify that an external supplier is accredited or an actual audit occurred.
- **Replay is process-local.** A nonce is reserved before async work; durable cross-process exactly-once side effects and recovery have not been implemented. If the buyer records locally and a later audit fails, the journal entry is not rolled back.

### Implementation boundaries

The locally generated private keys for demo actors are used by their mock handlers; the `EnsembleEngine` is a single process, not a secure isolated signer network. `registerLocalAgent` allows a host to install a trusted signer for a research/audit role, **not** to grant a new permission. A real deployment requires identity attestation, independently managed keys, governance approval, revocation, hardened VCC isolation, persistent atomic nonce claims and independently verified tool outcomes.

Cardano, Midnight, PCD/Groth16, external agent communications, real purchases and OFP federation are **not** implemented. Don't connect privileged MCP tools or wallets to this prototype.

## Project structure

- `src/` — backward-compatible parser/compiler, score and evidence verification
- `examples/community-ensemble.octo` — complete multi-agent language example
- `ensemble/engine.js` — bounded conductor, per-step VCC and agent verification
- `ensemble/verify.js` — independent verifier requiring caller-pinned public keys
- `ensemble/demo.js` — terminal walkthrough
- `integration/` — v0.3 VCG/VCC bridge to original Octonomous Runtime
- `studio/` — local browser score studio, mock evidence/approval, optional AI composer
- `test/ensemble.test.js` — 9 adversarial and API tests (plus 23 previous)
- `docs/ENSEMBLE.md` — language, trust boundaries, verification contract and extension plan
- `docs/INTEGRATION.md` — v0.3 bridge specification
- `vendor/octonomous-runtime/LICENSE` — original MIT licence

## Roadmap (not implemented)

- General DAG scores with typed inputs/outputs, parallelism and compensating actions.
- Independently operated agents with remote challenge/response, OFP signed envelopes and governance-approved identities.
- Persisted idempotency and authorisation grant journals with durable atomic claims.
- Isolated/attested VCC and real VCG provenance and revocation resolution.
- Optional PCD / Groth16 constraint proving, Cardano / Midnight settlement adapters with separate custody.

See `CHANGELOG.md` for v0.4 release notes.

## OctoLang v1.3 — Midnight Network (experimental)

This version adds a **human-reviewed `anchor ... { backend midnight ... }` declaration** to the mission language and a pluggable post-execution Midnight commitment interface. It creates domain-separated, salted SHA-256 commitments from **independently verified** signed Octonomous evidence, requires **separate human-signed approval of the chain target and commitment**, and provides a local fixture to test the adapter boundary. It includes a sample Compact contract source file.

```bash
npm test
npm run midnight:compile-mission
npm run midnight:demo
```

**No live Midnight transaction, ZK proof generation/verification, chain deployment or wallet transaction was performed for this release.** `midnight:demo` uses an in-memory fixture and never connects to midnight.network. Production Midnight integration must supply a separately audited Compact contract, compatible SDK/wallet/proof-server and independently trusted chain-reader adapter. Full instructions and limitations: **`docs/MIDNIGHT-v1.3.md`**.
