'use strict';
// v1.2 capability/proof type demo: local note service only, no third-party API.
const path=require('node:path');
const fs=require('node:fs');
const {source,setup}=require('../capabilities/demo');
const {fixtures}=require('../mission/demo');
const {MissionExecutionController,STATUS_EXT}=require('../mission/executor');
const {verifyBundle,exportPublic}=require('../capabilities/verify');
const {exportPins}=require('../mission/bundle');
const typedSource=source
  .replace('role scout { capability "service.note.record" }',`role scout { capability "service.note.record" }
  capability note_writer { role scout name "service.note.record" fields "note:text" service "notes-provider" }`)
  .replace('  on violation DENY',`  proof supplier_proof { task find_supplier kind service_receipt service "notes-provider" }
  proof vetted_proof { task vet_supplier kind controller_receipt }
  proof intent_proof { task record_intent kind controller_receipt }
  proof audit_proof { task independent_audit kind agent_receipt }

  on violation DENY`);
async function demo(){
  const h=setup({missionSource:typedSource});
  try{
    const {registry,manifest}=await h.start();
    const f=fixtures(h.mission,{inputs:{amount:'25',priority:'2',project:'Community learning',urgent:false,note:'Independent typed proof assessment'}});
    const params={mission:h.mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
    const engine=new MissionExecutionController({dataDir:path.join(h.dataDir,'controller'),
      controllerKeyPair:h.controller,capabilityRegistry:registry,
      agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]))});
    const result=await engine.execute(params);
    if(result.status!=='COMPLETED_CAPABILITY_MISSION')throw Error(result.reason||result.status);
    const bundle={...params,trust:undefined,plan:result.plan,receipts:result.receipts,capabilityManifests:[manifest]};
    const pins={...exportPins(f.trust,h.controller.publicKey),capabilityIssuers:{'community-operator':exportPublic(h.issuer.publicKey)},services:{'notes-provider':exportPublic(h.service.publicKey)}};
    fs.writeFileSync(path.join(h.dataDir,'typed-bundle.json'),JSON.stringify(bundle,null,2));
    fs.writeFileSync(path.join(h.dataDir,'public-demo-pins.json'),JSON.stringify(pins,null,2));
    const verified=verifyBundle(bundle,pins);
    if(verified.status!==STATUS_EXT||verified.typedProofs?.length!==4)throw Error(verified.reason||'Missing typed proof verification');
    console.log(JSON.stringify({status:result.status,schema:h.mission.schema,
      capabilityContract:h.mission.capabilities[0],proofs:verified.typedProofs,
      evidenceRoot:verified.root,serviceNoteCount:fs.readdirSync(path.join(h.dataDir,'service-notes')).length,
      dataDir:h.dataDir,externalEffect:'localhost note only',payments:false},null,2));
    return {h,result,bundle,pins,verified,registry,manifest,f,params};
  }finally{await new Promise((resolve,reject)=>h.server.close(e=>e?reject(e):resolve()));}
}
if(require.main===module)demo().catch(e=>{console.error(e);process.exitCode=1;});
module.exports={demo,typedSource};
