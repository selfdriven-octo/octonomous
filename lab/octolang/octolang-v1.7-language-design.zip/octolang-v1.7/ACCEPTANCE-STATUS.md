# OctoLang v1.5 — Acceptance status

Build date: 20 October 2026.

## Verified locally in the build environment

- Node.js v22.16.0.
- Existing v1.4 150-test regression suite: passed.
- Six new v1.5 acceptance/security tests: passed.
- Combined v1.5 test suite: **156 / 156 passed**.
- Static JavaScript syntax check of new and modified scripts: passed.
- Package clean-extraction test: see deliverable verification step.

## Not verified here

- Compact 0.31.1 compilation: compiler unavailable.
- Starting a Midnight network, indexer or proof server: Docker unavailable.
- Midnight SDK integration against an installed real SDK: dependencies not installed here.
- Wallet funding or DUST availability: no operator wallet configured.
- Actual contract deployment: not executed.
- Actual circuit ZK proof generation: not executed.
- Live Midnight transaction ID or chain confirmation: not observed.

A mocked indexer response or in-memory fixture is **not** a real Midnight chain observation. A real acceptance record can be produced by the commands in `docs/MIDNIGHT-ACCEPTANCE-v1.5.md` only once the operator has established a local Devnet.

## Security statements

The read-only indexer observer does not access wallet mnemonics, signing keys, private state or proof-server secrets. It checks the already signed off-chain evidence before querying the public state of the specified local contract. The target is immutable under the reviewed mission and signed publication approval. Its result establishes *current indexer-reported commitment membership*, not independent chain finality or real-world truth.
