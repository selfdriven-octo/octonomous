#!/usr/bin/env node
// Real Midnight local-devnet commands. No blockchain traffic in 'doctor'.
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import {spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {openLocalWallet,walletEnvironment} from './wallet.mjs';
import {loadSdk,deployLive,makeSdkAdapter} from './sdk.mjs';
const require=createRequire(import.meta.url);
const {verifyPrepared,verifyApproval,submitAnchor}=require('../bridge.js');
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const assets=path.join(root,'midnight/live/managed/evidence-anchor');
const load=(file)=>JSON.parse(fs.readFileSync(path.resolve(file),'utf8'));
const saveNew=(file,doc)=>fs.writeFileSync(path.resolve(file),JSON.stringify(doc,null,2)+'\n',{flag:'wx',mode:0o600});
const usage=()=>{
 console.log('Usage:\n  npm run midnight:doctor\n  npm run midnight:wallet-address\n  npm run midnight:deploy -- <new-deployment.json>\n  npm run midnight:anchor-live -- <bundle.json> <pins.json> <prepared-private.json> <approval.json> <reviewer-public.pem> <deployment.json> <new-result.json>\n  npm run midnight:verify-live -- <bundle.json> <pins.json> <prepared-private.json>');
};
function allow(name){if(process.env[name]!=='YES_LOCAL_DEVNET')throw Error(`Explicit ${name}=YES_LOCAL_DEVNET required`);}
function portOpen(port){return new Promise(r=>{
 const sock=net.connect({host:'127.0.0.1',port});const end=(v)=>{sock.removeAllListeners();sock.destroy();r(v)};
 sock.setTimeout(500,()=>end(false)).once('error',()=>end(false)).once('connect',()=>end(true));
});}
async function doctor(){
 const ports=await Promise.all([9944,8088,6300].map(async(port)=>({port,reachable:await portOpen(port)})));
 const assetsPresent=['contract/index.js','keys','zkir'].every(f=>fs.existsSync(path.join(assets,f)));
 const have=fs.existsSync(path.join(root,'midnight/live/node_modules/@midnight-ntwrk'));
 const compiler=spawnSync('compact',['compile','--version'],{encoding:'utf8',timeout:2500});
 console.log(JSON.stringify({mode:'LOCAL_DEVNET_PREFLIGHT_ONLY',network:'undeployed',ports,compilerArtifacts:assetsPresent,optionalSdkPackages:have,compactCompilerAvailable:compiler.status===0,compactCompilerVersion:(compiler.stdout||'').trim()||null,
 realProofGenerated:false,chainTransaction:false},null,2));
 if(!assetsPresent||!have||ports.some(x=>!x.reachable))process.exitCode=1;
}
async function context(){
 // Change to repository root so state paths and compile artifact locations are stable.
 process.chdir(root);
 const wallet=await openLocalWallet(walletEnvironment());
 try{await wallet.wallet.waitForSyncedState();const sdk=await loadSdk({managedDir:assets});return {wallet,sdk};}
 catch(e){await wallet.stop();throw e;}
}
async function walletAddress(){
 process.chdir(root);
 const wallet=await openLocalWallet(walletEnvironment());
 try{console.log(JSON.stringify({network:'local-devnet',address:wallet.accountId},null,2));}
 finally{await wallet.stop();}
}
async function deploy(file){
 allow('OCTOLANG_MIDNIGHT_ALLOW_DEPLOY');
 if(!file)throw Error('Missing new deployment JSON path');
 if(fs.existsSync(path.resolve(file)))throw Error('Refusing to overwrite existing deployment file');
 const {wallet,sdk}=await context();
 try{
  const result=await deployLive({providers:wallet.providers,sdk});
  const doc={schema:'octolang.midnight-deployment.v1',network:'local-devnet',contract:result.contractAddress,
    deploymentTransactionId:result.transactionId,createdAt:new Date().toISOString(),walletAddress:wallet.accountId};
  saveNew(file,doc);
  console.log(JSON.stringify({status:'MIDNIGHT_SDK_DEPLOY_RETURNED',network:doc.network,contract:doc.contract,
    transactionId:doc.deploymentTransactionId,deploymentFile:path.resolve(file)},null,2));
 }finally{await wallet.stop();}
}
async function submit(args){
 allow('OCTOLANG_MIDNIGHT_ALLOW_SUBMIT');
 if(args.length!==7)throw Error('Supply 7 paths: bundle pins prepared approval reviewerPublicKey deployment output');
 const [bundleFile,pinsFile,preparedFile,approvalFile,pubFile,deploymentFile,outFile]=args;
 if(fs.existsSync(path.resolve(outFile)))throw Error('Refusing to overwrite existing submission result');
 const bundle=load(bundleFile),pins=load(pinsFile),prepared=load(preparedFile),approval=load(approvalFile);
 const pub=fs.readFileSync(path.resolve(pubFile),'utf8');
 const deployment=load(deploymentFile);
 if(deployment?.schema!=='octolang.midnight-deployment.v1'||deployment.network!=='local-devnet'||
   deployment.contract!==prepared?.contract||prepared?.network!=='local-devnet')throw Error('Approved mission target does not match pinned deployment');
 if(!verifyPrepared(prepared,bundle,pins)||!verifyApproval(prepared,approval,pub))throw Error('Mission evidence or separate human anchor approval invalid');
 const {wallet,sdk}=await context();
 try{
  const adapter=makeSdkAdapter({providers:wallet.providers,sdk,contractAddress:deployment.contract});
  const submittedAt=new Date().toISOString();
  const sub=await submitAnchor({prepared,bundle,pins,approval,pinnedReviewerKey:pub,adapter});
  const chain=await adapter.readCommitment({network:sub.network,contract:sub.contract,transactionId:sub.transactionId});
  if(chain.commitment!==prepared.commitment||chain.finalized!==true)throw Error('Indexer state did not confirm the exact commitment after SDK call');
  const record={schema:'octolang.midnight-local-devnet-result.v1',status:'SDK_FINALIZED_AND_INDEXER_OBSERVED',
    network:sub.network,contract:sub.contract,commitment:sub.commitment,transactionId:sub.transactionId,
    submittedAt,observedAt:new Date().toISOString(),sdkAssurance:chain.assurance,blockHeight:chain.blockHeight??null,
    evidenceTruthProven:false,policyZkProofProven:false,
    caveat:'Midnight.js circuit call produced an SDK-finalized transaction; Compact ZK statement proves the circuit operation, NOT OctoLang off-chain policy compliance.'};
  saveNew(outFile,record);
  console.log(JSON.stringify(record,null,2));
 }finally{await wallet.stop();}
}
function verify(args){
 if(args.length!==3)throw Error('Supply bundle, pins, prepared paths');
 const [bundleFile,pinsFile,preparedFile]=args;
 const ok=verifyPrepared(load(preparedFile),load(bundleFile),load(pinsFile));
 console.log(JSON.stringify({status:ok?'INDEPENDENT_OFFCHAIN_COMMITMENT_VALID':'DENY',midnightTransaction:false},null,2));
 if(!ok)process.exitCode=1;
}
async function main(){const [action,...args]=process.argv.slice(2);
 switch(action){case'doctor':return doctor();case'wallet-address':return walletAddress();case'deploy':return deploy(args[0]);case'submit':return submit(args);case'verify':return verify(args);default:usage();process.exitCode=2;}
}
if(import.meta.url===`file://${process.argv[1]}`)main().catch(e=>{console.error(`OctoLang Midnight: ${e.message}`);process.exitCode=1;});
