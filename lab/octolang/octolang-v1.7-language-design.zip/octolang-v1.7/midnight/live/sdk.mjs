// Real Midnight.js contract API boundary; no package loads until invoked by operator.
// Only a wallet-owning operator process can instantiate this API.
import { Buffer } from 'node:buffer';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';

const HEX32=/^[a-f0-9]{64}$/;
export const requireCommitment=(hex)=>{
  if(typeof hex!=='string'||!HEX32.test(hex))throw Error('Expected exactly 32 bytes of lower-case hex');
  return Uint8Array.from(Buffer.from(hex,'hex'));
};
export function assertTarget({network,contract},expected){
  if(network!=='local-devnet'||expected.network!=='local-devnet')throw Error('Live adapter only permits local-devnet');
  if(typeof contract!=='string'||!contract||contract!==expected.contract)throw Error('Contract target is not the pinned deployed contract');
}
export function commitmentMember(ledgerState,hex){
  const member=ledgerState?.evidenceCommitments;
  if(!member)throw Error('Indexer did not return evidenceCommitments ledger field');
  const bytes=requireCommitment(hex);
  if(typeof member.member==='function')return member.member(bytes)===true;
  if(typeof member.has==='function')return member.has(bytes)===true;
  throw Error('Unsupported Compact ledger map access; review generated binding API');
}
export async function loadSdk({managedDir}){
  const assets=path.resolve(managedDir);
  for(const dir of ['contract','keys','zkir']){
    if(!fs.existsSync(path.join(assets,dir)))throw Error(`Missing Compact compiler output: ${dir} (run npm run midnight:compact)`);
  }
  const {setNetworkId}=await import('@midnight-ntwrk/midnight-js-network-id');
  setNetworkId('undeployed');
  const [{CompiledContract}, {deployContract,findDeployedContract}]=await Promise.all([
    import('@midnight-ntwrk/midnight-js-protocol/compact-js'),
    import('@midnight-ntwrk/midnight-js-contracts')]);
  const modulePath=path.join(assets,'contract','index.js');
  if(!fs.existsSync(modulePath))throw Error('Missing generated Compact contract index.js');
  const generated=await import(pathToFileURL(modulePath).href);
  if(typeof generated.Contract!=='function'||typeof generated.ledger!=='function')throw Error('Unexpected generated Compact contract exports');
  const compiled=CompiledContract.withCompiledFileAssets(
    CompiledContract.withWitnesses(CompiledContract.make('evidence-anchor',generated.Contract),{}),assets);
  return {compiled,deployContract,findDeployedContract,ledger:generated.ledger};
}
export async function deployLive({providers,sdk}){
  const deployed=await sdk.deployContract(providers,{compiledContract:sdk.compiled,
    privateStateId:'octolangEvidenceAnchorPrivateState',initialPrivateState:{}});
  const contractAddress=deployed?.deployTxData?.public?.contractAddress;
  if(typeof contractAddress!=='string'||!contractAddress)throw Error('Deployment returned no contract address');
  return {contractAddress,transactionId:deployed?.deployTxData?.public?.txId??null};
}
export function makeSdkAdapter({providers,sdk,contractAddress,network='local-devnet',submitted=new Map()}){
  const expected={network,contract:contractAddress};
  if(!contractAddress||typeof contractAddress!=='string')throw Error('Pinned contract address required');
  if(!providers?.publicDataProvider||!sdk?.compiled||!sdk?.findDeployedContract||!sdk?.ledger)throw Error('Missing signed-off Midnight.js providers');
  return {
    async submitCommitment(input){
      assertTarget(input,expected);
      const bytes=requireCommitment(input.commitment);
      const deployed=await sdk.findDeployedContract(providers,{contractAddress,
        compiledContract:sdk.compiled,privateStateId:'octolangEvidenceAnchorPrivateState',initialPrivateState:{}});
      if(typeof deployed?.callTx?.anchorEvidence!=='function')throw Error('Generated Compact circuit anchorEvidence unavailable');
      // Real proof generation, balancing and transaction submission happen inside callTx.
      const result=await deployed.callTx.anchorEvidence(bytes);
      const txId=result?.public?.txId;
      if(typeof txId!=='string'||!txId)throw Error('Midnight SDK did not return a transaction ID');
      submitted.set(txId,{commitment:input.commitment,blockHeight:result?.public?.blockHeight??null});
      return {transactionId:txId,blockHeight:result?.public?.blockHeight??null};
    },
    async readCommitment({network:requestedNetwork,contract,transactionId}){
      assertTarget({network:requestedNetwork,contract},expected);
      // Do not pretend matching contract state alone establishes an association with a tx ID.
      const record=submitted.get(transactionId);
      if(!record)throw Error('Transaction has no locally observed verified submission record');
      const state=await providers.publicDataProvider.queryContractState(contractAddress);
      const material=sdk.ledger(state?.data);
      if(!commitmentMember(material,record.commitment))return {commitment:null,finalized:false};
      // 'finalized' reflects SDK callTx's returned confirmation and indexer state, not a
      // standalone consensus/finality proof. Do not use for high-assurance independent audit.
      return {commitment:record.commitment,finalized:true,
        blockHeight:record.blockHeight,assurance:'SDK_FINALIZED_CALL_AND_INDEXER_MEMBERSHIP'};
    }
  };
}
