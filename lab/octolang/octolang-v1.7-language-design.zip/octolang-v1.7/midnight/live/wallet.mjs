// Operator-held WalletFacade for local Midnight Devnet only.
// Based on the documented Node.js wallet provider pattern (Midnight.js 4.1.1).
import fs from 'node:fs';
import path from 'node:path';
import {Buffer} from 'node:buffer';

export function walletEnvironment(env=process.env){
  const seed=env.WALLET_SEED;
  const mnemonic=env.WALLET_MNEMONIC;
  if(Boolean(seed)===Boolean(mnemonic))throw Error('Set exactly one of WALLET_SEED or WALLET_MNEMONIC');
  if(seed&&!/^(?:[0-9a-fA-F]{2}){16,64}$/.test(seed.trim()))throw Error('Invalid wallet hex seed');
  const pwd=env.PRIVATE_STATE_PASSWORD;
  if(typeof pwd!=='string'||pwd.length<16)throw Error('PRIVATE_STATE_PASSWORD needs a strong value of 16+ chars');
  const home=path.resolve(env.OCTOLANG_MIDNIGHT_HOME||path.join(process.cwd(),'midnight','live','state'));
  if(env.MIDNIGHT_NETWORK&&env.MIDNIGHT_NETWORK!=='undeployed')throw Error('Only undeployed local network is supported by this prototype');
  return {seed,mnemonic,pwd,home};
}
const safeSnapshot=(home,address)=>path.join(home,`wallet-state-${address.replace(/[^a-zA-Z0-9_-]/g,'_')}.json`);
export async function openLocalWallet(options=walletEnvironment()){
  const {setNetworkId,getNetworkId}=await import('@midnight-ntwrk/midnight-js-network-id');
  setNetworkId('undeployed');
  const walletSdk=await import('@midnightntwrk/wallet-sdk');
  const ledger=await import('@midnight-ntwrk/midnight-js-protocol/ledger');
  const {levelPrivateStateProvider}=await import('@midnight-ntwrk/midnight-js-level-private-state-provider');
  const {indexerPublicDataProvider}=await import('@midnight-ntwrk/midnight-js-indexer-public-data-provider');
  const {NodeZkConfigProvider}=await import('@midnight-ntwrk/midnight-js-node-zk-config-provider');
  const {httpClientProofProvider}=await import('@midnight-ntwrk/midnight-js-http-client-proof-provider');
  const {ttlOneHour}=await import('@midnight-ntwrk/midnight-js-utils');
  const {mnemonicToSeedSync}=await import('@scure/bip39');
  let seed;
  if(options.seed)seed=Buffer.from(options.seed.trim(),'hex');
  else {
    const phrase=options.mnemonic.trim().toLowerCase().replace(/\s+/g,' ');
    if(!walletSdk.validateMnemonic(phrase))throw Error('Invalid BIP39 wallet mnemonic');
    seed=mnemonicToSeedSync(phrase);
  }
  const hd=walletSdk.HDWallet.fromSeed(seed);
  if(hd.type!=='seedOk')throw Error('Wallet seed rejected');
  const result=hd.hdWallet.selectAccount(0).selectRoles([walletSdk.Roles.Zswap,walletSdk.Roles.NightExternal,walletSdk.Roles.Dust]).deriveKeysAt(0);
  if(result.type!=='keysDerived')throw Error('Wallet key derivation failed');
  hd.hdWallet.clear();
  seed.fill(0);
  const shieldedSecretKeys=ledger.ZswapSecretKeys.fromSeed(result.keys[walletSdk.Roles.Zswap]);
  const dustSecretKey=ledger.DustSecretKey.fromSeed(result.keys[walletSdk.Roles.Dust]);
  const unshieldedKeystore=walletSdk.createKeystore(result.keys[walletSdk.Roles.NightExternal],getNetworkId());
  const accountId=String(unshieldedKeystore.getBech32Address());
  fs.mkdirSync(options.home,{recursive:true,mode:0o700});
  const statePath=safeSnapshot(options.home,accountId);
  const stored=fs.existsSync(statePath)?JSON.parse(fs.readFileSync(statePath,'utf8')):null;
  const endpoints={indexerHttpUrl:'http://127.0.0.1:8088/api/v4/graphql',indexerWsUrl:'ws://127.0.0.1:8088/api/v4/graphql/ws',node:'http://127.0.0.1:9944',proofServer:'http://127.0.0.1:6300'};
  const wallet=await walletSdk.WalletFacade.init({
    configuration:{networkId:getNetworkId(),indexerClientConnection:{indexerHttpUrl:endpoints.indexerHttpUrl,indexerWsUrl:endpoints.indexerWsUrl},
      provingServerUrl:new URL(endpoints.proofServer),relayURL:new URL('ws://127.0.0.1:9944'),
      txHistoryStorage:new walletSdk.NoOpTransactionHistoryStorage(),
      costParameters:{additionalFeeOverhead:300_000_000_000_000n,feeBlocksMargin:5}},
    shielded:(cfg)=>stored?walletSdk.ShieldedWallet(cfg).restore(stored.shielded):walletSdk.ShieldedWallet(cfg).startWithSecretKeys(shieldedSecretKeys),
    unshielded:(cfg)=>stored?walletSdk.UnshieldedWallet(cfg).restore(stored.unshielded):walletSdk.UnshieldedWallet(cfg).startWithPublicKey(walletSdk.PublicKey.fromKeyStore(unshieldedKeystore)),
    dust:(cfg)=>stored?walletSdk.DustWallet(cfg).restore(stored.dust):walletSdk.DustWallet(cfg).startWithSecretKey(dustSecretKey,ledger.LedgerParameters.initialParameters().dust)
  });
  await wallet.start(shieldedSecretKeys,dustSecretKey);
  let stopped=false;
  async function stop(){
    if(stopped)return;
    stopped=true;
    const snapshot={shielded:await wallet.shielded.serializeState(),unshielded:await wallet.unshielded.serializeState(),dust:await wallet.dust.serializeState()};
    const tmp=statePath+'.tmp';
    fs.writeFileSync(tmp,JSON.stringify(snapshot),{mode:0o600});
    fs.renameSync(tmp,statePath);
    await wallet.stop();
  }
  const zkConfigProvider=new NodeZkConfigProvider(path.resolve('midnight/live/managed/evidence-anchor'));
  const privateStateProvider=levelPrivateStateProvider({privateStateStoreName:path.join(options.home,'contract-private-state'),
    signingKeyStoreName:path.join(options.home,'contract-signing-keys'),privateStoragePasswordProvider:()=>options.pwd,accountId});
  const combinedProvider={
    getCoinPublicKey:()=>shieldedSecretKeys.coinPublicKey,
    getEncryptionPublicKey:()=>shieldedSecretKeys.encryptionPublicKey,
    async balanceTx(tx,ttl=ttlOneHour()){
      const recipe=await wallet.balanceUnboundTransaction(tx,{shieldedSecretKeys,dustSecretKey},{ttl});
      return wallet.finalizeRecipe(recipe);
    },
    submitTx:(tx)=>wallet.submitTransaction(tx)
  };
  const providers={privateStateProvider,
    publicDataProvider:indexerPublicDataProvider(endpoints.indexerHttpUrl,endpoints.indexerWsUrl),zkConfigProvider,
    proofProvider:httpClientProofProvider(endpoints.proofServer,zkConfigProvider),
    walletProvider:combinedProvider,midnightProvider:combinedProvider};
  return {providers,wallet,accountId,stop,statePath};
}
