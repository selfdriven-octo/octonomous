'use strict';
// Operator-triggered local note-writing demo. Rebinds actual deployed contract target
// BEFORE compiling, reviewing and running the mission; never publishes on-chain.
const fs=require('node:fs'),crypto=require('node:crypto'),path=require('node:path');
const {setup}=require('../../capabilities/demo');
const {fixtures}=require('../../mission/demo');
const {MissionExecutionController}=require('../../mission/executor');
const {exportPins}=require('../../mission/bundle');
const {exportPublic}=require('../../capabilities/verify');
const {prepareAnchor,verifyPrepared}=require('../bridge');
const source=fs.readFileSync(path.join(__dirname,'../../examples/community-midnight.octo'),'utf8');
async function generate(deploymentFile,newDir){
 const deployment=JSON.parse(fs.readFileSync(deploymentFile,'utf8'));
 if(deployment.schema!=='octolang.midnight-deployment.v1'||deployment.network!=='local-devnet'||
    typeof deployment.contract!=='string'||!deployment.contract||!/^[-_a-zA-Z0-9]{12,160}$/.test(deployment.contract))throw Error('Invalid local-devnet deployment document');
 if(!source.includes('contract "octolang_demo_contract_0001"'))throw Error('Anchor template changed; update binding logic');
 const missionSource=source.replace('contract "octolang_demo_contract_0001"',`contract "${deployment.contract}"`);
 if(fs.existsSync(newDir))throw Error('Output directory exists; refusing to overwrite');
 const h=setup({missionSource});
 try{
  const {registry,manifest}=await h.start();
  const f=fixtures(h.mission,{inputs:{amount:'25',priority:'2',project:'Community learning',urgent:false,note:'Midnight locally signed evidence commitment'}});
  const params={mission:h.mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
  const engine=new MissionExecutionController({dataDir:path.join(h.dataDir,'controller'),controllerKeyPair:h.controller,
      capabilityRegistry:registry,agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]))});
  const out=await engine.execute(params);
  if(out.status!=='COMPLETED_CAPABILITY_MISSION')throw Error(`Local mission refused: ${out.reason||out.status}`);
  const bundle={...params,trust:undefined,plan:out.plan,receipts:out.receipts,capabilityManifests:[manifest]};
  const pins={...exportPins(f.trust,h.controller.publicKey),capabilityIssuers:{'community-operator':exportPublic(h.issuer.publicKey)},services:{'notes-provider':exportPublic(h.service.publicKey)}};
  const prepared=prepareAnchor(bundle,pins);
  if(!verifyPrepared(prepared,bundle,pins))throw Error('Round-trip independent verification failed');
  fs.mkdirSync(newDir,{recursive:false,mode:0o700});
  for(const [name,data] of [['bundle.json',bundle],['pins.json',pins],['prepared-private.json',prepared]]){
    fs.writeFileSync(path.join(newDir,name),JSON.stringify(data,null,2)+'\n',{flag:'wx',mode:0o600});
  }
  return {status:'LOCAL_EVIDENCE_BUNDLE_READY_NOT_PUBLISHED',missionDigest:h.mission.digest,
    commitment:prepared.commitment,network:prepared.network,contract:prepared.contract,
    location:path.resolve(newDir),syntheticDemoIdentities:true,midnightTransactions:0};
 }finally{await new Promise((resolve,reject)=>h.server.close(e=>e?reject(e):resolve()));}
}
if(require.main===module){const [deployment,dest]=process.argv.slice(2);
 if(!deployment||!dest){console.error('Usage: npm run midnight:make-evidence -- <deployment.json> <new-empty-output-directory>');process.exitCode=2;}
 else generate(deployment,dest).then(x=>console.log(JSON.stringify(x,null,2))).catch(e=>{console.error(e.stack||e.message);process.exitCode=1;});
}
module.exports={generate};
