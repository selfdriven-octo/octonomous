'use strict';
// Human-controlled, off-chain sign-only operation, no network calls.
const fs=require('node:fs'),path=require('node:path');
const {verifyPrepared,signApproval}=require('../bridge');
function approve(preparedFile,bundleFile,pinsFile,privatePemFile,outFile){
  const prepared=JSON.parse(fs.readFileSync(preparedFile,'utf8'));
  const bundle=JSON.parse(fs.readFileSync(bundleFile,'utf8'));
  const pins=JSON.parse(fs.readFileSync(pinsFile,'utf8'));
  if(!verifyPrepared(prepared,bundle,pins))throw Error('Source evidence changed or independently invalid; refusing approval');
  if(prepared.network!=='local-devnet')throw Error('Approval tool only supports local-devnet');
  const privatePem=fs.readFileSync(privatePemFile,'utf8');
  const approval=signApproval(prepared,privatePem);
  fs.writeFileSync(outFile,JSON.stringify(approval,null,2)+'\n',{flag:'wx',mode:0o600});
  return {status:'HUMAN_SIGNATURE_CREATED_OFFLINE',output:path.resolve(outFile),commitment:prepared.commitment,network:prepared.network,contract:prepared.contract};
}
if(require.main===module){const args=process.argv.slice(2);
  if(args.length!==5){console.error('Usage: npm run midnight:approve -- <prepared-private.json> <bundle.json> <pins.json> <reviewer-private.pem> <new-approval.json>');process.exitCode=2;}
  else try{console.log(JSON.stringify(approve(...args),null,2))}catch(e){console.error(e.message);process.exitCode=1;}
}
module.exports={approve};
