'use strict';
const fs=require('node:fs');const crypto=require('node:crypto');const path=require('node:path');
const {setup}=require('../capabilities/demo');
const {fixtures}=require('../mission/demo');
const {MissionExecutionController}=require('../mission/executor');
const {exportPins}=require('../mission/bundle');
const {exportPublic}=require('../capabilities/verify');
const {LocalMidnightFixture}=require('./local-adapter');
const {prepareAnchor,signApproval,submitAnchor,signObservation,verifyObservedState}=require('./bridge');
const missionSource=fs.readFileSync(path.join(__dirname,'../examples/community-midnight.octo'),'utf8');
async function demo(){
  const h=setup({missionSource});
  try {
    const {registry,manifest}=await h.start();
    const f=fixtures(h.mission,{inputs:{amount:'25',priority:'2',project:'Community learning',urgent:false,note:'Privacy-preserving evidence commitment'}});
    const params={mission:h.mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
    const engine=new MissionExecutionController({dataDir:path.join(h.dataDir,'controller'),controllerKeyPair:h.controller,
      capabilityRegistry:registry,agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]))});
    const out=await engine.execute(params);
    if(out.status!=='COMPLETED_CAPABILITY_MISSION')throw Error(`Mission execution denied: ${out.reason||out.status}`);
    const bundle={...params,trust:undefined,plan:out.plan,receipts:out.receipts,capabilityManifests:[manifest]};
    const pins={...exportPins(f.trust,h.controller.publicKey),capabilityIssuers:{'community-operator':exportPublic(h.issuer.publicKey)},services:{'notes-provider':exportPublic(h.service.publicKey)}};
    const prepared=prepareAnchor(bundle,pins);
    // Fixture exports only the public reviewer key. Generate an independent, explicitly pinned
    // anchor operator key instead of pretending the mission review grants chain submission.
    const operator=crypto.generateKeyPairSync('ed25519');
    const actualApproval=signApproval(prepared,operator.privateKey);
    const adapter=new LocalMidnightFixture();
    const submission=await submitAnchor({prepared,bundle,pins,approval:actualApproval,pinnedReviewerKey:operator.publicKey,adapter});
    const observer=crypto.generateKeyPairSync('ed25519');
    const observation=signObservation(submission,observer.privateKey);
    const verified=await verifyObservedState({prepared,bundle,pins,submission,observation,pinnedObserverKey:observer.publicKey,adapter});
    if(verified.status!=='MATCHED_TRUSTED_MIDNIGHT_STATE_READER')throw Error(verified.reason||'Mock adapter validation failed');
    console.log(JSON.stringify({missionSchema:h.mission.schema,missionStatus:out.status,
      anchorBackend:h.mission.anchors[0].backend,commitment:prepared.commitment,publicContract:prepared.contract,
      reviewRequired:true,privateSaltNotPublished:true,localFixtureWrites:adapter.calls,
      observationStatus:verified.status,environment:'IN_MEMORY_MOCK_NOT_MIDNIGHT_NETWORK',
      midnightTransaction:false,groth16Proof:false,payments:false},null,2));
    return {h,out,bundle,pins,prepared,actualApproval,submission,observation,verified,adapter,operator,observer};
  } finally {await new Promise((resolve,reject)=>h.server.close(e=>e?reject(e):resolve()));}
}
if(require.main===module)demo().catch(e=>{console.error(e.stack||e);process.exitCode=1;});
module.exports={demo,missionSource};
