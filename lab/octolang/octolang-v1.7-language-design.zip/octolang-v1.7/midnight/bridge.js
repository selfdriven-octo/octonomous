'use strict';
// Midnight v1.3 integration seam. No Compact proof, chain transaction, or chain finality is
// asserted by this module. Actual submission and state reads require operator-provided adapters.
const crypto=require('node:crypto');
const {canonical,digest,signed,verifiedSigned}=require('../src/canonical');
const {verifyBundle}=require('../capabilities/verify');
const {STATUS,STATUS_EXT}=require('../mission/executor');
const DOMAIN=Buffer.from('octolang.midnight.anchor.v1\0','utf8');
const APPROVAL_SCHEMA='octolang.midnight-anchor-approval.v1';
const OBSERVATION_SCHEMA='octolang.midnight-observation.v1';
const HEX32=/^[a-f0-9]{64}$/;
const deny=(reason)=>({status:'DENY',reason});
const iso=ms=>new Date(ms).toISOString();
function exactAnchor(bundle){
  const a=bundle?.mission?.anchors;
  if(bundle?.mission?.schema!=='octolang.mission.v1.3'||!Array.isArray(a)||a.length!==1||a[0].backend!=='midnight'||a[0].phase!=='post_execution')
    throw Error('An exact human-reviewed Midnight anchor declaration is required');
  return a[0];
}
function computeCommitment(statement,salt){
  if(!HEX32.test(salt))throw Error('Salt must be 32 cryptographically random bytes');
  return crypto.createHash('sha256').update(DOMAIN).update(Buffer.from(salt,'hex')).update(Buffer.from(canonical(statement))).digest('hex');
}
function prepareAnchor(bundle,pins,{salt=crypto.randomBytes(32).toString('hex')}={}){
  const verified=verifyBundle(bundle,pins);
  if(![STATUS,STATUS_EXT].includes(verified.status))throw Error(`Independent mission evidence verification failed: ${verified.reason||verified.status}`);
  const {network,contract,label}=exactAnchor(bundle);
  const statement={schema:'octolang.midnight-evidence-statement.v1',missionDigest:bundle.mission.digest,
    planDigest:bundle.plan.digest,requestDigest:digest(bundle.request),contextRoot:bundle.plan.contextRoot,
    evidenceRoot:verified.root,network,contract};
  const commitment=computeCommitment(statement,salt);
  return {schema:'octolang.midnight-anchor-prepared.v1',anchor:label,network,contract,
    commitment,private:{salt,statement},chainStatus:'NOT_SUBMITTED',
    evidenceStatus:verified.status};
}
function verifyPrepared(prepared,bundle,pins){
  try{
    const expected=prepareAnchor(bundle,pins,{salt:prepared?.private?.salt});
    return prepared?.schema===expected.schema&&prepared.anchor===expected.anchor&&
      prepared.contract===expected.contract&&prepared.network===expected.network&&
      prepared.commitment===expected.commitment&&
      digest(prepared.private.statement)===digest(expected.private.statement);
  }catch{return false;}
}
function signApproval(prepared,reviewerPrivateKey,{reviewer='local-reviewer',now=Date.now(),minutes=5}={}){
  if(!HEX32.test(prepared?.commitment)||!Number.isInteger(minutes)||minutes<1||minutes>60)throw Error('Invalid prepared commitment or approval window');
  return signed({schema:APPROVAL_SCHEMA,reviewer,network:prepared.network,contract:prepared.contract,
    commitment:prepared.commitment,missionDigest:prepared.private.statement.missionDigest,
    requestDigest:prepared.private.statement.requestDigest,issuedAt:iso(now),expiresAt:iso(now+minutes*60000)},reviewerPrivateKey);
}
function verifyApproval(prepared,approval,pinnedReviewerKey,now=Date.now()){
  const p=approval?.payload;
  return !!(p&&p.schema===APPROVAL_SCHEMA&&p.network===prepared?.network&&p.contract===prepared?.contract&&
    p.commitment===prepared?.commitment&&p.missionDigest===prepared?.private?.statement?.missionDigest&&
    p.requestDigest===prepared?.private?.statement?.requestDigest&&
    p.reviewer==='local-reviewer'&&
    Number.isFinite(Date.parse(p.issuedAt))&&Number.isFinite(Date.parse(p.expiresAt))&&
    Date.parse(p.issuedAt)<=now+30000&&Date.parse(p.expiresAt)>now&&
    Date.parse(p.expiresAt)-Date.parse(p.issuedAt)<=3600000&&
    verifiedSigned(approval,pinnedReviewerKey));
}
async function submitAnchor({prepared,bundle,pins,approval,pinnedReviewerKey,adapter,now=Date.now()}={}){
  if(!verifyPrepared(prepared,bundle,pins))throw Error('Anchor evidence has changed or cannot be independently verified');
  if(!verifyApproval(prepared,approval,pinnedReviewerKey,now))throw Error('Separate human authorisation of exact Midnight commitment required');
  if(!adapter||typeof adapter.submitCommitment!=='function')throw Error('Explicitly configured Midnight adapter is required; no default network access');
  // Only the commitment and configured target leave this layer, never private witnesses or salt.
  const res=await adapter.submitCommitment({network:prepared.network,contract:prepared.contract,commitment:prepared.commitment});
  if(!res||typeof res.transactionId!=='string'||!/^[-_a-zA-Z0-9]{12,128}$/.test(res.transactionId))throw Error('Adapter did not return a valid transaction identifier');
  return {schema:'octolang.midnight-submission.v1',network:prepared.network,contract:prepared.contract,
    commitment:prepared.commitment,transactionId:res.transactionId,status:'SUBMITTED_UNCONFIRMED'};
}
// A correctly signed observation is an assertion BY THE OBSERVER. It is not a ZK proof.
function signObservation(submission,observerPrivateKey,{observer='trusted-indexer-operator',now=Date.now()}={}){
  if(submission?.schema!=='octolang.midnight-submission.v1')throw Error('Cannot observe invalid submission');
  return signed({schema:OBSERVATION_SCHEMA,observer,network:submission.network,contract:submission.contract,
    commitment:submission.commitment,transactionId:submission.transactionId,observedAt:iso(now)},observerPrivateKey);
}
function verifyObservation(prepared,submission,observation,pinnedObserverKey,{now=Date.now(),maxAgeMs=300000}={}){
  const p=observation?.payload;
  if(!p||!HEX32.test(prepared?.commitment)||submission?.schema!=='octolang.midnight-submission.v1'||
    p.schema!==OBSERVATION_SCHEMA||p.observer!=='trusted-indexer-operator'||
    p.network!==prepared.network||p.contract!==prepared.contract||p.commitment!==prepared.commitment||
    submission.network!==prepared.network||submission.contract!==prepared.contract||submission.commitment!==prepared.commitment||
    p.transactionId!==submission.transactionId||!Number.isFinite(Date.parse(p.observedAt))||
    Date.parse(p.observedAt)>now+30000||now-Date.parse(p.observedAt)>maxAgeMs||
    !verifiedSigned(observation,pinnedObserverKey))return deny('Untrusted or mismatched Midnight observer attestation');
  return {status:'VERIFIED_OBSERVER_ATTESTATION',commitment:p.commitment,transactionId:p.transactionId,
    warning:'Verifier signed an observation; this does not independently establish Midnight ledger inclusion or verify a ZK proof'};
}
// Optional verification against an independently configured authenticated network state reader.
// The reader itself is a trust assumption and must not be supplied by an untrusted bundle.
async function verifyObservedState({prepared,bundle,pins,submission,observation,pinnedObserverKey,adapter,now=Date.now()}={}){
  if(!verifyPrepared(prepared,bundle,pins))return deny('Off-chain evidence or prepared commitment is invalid');
  const attested=verifyObservation(prepared,submission,observation,pinnedObserverKey,{now});
  if(attested.status!=='VERIFIED_OBSERVER_ATTESTATION')return attested;
  if(typeof adapter?.readCommitment!=='function')return deny('Independently configured state reader is required');
  try{
    const actual=await adapter.readCommitment({network:prepared.network,contract:prepared.contract,transactionId:submission.transactionId});
    if(actual?.commitment!==prepared.commitment||actual?.finalized!==true)return deny('Independent state reader did not confirm exact finalized commitment');
    return {status:'MATCHED_TRUSTED_MIDNIGHT_STATE_READER',commitment:prepared.commitment,transactionId:submission.transactionId,
      warning:'Result depends on the independently configured state reader; not a local Groth16 proof verification'};
  }catch(e){return deny(`Midnight reader unavailable: ${e.message}`);}
}
module.exports={prepareAnchor,verifyPrepared,computeCommitment,signApproval,verifyApproval,submitAnchor,signObservation,verifyObservation,verifyObservedState};
