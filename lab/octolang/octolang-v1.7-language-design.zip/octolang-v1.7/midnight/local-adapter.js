'use strict';
// Local fixture ONLY. NOT the Midnight SDK or blockchain. Never use as a production adapter.
const crypto=require('node:crypto');
const {digest}=require('../src/canonical');
class LocalMidnightFixture {
  constructor(){this.records=new Map();this.calls=0;}
  async submitCommitment({network,contract,commitment}) {
    if(network!=='local-devnet'||!/^([a-f0-9]{64})$/.test(commitment))throw Error('local test configuration required');
    const transactionId='MOCK_'+digest({network,contract,commitment}).slice(0,60);
    const prior=this.records.get(transactionId);
    if(prior&&prior.commitment!==commitment)throw Error('Conflicting mock record');
    if(!prior){this.calls++;this.records.set(transactionId,{network,contract,commitment,finalized:true});}
    return {transactionId};
  }
  async readCommitment({network,contract,transactionId}) {
    const p=this.records.get(transactionId);
    if(!p||p.network!==network||p.contract!==contract)return null;
    return {...p};
  }
}
module.exports={LocalMidnightFixture};
