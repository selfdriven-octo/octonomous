'use strict';
// Offline, no network request. Writes PRIVATELY HELD salt / evidence opening to chmod 0600 file.
const fs=require('node:fs');const path=require('node:path');
const {prepareAnchor}=require('./bridge');
function prepareFiles(bundlePath,pinsPath,outputPath){
  const bundle=JSON.parse(fs.readFileSync(bundlePath,'utf8'));
  const pins=JSON.parse(fs.readFileSync(pinsPath,'utf8'));
  const prepared=prepareAnchor(bundle,pins);
  const safe=path.resolve(outputPath);
  fs.writeFileSync(safe,JSON.stringify(prepared,null,2)+'\n',{flag:'wx',mode:0o600});
  return {schema:prepared.schema,network:prepared.network,contract:prepared.contract,
    commitment:prepared.commitment,status:prepared.chainStatus,
    privateOpeningFile:safe,warning:'Keep private opening file off-chain and protect its salt; no transaction submitted'};
}
if(require.main===module){const [bundle,pins,dest]=process.argv.slice(2);
  if(!bundle||!pins||!dest){console.error('Usage: npm run midnight:prepare -- <v1.3-evidence-bundle.json> <independently-pinned-public-keys.json> <new-private-opening.json>');process.exitCode=2;}
  else try{console.log(JSON.stringify(prepareFiles(bundle,pins,dest),null,2));}catch(e){console.error(e.message);process.exitCode=1;}
}
module.exports={prepareFiles};
