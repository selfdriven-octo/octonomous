#!/usr/bin/env node
'use strict';
// Only checks prerequisites. It never deploys, funds a wallet or submits a transaction.
const fs=require('node:fs');const path=require('node:path');const net=require('node:net');const {spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'../..');
function binary(name,args=[]){
 const r=spawnSync(name,args,{encoding:'utf8',timeout:4500});
 return {available:!r.error&&r.status===0,version:((r.stdout||r.stderr||'').trim().split('\n')[0]||'').slice(0,120)};
}
function reachable(port){return new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port});
 const end=v=>{s.removeAllListeners();s.destroy();resolve(v)};s.setTimeout(600,()=>end(false)).on('error',()=>end(false)).on('connect',()=>end(true));});}
async function collect({bin=binary,port=reachable,exists=fs.existsSync,env=process.env}={}){
 const node=process.versions.node;const docker=bin('docker',['compose','version']);const compiler=bin('compact',['compile','--version']);
 const generated=path.join(root,'midnight/live/managed/evidence-anchor');
 const artifacts=['contract/index.js','keys','zkir'].map(f=>({item:f,present:exists(path.join(generated,f))}));
 const services=await Promise.all([9944,8088,6300].map(async x=>({port:x,reachable:await port(x)})));
 const sdkPresent=exists(path.join(root,'midnight/live/node_modules/@midnight-ntwrk/midnight-js-contracts'));
 const walletConfigured=Boolean(env.WALLET_MNEMONIC)!==Boolean(env.WALLET_SEED);
 const privateStateConfigured=Boolean(env.PRIVATE_STATE_PASSWORD);
 const blockers=[];
 if(Number(node.split('.')[0])<22||(Number(node.split('.')[0])===22&&Number(node.split('.')[1])<12))blockers.push('Node 22.12+ needed');
 if(!docker.available)blockers.push('Docker Compose v2 unavailable');
 if(!compiler.available||!compiler.version.includes('0.31.1'))blockers.push('Compact 0.31.1 unavailable');
 if(artifacts.some(x=>!x.present))blockers.push('Compiled Compact artifacts missing');
 if(!sdkPresent)blockers.push('Optional Midnight SDK dependencies missing');
 if(services.some(x=>!x.reachable))blockers.push('Local network ports not all reachable');
 if(!walletConfigured||!privateStateConfigured)blockers.push('Disposable local wallet secret or private-state password missing');
 return {schema:'octolang.midnight-local-preflight.v1',checkedAt:new Date().toISOString(),readOnly:true,
  versions:{node,docker,compact:compiler},artifacts,services,
  sdkPresent,walletSecretConfigured:walletConfigured,privateStatePasswordConfigured:privateStateConfigured,
  readyForOperatorLiveAttempt:blockers.length===0,blockers,performedLiveProof:false,transactionSubmitted:false};
}
if(require.main===module)collect().then(r=>{console.log(JSON.stringify(r,null,2));if(r.blockers.length)process.exitCode=1;})
 .catch(e=>{console.error('Preflight failed:',e.message);process.exitCode=1;});
module.exports={collect};
