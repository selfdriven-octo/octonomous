'use strict';
// Read-only assessment. Does not create or send transactions, and does not require a wallet.
const {verifyPrepared,verifyApproval}=require('../bridge');
const HEX32=/^[a-f0-9]{64}$/;
const TX=/^[A-Za-z0-9_-]{12,128}$/;
function assertDocumentBinding({bundle,pins,prepared,approval,reviewerPublicKey,deployment,result}){
  const fail=(reason)=>({ok:false,status:'DENY',reason});
  if(!verifyPrepared(prepared,bundle,pins))return fail('Signed mission evidence or salted commitment is invalid');
  if(deployment?.schema!=='octolang.midnight-deployment.v1'||deployment.network!=='local-devnet'||
    typeof deployment.contract!=='string'||!deployment.contract||deployment.contract!==prepared.contract||
    prepared.network!=='local-devnet')return fail('Deployment target does not match the reviewed mission');
  if(result?.schema!=='octolang.midnight-local-devnet-result.v1'||result.status!=='SDK_FINALIZED_AND_INDEXER_OBSERVED'||
    result.network!=='local-devnet'||result.contract!==prepared.contract||
    result.commitment!==prepared.commitment||!HEX32.test(result.commitment)||
    typeof result.transactionId!=='string'||!TX.test(result.transactionId))return fail('Result does not bind to the deployment and prepared commitment');
  if(result.evidenceTruthProven!==false||result.policyZkProofProven!==false)
    return fail('Result improperly claims that off-chain truth or policy proof was established');
  // Check human authorisation at the operator-recorded submission time, not long after expiry.
  // The timestamp itself is not remotely attested and is not evidence of when a chain tx occurred.
  const submittedAt=Date.parse(result.submittedAt);
  if(!Number.isFinite(submittedAt))return fail('No recorded submission initiation time (v1.5 result required)');
  if(!verifyApproval(prepared,approval,reviewerPublicKey,submittedAt))return fail('Invalid reviewer signature or expired approval at recorded submission time');
  const observedAt=Date.parse(result.observedAt);
  if(!Number.isFinite(observedAt)||observedAt<submittedAt)return fail('Missing or inconsistent result observation time');
  return {ok:true,status:'OFFCHAIN_SIGNATURES_VALID_AND_SDK_REPORT_BOUND',
    contract:prepared.contract,network:prepared.network,commitment:prepared.commitment,
    transactionId:result.transactionId,submissionTimeIsOperatorAsserted:true};
}
function assessIndexerMembership(doc,member){
  const pre=assertDocumentBinding(doc);
  if(!pre.ok)return pre;
  if(member!==true)return {ok:false,status:'NOT_OBSERVED',reason:'Configured indexer does not show exact commitment'};
  return {...pre,status:'INDEXER_MEMBERSHIP_CONFIRMED',ok:true,
    assurance:'Verified signatures and exact commitment currently appears in configured local Midnight indexer. Not an independent proof of transaction causality, finality, or external facts.',
    realWorldTruthProven:false,offchainPolicyZkProven:false};
}
module.exports={assertDocumentBinding,assessIndexerMembership};
