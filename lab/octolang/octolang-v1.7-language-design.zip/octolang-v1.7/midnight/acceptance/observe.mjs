#!/usr/bin/env node
// Independent read-only local indexer query: wallet keys, mnemonic, private salt never sent.
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {assessIndexerMembership,assertDocumentBinding}=require('./core.cjs');
const {commitmentMember}=await import('../live/sdk.mjs');
const load=(p)=>JSON.parse(fs.readFileSync(path.resolve(p),'utf8'));
const save=(p,data)=>fs.writeFileSync(path.resolve(p),JSON.stringify(data,null,2)+'\n',{flag:'wx',mode:0o600});
function help(){console.error('Usage: node midnight/acceptance/observe.mjs <bundle> <pins> <prepared-private> <approval> <reviewer-public.pem> <deployment> <sdk-result> <new-observation.json>');}
export async function queryMembership({address,commitment,provider,generatedLedger}){
 if(typeof address!=='string'||!address||!/^[a-f0-9]{64}$/i.test(commitment))throw Error('Malformed indexer read target');
 const response=await provider.queryContractState(address);
 if(!response?.data)throw Error('No readable contract state at target');
 return commitmentMember(generatedLedger(response.data),commitment.toLowerCase());
}
async function main(){
 const paths=process.argv.slice(2);
 if(paths.length!==8){help();process.exitCode=2;return;}
 const [bundle,pins,prepared,approval,publicKey,deployment,result,out]=paths;
 if(fs.existsSync(path.resolve(out)))throw Error('Refusing to overwrite existing observation file');
 const doc={bundle:load(bundle),pins:load(pins),prepared:load(prepared),approval:load(approval),
  reviewerPublicKey:fs.readFileSync(path.resolve(publicKey),'utf8'),deployment:load(deployment),result:load(result)};
 const valid=assertDocumentBinding(doc);
 if(!valid.ok)throw Error(valid.reason);
 const {setNetworkId}=await import('@midnight-ntwrk/midnight-js-network-id');
 const {indexerPublicDataProvider}=await import('@midnight-ntwrk/midnight-js-indexer-public-data-provider');
 setNetworkId('undeployed');
 const generatedFile=path.join(path.dirname(fileURLToPath(import.meta.url)),'../live/managed/evidence-anchor/contract/index.js');
 if(!fs.existsSync(generatedFile))throw Error('Compact-generated ledger code missing; compile contract first');
 const generated=await import(pathToFileURL(path.resolve(generatedFile)).href);
 if(typeof generated.ledger!=='function')throw Error('Compact-generated ledger reader missing');
 const indexerUrl='http://127.0.0.1:8088/api/v4/graphql';
 const websocketUrl='ws://127.0.0.1:8088/api/v4/graphql/ws';
 const provider=indexerPublicDataProvider(indexerUrl,websocketUrl);
 const member=await queryMembership({address:doc.deployment.contract,commitment:doc.prepared.commitment,provider,generatedLedger:generated.ledger});
 const assessment=assessIndexerMembership(doc,member);
 const receipt={schema:'octolang.midnight-acceptance-observation.v1',observedAt:new Date().toISOString(),
   source:'operator-selected-local-indexer',indexer:indexerUrl,...assessment};
 save(out,receipt);
 console.log(JSON.stringify(receipt,null,2));
 if(!assessment.ok)process.exitCode=1;
}
if(import.meta.url===pathToFileURL(process.argv[1]||'').href)main().catch(e=>{console.error(`Midnight indexer observation refused: ${e.message}`);process.exitCode=1;});
