'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const Octonomous = require('../vendor/octonomous-runtime');
const { signed, digest } = require('../src/canonical');
const { assess } = require('./vcc');

// Real Octonomous Runtime v1.0 + ToolRegistry + Policy. One hardcoded, local-only tool.
// NOT a wallet, payment, federation gateway, production VCG, or custody system.
class OctonomousBridge {
  constructor({ dataDir, toolHook, usedNonces } = {}) {
    this.dataDir = dataDir || fs.mkdtempSync(path.join(os.tmpdir(), 'octolang-v0.3-'));
    fs.mkdirSync(this.dataDir, { recursive: true });
    this.fileStore = new Octonomous.stores.FileStore({ basePath: path.join(this.dataDir, 'beings') });
    this.tools = new Octonomous.ToolRegistry();
    this.pending = new Map();
    this.executedNonces = usedNonces || new Set();
    this.signer = crypto.generateKeyPairSync('ed25519');
    this.toolHook = toolHook || null; // test-only hook for demonstrating an independent tool gate
    this.tools.register({ name: 'record.purchase.intent', description: 'Append an authorised local intent; never pay or order' }, (input, context) => this._record(input, context));
    this.runtime = new Octonomous.Runtime({
      store: this.fileStore, tools: this.tools, policy: new Octonomous.Policy(),
      cognition: {
        consider: () => Promise.resolve({ relevant: true }),
        decide: ({ event }) => Promise.resolve(this._decide(event)),
        reflect: ({ actionResult }) => Promise.resolve({ kind: 'OCTOLANG_CONTROLLED', success: actionResult?.ok === true })
      }
    });
  }
  _decide(event) {
    const grant = this.pending.get(event?.payload?.grantId);
    if (!grant || grant.eventId !== event.id || grant.state !== 'issued' ||
        event.type !== 'octolang.authorised-action' || event.payload.requestDigest !== digest(grant.request)) {
      return { shouldAct: false, action: { enabled: false }, commitment: { enabled: false } };
    }
    return { shouldAct: true, rationale: 'Compiled and reviewed score pre-authorised by VCC',
      action: { enabled: true, tool: 'record.purchase.intent', input: { grantId: grant.id } }, commitment: { enabled: false } };
  }
  async _record(input, context) {
    const grant = this.pending.get(input?.grantId);
    if (!grant || grant.state !== 'issued' || context?.event?.id !== grant.eventId ||
        context?.being?.id !== grant.beingId ||
        context?.governance?.allowed !== true || context?.decision?.action?.tool !== 'record.purchase.intent') {
      throw new Error('Missing one-use grant and independent Octonomous tool authorisation');
    }
    // Recheck current evidence, review, expiry, approval, and exact root at effect boundary.
    const refreshed = assess({ ...grant.inputs, usedNonces: new Set() });
    if (refreshed.decision.status !== 'ALLOW' || refreshed.snapshot.root !== grant.contextRoot ||
        refreshed.decision.requestDigest !== grant.requestDigest) {
      grant.state = 'rejected';
      throw new Error('Effect-time VCC check failed');
    }
    grant.state = 'consumed'; // before any async/side effect; fail closed on errors
    if (this.toolHook) await this.toolHook(grant);
    const record = { schema: 'octolang.local-intent.v0.3',
      eventId: grant.eventId, scoreDigest: grant.policy.digest, requestDigest: grant.requestDigest,
      contextRoot: grant.contextRoot, agent: grant.request.agent,
      supplier: grant.request.target, amount: grant.request.amount, currency: 'ADA',
      outcome: 'RECORDED_LOCAL_INTENT', occurredAt: new Date().toISOString() };
    fs.appendFileSync(path.join(this.dataDir, 'local-intents.jsonl'), JSON.stringify(record) + '\n', { encoding: 'utf8', flag: 'a' });
    const receipt = signed({ schema: 'octolang.local-intent-receipt.v0.3',
      signer: 'local-journal-demo', recordDigest: digest(record), requestDigest: grant.requestDigest,
      scoreDigest: grant.policy.digest, contextRoot: grant.contextRoot, outcome: 'RECORDED_LOCAL_INTENT',
      nonce: crypto.randomUUID(), issuedAt: new Date().toISOString() }, this.signer.privateKey);
    return { ok: true, outcome: 'RECORDED_LOCAL_INTENT', record, receipt };
  }
  async dispatch(inputs) {
    const { policy, request } = inputs || {};
    // Replay check and reservation performed synchronously BEFORE awaiting store I/O.
    // Single-process demonstration only; replace with atomic durable store in production.
    const { decision, snapshot } = assess({ ...inputs, usedNonces: this.executedNonces });
    if (decision.status !== 'ALLOW') return { decision, effect: null };
    if (this.executedNonces.has(request.nonce)) return { decision: { status: 'DENY', reason: 'Replay: already executing' }, effect: null };
    this.executedNonces.add(request.nonce);
    const id = crypto.randomUUID();
    const beingId = `octolang_${policy.digest.slice(0, 20)}`;
    const eventId = crypto.randomUUID();
    const grant = { id, state: 'issued', eventId, beingId, policy, request,
      inputs, requestDigest: decision.requestDigest, contextRoot: snapshot.root };
    this.pending.set(id, grant);
    const being = { id: beingId, identity: { kind: 'local-demo' }, purpose: policy.intent,
      subscriptions: ['octolang.authorised-action'],
      authority: { allowedTools: ['record.purchase.intent'], requiresApproval: [] }, memory: {} };
    // The Octonomous Runtime provides its real Being lifecycle, local Policy check,
    // ToolRegistry invocation and reflection persistence.
    try {
      await this.runtime.registerBeing(being);
      const event = { id: eventId, type: 'octolang.authorised-action',
        sourceBeingId: beingId, payload: { grantId: id, requestDigest: decision.requestDigest } };
      const execution = await this.runtime.handleEventForBeing(beingId, event);
      const actionResult = execution?.actionResult;
      const success = actionResult?.ok === true && actionResult?.outcome === 'RECORDED_LOCAL_INTENT';
      return { decision, contextRoot: snapshot.root, receiptPublicKeySpki: this.signer.publicKey.export({ type: 'spki', format: 'der' }).toString('base64'), runtime: { beingId, governance: execution?.governance,
        eventId, reflection: execution?.reflection },
        effect: success ? actionResult : null,
        status: success ? 'RECORDED_LOCAL_INTENT' : 'FAILED_CLOSED',
        error: success ? undefined : (actionResult?.error || actionResult?.reason || 'Runtime did not execute authorised tool') };
    } catch (e) {
      return { decision, effect: null, status: 'FAILED_CLOSED', error: e.message };
    } finally { this.pending.delete(id); }
  }
}
module.exports = { OctonomousBridge, Octonomous };
