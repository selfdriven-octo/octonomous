'use strict';
const crypto = require('node:crypto');
const { digest, verifiedSigned } = require('../src/canonical');
function verifyLocalReceipt({ record, receipt, receiptSignerPublicKeySpki }) {
  try {
    const key = crypto.createPublicKey({ key: Buffer.from(receiptSignerPublicKeySpki, 'base64'), type: 'spki', format: 'der' });
    const p = receipt?.payload;
    return key.asymmetricKeyType === 'ed25519' && p?.schema === 'octolang.local-intent-receipt.v0.3' &&
      record?.schema === 'octolang.local-intent.v0.3' &&
      p.outcome === 'RECORDED_LOCAL_INTENT' && record.outcome === p.outcome &&
      p.recordDigest === digest(record) && p.scoreDigest === record.scoreDigest &&
      p.requestDigest === record.requestDigest && p.contextRoot === record.contextRoot &&
      verifiedSigned(receipt, key);
  } catch { return false; }
}
module.exports = { verifyLocalReceipt };
