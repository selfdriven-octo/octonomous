'use strict';
const { evaluate } = require('../src/runtime');
const { buildSnapshot } = require('./vcg');
function assess({ policy, request, claims = [], approvals = [], review, trusted, usedNonces = new Set(), now = Date.now() }) {
  const decision = evaluate({ policy, request, claims, approvals, review, trusted, usedNonces, now });
  if (decision.status !== 'ALLOW') return { decision, snapshot: null };
  try {
    const snapshot = buildSnapshot({ policy, request, claims, trusted, now });
    return { decision: { ...decision, contextRoot: snapshot.root, controller: 'octolang.vcc.v0.3' }, snapshot };
  } catch (e) {
    return { decision: { status: 'DENY', reason: e.message, controller: 'octolang.vcc.v0.3' }, snapshot: null };
  }
}
module.exports = { assess };
