'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { demoSetup } = require('../src/demo');
const { OctonomousBridge } = require('./bridge');
const source = fs.readFileSync(path.join(__dirname, '..', 'examples', 'community-supplies.octo'), 'utf8');
(async () => {
  const ctx = demoSetup(source);
  const request = ctx.request('75');
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'octolang-v0.3-demo-'));
  const bridge = new OctonomousBridge({ dataDir });
  const result = await bridge.dispatch({ policy: ctx.policy, request, review: ctx.review,
    claims: [ctx.claim()], approvals: [ctx.approval(request)], trusted: ctx.trusted });
  console.log(JSON.stringify({ dataDir, decision: result.decision, status: result.status,
    runtime: result.runtime, record: result.effect?.record, receipt: result.effect?.receipt }, null, 2));
})().catch(e => { console.error(e); process.exitCode = 1; });
