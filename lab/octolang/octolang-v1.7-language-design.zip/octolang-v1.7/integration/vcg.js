'use strict';
// Minimal, externally verified Context Graph snapshot for the existing v0.1 claims.
// Trust is explicitly pinned and never inferred from an LLM response.
const { digest, verifiedSigned } = require('../src/canonical');

function buildSnapshot({ policy, request, claims, trusted, now = Date.now() }) {
  if (!policy || !request || !Array.isArray(claims) || claims.length < 1 || claims.length > 20) {
    throw new Error('VCG: missing score, request or bounded evidence');
  }
  const required = policy.contexts.find(x => x.label === policy.requiredContext);
  if (!required) throw new Error('VCG: required context missing in compiled policy');
  const nodes = [];
  const observations = new Set();
  for (const claim of claims) {
    const p = claim?.payload;
    if (p?.schema !== 'octolang.claim.v1' || p.issuer !== required.issuer ||
        p.claim !== required.claim || p.subject !== request.target ||
        !['VERIFIED', 'CONFLICTED', 'REVOKED'].includes(p.status)) {
      throw new Error('VCG: context schema/subject/issuer mismatch');
    }
    if (!trusted?.issuers?.[p.issuer] || !verifiedSigned(claim, trusted.issuers[p.issuer])) {
      throw new Error('VCG: untrusted or invalid evidence signature');
    }
    const from = Date.parse(p.issuedAt), to = Date.parse(p.expiresAt);
    if (!Number.isFinite(from) || !Number.isFinite(to) || from > now + 30000 ||
        to <= now || to <= from || to - from > 365 * 86400000 ||
        now - from > required.maxAgeMs || typeof p.nonce !== 'string' || p.nonce.length < 16) {
      throw new Error('VCG: stale/expired/invalid claim');
    }
    if (observations.has(p.nonce)) throw new Error('VCG: duplicated claim nonce');
    observations.add(p.nonce);
    if (p.status !== 'VERIFIED') throw new Error('VCG: contradictory or revoked claim');
    nodes.push({ id: digest(claim), subject: p.subject, predicate: p.claim, status: p.status,
      issuer: p.issuer, observedAt: p.issuedAt, validUntil: p.expiresAt, evidenceDigest: digest(claim) });
  }
  nodes.sort((a, b) => a.id.localeCompare(b.id));
  const snapshot = {
    schema: 'octolang.vcg-snapshot.v0.3', policyDigest: policy.digest,
    requestDigest: digest(request), nodes,
    edges: nodes.map(n => ({ from: n.id, to: digest({ subject: request.target }), kind: 'ASSERTS_ABOUT' }))
  };
  return { ...snapshot, root: digest(snapshot) };
}
module.exports = { buildSnapshot };
