# OctoLang v1.7 — Adaptive and Recursive Composition (Draft Specification)

**Status:** reference implementation, compile/admission only. Not a formally proven language, production policy engine or autonomous executor.

## Intent

An AI composes an inspectable *composition* over an independently compiled root mission. The composition can have nested nodes, repeated instances of tasks and revised topological plans; it **cannot** invent tasks, roles, capabilities, context requirements, proof types or effects.

A signed governance **mandate** (issued separately from the AI-authored `.octo` file) sets static limits. Separately signed **role grants** pin each role's exact capability, agent identity and resource ceilings. The verifier admits a candidate composition *only for further governed consideration*. Any real tool invocation requires the existing independent VCC, human reviews, validated context, persistent resource accounting and replay protection.

## 1. Grammar (normative syntax profile)

```ebnf
Composition  = "composition" Identifier "{" "mission" Identifier {Node} "}" ;
Node         = "node" Identifier "{" Parent Task After Runs Budget "}" ;
Parent       = "parent" (Identifier | "root") ;
Task         = "task" Identifier ;
After        = "after" ("none" | Identifier | String) ;
Runs         = "max_runs" Integer ;
Budget       = "budget" Integer ;
Identifier   = /[A-Za-z_][A-Za-z0-9_-]*/ ;
Integer      = /0|[1-9][0-9]*/ ;
```

`after` quoted strings contain comma-separated node identifiers. Parent, task, after, max_runs and budget each occur **exactly once** per node, in any order. `mission` occurs exactly once. Node declarations can occur in any order. `#` and `//` start comments. No executable expressions, loops, arbitrary imports, dynamic code, code evaluation, URLs or tokens beyond this grammar.

At most 32 nodes. `max_runs` 1..16; `budget` 0..1,000,000 abstract *budget units per run*. No unit conversion, billing or payment is implied. Structural depth is at most 6. A mission must first compile and pass the **v1.6 Typed IR** checks. Legacy score-only source is unsupported by this profile.

## 2. Static semantics

Define the root mission task table `Γtask`. For every composition node `n`:

1. `Γtask[n.task]` must exist. The node's role, required capability, effect classification, context and declared proofs are **derived from the root**, never asserted by AI-authored source.
2. `n.parent` is `root` or a valid other node. It is an orchestration dependency **not** a delegation of authority.
3. `n.after` lists zero or more valid other nodes, without duplicates or a reference to itself. Combined parent and after edges must form an acyclic graph.
4. Every task dependency from `Γtask[n.task].dependencies` must be represented by a reachable predecessor composition node with that root task name; nesting alone may satisfy this requirement.
5. The deterministic schedule is obtained by visiting all nodes in lexical name order, recursively visiting the sorted union of parent and after predecessors, and emitting each node once. This is a **stable topological schedule**, not permission to execute.
6. Worst-case reserved budget is `Σ(node.maxRuns × node.budgetUnitsPerRun)`; all arithmetic is exact safe integers within the specified limits. This represents one proposed plan, not actual spent resources.

A plan remains valid when its source comments, whitespace, field ordering or declaration order change without changing the derived IR. A semantically changed plan has a different IR digest.

## 3. Versioned IR and deterministic digest

Schema `octolang.composition-ir.v1.7` is a canonical JSON object with:

- `kind`, `name`, `missionName`, `missionIRDigest`;
- fixed `authority=REQUIRES_EXTERNAL_SIGNED_MANDATE_AND_ROLE_GRANTS`;
- sorted `nodes`, each bound to the root mission task, role, capability, effect, context, and proof obligations;
- `maxDepth`, `worstCaseBudgetUnits`, and deterministic `schedule`.

The SHA-256 digest is computed over `"OctoLang Composition IR v1.7\n" + canonical(ir)` using the existing canonical JSON serializer (sorted object keys, UTF-8, JSON primitives). `octolang.composition-artifact.v1.7` additionally stores raw source SHA-256 digests and the root mission typed-IR digest. The source-bound verifier recompiles **both** programs. The independent IR verifier rederives the graph and effect/proof bindings from an independently validated root IR.

The v1.7 composition digest is *not* a replacement for a v1.6 typed-IR digest, original mission-policy digest or reviewer approval. These are separate domains.

## 4. Signed authority envelope (preflight only)

An external issuer signs `octolang.composition-mandate.v1.7` using Ed25519 (canonical signed JSON). It includes:

- root mission IR digest, governance issuer, exact community subject, validFrom/expiresAt, fresh nonce;
- `allowRevision` boolean;
- `maxNodes`, `maxDepth`, `maxTotalBudgetUnits`;
- `allowedTasks[]` with exact root-task identity, `maxInstances`, `maxRunsPerInstance`, `maxBudgetUnitsPerRun`.

An independently pinned grant issuer signs `octolang.composition-role-grant.v1.7` for each used role, binding the **same explicitly expected community subject**, agent ID, root mission digest, role, exact capability, time window, max aggregate runs and maximum abstract budget units. The caller must supply `expectedSubject` out-of-band; a signed document cannot choose its own community context.

Admission requires all relevant signatures, pin lookups, schema fields and time windows to validate; the candidate IR must not exceed **any** mandate or role-grant ceiling. Signed documents cannot bootstrap their own key trust: the verifier receives issuer public keys from independent operator configuration. Rejection is `DENY`. Success is `ADMISSIBLE_PROPOSAL`, **never** an execution permit.

## 5. Revision semantics

An AI may propose a changed plan only if the governing signed mandate has `allowRevision=true`. A separately pinned proposer signs `octolang.composition-revision.v1.7`, binding both old and new exact IR digests, the signed mandate digest, sequence, random nonce and reason.

The reference verifier admits a revision only if both plans independently pass mandate/grant limits and the previous node identities cannot be repurposed for other tasks, capabilities, effect categories or proof declarations. For an existing node name, `maxRuns` and `budgetUnitsPerRun` may decrease but **not increase**. New node names can appear only within the externally signed task-instance and global ceilings.

The signature on the revision is evidence of **who proposed** it, not governance approval, actual execution, proof of outcome or a durable freshness guarantee. This library does not maintain a cross-revision spent-budget ledger, accept/reject sequence register, key revocation database, durable execution receipts or tool effects. A production controller MUST atomically track accumulated budget and idempotency across all revisions, enforce signed sequential accepted-parent continuity, and repeat all authority checks at execution time.

## 6. Privacy and threat boundaries

- No private keys, wallet signing or federation transport are involved in the compiler.
- A forged grant, unknown issuer key, wrong mission digest, excessive node budget, cyclic plan or missing root dependency is rejected.
- Compiled `requiredProofs` are obligations. Even a signed service receipt does **not** establish real-world truth.
- A parent node cannot automatically grant authority to its child. A child with a different role needs its own out-of-band signed role grant.
- No actual recursion at runtime is implemented: nesting is a finite statically bounded composition graph; new nodes require an explicitly admitted revision.
- It is unsafe to use `ADMISSIBLE_PROPOSAL` or `ADMISSIBLE_REVISION` as tool execution authorisation or to treat their abstract budget limits as a persistent accounting ledger.

## 7. Compatibility

The existing `mission`, `score`, Studio, Octonomous federation, Midnight scripts and proof adapters are untouched. This is a separate opt-in compilation and review path. No changes to legacy digests, transaction flows or signing keys.

The structural JSON Schema at `language/v1.7/composition-ir.schema.json` is advisory and does not replace the independent semantic verifier.

Frozen conformance examples: `conformance/v1.7/manifest.json`. Operator demo uses ephemeral keys only and has no effects beyond printing results.
