# OctoLang Typed Intermediate Representation v1.6

**Status:** reproducible draft IR for AI-authored, human-reviewable missions. Implemented in `language/v1.6/index.js` and independently structure-checked by `language/v1.6/validate.js`.

## Goals

Portable JSON Schema companions: `language/v1.6/typed-ir.schema.json` and `language/v1.6/artifact.schema.json`. These perform **structural validation only**; name resolution, proof associations, graph topology and hash binding must also be checked using `validate.js` or equivalent.

An independent implementation should be able to inspect a mission without rerunning the AI that composed it, interpret its bounded effect classifications, and reproduce the exact same semantic hash for equivalent sources. This IR is for analysis; it is **not an authority credential**.

## Top-level shape

```json
{
  "schema": "octolang.typed-ir.v1.6",
  "kind": "mission",
  "name": "learning_materials",
  "goal": "Research suppliers, record an intent and audit the outcome",
  "governance": {"onViolation":"DENY","source":"OUT_OF_BAND_HUMAN_REVIEW_AND_AGENT_GRANTS","grantsImplied":false},
  "contextRequirements": [],
  "inputs": [],
  "roles": [],
  "constraints": [],
  "capabilities": [],
  "tasks": [],
  "proofs": [],
  "outcomes": [],
  "anchors": [],
  "schedule": []
}
```

The arrays in this illustrative fragment are not a valid complete mission: valid missions need context, input, role, task and outcome declarations. The `compile` CLI produces a complete example.

### Type, authority and effect vocabulary

| IR property | Meaning |
|---|---|
| `inputs[].type` | `amount:lovelace`, `integer`, `text`, `boolean` |
| `constraints[].kind` | `MAXIMUM` with exact integer `maxValue` string, or `REQUIRED_CONTEXT` |
| `roles[].grant` | `OUT_OF_BAND_SIGNED_GRANT` — never implicit |
| `roles[].effect` | `LOCAL_CAPABILITY`, `EXTERNAL_SERVICE`, `UNRESOLVED_CAPABILITY` |
| `capabilities[].disclosedFields` | Explicit per-service request field names and source types; no ambient input disclosure |
| `tasks[].dependencies` | Lexically sorted existing task identifiers; must form DAG |
| `tasks[].declaredProofs` | Sorted identifiers of the corresponding proof declarations |
| `proofs[].kind` | `service_receipt`, `controller_receipt`, `agent_receipt` |
| `contextRequirements[].requiredState` | Required externally verified claim status (not a compile-time assertion of truth) |
| `anchors[].phase` | `post_execution`, not automatic on-chain deployment |

### Semantic normalisation

1. Object property keys sorted according to JavaScript UTF-16 lexical comparison using `locale-free` `<`, `>` comparisons.
2. Declaration arrays (`contexts`, `inputs`, `roles`, `constraints`, `capabilities`, `tasks`, `proofs`, `outcomes`, `anchors`) sorted by their `name` field in ascending ASCII order. Source labels are ASCII-only identifiers.
3. Task dependency lists and proof associations sorted lexically and checked for duplicates.
4. Schedule is independently recomputed using the batch-ready DAG algorithm defined by the Formal Mission Core specification; it is *not* sorted as a plain array.
5. ADA values converted to exact integer lovelace strings, never floating-point JSON amounts; integer constraint maxima use decimal strings.
6. The IR excludes source positions, comment content, source path, compilation timestamp, generated reviewer identities, grants, signers and wallet material.

### Digest algorithm (normative for v1.6)

```
irDigest = lowercaseHex(SHA256(UTF8("OctoLang Typed IR v1.6\n" + canonical(ir))))
```

`canonical` is the **existing OctoLang reference canonicaliser** in `src/canonical.js`: it JSON-encodes finite primitive values, recurses arrays in order, sorts plain-object keys lexically, and forbids unsupported values. This is **not** a blanket claim of RFC 8785 / JCS compatibility: future cross-language implementations must reproduce its documented behaviour, including string escaping. The emitted v1.6 IR uses ordinary JSON strings, booleans, arrays, objects and bounded integer numbers only.

The string prefix is included to prevent a digest for a different object type from being confused with a typed IR digest. This hash is **not a digital signature**.

## Artifact envelope

```
{
  "schema": "octolang.language-artifact.v1.6",
  "sourceSha256": "...",
  "legacyPolicy": {"schema":"octolang.mission.v1.2", "digest":"...", "...":"..."},
  "ir": {"schema":"octolang.typed-ir.v1.6", "...":"..."},
  "irDigest": "...",
  "diagnostics": [{"severity":"WARNING","code":"OL1602", "message":"...", "where":"..."}]
}
```

`sourceSha256` hashes the **exact UTF-8 source**, not the canonical IR. If a comment or spacing changes, the source hash changes even where the IR hash does not. This envelope binds the legacy policy and typed representation to exactly the source a human examined; it does not itself contain any human signature. Do not treat `irDigest` as equivalent to the old `legacyPolicy.digest` in existing execution protocols.

A signed human review of legacy policy is **not transferable** to the typed IR without an explicit versioned review mechanism.

## Portable verification strategies

1. **Source available**: recompile with independent parser, compare `sourceSha256`, legacy policy and IR digests, validate IR semantics, and verify any *separate* review signatures against pinned keys.
2. **IR only**: check schema, type/graph invariants and digest with `verifyIR`. This confirms internal consistency only, not provenance or human consent.
3. **Execution evidence**: use the existing independent VCC/execution verifier with out-of-band trust pins; the typed IR verifier is not a substitute.

## Version evolution rules

Any change to semantic meaning, normalisation, the hash domain or type vocabulary requires a new IR schema identifier and golden conformance cases. Non-normative diagnostic improvements can evolve without changing `irDigest`, but the full artifact verifier checks diagnostics produced by this exact v1.6 implementation.
