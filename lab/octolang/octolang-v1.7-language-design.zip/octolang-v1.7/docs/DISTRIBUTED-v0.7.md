# OctoLang v0.7 — Separate-Host Federated Pilot

**Status: experimental / NOT production-hardened.** Node.js 22+, OpenSSL; CommonJS, no npm dependency installation. Real separate-process HTTPS/OFP and local independently generated keys. No payment capability. The automated test suite runs on **one machine with four isolated homes**, not across physical hosts. The commands below support separately operated machines reachable on a **private/VPN network**, but that topology has not been independently validated over real multi-host infrastructure.

## What v0.7 adds

- **Independent provisioning:** private Ed25519 community, agent, and local governance keys generated on each peer's machine. The coordinator generates its *own* keys and a signing credential authority. Nothing in peer-registration files or activation bundles carries a private key.
- **Explicit identity enrolment:** the operator compares peers' displayed SHA-256 identity fingerprints through a separate trusted channel, supplies those pins to enrolment, then sends each peer a *signed public* activation bundle. Each peer must independently pin the coordinator's credential authority fingerprint before activation. Registration proves private-key possession, **not** human/organisation identity; the operator is responsible for verification.
- **Independently signed local authority:** peers sign their own score-, capability-, credential- and time-bound governance grant using a key that never leaves their own home. Execution rechecks authority and revocation at the point of effect.
- **Network:** mutual TLS with locally generated 30-day self-signed demo certificates. Both participants pin the peer's exact certificate and check the peer's TLS identity, in addition to OFP signed-envelope sender/recipient/nonce/expiry verification.
- **Persisted delivery & recovery:** coordinator fsynced outbox state stores exact signed inputs, proposed OFP envelopes, delivery attempts, completed chain and final response. Resumption uses the identical signed intent; retries issue fresh signed OFP envelopes while preserving the step-input digest. Peers retain immutable completed-step contribution receipts and return them after restart without invoking the tool again.
- **Conservative crash boundary:** stage reservations are deliberately sticky. If an effect might have occurred but the completion receipt was not saved, the peer **does not** automatically retry. An operator must inspect the effect journal and repair/reconcile the state. This is **not exactly-once distributed execution**.

## Quick demonstration (one development machine)

```sh
node --version                 # 22+
openssl version
npm test                       # 61 tests including 11 new distributed cases
npm run distributed:demo       # 4 isolated identity homes, 3 peer processes, pinned mutual TLS
```

The default demo creates a temporary directory and deletes it at the end. Set `OCTOLANG_DEMO_KEEP=1` and `OCTOLANG_DISTRIBUTED_HOME=/path/to/new/directory` to inspect generated state and public registrations. Never reuse demo keys or reviewer/issuer/steward attestations as real organisational credentials.

## Four-machine runbook (three community peers + coordinator)

Use a trusted **private, encrypted VPN** and firewall rules: only the coordinator should reach each peer's HTTPS port. Do not publish to the Internet. Example private network addresses below must be replaced with the hosts' real reachable addresses.

### 1. Initialise identities independently

**Coordinator machine:**

```sh
node distributed/provision.js init-coordinator ./coordinator-home
```

Keep its displayed `authorityPin` for a separate secure exchange to each peer. `./coordinator-home/governance/credential-authority.pem` remains **only** on the coordinator host.

**Research machine:**

```sh
node distributed/provision.js init-peer ./research-home community-research https://10.20.0.11:9811
```

**Execution machine:**

```sh
node distributed/provision.js init-peer ./execution-home community-execution https://10.20.0.12:9812
```

**Audit machine:**

```sh
node distributed/provision.js init-peer ./audit-home community-audit https://10.20.0.13:9813
```

Every peer stores its `.pem` private keys locally with user-only permissions. Transfer **only** `<home>/<community>/registration.json` to the coordinator using an authenticated out-of-band method. Confirm the public-key fingerprint for each registration in person or via a separate trusted channel. Do not rely solely on a registration file carried over an untrusted channel.

### 2. Coordinator enrols public registrations

Place copies of registration files on the coordinator host, for example `research.json`, `execution.json`, `audit.json`, and compare their identity pins separately.

```sh
node distributed/provision.js enroll ./coordinator-home \
  ./research.json ./execution.json ./audit.json \
  --trust <research-identity-pin>,<execution-identity-pin>,<audit-identity-pin>
```

This writes `./coordinator-home/community-coordinator/local.json` and **public-only** signed activation bundles in `./coordinator-home/bundles/`. Transfer only the corresponding bundle to each peer. The enrolment returns the credential authority fingerprint (`authorityPin`); send/verify that fingerprint separately. **Enrolment currently uses one centrally operated credential issuer** — peer governance is independent, but credential authority is not decentralised.

### 3. Each peer checks and activates the trusted bundle

On each host, for example research:

```sh
node distributed/provision.js activate ./research-home ./community-research.json <verified-authority-pin>
```

Repeat for execution and audit, using their own matching bundle and home. Activation verifies the coordinator authority signature and the peer's *locally generated* identity, role, URL, certificate, credential and exact compiled score digest. A peer cannot accept a different identity or trust root merely because a remote message says so.

### 4. Start the peer processes

Run each on its **own host** and explicitly bind to that host's private VPN IP address:

```sh
OCTOLANG_BIND=10.20.0.11 node distributed/peer.js ./research-home community-research
OCTOLANG_BIND=10.20.0.12 node distributed/peer.js ./execution-home community-execution
OCTOLANG_BIND=10.20.0.13 node distributed/peer.js ./audit-home community-audit
```

Those are three separate commands on three separate machines, **not** commands to run in one shell. `OCTOLANG_BIND` defaults to `127.0.0.1` for safety. If a host's interface only supports wildcard binding, `0.0.0.0` is possible but **not recommended** without restrictive VPN ingress firewall rules.

### 5. Conduct a reviewed demo score from coordinator

```sh
node distributed/conduct.js ./coordinator-home
```

This CLI creates **explicitly synthetic** reviewer, accredited-provider claim, and steward approval signatures. It cannot purchase or spend anything. The research peer checks the claim; the buyer peer invokes the original Octonomous Runtime 1.0 `record.purchase.intent` journal capability only; the audit peer verifies/signs a bounded evidence chain. All messages are signed OFP envelopes over mutual TLS.

If a peer is temporarily offline, the coordinator persists a `WAITING_DELIVERY` state and bounded retry attempts. After the peer returns, continue **the same signed inputs**:

```sh
node distributed/conduct.js ./coordinator-home --resume
```

Do not run the command without `--resume` expecting an old run to continue: the default creates a *new* demo intent. Peer cache is keyed by an immutable score/nonce/community/step and exact payload digest; altered payloads do not inherit prior receipts. Each step result is signed with the peer's pinned agent key.

## Recovery and limits

- **Data paths:** each peer stores `state/claims/`, `state/steps/`, and (buyer only) `state/effects/local-intents.jsonl`. The coordinator stores `state/outbox/` and `state/claims/`. Back these up using filesystem-owner permissions and encrypted storage.
- **Pending outbox:** after connection failure, the signed inputs and attempt history are retained. Each subsequent `--resume` rechecks validity and revocation rather than trusting the old decision. Requests in the demo expire after ~4 minutes, and contribution attestations after ~2 minutes; automatic extension or reauthorisation is **not provided**. Once expired, a human must authorise a **new** request with a fresh nonce.
- **Crash in an uncertain step:** a sticky `*.claimed` with no `*.receipt.json` means the peer may already have applied a side effect. Stop and inspect the journal; do not delete the claim to force a retry. Recovery tooling for coordinated reconciliation is future work.
- **Stale coordinator `.lock`:** if a coordinator process dies, the lock intentionally remains. A human must confirm no coordinator process is running and reconcile the outbox and peer journals before removing the stale `.lock`. Running two coordinators over one state directory is not supported.
- **Trust rotations:** TLS certificates expire at 30 days, governance/credential grants at 7 days, and review/action proofs sooner. The provisioning CLI deliberately cannot overwrite identities or silently rotate peers. Manual rotation, signed trust upgrades and renewable credentials are not implemented.
- **Credential revocation:** `revoked.json` is checked locally. There is no automatic cross-host publication, propagation guarantee, global revocation registry, KERI DID resolution or W3C Verifiable Credential support.
- **No secure audit log:** local JSON files are fsynced but not a Byzantine-resistant tamper-evident store. Local root/OS compromise can change them. There is no distributed DB, consensus, broker, TEE, zero-knowledge proof, wallet, Cardano/Midnight adapter or custody system.
- **No unrestricted AI:** score remains the existing strict three-step v0.5 federation policy. Browser Studio retains the v0.5 in-process conduct mode. The v0.7 network coordinator uses precompiled score and deliberately mock reviewer credentials. It does **not** accept unreviewed agent-generated instructions.
- **TLS trust:** short-lived self-signed development certificates and manually provisioned SPKI pins are fine for controlled demonstrations but need proper lifecycle management, monitoring, backup and security review before broader deployment.

## Threat model and assurance

Trust boundary chain: **human-approved exact score → coordinator local intent verification → issuer-signed peer credential → peer-local governance signature → sender+recipient-bound OFP envelope → pinned mutual TLS → VCG/VCC check → replay claim → journal-only effect → signed contribution/receipt → independent transcript verifier.**

A valid signature proves possession of a key and binding of exact data, not the factual correctness of a self-asserted supplier accreditation or the safety of a legal/governance process. Do not connect real wallet or privileged MCP endpoints to this research implementation.

## File map

- `distributed/provision.js` — independent identity generation, signed public registrations, pinned enrollment and activation.
- `distributed/coordinator.js` — persistent outbox and bounded at-least-once delivery.
- `distributed/steps.js` — immutable peer step-result cache and fail-closed uncertainty handling.
- `distributed/peer.js`, `distributed/conduct.js`, `distributed/demo.js` — distinct-host services, conduct and local demonstration.
- `network/{peer,transport}.js` — conditional remote mTLS support (v0.6 loopback remains unchanged).
- `test/distributed.test.js` — 11 new tests; v0.6's original 50 still run unmodified.

