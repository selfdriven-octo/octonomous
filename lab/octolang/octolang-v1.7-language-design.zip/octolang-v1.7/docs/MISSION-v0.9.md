# OctoLang Mission Language v0.9 — Reference specification

Status: **experimental / research prototype**, not a security-certified programming language. No externally authorised tool execution is implemented in the v0.9 mission flow.

## Design objective

Use a DSL that is straightforward for AI to propose and for humans to review, but that separates descriptions of goals from cryptographic sources of authority. A valid compile **does not authorise** anything; a reviewer signature proves only who signed the exact program digest. Signatures on evidence only authenticate the signing keys' claims, not truth of the real world.

## Quick start

```bash
node bin/octolang.js check examples/community-mission.octo
node bin/octolang.js compile examples/community-mission.octo mission-policy.json
node mission/demo.js
npm test
npm run studio
```

The Studio Mission panel is separate from legacy single-purchase scores and the remote OFP federation demo. The *only* v0.9 mission execution path constructs **synthetic in-memory receipts** and verifies them. No action executor or payment capability is exposed.

## Grammar (v0.9)

The entrypoint is `mission identifier { ... }` (not `score`). Comments begin with `//` or `#`. Unknown fields, repeats and trailing tokens fail compilation. Source is limited to 64 KiB and 2,000 tokens.

| Declaration | Syntax (inside a mission) | Meaning |
| --- | --- | --- |
| Goal | `goal "..."` | Plain-language outcome; maximum 500 characters. |
| Context | `context supplier { claim "supplier.accredited" issuer "community-registry" status VERIFIED max_age 30d }` | Signed claim required, freshness bound to subject. |
| Typed input | `input amount { type ada }` | Types: `ada`, `integer`, `text`, `boolean`. |
| Role | `role researcher { capability "research" }` | Requirement, **not an asserted grant**. |
| Max constraint | `constraint spend { input amount max 100 ADA }` | Decimal ADA -> exact lovelace; integer uses `count`. |
| Context constraint | `constraint eligible { context supplier }` | Explicitly name verified context. Every declared context is mandatory during planning in this reference. |
| Task | `task find { role researcher depends none require supplier produces "shortlist" }` | Directed dependency; requires available, signed context. |
| Multi-dependency | `depends "find,vet"` | Comma-separated identifiers; cycles rejected. |
| Outcome | `outcome result { task find evidence "shortlist" }` | Named evidence must equal the task's declared output. |
| Failure | `on violation DENY` | Mandatory, no arbitrary alternative execution. |

A mission needs a goal, at least one context, input, role, task and outcome. At most 16 contexts, 16 inputs, 16 roles, 32 constraints, 32 tasks, 32 outcomes. Up to 365-day `max_age`. Compiler rejects unrecognised syntax, imports, scripts, functions, delegation or dynamic code evaluation.

The compiled JSON has `schema: octolang.mission.v0.9` and a SHA-256 `digest` over a canonical representation. All semantically relevant declarations (including identities of issuers, capability names, graph structure and bounds) are included. Comments and whitespace do not affect the digest. Legacy `octolang.policy.v0.1`, `.v0.4` and `.v0.5` remain unchanged.

## Checks and boundaries

1. **Compile:** check grammar, declared names, exact decimal units, typed constraints, DAG and named outcomes. Produces *unsigned* declarative policy.
2. **Review:** require an Ed25519 `octolang.review.v1` with the exact compiled digest, trusted public reviewer key, nonce and bounded validity dates. AI output is not a signature or an authority source.
3. **Context:** `octolang.claim.v1` must have the exact target subject and issuer's pinned key; check signature, claim name, asserted VERIFIED state, expiry and freshness. A signed assertion can still be wrong.
4. **Grant:** trusted issuer signs `octolang.agent-grant.v0.9` binding `missionDigest`, `role`, `capability`, `agent`, `issuer`, expiry and nonce. Agent identity keys must be separately pinned. Signer of a grant is separate from its named agent. Select the lexicographically first qualified agent for each role, disallowing reuse across roles. **This is a deterministic pilot selector, not a production scheduler.**
5. **Request:** `octolang.mission-request.v0.9` binds exact mission digest, subject, typed inputs, nonce and a short expiry. All declared inputs are mandatory, no unexpected keys. Every max constraint is checked using integer-safe arithmetic.
6. **Plan:** deterministic ordered tasks and exact assignments; hash binds to request digest, context-root digest, role grant digests and task graph. Planning returns `READY_FOR_SIMULATION`, not an execute token.
7. **Outcomes:** `octolang.mission-evidence.v0.9` receipt for each task signed by that agent's pinned Ed25519 public key, binding exact task, role, produced evidence name, mission digest, request digest, plan digest, context root, predecessor receipt digests and validity interval. The independent verifier recomputes the plan from *human review, signed grants, claims and constraints*, not just from evidence receipts.

## Demo vs real systems

`npm run mission` constructs temporary in-memory cryptographic identities; grants, registry claims and evidence describe **synthetic** objects. The demo does **not** run a real `research` agent, produce a real supplier shortlist, buy supplies, or independently audit financial records. No wallet key, real credential authority, unbounded tool, third-party request or blockchain transaction is used.

Older `score`/OFP flows are **not** driven by the new `mission` compiler. A production implementation needs an explicit, separately audited adapter from authorised mission plans to the existing Octonomous VCC/OFP and tool custody boundaries; durable idempotency, revocation, human/threshold governance, independent verifiers, safe execution windows and external receipt reconciliation. Groth16 would prove formally encoded relations only, not arbitrary real-world claims.

## Security invariants and incomplete pieces

- AI model output is always untrusted input; validation is necessary but never sufficient for authorisation.
- The verifier checks trusted public keys passed separately, never keys supplied by a score or self-presented as authority.
- Mission-request inputs are not themselves signed by a requester in this demo; no real execution is permitted. For a production system, a request signature, mandate, nonce persistence, revocation and target binding need to be mandatory.
- The example's signed grant/claim receipts are **not** W3C VC compatible and do not implement revocation or full delegated governance. Existing network federation has its own governed credentials; do not conflate them with mission grants.
- Signature-valid evidence does not imply the output was truly performed, nor that the signer can be trusted generally.
- Simulation has no irreversible side effect and keeps no durable record; it is neither a distributed runtime nor an exactly-once engine.
- No proof-carrying data or Groth16 circuit has been implemented.
