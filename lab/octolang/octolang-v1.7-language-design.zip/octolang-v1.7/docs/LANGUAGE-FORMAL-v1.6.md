# OctoLang v1.6 — Formal Mission Core (Draft Specification)

**Status:** reference specification / draft; not formally proven, security-certified, or a new execution engine.

**Scope:** the existing `mission` grammar (v0.9, v1.2 typed capability/proof extensions and v1.3 Midnight anchor declaration) and its *compile-time* semantics. Legacy `score` remains supported by the original compiler but is **outside** v1.6's typed-IR profile. Future features such as dynamic delegation, recursive scores, uncertain epistemic types or learning do not exist in this version.

The normative reference implementation lives at `language/v1.6` and the frozen acceptance cases in `conformance/v1.6`. In cases of ambiguity, the specification and reference implementation should be reconciled through a new test vector and version; the document is not a licence to execute undeclared actions.

## 1. Core principles and trust boundaries

1. A generated mission is **untrusted source text**. Compilation never gives an agent permission, signs an authority grant, identifies a truthful fact or launches a capability.
2. Compiled missions and typed IR are **policy proposals**. Human-approved mission digests, externally governed agent grants, verified context claims and runtime VCC checks are distinct prerequisites outside the language compiler.
3. Declarative `proof` rules are **proof obligations** (specific receipt types), not proof that a claim is true. Evidence authenticity, provenance and actual correctness are distinct.
4. All meaningful effectful operations occur outside this compiler. No embedded JavaScript, function calls, arbitrary imports, wallet operations or live-network requests are part of the language semantics.
5. The v1.6 IR is an **additional** versioned compiler output; it does not replace existing v0.9/v1.2/v1.3 digests or approvals. A human who approved the legacy digest has **not** thereby approved an unrelated v1.6 digest, and vice versa.

## 2. Lexical grammar

* UTF-8 source (Node.js reads as UTF-8), maximum 65,536 JS string code units; at most 2,000 tokens.
* Whitespace is insignificant except as a separator. `# ...` and `// ...` to end-of-line are comments.
* Identifiers: `[A-Za-z_][A-Za-z0-9_-]*`. Names are case-sensitive and use ASCII order. Keywords are case-sensitive.
* Quoted strings use double quotes and the legacy tokenizer's JSON escapes: `\\`, `\\"`, `\\n`, `\\r`, `\\t`. Literal line breaks inside strings are forbidden. Other JSON escape forms (such as `\\uXXXX`) are not presently lexed.
* Numeric literals: nonnegative decimal literals `0`, `12`, `12.3` (later restricted by the relevant type). No exponent notation, minus sign, arithmetic expression, or units inside the numeric token.
* Structural tokens `{`, `}`; no semicolon, assignment, conditional execution, loops or external imports.
* Source containing unknown characters, unknown fields, duplicates of a field inside a block or trailing tokens is rejected.

## 3. Concrete grammar (EBNF-style, field order is free inside blocks)

The notation below describes **shape**; semantic validity and exact field cardinalities are defined below. `{ X }` in the EBNF means repetition, distinct from literal braces written in quotes.

```ebnf
Mission     = "mission" Identifier "{" Goal { Decl } "on" "violation" "DENY" "}" ;
Decl        = Context | Input | Role | Constraint | Task | Outcome
            | Capability | Proof | Anchor ;
Goal        = "goal" String ;
Context     = "context" Identifier "{" "claim" String "issuer" String
              "status" "VERIFIED" "max_age" Decimal AgeUnit "}" ;
Input       = "input" Identifier "{" "type" InputType "}" ;
Role        = "role" Identifier "{" "capability" String "}" ;
Constraint  = "constraint" Identifier "{" (
                "context" Identifier |
                "input" Identifier "max" Decimal LimitUnit ) "}" ;
Task        = "task" Identifier "{" "role" Identifier "depends" Dependencies
              "require" (Identifier | "none") "produces" String "}" ;
Outcome     = "outcome" Identifier "{" "task" Identifier "evidence" String "}" ;
Capability  = "capability" Identifier "{" "role" Identifier "name" String
              "fields" String "service" String "}" ;
Proof       = "proof" Identifier "{" "task" Identifier "kind" ProofKind
              [ "service" String ] "}" ;
Anchor      = "anchor" Identifier "{" "backend" "midnight"
              "network" String "contract" String "}" ;
Dependencies= "none" | Identifier | String ;
InputType   = "ada" | "integer" | "text" | "boolean" ;
AgeUnit     = "m" | "h" | "d" ;
LimitUnit   = "ADA" | "count" ;
ProofKind   = "service_receipt" | "controller_receipt" | "agent_receipt" ;
Identifier  = /[A-Za-z_][A-Za-z0-9_-]*/ ;
Decimal     = /[0-9]+(\.[0-9]+)?/ ;
```

**Important implementation detail:** fields inside a `{ ... }` block may appear in any order, though all mandatory fields must appear exactly once. The source parser accepts declarations in any order within a mission, but validates references after parsing. The grammar uses one order for readability, not as a restriction. The `goal` declaration may appear anywhere within the mission body and at most once. The `on violation DENY` declaration may also appear anywhere and is mandatory. `depends` quoted text contains comma-separated task identifiers (e.g. `"research,validate"`).

Cardinality limits: contexts ≤16, inputs ≤16, roles ≤16, constraints ≤32, tasks ≤32, outcomes ≤32, capabilities ≤16, proofs ≤64 and anchors ≤1. A valid mission must contain a goal and at least one context, input, role, task and outcome. An identifier must be unique within its declaration namespace.

## 4. Static type system and constraint semantics

Write `Γ` for the symbol table of declared contexts, inputs, roles and tasks.

* `Γ(input)` is one of `ADA`, `INTEGER`, `TEXT`, `BOOLEAN`. The compiler rejects all other input types.
* `Γ ⊢ constraint(input x, max n u)` iff `x ∈ dom(inputs)`, `Γ(x)=ADA ∧ u=ADA` OR `Γ(x)=INTEGER ∧ u=count`; there is no implicit conversion between quantity units.
* ADA bounds are converted into **exact integer lovelace strings**, where 1 ADA = 1,000,000 lovelace. At most six fractional places are accepted, and existing v0.9 max-supply limits apply.
* Integer limits are represented as canonical non-negative **decimal strings** and may not exceed `Number.MAX_SAFE_INTEGER` (as required by the inherited v0.9 implementation).
* `Γ ⊢ task` only if its role is declared, `require` names a declared context or `none`, every dependency names a distinct existing task other than itself, and the graph is acyclic.
* `Γ ⊢ outcome` only if its referenced task exists and the outcome's evidence string equals that task's `produces` string.
* The only accepted failure mode is `on violation DENY`.

Typed capability extensions:

* A declared external capability binds exactly one role, service identity, operation and an explicit list of disclosed request fields. All disclosed fields must be declared inputs of the exact indicated type; no field may appear twice. Declaring a capability does not grant it.
* Where typed capability and proof declarations are used, both must be present. Every task must have at least one declared proof obligation. An external-service task must include a `service_receipt` bound to the matching service identity; a local task cannot claim an external-service receipt.
* Built-in role capability strings recognised by the inherited language are `research`, `validate`, `intent.record`, `audit`. Any other undeclared capability in legacy v0.9 is classified as **UNRESOLVED_CAPABILITY** in the IR (not silently trusted or classified as local).
* `anchor` is a post-execution declaration for the Midnight backend, accepted only alongside typed proof declarations. Its presence does not mean proof generation, wallet authorisation or an on-chain transaction occurred.

## 5. Deterministic plan ordering

Let `T` be all declared tasks. Begin with no scheduled tasks. In each round select **all** unscheduled tasks whose dependencies are scheduled; sort that round's tasks by identifier in ascending ASCII order; append them; repeat. If no task is ready while tasks remain, compilation fails for a cycle. This *batch-ready* algorithm, rather than a single-item min-heap, matches the inherited compiler and is normative for the v1.6 schedule field.

## 6. Semantic IR, authority and observational claims

The typed intermediate representation is specified in `TYPED-IR-v1.6.md`. Source declaration order, comments and whitespace do not affect the typed IR digest. Structurally equivalent dependency declarations are normalised into lexically sorted arrays. A semantic change such as adjusting a bound or service identity changes the digest.

The IR explicitly distinguishes these facts:

* `governance.grantsImplied=false`: the program creates **zero** executable grants.
* `requiredState="VERIFIED"` denotes a **requirement** for future trusted context validation; it does not assert that a source is verified.
* `effect=EXTERNAL_SERVICE` is an operation requiring an externally authorised capability and approved service manifest; `LOCAL_CAPABILITY` is only a capability classification, not a permission. `UNRESOLVED_CAPABILITY` must not be executed without a separately defined binding.
* `proof.kind` indicates evidence expected to be presented and checked by an appropriately trusted verifier. Signed statements alone establish signer attribution, not objective truth or good outcomes.
* Numeric type enforcement must also be performed at **execution time** against current requests, not only at compile time.

A compiler result contains no execution tokens, agent private keys, custody secrets, automatic delegation, human approval, blockchain transactions, or Groth16 proofs.

## 7. Compatibility and versioning

* `octolang.mission.v0.9`, `.v1.2` and `.v1.3` remain the original policy schemas and original digests used by pre-v1.6 flows.
* `octolang.typed-ir.v1.6` is a separately domain-separated representation suitable for offline analysis and further compiler development.
* New IR schema versions are required when any normative meaning changes. New syntax, type/effect categories and proof predicates must go through new positive and adversarial conformance vectors.
* `verify <source.octo> <artifact.json>` **recompiles the exact source and checks both artifacts**, but does not verify agent signatures or outcome truth.
* `verifyIR(ir, digest)` can check an IR structurally without source and without custody keys. This is not evidence that it came from an authorised source or was reviewed by a human.

## 8. Deliberately unresolved questions for v1.7 onward

Formal delegation attenuation, mutable context snapshots, epistemic trust states, conditional scores, recursion termination, partial ordering and concurrency semantics, total resource budgets across agent sub-missions, privacy-flow types, compositional proofs, and machine-checked safety invariants. These require new semantics and evidence models, not just more keywords.
