# OctoLang v1.1 — Signed Capability Services

**Status:** research reference implementation, not Internet-production-ready. Node.js 22+, CommonJS, no third-party dependencies. Extends the v1.0 execution controller and preserves all earlier mission, Studio, network and federation demos.

## Purpose

An AI composes a `.octo` mission describing `role ... capability "service.note.record"`. The AI does **not** decide where network requests go, which issuer to trust, what fields are disclosed, or what services may act. Those are independently governed, signed operator decisions.

The v1.1 implementation adds:

1. **Mission-scoped, Ed25519-signed capability manifest** from a pinned *operator* identity. Exact endpoint, POST method, service, input-field disclosure allowlist, timeout, maximum response bytes and expiry are immutable signed fields.
2. **Separate service identity:** the reply is a structured result and a service-signed attestation. Its public key is pinned independently of the operator and of the agent/controller keys.
3. **Controller-signed, short-lived authorisation** for the exact outbound request digest; service checks it against its pinned controller key. An unauthorised request cannot create a record in the included service.
4. **VCC checks** at planning, pre-tool and effect time. Existing human-signed review, signed agent role grants, signed context, typed constraints, one-use runtime token, persistent nonce reservation and Octonomous Runtime 1.0 policy remain enforced.
5. **Evidence:** controller-signed tool result + agent-signed dependency-linked contribution + service-signed response. An independent verifier rechecks all layers against administrator-provided public key pins.
6. **Conservative network transport:** outbound network disabled unless explicitly configured. Built-in demo accepts `http://127.0.0.1:<port>/v1/execute` only with `allowLoopbackHttp: true`; optional remote mode requires HTTPS PKI validation, an explicit DNS-public endpoint and `allowRemoteHttps: true`. No redirects, arbitrary paths, query strings, dynamic URLs or wildcard endpoints.

### Flow

```text
AI-authored .octo mission
  ↓ compile, review and human signature (exact mission digest)
Signed VCG claims + typed inputs + operator-issued agent grants
  ↓ deterministic plan + capability manifest (trusted operator signature)
Octonomous Runtime: independently scoped role/tool authorization
  ↓ one-use token + effect-time recheck + durable replay reservation
Controller-signed fixed-endpoint request (discloses allowlisted input fields only)
  ↓ HTTP loopback demo / explicitly configured HTTPS
Independently operated service verifies authorization, uses idempotency key,
  performs bounded operation, signs exact result
  ↓
Agent, controller and service signed receipts + independent offline verification
```

## Quick start

```bash
node -v                       # >=22
npm test                      # 108 tests (94 original + 14 v1.1)
npm run capability:demo       # separate localhost HTTP service records one note
npm run mission:execute       # v1.0 local-only example remains available
npm run studio                # existing v1.0 Studio; no arbitrary services in UI
```

`capability:demo` prints its data directory. The directory contains the service note journal, the controller's persistent claim state, `capability-bundle.json`, and `demo-public-pins.json`.

Run independent verification while the evidence is within its proof freshness window (the legacy v1.0 verifier checks signed agent evidence around execution time):

```bash
node capabilities/verify.js /tmp/octolang-v1.1-XXXX/capability-bundle.json /tmp/octolang-v1.1-XXXX/demo-public-pins.json
```

**Do not use pins obtained only from an untrusted evidence bundle.** The demo writes pins beside the bundle for convenience; actual verification requires pin distribution through an independent trusted channel.

## An AI-generated score

```text
role scout { capability "service.note.record" }
input note { type text }
task find_supplier { role scout depends none require accredited_supplier produces "supplier.shortlist" }
```

The role grant must *also* independently authorise `service.note.record` for the reviewed mission digest. The separately signed manifest must bind that exact digest and include only `note` as a disclosure field. A generated score cannot change the HTTP endpoint or invent a service trust key. The service demo records a note, **not an actual supplier research result**; the evidence is only proof of that bounded operation and signature.

## Registering a new capability

1. Implement a service that accepts `POST /v1/execute` and checks `octolang.capability-authorization.v1` against a pinned controller signing key. Use atomic idempotency keyed by `idempotencyKey`. Issue `octolang.capability-service-receipt.v1` signed with a separate service key, covering the exact input request, operation, manifest and result digest.
2. Provision separate Ed25519 key pairs for the operator, service and controller. Manage keys outside the repo and do not embed real secrets in `.octo` or receipt bundles.
3. Compile and review a mission. An authorised governance operator signs its exact `missionDigest` in a `octolang.capability-manifest.v1` object; include `service`, `issuer`, fixed `endpoint`, `inputFields`, small `maxResponseBytes`, `timeoutMs` and expiry.
4. Create a `CapabilityRegistry` using the manifest and independently pinned issuer/service public keys. Network access remains off unless the operator explicitly permits one of the supported transport profiles. `allowLoopbackHttp` is **development-only**.
5. Supply `capabilityRegistry` to `MissionExecutionController`. The controller registers the exact tool as `mission.external.<capability>` in the existing Octonomous `ToolRegistry`. The agent must already have a valid signed mission-specific grant with the exact capability and must pass normal human review/VCG/VCC checks.
6. Export receipts and verify with `capabilities/verify.js` using separately distributed trust pins. Do not treat a service-signed result as proof of independent real-world truth.

See `capabilities/demo.js`, `capabilities/registry.js` and `capabilities/service.js` for reference code. Only a single fixed-contract note service has been tested end-to-end.

## Safety and production limitations

- **No wallet, payment, arbitrary shell, browser-control, unrestricted HTTP/MCP or Cardano adapter.** The only added side effect is one note written to a loopback HTTP test service. The existing intent-recording tool can still write its local journal.
- Agent, governance and issuer keys are generated synthetically in the demonstration. The Studio does not expose this capability system or let the browser select remote endpoints. The remote HTTPS path has not been tested with a real external service or deployed public infrastructure.
- Custom signed manifests and authorisations are **not W3C Verifiable Credentials** and do not imply compatibility with production credential revocation protocols. The implementation rechecks expiry, but production deployment requires durable revocation distribution, key rotation, audit, host/service policy, per-community isolation and ongoing trust management.
- Remote endpoint restrictions reduce SSRF risk but do **not** constitute a complete network egress isolation design. Use host-level egress firewalls/proxies, isolated accounts and TLS/mTLS under an independently managed PKI for real systems. The demo HTTP service has *no encryption*; only ever run it on loopback.
- A request may have succeeded remotely even if the local process crashes before it stores a receipt. The **sticky reconciliation state** deliberately prevents automatic re-execution; the remote service independently enforces idempotency. Do not claim global exactly-once execution.
- The time window of the original mission receipt verifier is short. Long-term archival verification needs timestamp authority, explicit revocation-at-time semantics and a trust-history model.
- The note service's Ed25519 signature verifies the **service's assertion**, not the truth of any subsequent off-chain business outcome. Governance and human risk review are still required before enabling consequential capabilities.
