# OctoLang v1.4 — Midnight local Devnet execution runbook

**Status**: SDK integration implemented and unit-tested, but **Compact compilation, Midnight wallet transactions, proof generation and actual ledger inclusion have NOT been executed in the build environment**. The live path requires a user-provisioned Midnight devnet and compatible toolchain. The older `midnight:demo` remains an in-memory fixture.

## Security model

1. An AI can propose an OctoLang mission but cannot authorise publication.
2. Local Octonomous execution requires its own signed mission review, scoped grant, service manifest, VCG evidence, and VCC checks.
3. A **separate** human signs an exact 32-byte salted commitment, network and deployed contract address; this is not the mission review.
4. Midnight.js uses the local wallet, proof server, node and indexer. `callTx.anchorEvidence` invokes generated Compact circuit bindings, proving and submitting the *Compact contract operation*, not the correctness of arbitrary off-chain evidence.
5. The public contract contains **only** the 32-byte commitment and a marker. Salt, claims, local signed receipts and human names stay off-chain.
6. Live calls are explicitly gated by environment variables; no Studio or AI-provided mission can set those gates. This release **only** targets local Devnet. No real funds or production custody keys.

## 1. Install / start the official local network (on your Mac)

Requires Node.js 22.12+, Docker Desktop and Compact 0.31.1, compatible with the pinned Midnight.js v4.1.1 / runtime 0.16.0 dependencies. Follow current official compatibility matrix before attempting a live test.

Use the official [midnight-local-dev](https://github.com/midnightntwrk/midnight-local-dev) project **outside** the OctoLang checkout:

```bash
git clone https://github.com/midnightntwrk/midnight-local-dev.git
cd midnight-local-dev
npm install
npm start
```

This tool starts the node (9944), indexer (8088), proof server (6300) and offers interactive test-wallet funding with NIGHT plus DUST registration. Keep it running. **Do not use real wallet recovery phrases** on this research stack.

Install Compact per [official docs](https://docs.midnight.network/getting-started/installation), then:

```bash
compact update 0.31.1
compact compile --version
```

## 2. Compile and install optional Midnight SDK (OctoLang terminal)

From the extracted **OctoLang v1.4** directory:

```bash
npm run midnight:compact
cd midnight/live
npm install
cd ../..
npm run midnight:doctor
```

The optional `midnight/live/package.json` pins Midnight.js 4.1.1, wallet SDK 1.2.0, `@midnight-ntwrk/compact-runtime` 0.16.0, plus an `onchain-runtime-v3` override. The regular OctoLang tests require no network or Midnight SDK installation.

If the compiler reports a language version mismatch, **stop** and consult the official support matrix. Do not fix by blindly installing the latest compiler.

## 3. Create and fund a local-only wallet

Generate a **new disposable** local development mnemonic from the installed SDK, store it offline and supply it securely as `WALLET_MNEMONIC` (or supply a 32–64 byte hex `WALLET_SEED`). Also supply a strong `PRIVATE_STATE_PASSWORD` (16+ characters, 3 character classes).

```bash
# Example names only — do not use these literal strings as secrets.
export WALLET_MNEMONIC='YOUR_NEW_DISPOSABLE_LOCAL_DEVNET_MNEMONIC'
export PRIVATE_STATE_PASSWORD='YOUR_LONG_UNIQUE_PASSWORD'
export OCTOLANG_MIDNIGHT_HOME="$HOME/.octolang-midnight-dev"

npm run midnight:wallet-address
```

Fund **that address** through the `midnight-local-dev` funding menu, choosing a mnemonic-backed account, registering NIGHT for DUST. Use the *same* disposable mnemonic. The funding tool may be run from a separate shell. Never put any wallet secrets or private signing keys in a repository or in agent messages. Wallet snapshots are mode 0600; contract private state is encrypted by the SDK. Back up dev keys only if you need to persist this experimental wallet.

## 4. Explicitly deploy the Compact contract

```bash
OCTOLANG_MIDNIGHT_ALLOW_DEPLOY=YES_LOCAL_DEVNET \
  npm run midnight:deploy -- ./my-local-deployment.json
```

This triggers a real wallet operation and normally spends **local Devnet DUST**. It creates a new deployment file and refuses to overwrite one. A real `contract` address is returned only if the SDK deployment succeeds.

## 5. Execute bounded local demo and prepare the commitment

```bash
npm run midnight:make-evidence -- ./my-local-deployment.json ./private-evidence-001
npm run midnight:verify-live -- \
  ./private-evidence-001/bundle.json \
  ./private-evidence-001/pins.json \
  ./private-evidence-001/prepared-private.json
```

The command **replaces the illustrative contract address before compiling/signing** the demo mission, then executes the bounded local `notes-provider` capability and writes the verified evidence bundle plus randomly salted private opening with mode 0600. It uses synthetic demonstration review/agent keys; replace these with real governance keys for any deployment beyond research.

**Only the commitment is designed to be published.** Never upload `prepared-private.json` to a chain, a proof server, a public API or a third-party agent.

## 6. Independently sign the exact commitment for publication

Create a **separate** Ed25519 reviewer signing key under your custody and export the public key; an example Node.js command (make sure terminal history and permissions are protected):

```bash
node -e 'const fs=require("fs"),c=require("crypto"); const p=c.generateKeyPairSync("ed25519"); fs.writeFileSync("./anchor-private.pem",p.privateKey.export({format:"pem",type:"pkcs8"}),{mode:0o600,flag:"wx"}); fs.writeFileSync("./anchor-public.pem",p.publicKey.export({format:"pem",type:"spki"}),{flag:"wx"})'
```

Inspect the prepared commitment, target address, input evidence and retained private salt. When satisfied:

```bash
npm run midnight:approve -- \
  ./private-evidence-001/prepared-private.json \
  ./private-evidence-001/bundle.json \
  ./private-evidence-001/pins.json \
  ./anchor-private.pem \
  ./anchor-approval.json
```

The approval is a signature over the exact commitment and target, valid for five minutes by default. The key above is an **illustrative local reviewer**; production key custody and identity assurance are out of scope.

## 7. Execute Midnight ZK circuit and submit transaction

```bash
OCTOLANG_MIDNIGHT_ALLOW_SUBMIT=YES_LOCAL_DEVNET \
 npm run midnight:anchor-live -- \
   ./private-evidence-001/bundle.json \
   ./private-evidence-001/pins.json \
   ./private-evidence-001/prepared-private.json \
   ./anchor-approval.json \
   ./anchor-public.pem \
   ./my-local-deployment.json \
   ./new-local-result.json
```

This invokes the actual Midnight.js `findDeployedContract(...).callTx.anchorEvidence(...)` workflow. `callTx` runs the Compact circuit and prover, balances the transaction with local DUST, and submits it. The adapter then queries contract state via the indexer using generated bindings. **The output is not a general independent ZK verification of all OctoLang evidence**. If a submit times out after network acceptance, do **not** blindly retry: inspect the ledger for the commitment and reconcile the transaction first. The public registry rejects duplicate commitments, but the SDK adapter does not yet persist an across-crash transaction-index.

`SDK_FINALIZED_AND_INDEXER_OBSERVED` is the expected status when the *real* SDK confirms the circuit call and indexer map membership. This is not an independent consensus proof or proof that the supplier or service performed a real-world action.

## Supported and excluded

| Capability | v1.4 |
|---|---|
| Compile hash-bound OctoLang mission with Midnight anchor | Yes |
| Independently verify VCG/VCC evidence before preparing anchor | Yes |
| Ed25519 human approval of exact commitment & contract | Yes |
| Midnight.js contract deployment and `anchorEvidence` caller code | Included, local Devnet only; **not live-tested here** |
| Indexer-backed ledger map membership read | Included, SDK seam unit-tested; **not live-tested here** |
| Groth16 / ZK proof of **off-chain OctoLang policy compliance** | **No** |
| Public preprod/mainnet | **No** |
| Decentralised production custody, durability and operational assurance | **No** |

## Operational and audit warnings

- Verify generated Compact code is consistent with your compiler and SDK versions, and independently review the contract before publishing.
- The contract is an **open commitment registry**, not an on-chain authority check. Any Midnight wallet may insert any unique commitment. The off-chain reviewer approves publication separately; the contract doesn't verify that review itself.
- A commitment only binds what *the signing parties asserted*. It is not independent proof of the real-world facts underneath.
- Indexer queries establish observed state under the indexer's trust assumptions; `callTx`'s return plus map membership are not a third-party finality certificate or durable transaction recovery mechanism.
- Additional security work is required for wallet restoration, precise contract-state semantics across upgrades, node outages, chain reorganisations, confirmation-depth checks, SDK exception/idempotency recovery, access control, external custody and production network rollout.
- Keep the contract deployed-address source and human-reviewed source aligned. A change to the address invalidates the compiled mission digest and the approval.

## Current external technical references

- [Midnight local-dev setup](https://github.com/midnightntwrk/midnight-local-dev)
- [Midnight install toolchain](https://docs.midnight.network/getting-started/installation)
- [Midnight deploy and operate](https://docs.midnight.network/guides/deploy-and-operate)
- [Node.js wallet](https://docs.midnight.network/guides/node-server-wallet)
- [Midnight.js API](https://docs.midnight.network/api-reference/midnight-js)

_Last reviewed: 20 October 2026._
