# OctoLang ↔ Octonomous Runtime 1.0 — integration notes (v0.3)

## Implemented control flow

```text
natural-language intent -> AI/offline unapproved .octo draft
  -> deterministic compiler / policyDigest
  -> independently generated human review signature
  -> proposed action + mock signed registry claim + optional mock steward signature
  -> VCC: exact digest, expiry, scope, amount, approvals, nonce
  -> VCG: signed claim checks, status/freshness and graph snapshot root
  -> atomic (within process) nonce reservation + one-use permit
  -> Octonomous Runtime.registerBeing / handleEventForBeing
  -> Octonomous Being cognition adapter proposes only hardcoded tool
  -> Octonomous Policy.check: native allowlisted tool authorisation
  -> ToolRegistry: one-use event- and Being-bound permit + effect-time VCC re-evaluation
  -> append to local-intents.jsonl only
  -> sign local receipt: requestDigest + scoreDigest + contextRoot + recordDigest
  -> Runtime.reflect + store Being memory
```

The runtime package is a direct copy of the user's Octonomous Runtime 1.0.0 npm tarball, not a mock or an independently reimplemented Runtime. No changes were made to the vendored package. The OctoLang custom adapter lives solely in `integration/bridge.js`.

### Why two authorisation checks?

OctoLang VCC verifies a human-reviewed score against a signed context snapshot; the native Octonomous Policy independently checks whether that Being is allowed to call the one registered tool. The tool boundary then requires a single-use grant and performs a fresh VCC check before writing. Direct calls to the ToolRegistry without a grant fail. AI never receives a grant.

### Identity, evidence, and receipts

A signature proves who *signed the data* assuming the public key is trusted; it does not prove the real-world claim is true. The VCG context root proves which claim objects were used, not universal truth. The local receipt proves only that the temporary local signer attested to a journal entry. The signer must be independently enrolled and pinned to become useful outside this demonstration.

### Known gaps before real external side effects

1. Durable, transactional replay/idempotency and outbox store with crash recovery, distributed concurrency and exact effect reconciliation.
2. Real external supplier/accreditation proofs, revocation checking, provenance freshness and formally defined graph semantics.
3. Independent policy build/sign/deploy pipeline, isolated verifier and custody; human governance identities and signed threshold approvals.
4. External capability adapters with scoped credentials, allowlisted endpoints, locked-down tool schema, signed downstream receipts, dry-run and rollback controls.
5. Stronger signed event binding across the Runtime/ToolRegistry boundary, robust revalidation at point of effect, and audit/event tamper-evidence.
6. Agent-to-agent score composition, multiple Being identities, scoped delegation, reconciliation and optional OFP transport.
7. Verified Context Graph consistency and canonicalization standard, threat modelling, fuzz/property testing and independent security review.
8. Optional Midnight/Cardano/ZK proof statements, circuit compilation and audited Groth16 verifier adapter.

**Do not use this code to make payments or control privileged infrastructure.** It is a working integration *research prototype*, not a production runtime.
