# OctoLang 0.6 — Networked OFP and Demo Credential Governance

**Status:** runnable research prototype. Independently scheduled Node.js **processes** exchanging real signed OFP messages over **loopback HTTP** or optional **mutual TLS**, on one machine. Not independently hosted real-world organisations and not hardened for Internet use.

## Two ways to run

Quick one-command demonstration (makes a new randomly named `/tmp` root and starts/stops three OS child processes):

```bash
npm test
npm run network:mtls     # recommended, uses openssl to generate throwaway development certificates
# or npm run network     # signed OFP over 127.0.0.1 HTTP; no transport encryption
```

To retain the same identities between runs, provision explicitly, then start **four** independent terminals:

```bash
# once — NOTE this generates development secrets; never commit or share this folder
node network/identity.js .octolang-network --mtls

# terminal 1
node network/peer.js .octolang-network community-research
# terminal 2
node network/peer.js .octolang-network community-execution
# terminal 3
node network/peer.js .octolang-network community-audit
# terminal 4 — only after all peers report listening
npm run network:conduct
```

Each `network:conduct` prepares a **new demo action** with new signed mock review, issuer claim and steward approval, then runs the coordinator. For other ports, call `provision(directory, {ports:[...],tls:true})` from a Node script. Keys are fixed to the provisioned local score (digest); changed scores require *explicit reprovisioning and fresh approvals*, not accepting a new score from the network. Provisioning refuses to overwrite existing identities.

## Trust flow

1. A provisioning operator creates Ed25519 keys for the coordinator, the three independently running community processes, three individual agent signers, a credential authority, three local governance signers, and separate demo reviewer/registry/steward keys. Each PEM is stored with `0600` permissions under its own role's directory; public keys are copied into each local **pinned trust bundle**. Keep the entire provisioning root protected: a single demo operator initially manages all its private keys.
2. The operator issues **custom signed demo credentials** with `community`, `agent`, `capability`, `maxLovelace`, public signing keys, expiry and revocation ID. These ARE NOT W3C Verifiable Credentials, DID/VC Data Model, KERI identities or interoperable PCD.
3. Each community has its own locally pinned and signed grant authorising one specific compiled score digest, agent, capability, limit and no delegation. Credentials identify/scoped roles; they do not automatically grant execution authority.
4. The coordinator checks an independently pinned registry authority and recipient credential before issuing an OFP 2.0 signed envelope, as well as the exact human reviewer signature, demo context claim and demo approval. The coordinator never grants authority to peers by merely signing a message.
5. The peer checks the sender from its pinned public-key directory, OFP signature and recipient binding, timestamps, durable envelope-id and nonce replay claims. It loads its **local** trust bundle (never from the incoming network payload), checks the credential signature plus current local revocation file, checks the governance grant, recomputes VCC + VCG and verifies previous agent contributions.
6. The peer consumes its own durable action-nonce claim *before* the local action. Only the buyer invokes the original vendored Octonomous Runtime 1.0 local `record.purchase.intent` tool. Its receipt is signed with a persistent buyer-specific agent key.
7. Peers return signed OFP result envelopes containing separately signed agent contributions. The coordinator checks source, credential ID, request digest, score digest, context root, preceding contributions, journal receipt and final evidence chain against **out-of-band pinned keys**.

## TLS profile

With `--mtls`, the provisioner invokes the local `openssl` binary to mint a seven-day **demo CA** and distinct local client/server certificates (subject CN bound to each community ID). Peers use Node `https.createServer` with `requestCert: true`, `rejectUnauthorized: true`, a locally provisioned CA and an additional coordinator-CN check. The coordinator uses `https.request` with its client certificate, `rejectUnauthorized: true`, the pinned CA and a community-CN check. Signed OFP envelopes are **always** verified in addition to TLS identities. The CA and all certs are development-only and are managed by one operator.

The network is deliberately **bound to `127.0.0.1`**; the client explicitly rejects non-loopback URLs. To deploy on separate machines would require a reviewed transport/configuration change, real independently operated PKI, identity attestation, DNS/IP policy, external credential provisioning and stronger custody/secret management. Do **not** modify the hostname restriction alone and call it production-ready.

## Replay and failure model

Reservations are exclusively created filesystem files on **each process's local filesystem**, not a shared directory across hosts. Every peer consumes envelope ID, envelope nonce, and action nonce independently; the coordinator consumes its own action and response-envelope reservations. A failed run leaves its reservations in place. There are no retries, distributed transactions, exactly-once semantics, outbox/inbox acknowledgements, garbage collection, or crash-safe reconstruction of an in-flight transaction. If the buyer has recorded an intent but audit fails, inspect the journal and manually reconcile before authorising another action.

The experiment does not establish that a real supplier was accredited, that a human audit occurred, or that the model made a good decision. The VCG and steward approvals are generated **as explicitly labelled fixtures** for demonstration. Nor does a cryptographic signature imply objective real-world truth. No purchasing, payment, Cardano, Midnight, Groth16, production W3C VCs, federation consensus or external privilege/custody is implemented.

## Studio compatibility

`npm run studio` continues to provide a loopback human-review environment and the v0.5 **in-process federation simulator**. It does not silently trust browser reviewer keys inside separately provisioned v0.6 peers. This separation is intentional: importing a new trusted browser identity must require an explicit governance-approved administrative action. The networked demonstration is currently CLI-driven.

## Security demonstrations

`test/network.test.js` covers separate OS processes; cryptographic replay after restart; absent reviewer signature, issuer claim and steward approval; over-limit requests; OFP signature tampering and sender spoofing; credential tampering and revocation; locally signed grant tampering; duplicate steps with newly signed envelopes; modified compiled score; and mTLS client-certificate authentication.

## Toward v0.7

- Independently operated remote gateways using vetted TLS/mTLS and externally managed certificates, HSM/isolated signing and real credential issuers; issuer revocation status with pinned signed transparency updates.
- Durable transactional inbox/outbox and completion idempotency, signed receipts across crashes, queues and recovery/reconciliation tools.
- Explicit governance votes/threshold approvals rather than fixed one-operator bootstrap grants.
- W3C-compatible VCs, DIDs/KERI as optional interoperable identity adapters, and independent verification.
- Richer typed score/DAG composition and external-tool adapters behind isolated custody and auditable VCCs.
