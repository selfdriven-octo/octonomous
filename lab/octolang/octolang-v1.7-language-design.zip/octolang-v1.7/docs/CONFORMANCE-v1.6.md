# OctoLang v1.6 Conformance

`conformance/v1.6/manifest.json` contains **22 frozen vectors**: accepted examples with expected typed IR SHA-256 digests and diagnostic codes, and rejected examples with expected error substrings. These include equivalent source comment/declaration ordering, genuine semantic edits, cycles, illegal authority modes, missing proof obligations and service identity mismatch.

Run:

```bash
npm run language:conformance
node --test test/language-v1.6.test.js
npm test
```

Conformance criterion for a prospective independent implementation:

1. Parse each `.octo` fixture; accept or reject exactly as the manifest specifies.
2. For valid fixtures, produce the frozen *typed* IR hash and matching diagnostic code sequence.
3. For valid IR, verify all schema and DAG invariants using an independent static verifier.
4. Reject tampering even if the attacker recomputes the SHA-256 digest: altered schedule, different service identity, undeclared data flow, invalid role binding and fabricated authority fields.
5. Preserve the legacy mission compiled policy and digest for existing execution integrations; do **not** silently substitute the new IR digest for an approved legacy digest.

`make-fixtures.py` is a **maintainer-only regeneration utility**. Normal conformance must use the checked-in, frozen manifest; a compiler must never regenerate golden expected values as part of a conformance run.

All tests are local and offline. Passing tests does not certify mathematical security of any proof system, implementation absence of bugs, a trustworthy signer, real-world event truth, or actual Midnight chain settlement.
