# AI-first authoring and human review

This project intentionally favours **AI-generated OctoLang**, with independent human inspection and explicit permission to deploy.

## Programmatic interface

`src/authoring.js` exports `propose({ userIntent, modelAdapter })`. The adapter is supplied by the application; it accepts `{ system, user }` and returns plain `.octo` source as a string. It can use any local or remote model. This repo includes **no provider API integration** and requires no API key.

```javascript
const { propose } = require('./src/authoring');
const fs = require('node:fs');

const adapter = () => Promise.resolve(
  fs.readFileSync('examples/community-supplies.octo', 'utf8')
);

propose({ userIntent: 'Buy learning supplies with independent approval', modelAdapter: adapter })
  .then(({ draft, compiled, status }) => {
    console.log(status, compiled.digest);
    console.log(draft);
  })
  .catch(console.error);
```

A real model adapter could be plugged into this method later. A model's output is **only a proposal**. Compilation checks structural and local semantic validity, not whether policy and evidence requirements are appropriate.

## Required production human-review flow

1. Show the entire `.octo` draft, the compiled IR, effective capabilities and effective numeric limits in human-readable form.
2. Review each issuer/trust root, actor identity, target restriction, max age, escalation signer and evidence requirement.
3. Review both allowed and denied test examples; challenge whether a legitimate but harmful action would pass.
4. Use independent, authenticated signing to produce a review record bound to the exact policy digest.
5. On any change to the source that changes the IR, invalidate all existing review receipts and repeat.
6. Deploy policy through an independent VCC that checks revocation and live mandates. Do not permit model-generated proof strings or policy files to self-authorise.

The built-in demo produces an **ephemeral review signature for demonstration** and is not a real human-approval workflow.

## v0.4 extension: multi-agent drafting

Studio now offers `offline-ensemble` and optional `openai-ensemble` authoring modes. The optional AI adapter receives a constrained three-agent grammar exemplar; the returned `.octo` text is always compiled and fails on extra capabilities, multi-agent delegation, invalid dependency edges or unbounded spending. The human must still inspect and sign the **exact compiled digest**; AI text never enrolls agents or creates governance approvals. `scout` and `checker` are local demo signers, not autonomous external agents. See `docs/ENSEMBLE.md`.
