# OctoLang v1.5 — Midnight live Devnet acceptance runbook

## Scope and current verification status

This release adds a read-only preflight diagnostic and a **new independent indexer observation command** on top of OctoLang v1.4. It DOES NOT mean the OctoLang developers have compiled or deployed this Compact contract, generated a live ZK proof, submitted to Midnight, or inspected a real chain in the build environment. These steps require an operator's macOS/Linux machine with Docker and the Compact toolchain.

The acceptance criterion is:

1. Compile `midnight/contracts/evidence-anchor.compact` using a **compatible** Compact 0.31.1 release and install the pinned v4.1.1 Midnight SDK dependencies.
2. Bring up Midnight's **local** network node (9944), indexer (8088), and proof server (6300). Fund a disposable dev wallet with NIGHT and register DUST.
3. Deploy the contract (a real local ledger action) and capture the address and transaction ID.
4. Independently verify the signed OctoLang mission, VCG/VCC and service evidence; calculate a salted commitment; obtain **separate** human publication approval.
5. Explicitly submit the `anchorEvidence` circuit and obtain an SDK transaction ID plus a confirmed indexer observation.
6. In a separate process, requery the configured indexer without wallet keys and verify that the exact commitment is in the contract's ledger state. Archive the *redacted* observation and result.

**Proof scope:** A Midnight circuit proof establishes constraints encoded by *that Compact contract*. The current contract permits anybody to insert a unique, public 32-byte commitment; it does NOT prove off-chain supplier accreditation, agent intent, a reviewer signature or real-world task completion in ZK.

## Requirements

- macOS or Linux, Node.js >= 22.12 (22.16 is fine).
- Docker Desktop + Docker Compose v2, running.
- [Midnight local Devnet](https://github.com/midnightntwrk/midnight-local-dev) on `undeployed` network.
- Compact 0.31.1 compiler, not an untested latest compiler. `compact update 0.31.1` and `compact compile --version`.
- Disposable BIP39 test wallet, local NIGHT and DUST, 16+ character unique private-state password.
- Midnight.js SDK installed separately under `midnight/live/`; it is pinned to 4.1.1 and Compact runtime 0.16.0.

### Shell A: prepare the local network

```bash
git clone https://github.com/midnightntwrk/midnight-local-dev.git
cd midnight-local-dev
npm install
npm start
```

Keep this network session running; complete the local funding flow using a **disposable test-only mnemonic**. If you stop a network started by this tool, its Docker containers may shut down. Alternative startup is documented by the Midnight repo (`docker compose -f standalone.yml up -d`), but then wallet funding/registration is separately required. Use no real assets or production mnemonics.

### Shell B: prepare OctoLang

```bash
cd /path/to/octolang-v1.5
compact update 0.31.1
npm run midnight:compact
(cd midnight/live && npm install)
```

Set these environment variables **locally in your shell**, not inside `.octo` files or shared logs:

```bash
export WALLET_MNEMONIC='YOUR_DISPOSABLE_DEVNET_MNEMONIC'
export PRIVATE_STATE_PASSWORD='YOUR_UNIQUE_16_PLUS_CHARACTER_PASSWORD'
export OCTOLANG_MIDNIGHT_HOME="$HOME/.octolang-midnight-dev"
```

Do not run the following until the wallet is funded and has registered DUST:

```bash
npm run midnight:wallet-address
npm run midnight:acceptance:preflight
```

Preflight does not perform a transaction or reveal mnemonic/passphrase values. It checks binaries, local TCP service reachability, generated files, SDK installation, and presence of local wallet configuration. A pass is **necessary but not sufficient**: it does not prove services are healthy or the wallet has sufficient DUST.

### Shell B: operator-gated contract deployment

```bash
OCTOLANG_MIDNIGHT_ALLOW_DEPLOY=YES_LOCAL_DEVNET \
  npm run midnight:deploy -- ./local-deployment.json
```

If deployment fails, **do not invent an address or result**. Inspect local services, funded wallet, generated Compact code, SDK versions, and the specific error. Do not submit to public networks with this adapter.

### Shell B: prepare signed mission evidence and human approval

```bash
npm run midnight:make-evidence -- ./local-deployment.json ./evidence-001
npm run midnight:verify-live -- \
  ./evidence-001/bundle.json \
  ./evidence-001/pins.json \
  ./evidence-001/prepared-private.json
```

Review the mission, exact contract/network address, evidence and commitment. Create a **distinct local** Ed25519 reviewer key for this experimental test; keep its private key off-chain and out of agent inputs:

```bash
node -e 'const fs=require("fs"), c=require("crypto"), k=c.generateKeyPairSync("ed25519"); fs.writeFileSync("review-private.pem",k.privateKey.export({format:"pem",type:"pkcs8"}),{mode:0o600,flag:"wx"}); fs.writeFileSync("review-public.pem",k.publicKey.export({format:"pem",type:"spki"}),{flag:"wx"})'

npm run midnight:approve -- \
  ./evidence-001/prepared-private.json \
  ./evidence-001/bundle.json \
  ./evidence-001/pins.json \
  ./review-private.pem \
  ./review-approval.json
```

**The approval window is five minutes.** Start the submit step promptly after signing (the operator wallet may need time to synchronise; create the signature just before submission). No AI or Studio action is allowed to set the submission gate.

### Shell B: explicitly submit a real local transaction

```bash
OCTOLANG_MIDNIGHT_ALLOW_SUBMIT=YES_LOCAL_DEVNET \
  npm run midnight:anchor-live -- \
    ./evidence-001/bundle.json \
    ./evidence-001/pins.json \
    ./evidence-001/prepared-private.json \
    ./review-approval.json \
    ./review-public.pem \
    ./local-deployment.json \
    ./local-submission-result.json
```

`local-submission-result.json` is written only when the adapter received a plausible SDK transaction ID and saw exact commitment membership in the indexer. v1.5 additionally records `submittedAt` and `observedAt` (operator clock assertions) for audit. These do not provide block finality or independent transaction-to-commitment causality. On timeout or ambiguous errors, inspect chain state rather than blindly resubmit.

### Shell B: fresh read-only independent indexer observation

```bash
npm run midnight:acceptance:observe -- \
  ./evidence-001/bundle.json \
  ./evidence-001/pins.json \
  ./evidence-001/prepared-private.json \
  ./review-approval.json \
  ./review-public.pem \
  ./local-deployment.json \
  ./local-submission-result.json \
  ./new-indexer-observation.json
```

This command runs in a **fresh process** and uses *no wallet keys*. It re-verifies the OctoLang evidence/signature binding, checks reviewer signature validity at the operator-recorded initiation time, and independently asks the configured local Midnight indexer for the ledger state of the pinned contract. It fails if the exact commitment is absent. Output status `INDEXER_MEMBERSHIP_CONFIRMED` is not evidence that the alleged real-world action happened, proof that a particular tx inserted it, or an independent finality proof.

## Evidence and disclosure

Safe to send a collaborator after checking contents: `local-deployment.json`, `local-submission-result.json`, `new-indexer-observation.json` (still metadata; may expose network identity). Never send `evidence-001/prepared-private.json`, `review-private.pem`, wallet mnemonic/seed, `OCTOLANG_MIDNIGHT_HOME` wallet state/private-state stores, or the raw private evidence bundle unless the recipient has a legitimate need for it.

If you want help diagnosing a failure, share **only** the failure message plus redacted preflight output. The preflight command intentionally doesn't print the secret values.

## Remaining engineering requirements before production

- Run a real Compact compiler and prove/deploy/call sequence; review generated ledger map access and SDK behavior. No version upgrades without re-running compatibility tests.
- Compare ledger receipts against a trusted full node / multiple indexers; obtain appropriate confirmation depth/chain-finality guarantees.
- Add a durable transaction intent/outbox for at-most-once submission and crash recovery (currently no across-crash tx index).
- Review proof statement design: current Compact contract proves a public commitment registry operation, **not private OctoLang policy satisfaction**.
- Perform penetration and key custody reviews, test revocation, restore/recovery, external service failures, network partitions and upgrades.
- Use test-only identities and local funds until appropriate assurance is established.

Reference docs: https://docs.midnight.network/guides/node-server-wallet and https://docs.midnight.network/guides/deploy-and-operate
