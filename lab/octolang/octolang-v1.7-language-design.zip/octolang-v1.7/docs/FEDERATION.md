# OctoLang v0.5 — Federated Scores (Experimental)

## Implemented scope

This release integrates the **original** vendored MIT-licensed `octonomous-federation` 1.0.0 services, specifically:

- `FederationProtocolService` and `FederationEnvelopeService` to create and verify OFP 2.0 signed envelopes (OFP schema v1).
- `CommunitySigningService` with a **test-only Ed25519** signer/verifier, injected per local endpoint (no permissive missing verifier fallback).
- Three isolated **logical** community endpoints inside one local Node process, plus an in-process coordinator. Each endpoint can only sign under its own community identity; public keys are pinned in an out-of-band test directory.
- Request and response envelopes for the ordered `research → purchase → audit` score. The receiver verifies sender, exact recipient, signature, payload binding, approved score digest, VCG root, request nonce, scoped step, prior contribution and time window.
- Local role grants loaded at endpoint bootstrap, not from inbound messages. Only the buyer can invoke the existing Octonomous Runtime 1.0 `record.purchase.intent` capability. No payments.
- Exclusive-create filesystem records for run nonces, inbound envelope IDs and inbound envelope nonces. These survive process restart and block exact request replay. They do **not** provide production distributed transactions or automatic retry. They are intentionally never released; failed runs require **manual reconciliation**.
- Per-agent Ed25519 contributions with predecessor hashes, VCC approval and independent local verification of all three contributions.
- Offline and optional AI-authored federated `.octo` scores remain **drafts** until a human signs the compiled digest.

### Example: language

```octolang
score community_ensemble {
  // ...existing context, agent, before/after and ensemble declarations...
  federation community_supplies {
    member scout   { community "community-research" }
    member buyer   { community "community-execution" }
    member checker { community "community-audit" }
  }
  on violation DENY
}
```

See `examples/community-federation.octo` for a complete, working example. Federation is optional, and v0.1–v0.4 scores continue compiling against their original schema and checks. A federation score compiles to `octolang.policy.v0.5`, whose digest binds **all member-to-community assignments**. Changing these assignments requires fresh human review.

### Trust boundaries

```text
AI-written .octo draft ──compile──> versioned policy/digest
                               │
                         human signature
                               │
                 signed claim + steward approval
                               │
          coordinator ──signed OFP request──> research community
               │                   └─ signed OFP result / step proof
               ├────────> execution community
               │                   └─ native Runtime local-intent journal
               └────────> audit community
                                   └─ signed mock audit claim
                             verifier: independent pinned keys
```

The v0.5 proof is **an authenticated transcript of well-defined decisions and mock assertions**; it is not proof that a real supplier was accredited or that an independent human audit occurred. PCD and ZK/Groth16 are not implemented.

### Persistence model

- Data directory for CLI demo: randomly created OS temporary directory, printed in output.
- Data directory for Studio: `.octolang-local/federation/` for reservation files, `.octolang-local/local-intents.jsonl` for buyer journal (the previously existing bridge directory).
- Filesystem claims use `open(..., 'wx')` plus `fsync`, assuming a single local filesystem where exclusive file creation is atomic. Cross-machine networked NFS/shared hosting is **not guaranteed**.
- Reservations are crash-sticky. On failure after writing local intent, a later retry is **denied**, and the operator must inspect the journal and evidence. Never auto-delete claim files to force a retry.
- No automatic garbage collection, crash recovery, dead-letter queues, retries, durable rollback, key rehydration or reconciliation protocol. The signed result itself is not persisted as a completed idempotency receipt. Use a production transactional datastore for a real deployment.
- Dev signers are ephemeral, created inside the process; an exported public key in the returned result is **informational**, not a trust anchor. In real federation, verify independently pinned KERI/group AID keys, governance grants and revocation states.

### Explicitly not implemented

Internet federation and independently deployed peers, OFP inbound/outbound network gateways, protocol network retries, independently hosted signing/custody, real-world supplier discovery, production VCG provenance/revocation, real-world audit, governance threshold proofs, KERI identities, actual Cardano/Midnight verification, financial transfers, Groth16, secure enclave attestation. Shared input objects between logical peers deliberately simplify the local simulator; a live peer would need to fetch and independently verify the same signed policy and evidence.

### Threat cases tested

1. Tampering with an envelope payload invalidates the OFP receipt binding.
2. Duplicate message ID / nonce is rejected even when a different ID is freshly signed with the same nonce.
3. Same score request is blocked after a new engine instance (same data dir), including concurrent invocations.
4. Bad or missing human review, unsigned claim, invalid policy digest and missing steward approval produce no effect.
5. A peer-local grant that disagrees with the score denies the step.
6. A failed initial message creates a crash-sticky reservation; retry cannot perform a side effect.
7. End-to-end Studio HTTP route requires local-request header and accepted review.
8. v0.1/v0.2/v0.3/v0.4 regression tests remain intact.

### Next milestones

1. Distinct processes/hosts with mutually authenticated transports and independently managed DID/KERI community keys.
2. Explicit community approval documents, signed governance proofs and revocation checks, separately verified by each peer.
3. Durable atomic per-peer inbox/outbox, crash-safe idempotent processing and human-assisted reconciliation with no duplicate effects.
4. Stronger VCG provenance, append-only execution evidence and formal/PCD proofs where relevant.
5. Optional Cardano and Midnight adapters behind external custody and formally reviewed circuit constraints.
