# OctoLang v1.3 — Midnight Network integration boundary

**Status:** experimental **integration interface, off-chain verified commitment, Compact contract template and local in-memory fixture**. This release **has not compiled/deployed the Compact contract or generated/verified a Midnight ZK proof**. A real network adapter is not bundled because it requires separately provisioned Midnight SDK providers, a wallet, contract deployment, chain state and a local proof server. Never report the local mock's `MATCHED_TRUSTED_MIDNIGHT_STATE_READER` as on-chain confirmation.

## Why Midnight?

Midnight permits privacy-preserving smart contracts using Compact and zero-knowledge proofs. OctoLang retains signed VCG/VCC decisions and fine-grained executable authority off chain. We only propose posting an opaque, salted, 32-byte commitment to independently verified evidence on Midnight. This is not a proof of real-world truth. A true ZK proof of policy compliance needs a separately audited Compact circuit encoding **that exact policy**, verified by Midnight, which is out of scope here.

Official starting points (checked 20 October 2026):
- https://docs.midnight.network/guides/build-a-private-smart-contract
- https://docs.midnight.network/guides/deploy-and-operate
- https://docs.midnight.network/getting-started/installation
- https://docs.midnight.network/relnotes/compact/toolchain-0.35.0

The docs currently recommend Compact **0.31.x** (0.31.1 in the examples) for public-network ledger 8 contracts, which use Compact language **0.23** and runtime **0.16.x**. The newer 0.35 toolchain targets ledger 9; don't mix generated-code and SDK runtime versions. Pin versions to the official compatibility matrix for your deployment network.

## Language example

See `examples/community-midnight.octo`:

```text
anchor evidence_anchor {
  backend midnight
  network "local-devnet"
  contract "octolang_demo_contract_0001"
}
```

This declaration becomes part of the compiled `octolang.mission.v1.3` digest **before the human approves the mission**. Changing the target invalidates the human review and every bound grant. An anchor is **post-execution**: it is neither an executable tool capability nor a prerequisite for local tool authorisation. Actual publication requires a **second human-signed approval of the exact commitment and target**, distinct from the mission review.

## What works now

1. `npm run midnight:compile-mission` checks and compiles the v1.3 `.octo` mission with its anchor declaration.
2. `npm run midnight:demo` executes the normal, tightly scoped Octonomous note-recording capability on localhost; checks the signed human review, policy constraints, grants, context, agent results, controller receipts and service receipt; computes a commitment; separately signs a human anchor approval; and invokes a local adapter with only `{network, contract, commitment}`.
3. `midnight/bridge.js` accepts an operator-supplied adapter with `submitCommitment` and `readCommitment`, validates the exact human signature, and checks an independently pinned verifier observation and committed state.
4. `midnight/contracts/evidence-anchor.compact` is a **source-only** example of a public registry of unique commitments; the contract still needs a compile, audit, deployment and SDK bindings.
5. `npm run midnight:prepare -- <evidence-bundle.json> <trusted-public-pins.json> <new-private-opening.json>` creates a standalone off-chain commitment file with filesystem mode `0600`, fails rather than overwriting existing files, and **does not contact Midnight**.
6. `midnight/local-adapter.js` is an **in-memory fake** for demonstration. It cannot prove network inclusion, generate Groth16 proofs, or run a Midnight transaction.

## Privacy

`prepareAnchor` computes:

```
SHA256(UTF8("octolang.midnight.anchor.v1\\0") || 32-byte random salt || canonical(statement))
```

The private statement binds the exact compiled mission digest, approved request digest, execution plan digest, VCG context root, verified evidence root, target network and contract. The **salt and private statement must remain off-chain**; only the commitment is submitted. Both may reveal metadata when later shared for verification. Store private evidence encrypted, rotate salts, and do not publish raw VCG nodes, user names, or identity credentials.

## Chain adapter contract

Implement these interfaces in a **separately trusted** module on the operator's own machine:

```js
const adapter = {
  async submitCommitment({network, contract, commitment}) {
    // Use Midnight.js + generated Compact contract bindings, local proof-server,
    // separately controlled wallet/provider and the explicitly approved contract.
    // Return the actual submitted transaction ID after SDK submission.
    return {transactionId: /* actual transaction ID */ 'REPLACE_ME'};
  },
  async readCommitment({network, contract, transactionId}) {
    // Query a trusted indexer / ledger reader and verify this particular tx's
    // finality and the contract state entry corresponding to the commitment.
    // The caller trusts YOUR reader, NOT a field inside an untrusted bundle.
    return {commitment: /* read ledger */ '...', finalized: /* verified */ false};
  }
};
```

`submitAnchor({prepared,bundle,pins,approval,pinnedReviewerKey,adapter})` fails closed if the mission evidence, prepared hash, authorisation, target or adapter is missing/invalid. `verifyObservedState` *also* needs a signed observation from an independently pinned observer and a separately trusted reader. It reports `MATCHED_TRUSTED_MIDNIGHT_STATE_READER`, **not** `ZK_PROOF_VERIFIED`. The reader's chain-finality assurances are a separate trust assumption. Production implementation must additionally handle key custody, authenticated transport, durable submission idempotency, retries, revocation, confirmation depth, reorgs, chain protocol changes, costs and recovery.

The Compact example stores public commitments in a map, blocking exact duplicate keys; **it does not check who is allowed to submit** nor establish a real-world assertion. Verify the matching human approval separately; don't assume a registry record implies authority.

## Toolchain setup (operator machine only)

Consult the official docs before installing. On a supported Mac/Linux development machine:

```bash
compact update 0.31.1
compact compile +0.31.1 midnight/contracts/evidence-anchor.compact midnight/contracts/managed/evidence-anchor
# For transactions you also need the compatible Midnight.js SDK/provider stack,
# a configured indexer and node, a separate wallet, and a LOCAL proof server.
# See the docs for runtime/library versions and Docker proof-server:8.1.3.
```

The `.compact` example has **not** been compiler-validated here: Compact and Docker are not available in this execution environment. Even after compilation, the contract still needs deployment and production security review. Do not install tools or connect to a public network as an automatic result of processing an AI-authored mission.

## Trust separation

- AI authors mission / anchor proposal only.
- Human signs the exact compiled mission and separately approves the exact commitment / chain target.
- VCC authorises specific local tools; the chain adapter does not inherit those capabilities.
- Octonomous agents generate signed evidence; independently pinned trust roots verify it.
- Privacy-preserving commitment is generated from *already verified* receipts, not a generative model's statement.
- Midnight's on-chain proof validation would apply only to a separately compiled Compact contract's encoded rules, not arbitrary VCG or real-world truth.
- One mock fixture test does not mean remote-wallet, actual Midnight or ZK behaviour has been validated.
