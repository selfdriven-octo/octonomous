# Ensemble Scores: v0.4 language and assurance notes

## Scope

This experimental extension defines one bounded composition: scout (research), buyer (purchase-intent journal) and checker (audit assertion). It is not a general agent execution language. The `.octo` source can be drafted by AI, but the compiler restricts semantics and a separate human signature approves the *entire score digest*, never an AI's claim that it is safe.

## Grammar extension

```
ensemble <name> {
  step <id> {
    agent <declared_agent_id>
    capability "research" | "purchase" | "audit"
    depends none | <previous_step_id>
    require <same_VCC_context_id>
    evidence "<evidence_class>"
  }
  ...
}
```

Restrictions: exactly three distinct agents, exactly three steps in `research -> purchase -> audit` order, linear dependency chain, single shared VCC context, no delegation, no extra agents, no dynamic handlers, no external code or network execution. The purchase actor must hold the original `before purchase` authorisation, and all other agents have spending limit **0 ADA**. See `src/compiler.js` for authoritative validation.

The canonical `octolang.policy.v0.4` digest includes the multi-agent schedule, roles, context, limits, approval threshold and evidence names. v0.1 source still compiles as `octolang.policy.v0.1` for backward compatibility.

## Execution flow

1. Verify compiled source digest, time-bound human Ed25519 review signature, claim issuer and signed evidence, optional signed steward approval for >50 ADA.
2. Reserve the action nonce in memory. Validate VCG snapshot; bind `contextRoot` to request.
3. Re-evaluate VCC immediately before each agent step. `research` mock reads the source's signed claim and returns a signed shortlist **assertion**, not a real lookup.
4. Independently verify scout signature, compiled role and capability, output digest, score/request/root binding, and issuer evidence.
5. `purchase` invokes v0.3's real Octonomous Runtime 1.0 confined local `record.purchase.intent` tool. Verify its signed local receipt with an already-pinned journal signer public key.
6. Independently verify buyer signature and receipt binding before allowing the next step.
7. `audit` mock signs a statement about the buyer's exact prior contribution digest. Verify the signed assertion and expected dependency.
8. Return an ordered evidence chain and its SHA-256 chain head. A transcript verifier can run in a different process if the caller independently provides trustworthy agent keys, score and signing trust configuration.

## Signed agent contribution (v0.4)

```
{
  output: { schema: "octolang.step-output.v0.4", kind: "...", ... },
  attestation: {
    payload: {
      schema: "octolang.agent-contribution.v0.4",
      scoreDigest, requestDigest, contextRoot,
      ensemble, stepId, agent, capability, evidence,
      outputDigest, priorDigest, issuedAt, expiresAt, nonce
    },
    signature: "base64-ed25519"
  }
}
```

The `outputDigest` covers the full canonical output. `priorDigest` covers the **preceding complete contribution** (`output` + `attestation`). The first step uses `null`. A valid signature says that a pinned signer attested to bytes, **not** that a real-world supplier or audit is correct.

## Verifier contract

`verifyPartialTranscript({inputs, contributions, trustedAgentKeys, receiptSignerPublicKeySpki, now})` validates a nonempty prefix of the chain; `verifyTranscript(...)` requires the full three steps. Both reject unknown signer keys, altered output, predecessor mismatch, expired signatures, mismatched VCG root and modified local receipt records. **Never import signer keys from the untrusted transcript and treat those as anchors.** `inputs.trusted` includes keys for human reviewer, claim issuer and steward. Real deployments also require chain-wide governance identity binding and revocation verification.

## Isolation and failure modes

- Demo agent keys, studio pairing key, steward and registry identities are all locally generated. There is no remote agent discovery, DID/ACDC integration, separate-process key custody or remote OFP peers.
- A valid VCG signature is not proof of objective correctness. The mock research agent does not independently source evidence; the audit agent has no outside evidence beyond the buyer's signed local receipt.
- Local journal writes cannot be undone if a later step fails. Workflows with non-idempotent side effects require compensation and persistent state machines.
- Action requests themselves are not individually signed; human reviews bind a policy and steward approvals bind a particular request digest. Real deployment requires requester authentication and bounded capability grants.
- The process-local replay reservation and journal are not atomic under multiple processes/restarts. Do not use for financial activity.
- The implementation executes local code in a single Node.js trust domain; formal verification, sandboxing and TEE attestation are not claimed.
- The embedded Octonomous Runtime is original v1.0.0 as included in v0.3. New ensemble work uses an adapter and avoids mutating its own policy modules.

## Future design

Upgrade to typed DAG scores, governance-approved remote identity maps, VCC-isolated tool invocation, durable idempotency and OFP envelopes. Add PCD/Groth16 only for precisely defined predicates whose proof systems are independently audited, and keep chain settlement optional with custody outside the conductor.
