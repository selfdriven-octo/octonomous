# OctoLang v0.8 — Verifiable Agent Development Platform (pilot)

**Security-first experimental release. Node.js 22+, CommonJS, OpenSSL for distributed demo.**

## What's implemented

1. **Independent agent discovery** (`platform/discovery.js`): a peer advertises an Ed25519-signed, short-lived agent presentation at `GET /agent`. The coordinator reaches the peer over the existing mutually authenticated, exactly pinned HTTPS transport, then independently verifies the community signing key, role, endpoint, policy digest, credential, revocation status and peer's **separately signed local governance grant**. An unsigned discovery result can never grant authority. The coordinator checks discovery again before every OFP step delivery; remote peers still run their own VCC and governance verification.
2. **Verifiable-credential-style evidence**: v0.6 demo credentials are signed by the pinned governance issuer, tied to specific community and agent keys, scope, dates and a local revocation list. v0.8 adds a community-signed agent *presentation* which binds the credentials and original signed governance grant. **These are bespoke signed JSON objects, not interoperable W3C VC or DID implementations.** Neither key proof nor issuer signature guarantees external real-world truth. The issuer remains centrally operated in this demo.
3. **Distributed context re-verification** (`platform/context.js`): the research peer signs a short-lived attestation of the exact verified-context root, score, request and claim digests. The coordinator and other execution peers independently verify the signed underlying claims and freshness against their *locally pinned* issuer, independently recompute the VCG root, check the peer's pinned signer/credential and reject mismatches. The attestation does not substitute for independent claim verification.
4. **Unified browser surface, carefully separated authority**: the existing Studio still composes, reviews, signs and conducts its **local/in-process** scores. A new **Observe** panel uses a *read-only* `/api/distributed/status` endpoint to show the separately provisioned distributed coordinator's roles and the progress/status of up to 100 durable outbox runs. It rechecks policy and transcript proofs where present, never returns raw action inputs, keys or claims, and cannot execute distributed actions. A second **Verify live agent identities** button uses read-only `/api/distributed/discover` to verify the signed agent presentation, governance grant and issuer credential of every currently reachable peer (via pinned mutual TLS); it never authorises actions. It is **not** a browser-to-network authorisation bridge.
5. **No change to the only effect**: an authorised buyer agent appends a *purchase intent record* to a local Octonomous Runtime journal. No payments, Cardano transactions, remote wallets, privileged tool calls or public Internet service.

## Quick start (offline demo)

```bash
node --version
openssl version
npm test
npm run distributed:demo
npm run studio
```

Open <http://127.0.0.1:8787>. The Studio uses the original local in-process reviewer signer and simulation. To monitor a separate live distributed run, set the coordinator home's directory before starting Studio.

## Inspect a persistent distributed demo

```bash
# Choose an initially nonexistent directory, otherwise provisioning refuses to overwrite identities.
export OCTOLANG_DISTRIBUTED_HOME="$HOME/octolang-v08-demo-$(date +%s)"
export OCTOLANG_DEMO_KEEP=1
npm run distributed:demo

# Demo stops the peers after successful execution but retains the state.
export OCTOLANG_DISTRIBUTED_HOME="$OCTOLANG_DISTRIBUTED_HOME/owner-coordinator"
npm run distributed:status
npm run studio
```

In Studio click **Refresh distributed status** in the Observe section. The status may become `FAILED_OR_EXPIRED` after the demo's short proof lifetimes pass. This is a current *re-verification* result, not a claim that the original event never completed.

For **live** discovery, keep the peer processes running and use their respective independently provisioned homes, as documented in [the v0.7 runbook](DISTRIBUTED-v0.7.md). Then on the coordinator machine:

```bash
npm run distributed:discover -- ./coordinator-home
node distributed/conduct.js ./coordinator-home
```

The discovery CLI validates live signed peer presentations over pinned mTLS. `npm run distributed:status` is read-only; `distributed/conduct` creates an expressly *synthetic* signed request/approval using development keys. Reusing a completed request is denied.

### Trust boundaries / things intentionally not implemented

- Agent discovery does **not** perform dynamic permission assignment: only previously pinned communities are eligible. New peers require the v0.7 out-of-band registration and governance enrolment flow.
- Proofs are local Ed25519 evidence receipts and independently signed context checks. **Groth16, SNARK verification, proof-carrying data interoperability, Cardano, Midnight and W3C VC standards are not implemented.**
- The Studio reviewer key does **not** automatically become a reviewer on any separately provisioned coordinator. Distributed execution still requires a distinct approved score and governed signing keys.
- Revocation lists are local files; revocations do not yet propagate automatically. The coordinator and peer each check their own local registry, so timely synchronisation remains an operational requirement.
- The demonstration's reviewer, steward and accredited supplier are **synthetic fixtures**, not attestations from accredited external organisations.
- Outbox status and progress are read from local fsynced files, not a Byzantine-resistant audit log. Compromise of the file owner/root can falsify data. Strong tamper-evident logs, independent issuer onboarding, recovery operations and key rotation are unimplemented.
- No actual validation on different physical machines has been performed. Network endpoints and private/VPN deployment remain controlled-pilot features, not Internet-ready services.
- Discovery presentations expire after approximately three minutes; context attestations after approximately two. A paused outbox whose proofs expire must be reauthorised (possibly reconciled if an effect is uncertain) rather than silently extended.

## Architecture map

```text
AI / offline score composer → human-reviewed .octo digest
                           ↓
              VCC + signed VCG evidence
                           ↓
           Distributed coordinator + durable outbox
                  ↓ authenticated GET /agent
   pinned TLS + signed community agent presentation
    ↳ issuer credential + peer governance grant checked
                  ↓ signed OFP step request
      independent research peer computes signed VCG root
                  ↓
       buyer/audit peers reverify claims + root
                  ↓
   original Octonomous Runtime local journal receipt only
                  ↓
 Studio Observe reads SANITISED status; cannot execute
```

## Source map

- `platform/discovery.js`, `platform/discover.js`: present and independently validate pinned, signed agent discovery.
- `platform/context.js`: create and verify signed context proof **and recompute** its VCG root.
- `platform/monitor.js`: output-minimised and reverified read-only coordinator status.
- `network/peer.js`: new authenticated `GET /agent`; research step emits signed context proof and later peers independently check it.
- `network/transport.js`: pinned HTTPS allows signed discovery route.
- `distributed/coordinator.js`: short-lived discovery verification on each step, independent attestation checks, previous durable delivery semantics.
- `studio/server.js`, `studio/public/{index.html,app.js}`: read-only distributed view within existing Studio.
- `test/platform.test.js`: new adversarial and integration checks.

This extends v0.7 rather than changing the `.octo` grammar; compiled policies retain their `octolang.policy.v0.5` wire schema. Existing historical versions are preserved for reproducing earlier experiments.
