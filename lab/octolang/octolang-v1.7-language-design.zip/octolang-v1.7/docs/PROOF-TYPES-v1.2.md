# OctoLang v1.2: Declarative Capability & Proof Types

**Status:** experimental reference language, not a production security standard. v1.2 deliberately extends the `mission` grammar rather than introducing a competing policy language. AI output is a *proposal*, never an authority.

## Example

```octo
mission community_report {
  // This example shows the new declarations; see examples/community-proofs.octo
  // for a fully compilable four-task mission.
  role scout { capability "service.note.record" }
  input note { type text }

  capability note_writer {
    role scout
    name "service.note.record"
    fields "note:text"
    service "notes-provider"
  }
  proof note_recorded {
    task find_supplier
    kind service_receipt
    service "notes-provider"
  }
}
```

The snippet above is *partial*; use the complete working `.octo` example to compile.

### Capability contracts

- `role`: role defined by the reviewed mission.
- `name`: exact capability already required by that role. It **does not register or authorise** a service. A separate signed, mission-scoped operator manifest must enable the name and endpoint.
- `fields`: comma-separated `inputName:type` bindings. Supported types: `ada`, `integer`, `text`, `boolean`. Each input must already be declared in the mission with the same type. These are **exactly the fields** disclosed to the external service, not a subset. The separately operator-signed manifest's input allowlist must match the entire set.
- `service`: exact trusted Ed25519 service identity from the independently signed capability manifest and out-of-band public-key pins.
- One contract per external role. Built-in local roles use the pre-existing trusted controller instead of service contracts.

### Proof types

| Type | Evidence checked | What it cannot establish |
|---|---|---|
| `service_receipt` | Exact service identity and service-signed receipt bound to request, manifest and result. Requires `service "..."`. Mandatory for every external task. | Real-world truth or external side-effect correctness beyond service's signed assertion |
| `controller_receipt` | Controller-signed exact tool/result digest, mission, task and agent binding | That arbitrary third-party work was done |
| `agent_receipt` | Agent-signed, dependency-linked execution receipt, mission/context hash and tool receipt digest | That the agent's source data was objectively true |

Every task in a v1.2 mission requires at least one explicit `proof`. More than one kind can be required for the same task. The proof labels and obligation types are included in the mission's canonical hash and the human review signature. Unknown types fail compilation; there is **no** `groth16` or `zk` type in this release.

### Validation and execution sequence

1. **Compile** `.octo` source to `octolang.mission.v1.2`, reject undeclared/mismatched inputs, missing proofs and mismatched service roles. Hash the complete declaration set.
2. **Approve** the exact mission digest with the independently trusted human review key. The AI's proposed role or service is *not* authorisation.
3. **Plan** with an exact signed request, verified context claims, typed bounds and independently signed capability grants.
4. **Preflight controller** checks the operator-approved signed service manifest's identity, mission scope, expiry and input allowlist against the typed declarations, before reserving any side effect.
5. **Re-check at effect time** including revocation/expiry/manifest consistency; perform only the allowlisted bounded call. Replay reservation remains sticky after ambiguous failure.
6. **Generate** controller/agent/service signed receipts, as applicable, bound to the approved mission, tool/request digest and dependencies.
7. **Verify offline** with separately obtained public pins. Signature checks happen before typed proof obligations are satisfied. Return a typed evidence list with exact hashes, not a synthetic claim that a proof exists.

### Backward compatibility

An old mission without `capability` or `proof` remains schema `octolang.mission.v0.9` and is unchanged. New declarations opt into schema `octolang.mission.v1.2`. Old simulation code cannot claim verification of typed execution requirements. The Studio may review a v1.2 mission, but does not allow the browser to confer external-service authority; the new example runs through a separately provisioned CLI controller.

### Threat model and limitations

- Service substitution, leaked fields, forged manifests, invalid service keys, missing signed receipts, stale manifests, source modification and replayed mission requests fail closed in the tested local reference path.
- Never ingest issuer/service trust pins from an untrusted evidence bundle as authoritative. They must be independently verified; bundled demo pins are generated only for the local demonstration.
- The proof system is **Ed25519 receipt verification**, not ZK, proof-of-computation, BFT consensus or objectively verified results. A signed assertion can still be false.
- v1.2 is demonstrated with a localhost note-writing HTTP service. Remote HTTPS remains an experimental v1.1 feature, not a hardened public-network deployment. Key custody, distributed storage durability, revocation propagation and external-tool side effects require additional security engineering.
- No Cardano, Midnight, Groth16 or wallet custody is included.
