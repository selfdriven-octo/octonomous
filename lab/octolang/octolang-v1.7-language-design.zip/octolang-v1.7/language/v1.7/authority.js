'use strict';
// Admission is a pure preflight. Signing keys and durable spend/replay accounting MUST remain external.
const crypto=require('node:crypto');
const {canonical,verifiedSigned,digest}=require('../../src/canonical');
const {verifyIR:verifyRoot}=require('../v1.6/validate');
const {verifyIR:verifyComposition}=require('./validate');
const {digestIR}=require('./index');
const SCHEMA='octolang.composition-mandate.v1.7';
const GRANT='octolang.composition-role-grant.v1.7';
const REVISION='octolang.composition-revision.v1.7';
const pinKey=(map,issuer)=>map&&Object.hasOwn(map,issuer)?map[issuer]:null;
const plain=o=>!!o&&typeof o==='object'&&!Array.isArray(o)&&Object.getPrototypeOf(o)===Object.prototype;
const id=/^[A-Za-z_][A-Za-z0-9_-]*$/;
function check(x,m){if(!x)throw new Error(m);}
function keys(obj,names){check(plain(obj)&&Object.keys(obj).length===names.length&&names.every(k=>Object.hasOwn(obj,k)),'Unexpected or missing signed fields');}
function signedBy(object,map){check(plain(object)&&plain(object.payload)&&typeof object.signature==='string','Missing signed object');check(typeof object.payload.issuer==='string','Missing issuer');const key=pinKey(map,object.payload.issuer);check(!!key&&verifiedSigned(object,key),`Untrusted signature: ${object.payload.issuer}`);}
function window(p,now){check(Number.isSafeInteger(now)&&now>=0,'Invalid clock');check(Number.isSafeInteger(p.validFrom)&&Number.isSafeInteger(p.expiresAt)&&p.validFrom<=now&&now<p.expiresAt&&p.expiresAt>p.validFrom,'Expired or premature signed authorisation');check(p.expiresAt-p.validFrom<=366*86400000,'Authorization window too long');}
function int(n,min,max,name){check(Number.isSafeInteger(n)&&n>=min&&n<=max,`Invalid ${name}`);}
function validRoot(rootIR,missionIRDigest){check(verifyRoot(rootIR,missionIRDigest).valid,'Root typed IR invalid');}
function validComposition(artifact,rootIR){check(plain(artifact)&&artifact.irDigest===digestIR(artifact.ir),'Invalid composition artifact digest');check(verifyComposition(artifact.ir,rootIR,artifact.irDigest).valid,'Invalid composition IR');}
function authenticateMandate(signedMandate,{rootIR,missionIRDigest,trust,now,expectedSubject}){
  validRoot(rootIR,missionIRDigest);
  signedBy(signedMandate,trust?.mandateIssuers);
  const p=signedMandate.payload;
  keys(p,['schema','issuer','missionIRDigest','subject','validFrom','expiresAt','nonce','allowRevision','maxNodes','maxDepth','maxTotalBudgetUnits','allowedTasks']);
  check(p.schema===SCHEMA&&p.missionIRDigest===missionIRDigest,'Mandate cannot be applied to a different mission');
  check(typeof expectedSubject==='string'&&id.test(expectedSubject)&&p.subject===expectedSubject,'Mandate community subject mismatch');
  check(id.test(p.issuer)&&id.test(p.subject)&&/^[0-9a-f]{32,64}$/.test(p.nonce),'Invalid mandate identities/nonce');
  window(p,now);check(typeof p.allowRevision==='boolean','Invalid revision permission');
  int(p.maxNodes,1,32,'mandate maxNodes');int(p.maxDepth,1,6,'mandate maxDepth');int(p.maxTotalBudgetUnits,0,100000000,'mandate budget');
  check(Array.isArray(p.allowedTasks)&&p.allowedTasks.length>=1&&p.allowedTasks.length<=32,'Invalid allowedTasks');
  const allowed=new Map();
  for(const x of p.allowedTasks){
    keys(x,['task','maxInstances','maxRunsPerInstance','maxBudgetUnitsPerRun']);
    check(id.test(x.task)&&!allowed.has(x.task)&&rootIR.tasks.some(t=>t.name===x.task),'Invalid allowed task');
    int(x.maxInstances,1,32,'instances');int(x.maxRunsPerInstance,1,16,'runs ceiling');int(x.maxBudgetUnitsPerRun,0,1000000,'budget ceiling');
    allowed.set(x.task,x);
  }
  return {payload:p,allowed};
}
function authenticateGrants(signedGrants,{rootIR,missionIRDigest,trust,now,expectedSubject}){
  check(Array.isArray(signedGrants),'Role grants missing');const byRole=new Map();
  for(const signedGrant of signedGrants){
    signedBy(signedGrant,trust?.grantIssuers);const p=signedGrant.payload;
    keys(p,['schema','issuer','missionIRDigest','subject','agentId','role','capability','validFrom','expiresAt','maxRuns','maxBudgetUnits']);
    check(p.schema===GRANT&&p.missionIRDigest===missionIRDigest&&p.subject===expectedSubject,'Grant bound to wrong mission or community');
    check(id.test(p.issuer)&&id.test(p.agentId)&&id.test(p.role),'Invalid grant identities');
    const role=rootIR.roles.find(r=>r.name===p.role);
    check(role&&role.capability===p.capability,'Grant role/capability mismatch');
    check(!byRole.has(p.role),'Multiple grants for the same role are ambiguous');
    window(p,now);int(p.maxRuns,1,512,'grant maxRuns');int(p.maxBudgetUnits,0,100000000,'grant maxBudgetUnits');
    byRole.set(p.role,p);
  }
  return byRole;
}
function admit({artifact,rootIR,missionIRDigest,signedMandate,signedGrants,trust,expectedSubject,now=Date.now()}){
  try{
    validRoot(rootIR,missionIRDigest);validComposition(artifact,rootIR);
    check(artifact.ir.missionIRDigest===missionIRDigest,'Composition root mismatch');
    const mandate=authenticateMandate(signedMandate,{rootIR,missionIRDigest,trust,now,expectedSubject});
    const p=mandate.payload;
    check(artifact.ir.nodes.length<=p.maxNodes&&artifact.ir.maxDepth<=p.maxDepth&&artifact.ir.worstCaseBudgetUnits<=p.maxTotalBudgetUnits,'Composition exceeds mandate global ceiling');
    const grants=authenticateGrants(signedGrants,{rootIR,missionIRDigest,trust,now,expectedSubject});
    const counts=new Map(),runs=new Map(),budgets=new Map();
    for(const n of artifact.ir.nodes){
      const rule=mandate.allowed.get(n.task);
      check(!!rule,'Composition requests a task outside mandate');
      check(n.maxRuns<=rule.maxRunsPerInstance&&n.budgetUnitsPerRun<=rule.maxBudgetUnitsPerRun,`Task ceiling exceeded: ${n.task}`);
      counts.set(n.task,(counts.get(n.task)||0)+1);
      runs.set(n.role,(runs.get(n.role)||0)+n.maxRuns);
      budgets.set(n.role,(budgets.get(n.role)||0)+n.maxRuns*n.budgetUnitsPerRun);
      check(!!grants.get(n.role),`No independent trusted grant for role ${n.role}`);
    }
    for(const [name,num] of counts)check(num<=mandate.allowed.get(name).maxInstances,`Instance limit exceeded: ${name}`);
    for(const [role,num] of runs)check(num<=grants.get(role).maxRuns&&budgets.get(role)<=grants.get(role).maxBudgetUnits,`Role grant ceiling exceeded: ${role}`);
    return {status:'ADMISSIBLE_PROPOSAL',compositionIRDigest:artifact.irDigest,mandateDigest:digest(signedMandate),
      warning:'No execution authority: runtime must revalidate grants, context, approvals, revocation, budgets and replay at effect time.'};
  }catch(e){return {status:'DENY',reason:e.message};}
}
function verifyRevision({oldArtifact,newArtifact,revision,rootIR,missionIRDigest,signedMandate,signedGrants,trust,expectedSubject,now=Date.now()}){
  try{
    const old=admit({artifact:oldArtifact,rootIR,missionIRDigest,signedMandate,signedGrants,trust,now,expectedSubject});
    check(old.status==='ADMISSIBLE_PROPOSAL',`Previous composition not admitted: ${old.reason}`);
    const next=admit({artifact:newArtifact,rootIR,missionIRDigest,signedMandate,signedGrants,trust,now,expectedSubject});
    check(next.status==='ADMISSIBLE_PROPOSAL',`Revised composition not admitted: ${next.reason}`);
    check(signedMandate.payload.allowRevision===true,'Signed mandate does not allow adaptation');
    signedBy(revision,trust?.revisionProposers);
    const p=revision.payload;
    keys(p,['schema','issuer','fromIRDigest','toIRDigest','mandateDigest','sequence','nonce','reason']);
    check(p.schema===REVISION&&p.fromIRDigest===oldArtifact.irDigest&&p.toIRDigest===newArtifact.irDigest&&p.mandateDigest===old.mandateDigest,'Unbound plan revision');
    check(id.test(p.issuer)&&typeof p.reason==='string'&&p.reason.trim().length>0&&p.reason.length<=500&&/^[0-9a-f]{32,64}$/.test(p.nonce),'Invalid revision provenance');
    int(p.sequence,1,1000000000,'revision sequence');check(p.fromIRDigest!==p.toIRDigest,'Unchanged plan');
    const prior=new Map(oldArtifact.ir.nodes.map(x=>[x.name,x]));
    for(const n of newArtifact.ir.nodes){const before=prior.get(n.name);if(!before)continue;
      check(before.task===n.task&&before.role===n.role&&before.capability===n.capability&&before.effect===n.effect&&canonical(before.requiredProofs)===canonical(n.requiredProofs),'Existing node identity/scope was repurposed');
      check(n.maxRuns<=before.maxRuns&&n.budgetUnitsPerRun<=before.budgetUnitsPerRun,'Existing node resource ceiling increased');
    }
    return {status:'ADMISSIBLE_REVISION',fromIRDigest:p.fromIRDigest,toIRDigest:p.toIRDigest,
      note:'Admission only; no consumption state or approval to execute. Persist signed revisions and revalidate at effect time.'};
  }catch(e){return {status:'DENY',reason:e.message};}
}
module.exports={SCHEMA,GRANT,REVISION,authenticateMandate,authenticateGrants,admit,verifyRevision};
