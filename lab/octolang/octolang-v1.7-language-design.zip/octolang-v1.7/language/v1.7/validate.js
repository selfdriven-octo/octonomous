'use strict';
// Independent semantic verifier does NOT need composition source (needs pinned root typed IR).
const {canonical}=require('../../src/canonical');
const {makeIR,SCHEMA,digestIR}=require('./index');
const id=/^[A-Za-z_][A-Za-z0-9_-]*$/;
function need(x,message){if(!x)throw new Error(`Invalid composition IR: ${message}`);}
const plain=x=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
function fields(x,required){need(plain(x),'expected plain object');need(Object.keys(x).length===required.length&&required.every(k=>Object.hasOwn(x,k)),'missing or unexpected field');}
function validateIR(ir,rootIR){
  fields(ir,['schema','kind','name','missionName','missionIRDigest','authority','nodes','maxDepth','worstCaseBudgetUnits','schedule']);
  need(ir.schema===SCHEMA&&ir.kind==='composition'&&id.test(ir.name),'schema/name mismatch');
  need(ir.missionName===rootIR.name,'root mission mismatch');
  need(ir.authority==='REQUIRES_EXTERNAL_SIGNED_MANDATE_AND_ROLE_GRANTS','untrusted authority assertion');
  need(Array.isArray(ir.nodes)&&ir.nodes.length>0&&ir.nodes.length<=32,'nodes invalid');
  let prev='';const parsed=[];
  for(const n of ir.nodes){
    fields(n,['name','parent','task','role','capability','effect','after','maxRuns','budgetUnitsPerRun','requiredContext','requiredProofs','producedEvidence']);
    need(typeof n.name==='string'&&id.test(n.name)&&n.name>prev,'node order/identity invalid');prev=n.name;
    need(typeof n.parent==='string'&&(n.parent==='root'||id.test(n.parent)),'parent invalid');
    need(typeof n.task==='string'&&id.test(n.task),'task invalid');
    need(typeof n.role==='string'&&id.test(n.role),'role invalid');
    need(typeof n.capability==='string','capability invalid');
    need(typeof n.effect==='string','effect invalid');
    need(Array.isArray(n.after)&&n.after.every(x=>typeof x==='string'&&id.test(x))&&n.after.every((x,i)=>i===0||n.after[i-1]<x),'after invalid');
    need(Number.isSafeInteger(n.maxRuns)&&n.maxRuns>=1&&n.maxRuns<=16,'runs invalid');
    need(Number.isSafeInteger(n.budgetUnitsPerRun)&&n.budgetUnitsPerRun>=0&&n.budgetUnitsPerRun<=1000000,'budget invalid');
    need(typeof n.requiredContext==='string'&&typeof n.producedEvidence==='string'&&Array.isArray(n.requiredProofs),'proof fields invalid');
    parsed.push({name:n.name,parent:n.parent,task:n.task,after:n.after.join(',')||'none',max_runs:String(n.maxRuns),budget:String(n.budgetUnitsPerRun)});
  }
  const candidate=makeIR({name:ir.name,mission:rootIR.name,nodes:parsed},rootIR);
  need(canonical(candidate)===canonical(ir),'declared task, ancestry, schedule, context or proof altered');
  return true;
}
function verifyIR(ir,rootIR,expectedDigest){try{validateIR(ir,rootIR);need(digestIR(ir)===expectedDigest,'digest mismatch');return {valid:true,irDigest:expectedDigest};}catch(e){return {valid:false,reason:e.message};}}
module.exports={validateIR,verifyIR};
