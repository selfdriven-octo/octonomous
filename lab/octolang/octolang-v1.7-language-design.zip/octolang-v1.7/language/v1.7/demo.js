'use strict';
// Deterministic local example of governed, NON-EXECUTABLE plan adaptation.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {signed,digest}=require('../../src/canonical');
const {compileLanguage}=require('../v1.6');
const {compileComposition,verifyComposition}=require('./index');
const {admit,verifyRevision,SCHEMA,GRANT,REVISION}=require('./authority');
const examples=path.join(__dirname,'../../examples');
function demo(){
  const missionSource=fs.readFileSync(path.join(examples,'community-proofs.octo'),'utf8');
  const source=fs.readFileSync(path.join(examples,'community-adaptive.octo'),'utf8');
  const revisionSource=fs.readFileSync(path.join(examples,'community-adaptive-revised.octo'),'utf8');
  const root=compileLanguage(missionSource);
  const original=compileComposition(source,missionSource),revised=compileComposition(revisionSource,missionSource);
  const now=Date.now();
  const governance=crypto.generateKeyPairSync('ed25519');
  const agentAuthority=crypto.generateKeyPairSync('ed25519');
  const composer=crypto.generateKeyPairSync('ed25519');
  const trust={mandateIssuers:{community_council:governance.publicKey},grantIssuers:{agent_registry:agentAuthority.publicKey},revisionProposers:{composer:composer.publicKey}};
  const mandate=signed({schema:SCHEMA,issuer:'community_council',missionIRDigest:root.irDigest,subject:'community',validFrom:now-1000,expiresAt:now+3600000,nonce:crypto.randomBytes(16).toString('hex'),allowRevision:true,maxNodes:6,maxDepth:4,maxTotalBudgetUnits:12,
    allowedTasks:root.ir.tasks.map(task=>({task:task.name,maxInstances:task.name==='find_supplier'?2:1,maxRunsPerInstance:1,maxBudgetUnitsPerRun:4}))},governance.privateKey);
  const roleGrants=root.ir.roles.map(role=>signed({schema:GRANT,issuer:'agent_registry',missionIRDigest:root.irDigest,subject:'community',agentId:`agent_${role.name}`,role:role.name,capability:role.capability,validFrom:now-1000,expiresAt:now+3600000,maxRuns:role.name==='scout'?2:1,maxBudgetUnits:8},agentAuthority.privateKey));
  const args={rootIR:root.ir,missionIRDigest:root.irDigest,signedMandate:mandate,signedGrants:roleGrants,trust,expectedSubject:'community',now};
  const originalCheck=admit({artifact:original,...args}),revisedCheck=admit({artifact:revised,...args});
  const revision=signed({schema:REVISION,issuer:'composer',fromIRDigest:original.irDigest,toIRDigest:revised.irDigest,mandateDigest:digest(mandate),sequence:1,nonce:crypto.randomBytes(16).toString('hex'),reason:'Alternative supplier research within mandate'},composer.privateKey);
  const transition=verifyRevision({oldArtifact:original,newArtifact:revised,revision,...args});
  const output={schema:'octolang.composition-demo.v1.7',original:originalCheck,revised:revisedCheck,transition,
    sourceVerified:verifyComposition(source,missionSource,original),
    originalSchedule:original.ir.schedule,revisedSchedule:revised.ir.schedule,
    note:'Demo creates ephemeral signing keys; no tool calls, governance grant provisioning or resource consumption occurs.'};
  console.log(JSON.stringify(output,null,2));
  if([originalCheck.status,revisedCheck.status,transition.status].join('|')!=='ADMISSIBLE_PROPOSAL|ADMISSIBLE_PROPOSAL|ADMISSIBLE_REVISION')process.exitCode=1;
  return output;
}
if(require.main===module)Promise.resolve().then(demo).catch(e=>{console.error(e);process.exitCode=1;});
module.exports={demo};
