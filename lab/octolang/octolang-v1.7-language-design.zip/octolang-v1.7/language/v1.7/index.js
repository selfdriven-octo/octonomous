'use strict';
// OctoLang v1.7 composition: PURE compile/propose/verify. No tools, wallet, delegation or signing here.
const crypto = require('node:crypto');
const {canonical} = require('../../src/canonical');
const {compileLanguage} = require('../v1.6');
const SCHEMA='octolang.composition-ir.v1.7';
const ARTIFACT='octolang.composition-artifact.v1.7';
const PREFIX='OctoLang Composition IR v1.7\n';
const cmp=(a,b)=>a<b?-1:a>b?1:0;
const hash=text=>crypto.createHash('sha256').update(text,'utf8').digest('hex');
const digestIR=ir=>hash(PREFIX+canonical(ir));
const id=/^[A-Za-z_][A-Za-z0-9_-]*$/;
function need(x,m){if(!x)throw new Error(m);}
function tokenize(source){
  need(typeof source==='string'&&source.length<=65536,'Composition source must be text <=65536 characters');
  const out=[];let i=0;
  while(i<source.length){
    const tail=source.slice(i);
    if(/^\s+/.test(tail)){i+=tail.match(/^\s+/)[0].length;continue;}
    if(tail.startsWith('#')||tail.startsWith('//')){const k=source.indexOf('\n',i);i=k===-1?source.length:k+1;continue;}
    if(source[i]==='{'||source[i]==='}'){out.push(source[i]);i++;continue;}
    if(source[i]==='"'){
      const match=tail.match(/^"(?:[^"\\\n\r]|\\["\\nrt])*"/);
      need(!!match,`Invalid string near position ${i}`);
      out.push(JSON.parse(match[0]));i+=match[0].length;continue;
    }
    const match=tail.match(/^[A-Za-z_][A-Za-z0-9_-]*|^(?:0|[1-9][0-9]*)/);
    need(!!match,`Unknown token near position ${i}`);out.push(match[0]);i+=match[0].length;
    need(out.length<=2000,'Too many tokens');
  }
  return out;
}
function parse(source){
  const ts=tokenize(source);let cursor=0;
  function pop(expected){const value=ts[cursor++];need(value!==undefined,'Unexpected end of composition');if(expected!==undefined)need(value===expected,`Expected ${expected}, found ${value}`);return value;}
  function ident(){const x=pop();need(id.test(x),'Expected identifier');return x;}
  pop('composition');const name=ident();pop('{');let mission=null;const nodes=[];
  while(ts[cursor]!=='}'){
    const kind=pop();if(kind==='mission'){need(mission===null,'Duplicate mission declaration');mission=ident();continue;}
    need(kind==='node',`Unknown composition declaration ${kind}`);
    const nodeName=ident();pop('{');const f={};
    while(ts[cursor]!=='}'){
      const field=pop();need(['parent','task','after','max_runs','budget'].includes(field),`Unknown node field ${field}`);
      need(!Object.hasOwn(f,field),`Duplicate field ${field}`);
      f[field]=pop();
    }
    pop('}');need(Object.keys(f).length===5,`Incomplete node ${nodeName}`);
    nodes.push({name:nodeName,...f});need(nodes.length<=32,'Too many nodes');
  }
  pop('}');need(cursor===ts.length,'Trailing composition tokens');need(mission!==null,'Missing mission');need(nodes.length>0,'No nodes');return {name,mission,nodes};
}
function normalDependencies(value){
  if(value==='none')return [];
  need(typeof value==='string','Invalid after');const xs=value.split(',').map(x=>x.trim());
  need(xs.every(x=>id.test(x)),'Invalid after identifier');need(new Set(xs).size===xs.length,'Duplicate after dependency');return xs.sort(cmp);
}
function integer(value,min,max,label){need(typeof value==='string'&&/^(0|[1-9]\d*)$/.test(value),`Invalid ${label}`);const n=Number(value);need(Number.isSafeInteger(n)&&n>=min&&n<=max,`Out-of-range ${label}`);return n;}
function orderAndDepth(nodes){
  const map=new Map(nodes.map(n=>[n.name,n]));const temp=new Set(),done=new Set(),ordered=[],depth=new Map();
  function visit(n){
    if(done.has(n.name))return;
    need(!temp.has(n.name),`Composition cycle at ${n.name}`);temp.add(n.name);
    const prereqs=[...(n.parent==='root'?[]:[n.parent]),...n.after];
    for(const key of [...new Set(prereqs)].sort(cmp)){
      need(key!==n.name,`Self-reference in ${n.name}`);need(map.has(key),`Unknown composition node ${key}`);visit(map.get(key));
    }
    const d=n.parent==='root'?1:depth.get(n.parent)+1;
    need(d<=6,`Composition nesting depth above 6 at ${n.name}`);
    depth.set(n.name,d);temp.delete(n.name);done.add(n.name);ordered.push(n.name);
  }
  for(const n of nodes)visit(n);
  return {schedule:ordered,depth};
}
function makeIR(parsed,rootIR){
  need(parsed.mission===rootIR.name,`Composition must name mission ${rootIR.name}`);
  const tasks=new Map(rootIR.tasks.map(t=>[t.name,t]));
  const byName=new Set();const nodes=parsed.nodes.map(n=>{
    need(id.test(n.name)&&!byName.has(n.name),`Invalid or duplicate node ${n.name}`);byName.add(n.name);
    need(n.parent==='root'||id.test(n.parent),`Invalid parent of ${n.name}`);
    need(tasks.has(n.task),`Undeclared root task ${n.task}`);
    const task=tasks.get(n.task);
    need(task.effect!=='UNRESOLVED_CAPABILITY',`Unresolved capability for ${n.task}`);
    return {
      name:n.name,parent:n.parent,task:n.task,role:task.role,
      capability:task.requiredCapability,effect:task.effect,
      after:normalDependencies(n.after),
      maxRuns:integer(n.max_runs,1,16,'max_runs'),
      budgetUnitsPerRun:integer(n.budget,0,1000000,'budget'),
      requiredContext:task.requiredContext,
      requiredProofs:[...task.declaredProofs],producedEvidence:task.producedEvidence
    };
  }).sort((a,b)=>cmp(a.name,b.name));
  const {schedule,depth}=orderAndDepth(nodes);
  const map=new Map(nodes.map(n=>[n.name,n]));
  // Mission task dependencies must be witnessed by earlier, reachable composition nodes.
  function ancestors(n){const names=new Set(),queue=[...(n.parent==='root'?[]:[n.parent]),...n.after];
    while(queue.length){const key=queue.pop();if(names.has(key))continue;names.add(key);const dep=map.get(key);queue.push(...(dep.parent==='root'?[]:[dep.parent]),...dep.after);}return names;
  }
  for(const n of nodes){
    const ancestorsTasks=new Set([...ancestors(n)].map(name=>map.get(name).task));
    for(const dependency of tasks.get(n.task).dependencies)need(ancestorsTasks.has(dependency),`Missing required task dependency ${dependency} before ${n.name}`);
  }
  const maxDepth=Math.max(...depth.values());
  const worstCaseBudgetUnits=nodes.reduce((n,x)=>n+x.maxRuns*x.budgetUnitsPerRun,0);
  need(Number.isSafeInteger(worstCaseBudgetUnits),'Budget overflow');
  return {schema:SCHEMA,kind:'composition',name:parsed.name,missionName:rootIR.name,
    missionIRDigest:require('../v1.6').hashIR(rootIR),
    authority:'REQUIRES_EXTERNAL_SIGNED_MANDATE_AND_ROLE_GRANTS',
    nodes,maxDepth,worstCaseBudgetUnits,schedule};
}
function compileComposition(source,missionSource){
  const root=compileLanguage(missionSource);const ir=makeIR(parse(source),root.ir);
  return {schema:ARTIFACT,compositionSourceSha256:hash(source),missionSourceSha256:hash(missionSource),
    rootIRDigest:root.irDigest,ir,irDigest:digestIR(ir)};
}
function verifyComposition(source,missionSource,artifact){
  try{
    const expected=compileComposition(source,missionSource);
    const {validateIR}=require('./validate');validateIR(artifact.ir,compileLanguage(missionSource).ir);
    need(artifact.irDigest===digestIR(artifact.ir),'Composition digest mismatch');
    need(canonical(artifact)===canonical(expected),'Source/mission/IR/digest mismatch');
    return {valid:true,irDigest:expected.irDigest};
  }catch(err){return {valid:false,reason:err.message};}
}
module.exports={SCHEMA,ARTIFACT,PREFIX,parse,makeIR,compileComposition,verifyComposition,digestIR,orderAndDepth,integer};
