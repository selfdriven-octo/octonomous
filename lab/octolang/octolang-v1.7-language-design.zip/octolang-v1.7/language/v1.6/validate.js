'use strict';
// Independent, pure structural/semantic IR checker. No parsing, no authorisation.
const {hashIR,SCHEMA} = require('./index');
const id=/^[A-Za-z_][A-Za-z0-9_-]*$/;
const strict=(condition,message)=>{if(!condition)throw new Error(`Invalid typed IR: ${message}`);};
const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
const keys=(o,required,optional=[])=>{strict(object(o),'object expected');const ks=Object.keys(o);strict(required.every(k=>Object.hasOwn(o,k))&&ks.every(k=>required.includes(k)||optional.includes(k)),'missing or unknown property');};
const string=(s,max=500)=>strict(typeof s==='string'&&s.trim().length>0&&s.length<=max,'invalid string');
const identifier=s=>{string(s,128);strict(id.test(s),'invalid identifier');};
const named=(values,max,checks)=>{
  strict(Array.isArray(values)&&values.length<=max,'invalid declaration array');
  let prior=null;for(const v of values){strict(object(v),'invalid declaration');identifier(v.name);strict(prior===null||prior<v.name,'unordered or duplicate declaration');prior=v.name;checks(v);}
  return new Map(values.map(x=>[x.name,x]));
};
const exactSortedNames=(names)=>{strict(Array.isArray(names),'names must be array');names.forEach(identifier);strict(names.every((v,i)=>i===0||names[i-1]<v),'names must be unique, lexically sorted');};
const val=(ir)=>{
  keys(ir,['schema','kind','name','goal','governance','contextRequirements','inputs','roles','constraints','capabilities','tasks','proofs','outcomes','anchors','schedule']);
  strict(ir.schema===SCHEMA&&ir.kind==='mission','wrong IR schema/kind');identifier(ir.name);string(ir.goal);
  keys(ir.governance,['onViolation','source','grantsImplied']);
  strict(ir.governance.onViolation==='DENY'&&ir.governance.source==='OUT_OF_BAND_HUMAN_REVIEW_AND_AGENT_GRANTS'&&ir.governance.grantsImplied===false,'invalid governance semantics');
  const contexts=named(ir.contextRequirements,16,c=>{keys(c,['name','claim','issuer','requiredState','freshnessMaxMs','trust']);string(c.claim,128);string(c.issuer,128);strict(c.requiredState==='VERIFIED'&&c.trust==='EXTERNALLY_VERIFIED_SIGNED_CLAIM'&&Number.isSafeInteger(c.freshnessMaxMs)&&c.freshnessMaxMs>0&&c.freshnessMaxMs<=365*86400000,'invalid context requirement');});
  strict(contexts.size>0,'no context');
  const inputs=named(ir.inputs,16,i=>{keys(i,['name','type','source','mandatory']);strict(['amount:lovelace','integer','text','boolean'].includes(i.type),'invalid type');strict(i.source==='SIGNED_OR_AUTHORISABLE_REQUEST'&&i.mandatory===true,'invalid input provenance');});
  strict(inputs.size>0,'no inputs');
  const roles=named(ir.roles,16,r=>{keys(r,['name','capability','effect','grant']);string(r.capability,128);strict(['EXTERNAL_SERVICE','LOCAL_CAPABILITY','UNRESOLVED_CAPABILITY'].includes(r.effect)&&r.grant==='OUT_OF_BAND_SIGNED_GRANT','role authority/effect invalid');});
  strict(roles.size>0,'no roles');
  const constraints=named(ir.constraints,32,c=>{strict(['MAXIMUM','REQUIRED_CONTEXT'].includes(c.kind),'invalid constraint kind');
    if(c.kind==='MAXIMUM') {keys(c,['name','kind','input','maxValue','unit']);strict(inputs.has(c.input),'unknown constrained input');strict(/^(0|[1-9]\d*)$/.test(c.maxValue),'max must be canonical non-negative integer string');const input=inputs.get(c.input);strict((input.type==='amount:lovelace'&&c.unit==='lovelace'&&BigInt(c.maxValue)<=45000000000000000n)||(input.type==='integer'&&c.unit==='count'&&BigInt(c.maxValue)<=BigInt(Number.MAX_SAFE_INTEGER)),'max unit/type/range mismatch');}
    else {keys(c,['name','kind','context']);strict(contexts.has(c.context),'unknown constrained context');}
  });void constraints;
  const caps=named(ir.capabilities,16,c=>{keys(c,['name','role','operation','serviceIdentity','disclosedFields','effect','requiredAuthority']);strict(roles.has(c.role)&&roles.get(c.role).capability===c.operation,'capability role mismatch');strict(c.effect==='EXTERNAL_SERVICE'&&c.requiredAuthority==='SIGNED_SERVICE_MANIFEST_AND_AGENT_GRANT','capability authority mismatch');strict(/^service\.[a-z][a-z0-9.]*(?:[a-z0-9])$/.test(c.operation)&&c.operation.length<=120,'invalid service capability');strict(/^[a-z0-9-]{2,48}$/.test(c.serviceIdentity),'invalid service identity');const fields=named(c.disclosedFields,8,f=>{keys(f,['name','type']);strict(inputs.has(f.name)&&f.type!=='amount:lovelace'&&['ada','integer','text','boolean'].includes(f.type),'invalid disclosed field');strict((inputs.get(f.name).type==='amount:lovelace'?'ada':inputs.get(f.name).type)===f.type,'disclosed field type mismatch');});strict(fields.size>0,'capability must disclose typed fields');});
  const byRole=new Map();for(const cap of caps.values()){strict(!byRole.has(cap.role),'duplicate role capability contract');byRole.set(cap.role,cap);}
  const builtins=new Set(['research','validate','intent.record','audit']);
  for(const role of roles.values())strict(role.effect===(byRole.has(role.name)?'EXTERNAL_SERVICE':builtins.has(role.capability)?'LOCAL_CAPABILITY':'UNRESOLVED_CAPABILITY'),'role effect contradicts manifest declaration');
  const tasks=named(ir.tasks,32,t=>{keys(t,['name','role','requiredCapability','dependencies','requiredContext','producedEvidence','effect','declaredProofs']);strict(roles.has(t.role)&&t.requiredCapability===roles.get(t.role).capability,'unknown role or capability');strict(t.effect===roles.get(t.role).effect,'task effect mismatch');exactSortedNames(t.dependencies);strict(t.dependencies.every(d=>d!==t.name),'self dependency');strict(t.requiredContext==='none'||contexts.has(t.requiredContext),'unknown context');string(t.producedEvidence,128);exactSortedNames(t.declaredProofs);});strict(tasks.size>0,'no tasks');
  for(const t of tasks.values())strict(t.dependencies.every(d=>tasks.has(d)),'unknown dependency');
  const proofs=named(ir.proofs,64,p=>{keys(p,['name','task','kind'],['serviceIdentity']);strict(tasks.has(p.task),'orphan proof');strict(['service_receipt','controller_receipt','agent_receipt'].includes(p.kind),'invalid proof kind');const target=tasks.get(p.task),cap=byRole.get(target.role);if(p.kind==='service_receipt'){strict(cap&&p.serviceIdentity===cap.serviceIdentity,'service proof identity mismatch');} else strict(!Object.hasOwn(p,'serviceIdentity'),'unexpected service on non-service proof');});
  for(const t of tasks.values()){
    const expected=[...proofs.values()].filter(p=>p.task===t.name).map(p=>p.name);
    strict(JSON.stringify(expected)===JSON.stringify(t.declaredProofs),'task proof association mismatch');
    if (caps.size>0) {strict(expected.length>0,'typed mission task missing proof');
      if(t.effect==='EXTERNAL_SERVICE')strict([...proofs.values()].some(p=>p.task===t.name&&p.kind==='service_receipt'),'missing external service receipt');
      else strict(![...proofs.values()].some(p=>p.task===t.name&&p.kind==='service_receipt'),'local task has service receipt');
    }
  }
  strict((caps.size===0&&proofs.size===0)||(caps.size>0&&proofs.size>0),'partial typed mission');
  const outcomes=named(ir.outcomes,32,o=>{keys(o,['name','task','evidence']);strict(tasks.has(o.task)&&o.evidence===tasks.get(o.task).producedEvidence,'outcome not bound to task evidence');});strict(outcomes.size>0,'no outcomes');
  const anchors=named(ir.anchors,1,a=>{keys(a,['name','backend','network','contract','phase']);strict(a.backend==='midnight'&&a.phase==='post_execution','invalid anchor backend/phase');strict(/^[a-z][a-z0-9_-]{2,39}$/.test(a.network),'invalid anchor network');strict(/^[a-zA-Z0-9_-]{8,128}$/.test(a.contract),'invalid contract');});if(anchors.size)strict(proofs.size>0,'anchor requires proofs');
  strict(Array.isArray(ir.schedule)&&ir.schedule.length===tasks.size,'schedule size mismatch');
  const sequence=[],waiting=new Map(tasks);
  while(waiting.size){const next=[...waiting.values()].filter(t=>t.dependencies.every(d=>sequence.includes(d))).sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0);strict(next.length>0,'dependency cycle');for(const t of next){sequence.push(t.name);waiting.delete(t.name);}}
  strict(JSON.stringify(sequence)===JSON.stringify(ir.schedule),'non-deterministic or altered schedule');
  return true;
};
function verifyIR(ir,expectedDigest) {
  try {val(ir);const actual=hashIR(ir);if(actual!==expectedDigest)throw new Error('IR digest mismatch');return {valid:true,irDigest:actual};}
  catch(e){return {valid:false,reason:e.message};}
}
module.exports={validateIR:val,verifyIR};
