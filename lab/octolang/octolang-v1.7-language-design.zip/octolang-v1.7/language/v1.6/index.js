'use strict';

// OctoLang formal language track v1.6. Strictly compile/analyse/verify; NEVER invokes tools,
// approves missions, provides signing keys, or starts an Octonomous runtime.
const crypto = require('node:crypto');
const { compileMission } = require('../../src/mission');
const { canonical } = require('../../src/canonical');

const SCHEMA = 'octolang.typed-ir.v1.6';
const ARTIFACT_SCHEMA = 'octolang.language-artifact.v1.6';
const HASH_PREFIX = 'OctoLang Typed IR v1.6\n';
const BUILTINS = new Set(['research', 'validate', 'intent.record', 'audit']);
const cmp = (a,b) => a < b ? -1 : a > b ? 1 : 0;
const byName = (a,b) => cmp(a.name,b.name);
const sha256 = text => crypto.createHash('sha256').update(text,'utf8').digest('hex');
const hashIR = ir => sha256(HASH_PREFIX + canonical(ir));
const sorted = xs => [...xs].sort(byName);
const safe = value => JSON.parse(canonical(value));

// Pure projection: no trust is assigned to authored status, capability or proofs.
function project(policy) {
  if (!policy || !['octolang.mission.v0.9','octolang.mission.v1.2','octolang.mission.v1.3'].includes(policy.schema)) {
    throw new Error('v1.6 supports mission sources only; legacy score remains in the original compiler');
  }
  const roleByName = new Map(policy.roles.map(r => [r.label,r]));
  const proofsByTask = new Map(policy.tasks.map(t => [t.label,[]]));
  for (const p of (policy.proofs||[])) proofsByTask.get(p.task).push(p.label);
  const caps = (policy.capabilities||[]).map(c => ({
    name:c.label, role:c.role, operation:c.name, serviceIdentity:c.service,
    disclosedFields:[...c.fields].map(x=>({name:x.name,type:x.type})).sort(byName),
    effect:'EXTERNAL_SERVICE', requiredAuthority:'SIGNED_SERVICE_MANIFEST_AND_AGENT_GRANT'
  }));
  const capabilitiesByRole = new Map(caps.map(c => [c.role,c]));
  const ir = {
    schema:SCHEMA,
    kind:'mission',
    name:policy.name,
    goal:policy.goal,
    governance:{onViolation:policy.onViolation,source:'OUT_OF_BAND_HUMAN_REVIEW_AND_AGENT_GRANTS',grantsImplied:false},
    contextRequirements:sorted(policy.contexts.map(c => ({
      name:c.label,claim:c.claim,issuer:c.issuer,requiredState:'VERIFIED',freshnessMaxMs:c.maxAgeMs,
      trust:'EXTERNALLY_VERIFIED_SIGNED_CLAIM'
    }))),
    inputs:sorted(policy.inputs.map(i => ({name:i.label,type: i.type==='ada'?'amount:lovelace':i.type,
      source:'SIGNED_OR_AUTHORISABLE_REQUEST',mandatory:true}))),
    roles:sorted(policy.roles.map(r => ({name:r.label,capability:r.capability,
      effect:capabilitiesByRole.has(r.label)?'EXTERNAL_SERVICE':BUILTINS.has(r.capability)?'LOCAL_CAPABILITY':'UNRESOLVED_CAPABILITY',
      grant:'OUT_OF_BAND_SIGNED_GRANT'}))),
    constraints:sorted(policy.constraints.map(c => c.type==='max' ? {
      name:c.label,kind:'MAXIMUM',input:c.input,maxValue:String(c.max),unit:c.unit
    } : {name:c.label,kind:'REQUIRED_CONTEXT',context:c.context})),
    capabilities:sorted(caps),
    tasks:sorted(policy.tasks.map(t => ({
      name:t.label,role:t.role,requiredCapability:roleByName.get(t.role).capability,
      dependencies:[...t.dependencies].sort(cmp),requiredContext:t.requiredContext,
      producedEvidence:t.produces,effect:capabilitiesByRole.has(t.role)?'EXTERNAL_SERVICE':BUILTINS.has(roleByName.get(t.role).capability)?'LOCAL_CAPABILITY':'UNRESOLVED_CAPABILITY',
      declaredProofs:[...proofsByTask.get(t.label)].sort(cmp)
    }))),
    proofs:sorted((policy.proofs||[]).map(p => ({name:p.label,task:p.task,kind:p.kind,
      ...(p.service?{serviceIdentity:p.service}:{})}))),
    outcomes:sorted(policy.outcomes.map(o => ({name:o.label,task:o.task,evidence:o.evidence}))),
    anchors:sorted((policy.anchors||[]).map(a => ({name:a.label,backend:a.backend,
      network:a.network,contract:a.contract,phase:a.phase}))),
    schedule:[...policy.order]
  };
  return ir;
}

function analyse(ir) {
  const warnings = [];
  const warn = (code,message,where) => warnings.push({severity:'WARNING',code,message,where});
  const usedRoles = new Set(ir.tasks.map(t=>t.role));
  const usedInputs = new Set(ir.constraints.filter(c=>c.kind==='MAXIMUM').map(c=>c.input));
  for (const c of ir.capabilities) for (const f of c.disclosedFields) usedInputs.add(f.name);
  const maxBound = new Set(ir.constraints.filter(c=>c.kind==='MAXIMUM').map(c=>c.input));
  const outcomeTasks = new Set(ir.outcomes.map(o=>o.task));
  const usedByDownstream = new Set(ir.tasks.flatMap(t=>t.dependencies));
  for (const role of ir.roles) {
    if (!usedRoles.has(role.name)) warn('OL1601',`Declared role ${role.name} has no task`, `role:${role.name}`);
    if (role.effect==='UNRESOLVED_CAPABILITY') warn('OL1607',`Capability ${role.capability} has no typed manifest; cannot infer permitted effects`, `role:${role.name}`);
  }
  for (const input of ir.inputs) {
    if (!usedInputs.has(input.name)) warn('OL1602',`Input ${input.name} has no static consumer`, `input:${input.name}`);
    if (['amount:lovelace','integer'].includes(input.type) && !maxBound.has(input.name))
      warn('OL1603',`Numeric input ${input.name} has no static maximum`, `input:${input.name}`);
  }
  for (const task of ir.tasks) {
    if (task.requiredContext==='none') warn('OL1604',`Task ${task.name} has no task-specific context requirement`, `task:${task.name}`);
    if (!outcomeTasks.has(task.name) && !usedByDownstream.has(task.name))
      warn('OL1605',`Task ${task.name} is not covered by a declared outcome or dependency`, `task:${task.name}`);
    if (task.declaredProofs.length===0) warn('OL1606',`No typed proof obligation for task ${task.name}; legacy evidence rules still apply`, `task:${task.name}`);
  }
  const covered = new Set(ir.tasks.flatMap(t=>t.declaredProofs));
  if (covered.size < ir.proofs.length) throw new Error('Internal error: orphan proof');
  return warnings.sort((a,b)=>cmp(`${a.code}:${a.where}`,`${b.code}:${b.where}`));
}

function compileLanguage(source) {
  if (typeof source !== 'string') throw new TypeError('OctoLang source must be text');
  const legacyPolicy = compileMission(source); // existing parser + type/graph checks
  const ir = project(legacyPolicy);
  const irDigest = hashIR(ir);
  return {
    schema:ARTIFACT_SCHEMA,
    sourceSha256:sha256(source),
    legacyPolicy,
    ir,
    irDigest,
    diagnostics:analyse(ir)
  };
}

function verifyArtifact(source, artifact) {
  try {
    if (!artifact || Array.isArray(artifact) || typeof artifact !== 'object') return {valid:false,reason:'Artifact must be an object'};
    // A full reference recompilation, not just comparison against a caller-supplied hash.
    const expected = compileLanguage(source);
    const { verifyIR } = require('./validate');
    const check = verifyIR(artifact.ir, artifact.irDigest);
    if (!check.valid) return check;
    if (canonical(safe(artifact)) !== canonical(expected)) return {valid:false,reason:'Source, legacy policy, IR, digest or diagnostics mismatch'};
    return {valid:true,irDigest:expected.irDigest};
  } catch(err) {return {valid:false,reason:err.message};}
}

module.exports = {SCHEMA,ARTIFACT_SCHEMA,HASH_PREFIX,compileLanguage,verifyArtifact,project,analyse,hashIR};
