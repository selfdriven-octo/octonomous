'use strict';
// Independent verification without service or controller signing keys.
// Public-key pins MUST come from a trusted, out-of-band administrator.
const fs=require('node:fs');
const crypto=require('node:crypto');
const {verifyExecutionEvidence,STATUS_EXT}=require('../mission/executor');
const {importPins}=require('../mission/bundle');
const {CapabilityRegistry}=require('./registry');
const toKey=base64=>{
  if(typeof base64!=='string'||base64.length>256||!base64.length||Buffer.from(base64,'base64').toString('base64')!==base64)throw Error('Bad public-key pin');
  const k=crypto.createPublicKey({key:Buffer.from(base64,'base64'),type:'spki',format:'der'});
  if(k.asymmetricKeyType!=='ed25519')throw Error('Unsupported public key');return k;
};
const exportPublic=key=>key.export({format:'der',type:'spki'}).toString('base64');
function verifyBundle(bundle,pins){
  const {trust,controllerPublicKey}=importPins(pins);
  const issuerKeys=Object.fromEntries(Object.entries(pins.capabilityIssuers||{}).map(([id,value])=>[id,toKey(value)]));
  const serviceKeys=Object.fromEntries(Object.entries(pins.services||{}).map(([id,value])=>[id,toKey(value)]));
  const registry=new CapabilityRegistry({manifests:bundle.capabilityManifests||[],issuerKeys,serviceKeys,
    allowLoopbackHttp:true,allowRemoteHttps:true});
  return verifyExecutionEvidence({...bundle,trust,controllerPublicKey,capabilityRegistry:registry});
}
function verifyFiles(bundlePath,pinsPath){
  return verifyBundle(JSON.parse(fs.readFileSync(bundlePath,'utf8')),JSON.parse(fs.readFileSync(pinsPath,'utf8')));
}
if(require.main===module){
  const [bundle,pins]=process.argv.slice(2);
  if(!bundle||!pins){console.error('Usage: node capabilities/verify.js <bundle.json> <independently-trusted-public-pins.json>');process.exitCode=2;}
  else try{const result=verifyFiles(bundle,pins);console.log(JSON.stringify(result,null,2));if(result.status!==STATUS_EXT)process.exitCode=1;}
  catch(err){console.error('Verification failed:',err.message);process.exitCode=1;}
}
module.exports={verifyBundle,verifyFiles,exportPublic};
