'use strict';
// OctoLang v1.1: independently signed, operator-pinned capability manifests.
// Scores cannot create endpoints, transport options or service trust anchors.
const crypto=require('node:crypto');
const net=require('node:net');
const dns=require('node:dns').promises;
const http=require('node:http');
const https=require('node:https');
const {digest,signed,verifiedSigned}=require('../src/canonical');
const CAP_SCHEMA='octolang.capability-manifest.v1';
const REQUEST_SCHEMA='octolang.capability-request.v1';
const RECEIPT_SCHEMA='octolang.capability-service-receipt.v1';
const MAX_RESPONSE=65536;
const pattern=/^[a-z][a-z0-9]*(?:\.[a-z][a-z0-9]*){1,5}$/;
const strictKeys=(obj,keys)=>obj&&typeof obj==='object'&&!Array.isArray(obj)&&Object.keys(obj).every(k=>keys.includes(k));
const isoWindow=(p,now)=>{const start=Date.parse(p?.issuedAt),end=Date.parse(p?.expiresAt);return Number.isFinite(start)&&Number.isFinite(end)&&start<=now+30000&&end>now&&end-start<=86400000;};
const toolFor=capability=>'mission.external.'+capability;
function ipPublic(ip){
  if(net.isIP(ip)===4){
    const n=ip.split('.').map(Number);const [a,b]=n;
    return !(a===0||a===10||a===127||a>=224||a===169&&b===254||a===172&&b>=16&&b<=31||a===192&&b===168||a===100&&b>=64&&b<=127||a===198&&(b===18||b===19)||a===192&&b===0||a===192&&b===88||a===198&&b===51||a===203&&b===0);
  }
  if(net.isIP(ip)===6){
    const s=ip.toLowerCase();
    // Require routable-looking unicast; mapped IPv4, ULAs, link-local and loopback disallowed.
    if(s.includes('.')||s.startsWith('::')||s.startsWith('fc')||s.startsWith('fd')||s.startsWith('fe8')||s.startsWith('fe9')||s.startsWith('fea')||s.startsWith('feb'))return false;
    const first=parseInt(s.split(':')[0],16);return Number.isFinite(first)&&first>=0x2000&&first<=0x3fff;
  }
  return false;
}
function endpointAllowed(url,{allowLoopbackHttp=false,allowRemoteHttps=false}={}){
  let u;try{u=new URL(url);}catch{return false;}
  if(u.username||u.password||u.hash||u.search||u.pathname!=='/v1/execute')return false;
  if(u.protocol==='http:'&&allowLoopbackHttp)return u.hostname==='127.0.0.1'&&Number(u.port)>0;
  if(u.protocol==='https:'&&allowRemoteHttps)return u.hostname.includes('.')&&!net.isIP(u.hostname)&&!['localhost','local','internal','test','invalid'].includes(u.hostname.split('.').at(-1));
  return false;
}
function strictManifest(entry,{issuerKeys,serviceKeys,allowLoopbackHttp,allowRemoteHttps,now=Date.now()}){
  const p=entry?.payload;
  if(!strictKeys(p,['schema','capability','missionDigest','service','issuer','endpoint','method','inputFields','maxResponseBytes','timeoutMs','issuedAt','expiresAt'])||
    p?.schema!==CAP_SCHEMA||!pattern.test(p.capability||'')||!/^([a-f0-9]{64})$/.test(p.missionDigest||'')||
    !/^[a-z0-9-]{2,48}$/.test(p.service||'')||!/^[a-z0-9-]{2,48}$/.test(p.issuer||'')||
    p.method!=='POST'||!endpointAllowed(p.endpoint,{allowLoopbackHttp,allowRemoteHttps})||
    !Array.isArray(p.inputFields)||p.inputFields.length>8||new Set(p.inputFields).size!==p.inputFields.length||
    p.inputFields.some(x=>!/^[_a-z][_a-z0-9]{0,48}$/.test(x))||
    !Number.isInteger(p.timeoutMs)||p.timeoutMs<100||p.timeoutMs>10000||
    !Number.isInteger(p.maxResponseBytes)||p.maxResponseBytes<512||p.maxResponseBytes>MAX_RESPONSE||
    !isoWindow(p,now)||!issuerKeys?.[p.issuer]||!serviceKeys?.[p.service]||
    !verifiedSigned(entry,issuerKeys[p.issuer]))throw Error('Capability manifest invalid, expired or signed by untrusted issuer');
  return p;
}
function verifyServiceResult(result,request,entry,serviceKey,now=Date.now()){
  if(!result||typeof result!=='object'||!serviceKey)return false;
  const p=result.serviceReceipt?.payload;
  if(!p||p.schema!==RECEIPT_SCHEMA||p.service!==entry.payload.service||
    p.capability!==entry.payload.capability||p.manifestDigest!==digest(entry)||
    p.requestDigest!==digest(request)||p.idempotencyKey!==request.idempotencyKey||
    p.status!=='RECORDED'||p.resultDigest!==digest(result.record)||
    typeof p.issuedAt!=='string'||!Number.isFinite(Date.parse(p.issuedAt))||
    Math.abs(Date.parse(p.issuedAt)-now)>300000||!verifiedSigned(result.serviceReceipt,serviceKey))return false;
  if(result.record?.idempotencyKey!==request.idempotencyKey||result.record?.capability!==request.capability||
    result.record?.requestDigest!==digest(request))return false;
  return true;
}
function makeRequest({mission,plan,request,step,manifest}){
  const inputs=Object.fromEntries(manifest.payload.inputFields.map(k=>[k,request.inputs[k]]));
  return {schema:REQUEST_SCHEMA,missionDigest:mission.digest,planDigest:plan.digest,requestDigest:plan.requestDigest,
    contextRoot:plan.contextRoot,task:step.label,agent:step.agent,capability:manifest.payload.capability,
    manifestDigest:digest(manifest),idempotencyKey:digest({missionDigest:mission.digest,nonce:request.nonce,task:step.label}),
    subject:request.subject,inputs};
}
function sendJson(url,value,config){
  const u=new URL(url);const body=JSON.stringify(value);const secure=u.protocol==='https:';
  return new Promise((resolve,reject)=>{
    const opts={hostname:u.hostname,port:u.port|| (secure?443:80),path:u.pathname,method:'POST',
      headers:{'content-type':'application/json','content-length':Buffer.byteLength(body),'accept':'application/json'},
      timeout:config.timeoutMs,rejectUnauthorized:true};
    const invoke=(lookup)=>{
      if(lookup)opts.lookup=(_hostname,_options,callback)=>callback(null,lookup.address,lookup.family);
      const req=(secure?https:http).request(opts,res=>{
        if(res.statusCode!==200){res.resume();reject(Error(`Capability service returned HTTP ${res.statusCode}`));return;}
        if(res.headers['content-type']?.split(';')[0].trim()!=='application/json'){res.resume();reject(Error('Unexpected capability service content type'));return;}
        let size=0;const parts=[];
        res.on('data',chunk=>{size+=chunk.length;if(size>config.maxResponseBytes){req.destroy(Error('Capability response size exceeded'));return;}parts.push(chunk);});
        res.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(parts).toString('utf8')));}catch(e){reject(e);}});
      });
      req.on('timeout',()=>req.destroy(Error('Capability request timed out')));
      req.on('error',reject);req.end(body);
    };
    if(!secure){invoke(null);return;}
    // Pin the actual DNS result used by https.request; never accept private/link-local targets.
    dns.lookup(u.hostname,{all:true}).then(addrs=>{
      if(!addrs.length||addrs.some(a=>!ipPublic(a.address)))throw Error('Capability endpoint DNS is not exclusively public');
      invoke(addrs[0]);
    }).catch(reject);
  });
}
class CapabilityRegistry {
  constructor({manifests=[],issuerKeys={},serviceKeys={},allowLoopbackHttp=false,allowRemoteHttps=false}={}){
    this.issuerKeys=issuerKeys;this.serviceKeys=serviceKeys;
    this.options={allowLoopbackHttp,allowRemoteHttps};this.entries=new Map();
    for(const item of manifests){const p=strictManifest(item,{...this.options,issuerKeys,serviceKeys});
      if(this.entries.has(p.capability))throw Error(`Duplicate capability manifest ${p.capability}`);
      this.entries.set(p.capability,item);
    }
  }
  resolve(capability,missionDigest,now=Date.now()){
    const entry=this.entries.get(capability);if(!entry)return null;
    const p=strictManifest(entry,{...this.options,issuerKeys:this.issuerKeys,serviceKeys:this.serviceKeys,now});
    if(p.missionDigest!==missionDigest)throw Error('Capability manifest mission scope mismatch');
    return {entry,tool:toolFor(capability),manifestDigest:digest(entry)};
  }
  toolNames(){return [...this.entries.keys()].map(toolFor);}
  async invoke(capability,ctx){
    const resolved=this.resolve(capability,ctx.mission.digest);
    if(!resolved||resolved.manifestDigest!==ctx.manifestDigest)throw Error('Capability manifest revoked or changed');
    const {entry}=resolved,serviceRequest=makeRequest({...ctx,manifest:entry});
    const now=Date.now();
    const authorization=signed({schema:'octolang.capability-authorization.v1',requestDigest:digest(serviceRequest),
      manifestDigest:digest(entry),issuedAt:new Date(now).toISOString(),expiresAt:new Date(now+30000).toISOString()},ctx.controllerPrivateKey);
    const result=await sendJson(entry.payload.endpoint,{request:serviceRequest,authorization},entry.payload);
    if(!verifyServiceResult(result,serviceRequest,entry,this.serviceKeys[entry.payload.service]))throw Error('Invalid service-signed receipt');
    return {ok:true,outcome:'EXTERNAL_SERVICE_RECORDED',tool:resolved.tool,task:ctx.step.label,
      capability,manifestDigest:resolved.manifestDigest,serviceRequest,authorization,serviceReceipt:result.serviceReceipt,record:result.record};
  }
  verifyExternalResult(result,{mission,plan,request,step,controllerPublicKey,now=Date.now()}){
    try{
      const resolved=this.resolve(result?.capability,mission.digest,now);
      if(!resolved||result?.ok!==true||result.outcome!=='EXTERNAL_SERVICE_RECORDED'||
         result.manifestDigest!==resolved.manifestDigest||result.tool!==resolved.tool||result.task!==step.label)return false;
      const expected=makeRequest({mission,plan,request,step,manifest:resolved.entry});
      const auth=result.authorization?.payload;
      return digest(expected)===digest(result.serviceRequest)&&auth?.schema==='octolang.capability-authorization.v1'&&
        auth.requestDigest===digest(expected)&&auth.manifestDigest===resolved.manifestDigest&&
        verifiedSigned(result.authorization,controllerPublicKey)&&
        Number.isFinite(Date.parse(auth.issuedAt))&&Date.parse(auth.issuedAt)<=now+30000&&
        Number.isFinite(Date.parse(auth.expiresAt))&&Date.parse(auth.expiresAt)>Date.parse(auth.issuedAt)&&
        Date.parse(auth.expiresAt)-Date.parse(auth.issuedAt)<=30000&&
        verifyServiceResult(result,expected,resolved.entry,this.serviceKeys[resolved.entry.payload.service],now);
    }catch{return false;}
  }
}
module.exports={CapabilityRegistry,toolFor,makeRequest,verifyServiceResult,endpointAllowed,ipPublic,CAP_SCHEMA,RECEIPT_SCHEMA};
