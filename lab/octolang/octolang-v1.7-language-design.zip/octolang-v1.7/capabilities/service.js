'use strict';
// Explicit loopback-only test service; signs service receipts and persists idempotent results.
const http=require('node:http');
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const {digest,signed,verifiedSigned}=require('../src/canonical');
const {RECEIPT_SCHEMA}=require('./registry');
function createNoteService({privateKey,controllerPublicKey,service='notes-provider',dataDir}){
  if(!privateKey||!controllerPublicKey||!dataDir)throw Error('Private key, trusted controller public key and data directory required');
  fs.mkdirSync(dataDir,{recursive:true,mode:0o700});
  const server=http.createServer(async(req,res)=>{
    const reply=(code,obj)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(obj));};
    if(req.method!=='POST'||req.url!=='/v1/execute')return reply(404,{error:'not found'});
    try{
      let bytes=0;const chunks=[];
      for await (const chunk of req){bytes+=chunk.length;if(bytes>16384)throw Error('oversized request');chunks.push(chunk);}
      const envelope=JSON.parse(Buffer.concat(chunks).toString('utf8'));
      const p=envelope?.request,auth=envelope?.authorization?.payload;
      if(!auth||auth.schema!=='octolang.capability-authorization.v1'||auth.requestDigest!==digest(p)||
        auth.manifestDigest!==p?.manifestDigest||!verifiedSigned(envelope.authorization,controllerPublicKey)||
        !Number.isFinite(Date.parse(auth.issuedAt))||Date.parse(auth.issuedAt)>Date.now()+30000||
        !Number.isFinite(Date.parse(auth.expiresAt))||Date.parse(auth.expiresAt)<=Date.now()||
        Date.parse(auth.expiresAt)-Date.parse(auth.issuedAt)>30000)return reply(403,{error:'controller authorization failed'});
      if(p?.schema!=='octolang.capability-request.v1'||p.capability!=='service.note.record'||
        !/^[a-f0-9]{64}$/.test(p.idempotencyKey||'')||!/^([a-f0-9]{64})$/.test(p.manifestDigest||'')||
        typeof p.subject!=='string'||!p.subject||!p.inputs||Object.keys(p.inputs).length!==1||
        typeof p.inputs.note!=='string'||p.inputs.note.length>500||!p.inputs.note.length)return reply(400,{error:'invalid request'});
      const file=path.join(dataDir,p.idempotencyKey+'.json');let response;
      if(fs.existsSync(file)){
        response=JSON.parse(fs.readFileSync(file,'utf8'));
        if(response.record.requestDigest!==digest(p))return reply(409,{error:'idempotency conflict'});
      }else{
        const record={idempotencyKey:p.idempotencyKey,requestDigest:digest(p),capability:p.capability,
          subject:p.subject,note:p.inputs.note,recordedAt:new Date().toISOString()};
        const serviceReceipt=signed({schema:RECEIPT_SCHEMA,service,capability:p.capability,
          manifestDigest:p.manifestDigest,requestDigest:digest(p),idempotencyKey:p.idempotencyKey,
          status:'RECORDED',resultDigest:digest(record),issuedAt:new Date().toISOString()},privateKey);
        response={record,serviceReceipt};
        try{fs.writeFileSync(file,JSON.stringify(response),{flag:'wx',mode:0o600});}
        catch(e){if(e.code!=='EEXIST')throw e;response=JSON.parse(fs.readFileSync(file,'utf8'));}
      }
      reply(200,response);
    }catch(err){reply(400,{error:err.message});}
  });
  return server;
}
module.exports={createNoteService};
