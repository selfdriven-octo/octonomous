'use strict';
const fs=require('node:fs');const path=require('node:path');const os=require('node:os');const crypto=require('node:crypto');
const {compile}=require('../src/compiler');const {signed}=require('../src/canonical');
const {template,fixtures}=require('../mission/demo');
const {CapabilityRegistry,CAP_SCHEMA}=require('./registry');
const {createNoteService}=require('./service');
const {MissionExecutionController,verifyExecutionEvidence,STATUS_EXT}=require('../mission/executor');
const {exportPins}=require('../mission/bundle');
const {verifyBundle,exportPublic}=require('./verify');
const source=template.replace('input project { type text }','input project { type text }\n  input note { type text }')
  .replace('role scout { capability "research" }','role scout { capability "service.note.record" }');
function setup({dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v1.1-')),issuerKeyPair,serviceKeyPair,controllerKeyPair,missionSource=source}={}){
  const mission=compile(missionSource);
  const issuer=issuerKeyPair||crypto.generateKeyPairSync('ed25519');
  const service=serviceKeyPair||crypto.generateKeyPairSync('ed25519');
  const controller=controllerKeyPair||crypto.generateKeyPairSync('ed25519');
  const server=createNoteService({privateKey:service.privateKey,controllerPublicKey:controller.publicKey,
    dataDir:path.join(dataDir,'service-notes')});
  async function start(){
    await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
    const endpoint=`http://127.0.0.1:${server.address().port}/v1/execute`;
    const now=Date.now();
    const manifest=signed({schema:CAP_SCHEMA,capability:'service.note.record',missionDigest:mission.digest,
      service:'notes-provider',issuer:'community-operator',endpoint,method:'POST',inputFields:['note'],
      maxResponseBytes:8192,timeoutMs:3000,issuedAt:new Date(now-1000).toISOString(),
      expiresAt:new Date(now+240000).toISOString()},issuer.privateKey);
    const registry=new CapabilityRegistry({manifests:[manifest],issuerKeys:{'community-operator':issuer.publicKey},
      serviceKeys:{'notes-provider':service.publicKey},allowLoopbackHttp:true});
    return {registry,manifest,endpoint};
  }
  return {dataDir,mission,issuer,service,controller,server,start};
}
async function demo(){
  const c=setup();let started;
  try{
    started=await c.start();
    const f=fixtures(c.mission,{inputs:{amount:'25',priority:'2',project:'Community learning',urgent:false,note:'Prepare a supplier assessment'}});
    const params={mission:c.mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
    const engine=new MissionExecutionController({dataDir:path.join(c.dataDir,'controller'),
      controllerKeyPair:c.controller,capabilityRegistry:started.registry,
      agentPrivateKeys:Object.fromEntries(Object.entries(f.agents).map(([id,k])=>[id,k.privateKey]))});
    const result=await engine.execute(params);
    if(result.status!=='COMPLETED_CAPABILITY_MISSION')throw Error(result.reason||result.status);
    const verified=verifyExecutionEvidence({...params,plan:result.plan,receipts:result.receipts,
      capabilityRegistry:started.registry,controllerPublicKey:c.controller.publicKey});
    if(verified.status!==STATUS_EXT)throw Error(verified.reason);
    const bundle={...params,trust:undefined,plan:result.plan,receipts:result.receipts,capabilityManifests:[started.manifest]};
    const pins={...exportPins(f.trust,c.controller.publicKey),capabilityIssuers:{'community-operator':exportPublic(c.issuer.publicKey)},services:{'notes-provider':exportPublic(c.service.publicKey)}};
    fs.writeFileSync(path.join(c.dataDir,'capability-bundle.json'),JSON.stringify(bundle,null,2));
    fs.writeFileSync(path.join(c.dataDir,'demo-public-pins.json'),JSON.stringify(pins,null,2));
    if(verifyBundle(bundle,pins).status!==STATUS_EXT)throw Error('Independent bundle validation failed');
    console.log(JSON.stringify({status:result.status,mission:c.mission.name,service:'loopback HTTP, separate service',
      serviceRecords:fs.readdirSync(path.join(c.dataDir,'service-notes')).length,
      signedCapabilityManifest:started.manifest.payload.capability,
      verified:verified.status,taskOrder:result.plan.steps.map(s=>s.label),
      actualEffect:'one note recorded by independently signing loopback service',payments:false,
      dataDir:c.dataDir},null,2));
    return {c,started,f,params,result,verified};
  }finally{await new Promise((resolve,reject)=>c.server.close(err=>err?reject(err):resolve()));}
}
if(require.main===module)demo().catch(err=>{console.error(err);process.exitCode=1;});
module.exports={source,setup,demo};
