'use strict';
// v1.2 deterministic capability/proof contracts. These are RESTRICTIONS on
// independently pinned signed manifests, never new permissions from an LLM.
const {digest}=require('../src/canonical');
const BUILTINS=new Set(['research','validate','intent.record','audit']);
const TYPED_SCHEMA='octolang.mission.v1.2';
function assertContracts({mission,registry,now=Date.now()}) {
  if(![TYPED_SCHEMA,'octolang.mission.v1.3'].includes(mission?.schema))return [];
  if(!Array.isArray(mission.capabilities)||!Array.isArray(mission.proofs))throw Error('Missing typed contracts');
  const checked=[];
  for(const role of mission.roles){
    if(BUILTINS.has(role.capability))continue;
    const c=mission.capabilities.filter(x=>x.role===role.label);
    if(c.length!==1||c[0].name!==role.capability)throw Error(`Missing exact contract for ${role.label}`);
    if(!registry)throw Error('External capability registry required');
    const resolved=registry.resolve(role.capability,mission.digest,now);
    if(!resolved)throw Error(`No trusted signed manifest for ${role.capability}`);
    const p=resolved.entry.payload;
    if(p.capability!==c[0].name||p.service!==c[0].service)throw Error('Declared service does not match signed manifest');
    const expected=c[0].fields.map(f=>f.name).sort();
    if(!Array.isArray(p.inputFields)||digest(expected)!==digest([...p.inputFields].sort()))
      throw Error('Typed fields differ from independently signed manifest disclosure allowlist');
    for(const f of c[0].fields){
      if(!mission.inputs.some(x=>x.label===f.name&&x.type===f.type))
        throw Error('Typed field does not match compiled input');
    }
    checked.push({role:role.label,capability:role.capability,service:p.service,manifestDigest:resolved.manifestDigest});
  }
  for(const t of mission.tasks){
    const ps=mission.proofs.filter(x=>x.task===t.label);
    if(!ps.length)throw Error(`Missing mandatory proof for ${t.label}`);
    const role=mission.roles.find(r=>r.label===t.role);
    if(!BUILTINS.has(role.capability)){
      const match=checked.find(x=>x.role===role.label);
      if(!ps.some(x=>x.kind==='service_receipt'&&x.service===match?.service))
        throw Error(`Missing exact service_receipt proof for ${t.label}`);
    }
    if(BUILTINS.has(role.capability)&&ps.some(x=>x.kind==='service_receipt'))
      throw Error('Local role cannot claim service receipt');
  }
  return checked;
}
// Called ONLY after execution receipts, tool receipts, service receipts,
// role grants and dependency chain have passed independent cryptographic validation.
function verifyTypedProofs({mission,plan,receipts}) {
  if(![TYPED_SCHEMA,'octolang.mission.v1.3'].includes(mission.schema))return [];
  return mission.proofs.map(p=>{
    const index=plan.steps.findIndex(x=>x.label===p.task);
    const item=receipts[index];
    if(index<0||!item)throw Error(`Missing evidence for typed proof ${p.label}`);
    let evidence;
    if(p.kind==='service_receipt'){
      if(item.result?.outcome!=='EXTERNAL_SERVICE_RECORDED'||
        item.result?.serviceReceipt?.payload?.service!==p.service)
        throw Error(`Wrong service for typed proof ${p.label}`);
      evidence=item.result.serviceReceipt;
    }else if(p.kind==='controller_receipt')evidence=item.effectReceipt;
    else if(p.kind==='agent_receipt')evidence=item.agentReceipt;
    else throw Error(`Unknown proof type ${p.kind}`);
    if(!evidence?.payload||!evidence.signature)throw Error(`Missing signed proof ${p.label}`);
    return {label:p.label,task:p.task,kind:p.kind,evidenceDigest:digest(evidence),
      ...(p.service?{service:p.service}:{})};
  });
}
module.exports={assertContracts,verifyTypedProofs,TYPED_SCHEMA};
