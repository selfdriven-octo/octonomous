'use strict';
/** OctoLang three-host acceptance: read-only signed evidence capture + offline verification.
 * No activation, signing of execution requests, or effect invocation. */
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const {canonical}=require('../src/canonical');
const {verifyWitness}=require('../language/v2.3/witness');
const {signatureOk}=require('../language/v2.7/governance');
const {fetchJSON}=require('../language/v2.4/remote');
const CLAIM_PREFIX='OctoLang three-host operator claim v1\n';
const GOVERNANCE_PREFIX='OctoLang v2.7 Governance Receipt\n';
const hex64=x=>typeof x==='string'&&/^[0-9a-f]{64}$/.test(x);
const safeString=x=>typeof x==='string'&&x.length>0&&x.length<=128&&!/[\r\n\0]/.test(x);
const assert=(condition,reason)=>{if(!condition)throw Error(reason);};
const read=p=>fs.readFileSync(p);
const publicPEM=key=>crypto.createPublicKey(key).export({format:'pem',type:'spki'}).toString();
const fingerprint=key=>crypto.createHash('sha256').update(crypto.createPublicKey(key).export({type:'spki',format:'der'})).digest('hex');
function issueClaim(c,{now=Date.now()}={}){
  assert(['execution','governance','witness'].includes(c.role),'invalid role');
  assert(safeString(c.deploymentId)&&safeString(c.adminDomain)&&safeString(c.hostLabel),'invalid deployment, operator domain or host label');
  assert(hex64(c.scoreDigest),'invalid score digest');
  const ttl=c.validMinutes??60;
  assert(Number.isInteger(ttl)&&ttl>=1&&ttl<=1440,'role claim TTL must be 1–1440 minutes');
  const key=read(c.signingPrivateKey),pub=publicPEM(read(c.signingPublicKey));
  assert(publicPEM(key)===pub,'private/public signing key mismatch');
  const payload={schema:'octolang.threehost-role-claim.v1',deploymentId:c.deploymentId,role:c.role,
    scoreDigest:c.scoreDigest,adminDomain:c.adminDomain,hostLabel:c.hostLabel,
    signingPublicKey:pub,signingKeyFingerprint:fingerprint(pub),
    issuedAt:new Date(now).toISOString(),expiresAt:new Date(now+ttl*60000).toISOString(),nonce:crypto.randomBytes(16).toString('hex')};
  return {payload,signature:crypto.sign(null,Buffer.from(CLAIM_PREFIX+canonical(payload)),key).toString('base64')};
}
function verifyClaim(c,{deploymentId,scoreDigest,expectedRole,pinnedPublicKey,now=Date.now()}={}){
  assert(c&&c.payload&&typeof c.signature==='string','malformed role claim');
  const p=c.payload;
  assert(p.schema==='octolang.threehost-role-claim.v1'&&p.role===expectedRole,'role claim type mismatch');
  assert(p.deploymentId===deploymentId&&p.scoreDigest===scoreDigest,'role claim scope mismatch');
  assert(safeString(p.adminDomain)&&safeString(p.hostLabel),'role claim attribution missing');
  assert(typeof p.nonce==='string'&&/^[a-f0-9]{32}$/.test(p.nonce),'role claim nonce invalid');
  const issued=Date.parse(p.issuedAt),expires=Date.parse(p.expiresAt);
  assert(Number.isFinite(issued)&&Number.isFinite(expires)&&expires>issued&&expires-issued<=86400000&&issued<=now+30000&&expires>now,
    'role claim expired or future-dated');
  assert(publicPEM(p.signingPublicKey)===publicPEM(pinnedPublicKey)&&fingerprint(pinnedPublicKey)===p.signingKeyFingerprint,'untrusted signing key');
  const sig=Buffer.from(c.signature,'base64');
  assert(sig.length===64&&sig.toString('base64')===c.signature&&crypto.verify(null,Buffer.from(CLAIM_PREFIX+canonical(p)),pinnedPublicKey,sig),
    'role claim signature invalid');
  return {role:p.role,adminDomain:p.adminDomain,hostLabel:p.hostLabel,signingKeyFingerprint:p.signingKeyFingerprint};
}
function validateClaims({claims,trust,deploymentId,scoreDigest,now=Date.now()}){
  assert(claims&&typeof claims==='object'&&trust&&typeof trust==='object','claims/trust required');
  const ordered=['execution','governance','witness'];
  const checked=ordered.map(role=>verifyClaim(claims[role],{deploymentId,scoreDigest,expectedRole:role,pinnedPublicKey:trust[role],now}));
  assert(new Set(checked.map(x=>x.signingKeyFingerprint)).size===3,'three distinct signing identities required');
  assert(new Set(checked.map(x=>x.adminDomain)).size===3,'different declared administrator domains required');
  assert(new Set(checked.map(x=>x.hostLabel)).size===3,'different declared host labels required');
  return {valid:true,roles:checked,physicalSeparationVerified:false,remark:'Administrative domains and hosts are self-attested; independent inspection required'};
}
function witnessStatusFromRecords(records,publicKey){
  assert(typeof records==='string'&&Buffer.byteLength(records,'utf8')<=12*1024*1024,'invalid/oversized witness history');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-acceptance-'));
  try{
    if(records)fs.writeFileSync(path.join(dir,'checkpoints.jsonl'),records,{mode:0o600});
    const result=verifyWitness({directory:dir,publicKey});
    assert(result.valid,result.reason||'witness record verification failed');
    return {sequence:result.sequence,head:result.head,scoreDigest:result.snapshot?.scoreDigest||null};
  }finally{fs.rmSync(dir,{force:true,recursive:true});}
}
function verifyEvidence(e,trust,{previous=null,now=Date.now(),maxAgeMinutes=30}={}){
  assert(e?.schema==='octolang.threehost-evidence.v1'&&safeString(e.deploymentId)&&hex64(e.scoreDigest),'invalid evidence schema');
  assert(Number.isInteger(maxAgeMinutes)&&maxAgeMinutes>0&&maxAgeMinutes<=10080,'invalid maxAgeMinutes');
  assert(safeString(trust?.deploymentId)&&trust.deploymentId===e.deploymentId&&trust.scoreDigest===e.scoreDigest,'wrong trust scope');
  const when=Date.parse(e.observedAt);
  assert(Number.isFinite(when)&&when<=now+30000&&when>=now-maxAgeMinutes*60000,'observation too old or future-dated');
  const gov=e.governanceResponse;
  assert(gov?.payload?.schema==='octolang.governance-status.v2.7'&&gov.payload.scoreDigest===e.scoreDigest&&
    Number.isSafeInteger(gov.payload.sequence)&&gov.payload.sequence>=0,'governance status schema mismatch');
  assert(signatureOk(gov.payload,gov.signature,read(trust.governance.governorPublicKey),GOVERNANCE_PREFIX),'governance receipt signature invalid');
  const wh=e.witnessResponse;
  assert(wh?.schema==='octolang.witness-history.v2.4','witness response schema mismatch');
  const w=witnessStatusFromRecords(wh.records,read(trust.witness.witnessPublicKey));
  if(w.sequence>0)assert(w.scoreDigest===e.scoreDigest,'witness score mismatched');
  const summary={schema:'octolang.threehost-acceptance-summary.v1',deploymentId:e.deploymentId,scoreDigest:e.scoreDigest,
    observedAt:e.observedAt,governance:{sequence:gov.payload.sequence,head:gov.payload.lastHead,verified:true},
    witness:{sequence:w.sequence,head:w.head,verified:true},
    witnessedHistoryPresent:w.sequence>0,
    effectVerified:false, // A status probe cannot establish execution of an underlying effect.
    physicalSeparationVerified:false};
  if(previous){
    assert(previous.schema===e.schema&&previous.deploymentId===e.deploymentId&&previous.scoreDigest===e.scoreDigest,'previous observation scope mismatch');
    const old=verifyEvidence(previous,trust,{now:Date.parse(e.observedAt),maxAgeMinutes:10080});
    assert(old.governance.sequence<=summary.governance.sequence,'governance sequence rollback');
    if(old.governance.sequence===summary.governance.sequence)assert(old.governance.head===summary.governance.head,'governance head fork');
    assert(e.witnessResponse.records.startsWith(previous.witnessResponse.records),'witness journal rollback/fork');
    assert(old.witness.sequence<=summary.witness.sequence,'witness sequence rollback');
    summary.previousMonotonic=true;
  }
  return summary;
}
async function probe(config,{now=Date.now()}={}){
  assert(safeString(config.deploymentId)&&hex64(config.scoreDigest),'deploymentId and scoreDigest required');
  for(const role of ['governance','witness']){
    const c=config[role];assert(c&&c.url&&c.serverFingerprint&&c.clientCert&&c.clientKey&&c.ca,'incomplete '+role+' connection');
  }
  const fetch=async c=>fetchJSON({url:new URL('v1/status',c.url).toString(),cert:read(c.clientCert),key:read(c.clientKey),
    ca:read(c.ca),pinnedServerFingerprint:c.serverFingerprint,timeoutMs:7000});
  const [governanceResponse,witnessResponse]=await Promise.all([fetch(config.governance),fetch(config.witness)]);
  const evidence={schema:'octolang.threehost-evidence.v1',deploymentId:config.deploymentId,scoreDigest:config.scoreDigest,
    observedAt:new Date(now).toISOString(),governanceResponse,witnessResponse};
  return {evidence,summary:verifyEvidence(evidence,config,{now})};
}
function writePrivateJson(p,value){
  const dest=path.resolve(p);fs.mkdirSync(path.dirname(dest),{recursive:true,mode:0o700});
  const data=JSON.stringify(value,null,2)+'\n';
  const fd=fs.openSync(dest,'wx',0o600);
  try{fs.writeSync(fd,data);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
  return dest;
}
module.exports={issueClaim,verifyClaim,validateClaims,verifyEvidence,probe,writePrivateJson,fingerprint};
