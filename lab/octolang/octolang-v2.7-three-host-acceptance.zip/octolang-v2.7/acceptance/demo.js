'use strict';
/** Rehearsal on one physical machine; NEVER reports three-host separation as tested. */
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {setupPilot}=require('../language/v2.7/pilot');
const {probe,verifyEvidence,writePrivateJson}=require('./core');
async function main(){const p=await setupPilot();
 try{
  const dir=path.join(p.base,'acceptance'),gHome=path.join(p.base,'governance-host');
  fs.mkdirSync(dir,{recursive:true,mode:0o700});
  const witnessKey=path.join(dir,'witness-public.pem');fs.writeFileSync(witnessKey,p.remote.witnessPublicKey,{mode:0o600});
  const c={deploymentId:'localhost-acceptance-rehearsal',scoreDigest:p.score.irDigest,
   governance:{url:p.governance.url,clientCert:path.join(gHome,'pki','client.crt'),clientKey:path.join(gHome,'pki','client.key'),
     ca:path.join(gHome,'pki','ca.crt'),serverFingerprint:p.governance.pin,governorPublicKey:path.join(gHome,'governor-public.pem')},
   witness:{url:p.remote.url,clientCert:p.remote.pki.client.cert,clientKey:p.remote.pki.client.key,
     ca:p.remote.pki.ca,serverFingerprint:p.remote.pki.server.digest,witnessPublicKey:witnessKey}};
  const before=await probe(c);writePrivateJson(path.join(dir,'before.json'),before.evidence);
  await p.controller.execute({...p.decision,missionParams:p.missionParams});
  const after=await probe(c);writePrivateJson(path.join(dir,'after.json'),after.evidence);
  const summary=verifyEvidence(after.evidence,c,{previous:before.evidence});
  const effects=fs.readdirSync(path.join(p.ledgerDirectory,'effects')).length;
  if(effects!==1||!summary.previousMonotonic||!summary.witnessedHistoryPresent)throw Error('acceptance rehearsal invariant violated');
  console.log(JSON.stringify({status:'LOCAL_REHEARSAL_ONLY',independentlyOperatedPhysicalHostsVerified:false,
    signaturesAndMonotonicHistoryVerified:true,effects,governance:summary.governance,witness:summary.witness,
    safetyScope:'read-only acceptance probes; one existing bounded local effect; no payments'},null,2));
  return summary;
 }finally{await p.close();}}
if(require.main===module)main().catch(e=>{console.error(e.stack);process.exitCode=1;});
module.exports={main};
