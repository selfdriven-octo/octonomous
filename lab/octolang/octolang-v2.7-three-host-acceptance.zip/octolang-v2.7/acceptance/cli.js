#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {issueClaim,validateClaims,verifyEvidence,probe,writePrivateJson}=require('./core');
const readJson=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const usage=()=>{throw Error('Usage: node acceptance/cli.js claim ISSUE_CONFIG OUT.json | claims VERIFY_CONFIG | probe CONNECTIVITY_CONFIG OUT.json [PREVIOUS.json] | verify CONNECTIVITY_CONFIG EVIDENCE.json [PREVIOUS.json]');};
(async()=>{
  const [command,a,b,c]=process.argv.slice(2);
  if(command==='claim'){
    if(!a||!b)usage();const claim=issueClaim(readJson(a));writePrivateJson(b,claim);
    console.log(JSON.stringify({issued:true,role:claim.payload.role,keyFingerprint:claim.payload.signingKeyFingerprint,output:path.resolve(b)},null,2));
  }else if(command==='claims'){
    if(!a)usage();const cfg=readJson(a);
    const claims=Object.fromEntries(['execution','governance','witness'].map(r=>[r,readJson(cfg.claims[r])]));
    const trust=Object.fromEntries(['execution','governance','witness'].map(r=>[r,fs.readFileSync(cfg.pinnedPublicKeys[r])]));
    console.log(JSON.stringify(validateClaims({claims,trust,deploymentId:cfg.deploymentId,scoreDigest:cfg.scoreDigest}),null,2));
  }else if(command==='probe'){
    if(!a||!b)usage();const cfg=readJson(a),r=await probe(cfg);
    const previous=c?readJson(c):null;
    const summary=verifyEvidence(r.evidence,cfg,{previous});
    writePrivateJson(b,r.evidence);console.log(JSON.stringify({saved:path.resolve(b),...summary},null,2));
  }else if(command==='verify'){
    if(!a||!b)usage();const result=verifyEvidence(readJson(b),readJson(a),{previous:c?readJson(c):null});
    console.log(JSON.stringify(result,null,2));
  }else usage();
})().catch(e=>{console.error('Acceptance failed:',e.message);process.exitCode=1;});
