# OctoLang v2.7 — Three-host operational acceptance kit

**Scope:** independently administered execution (A), governance (B), witness (C).
**Status:** acceptance tooling passed against three *separate localhost processes* only. This kit does **not** assert deployment on three physical hosts, operator independence, hardware-backed keys, full distributed transaction correctness or real-world effects.

The tools in `acceptance/` do not send governance activation or witness-attestation requests. `probe` calls each service's authenticated read-only `/v1/status` endpoint. The existing `sovereign:demo` performs the only local effect: one bounded intent record. No payment or unrestricted agent capability is enabled.

## Starting with the known-good rehearsal (one machine)

```bash
node --version     # >= 22
openssl version
npm run threehost:test
npm run threehost:demo
npm run sovereign:test
```

## 1. Provision independent trust domains

Use **three separate machines or VMs under different administrators / cloud accounts**, independent storage/backup and independently generated Ed25519 identities. A separate process on the same host is **not** separation. The governance and witness private signing keys MUST remain on B and C respectively. Provision mTLS with distinct CAs or certificate authorities managed by each operator. Pin both TLS certificate and Ed25519 signer identities, comparing fingerprints using an independently authenticated channel. Never copy private keys into a shared package or commit them to source control.

See `docs/SOVEREIGN-PILOT-v2.7.md` if present, or the supplied `octolang-v2.7-deployment-guide.md`, for existing service-specific setup. In particular, v2.7's execution host wiring is **source reference code**, not a turnkey independent-host executable. Implement/validate that wiring on A before claiming end-to-end three-host acceptance.

**Sensitive pilot limitations:** The `testPki()` helper uses short-lived test certificates with unencrypted test keys. Do not reuse them as production identities. The reference service and journal are not Internet-hardened. Use a private, authenticated network and scoped firewall rules; do not expose the services directly to the public Internet.

## 2. Signed role claims (on each host)

Each host signs a role statement with **its own existing Ed25519 key**. Create a JSON config using `acceptance/examples/role-claim.example.json` and issue:

```bash
node acceptance/cli.js claim /secure/role-claim-config.json /secure/claims/role.json
```

Set `role` to `execution` on A (controller signing key), `governance` on B (governor signing key), and `witness` on C (witness signing key). The `adminDomain` and `hostLabel` fields are operator assertions, **not cryptographically verified host ownership**. Files contain public-key identity, score digest, expiry and Ed25519 signature; do **not** copy private-key files to the verifier. Trust pins must be enrolled by a human via authenticated out-of-band channels.

On the auditing machine, gather the three *signed claim files* and three *public keys*, then set `acceptance/examples/claims-verify.example.json` to point at them:

```bash
node acceptance/cli.js claims /secure/claims-verify.json
```

This checks signature, exact role, score scope, expiry, three distinct signing keys, and three distinct *declared* administration domains. It does not prove physical separation. Explicitly inspect the cloud account IDs, device ownership, backup access, IAM and custody procedures separately.

## 3. Read-only governance/witness probe from A or independent auditor

Start B (`language/v2.7/service.js`) and C (`language/v2.4/service.js`) according to the v2.7 deployment guide. Verify the configured mTLS server and client certificate pins out of band, then create a **private**, read-only connectivity config from `acceptance/examples/connectivity.example.json`. It contains certificate/private-key *file paths* for the client TLS identity, not raw key contents.

```bash
node acceptance/cli.js probe /secure/connectivity.json /secure/observation-before.json
node acceptance/cli.js verify /secure/connectivity.json /secure/observation-before.json
```

The verifier performs: TLS peer validation and SHA-256 certificate pinning at retrieval, governance Ed25519 receipt verification, signed witness journal-chain verification, and exact score binding. Output is restricted to mode `0600` and will not overwrite existing reports. **Keep observation files private**: witness history and identifiers may be sensitive. The verifier's later offline check verifies signed contents; it cannot retroactively verify the original TLS channel.

At this point, capture all three host configurations, service versions, public-key pins and a separately signed operator acceptance record. Avoid secrets and personally identifying data in reports.

## 4. Run one bounded effect under the approved score

On the execution host, use the established, explicitly approved v2.7 controller wiring (`language/v2.7/pilot.js`) but point the governance and witness clients to B and C, with their real independent keys. The existing local demo does **not** establish this remote wiring automatically. Before running, a human reviewer should confirm this is a non-financial intent record with exactly one idempotency key. **Do not run a payment, purchase or unrestricted tool.**

After the bounded effect, collect a second independent observation:

```bash
node acceptance/cli.js probe /secure/connectivity.json /secure/observation-after.json /secure/observation-before.json
node acceptance/cli.js verify /secure/connectivity.json /secure/observation-after.json /secure/observation-before.json
```

The second check detects a decrease in the governance signed sequence, a changed head at the same sequence, and any truncated/forked witnessed journal. This is **monotonic evidence checking, not distributed consensus**. It does not guarantee the entire execution is valid: independently audit the controller ledger, reservation, VCC decision, signed START/COMPLETE records and the single actual effect (v2.7 verifier). Never count signatures alone as proof of a physical effect.

## 5. Operational fault-injection matrix (manual, each scenario from a fresh deployment/state)

| Scenario | When | Required acceptance result |
|---|---|---|
| B offline | Before `PRE_EFFECT` | Deny effect; retain uncertain reservation; no automatic replay |
| C offline | Before signed `START` | No effect may occur |
| C disappears after local effect | Before completion acknowledgment | Require v2.5 evidence-only reconciliation; exactly one local effect |
| Restore A to older journal+seal | After witnessed higher checkpoint | B/C refuse conflicting history |
| Restore one witness checkpoint | After later valid checkpoint | Independent observer catches rollback against retained prior observation |
| Rotate TLS server cert without re-pinning | Before probe | Connection rejected; separately approved pin migration required |
| Forged governance claim | Before activation | Signature/pin rejected |
| Restart B and C | After successful checkpoint | Sequences and signed histories remain monotonic |
| Compromise two trust domains | Threat analysis, not automated test | Declare *not solved*; do not assert safe under correlated compromise |

**Important:** Do not kill a process during a privileged real-world action as an informal test. Use isolated snapshots and reversible, non-financial capabilities only. Retain `before` and `after` evidence under separate, independently controlled storage.

## 6. Exit criteria

- [ ] Three separately administered machines/cloud accounts verified by human reviewers
- [ ] Signing private keys never leave respective hosts; backup access independently controlled
- [ ] Distinct, pinned TLS and Ed25519 credentials; pin rotation rehearsed
- [ ] Exact score, mission approval and activation signatures checked at each host
- [ ] Both read-only signed-history probes pass across the actual network
- [ ] Single bounded effect independently observed and audited; no duplicate invocation
- [ ] Partition, crash/restart and rollback tests pass without authority escalation
- [ ] Independent governance and witness checkpoint durability confirmed
- [ ] Full evidence bundle reviewed, hashed and preserved in separate storage
- [ ] No open HIGH-severity findings within this pilot's stated threat model

Until every applicable item passes, the status is **NOT YET ACCEPTED — MULTI-HOST FIELD TEST OUTSTANDING**.

## Trust-model caveats

1. The signed role claims attest to what operators declared. They don't prove geographical location, hardware custody, independent administration or objectively correct outcomes.
2. Signed governance `GET /v1/status` does not include a caller-supplied nonce; freshness relies on the current mutually authenticated connection and retained earlier observations. A compromised trusted endpoint might replay signed status. Only a protocol-level challenge response can strengthen this.
3. Witness history shows what the controller reported and what the remote witness signed. A witness doesn't independently inspect a physical-world effect.
4. A coordinated rollback/compromise of execution, governance **and** witness trust domains is outside the supported safety guarantee.
5. The pilot lacks full production key rotation, redundancy, operator incident handling and multi-admin custody reviews.
6. Do not turn these tests into claims of formal verification or certified security for the entire Octonomous stack.
