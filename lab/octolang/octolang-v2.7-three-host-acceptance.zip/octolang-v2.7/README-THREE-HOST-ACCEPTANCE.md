# OctoLang v2.7 — Three-host acceptance supplement

This release includes the complete v2.7 reference prototype plus **read-only verification tools** for deployment on independent execution, governance and witness hosts.

## Quick local rehearsal

```bash
npm run threehost:test
npm run threehost:demo
```

## At a real site

Read `docs/THREE-HOST-ACCEPTANCE.md` and the existing `docs/SOVEREIGN-PILOT-v2.7.md` before attempting deployment.

From an auditing host with approved mTLS credentials and out-of-band enrolled public-key pins:

```bash
node acceptance/cli.js probe /secure/connectivity.json /secure/observation-before.json
node acceptance/cli.js verify /secure/connectivity.json /secure/observation-before.json
```

After an independently authorised, bounded action:

```bash
node acceptance/cli.js probe /secure/connectivity.json /secure/observation-after.json /secure/observation-before.json
```

Use `node acceptance/cli.js claim` on each host to issue local signed role declarations and `claims` to independently verify them. The example JSON is in `acceptance/examples/`. Keep all reports private.

## Trust scope

No three-host production deployment has been performed. Signed state history is not proof of the physical action. Never expose these research endpoints publicly or enable funds/high-consequence tools. See `ACCEPTANCE-STATUS-THREE-HOST.md` for actual test evidence and remaining work.
