# OctoLang v2.7 Three-Host Acceptance — 23 October 2026

**Release type:** operational acceptance support for v2.7, **not** a new language version.

## Confirmed locally

- `npm run threehost:test`: **7/7** new acceptance tests passed.
- `npm run sovereign:test`: **16/16** existing v2.7 tests passed.
- `npm run safety:test`: **19/19** existing v2.6 safety tests passed.
- `npm run threehost:demo`: three local processes, distinct signing identities, pinned mTLS, one authorised local intent effect, independently signed governance/witness histories and monotonic evidence comparison passed.
- No payment, ADA transfer, external service action, or unrestricted capability occurred.

**Total tests invoked this acceptance run:** 42/42. The entire inherited 380-test suite was **not** re-run in this release; previous v2.7 full-suite results are historical, not new validation.

## Not accepted / field validation outstanding

- No test across three separately administered physical machines was performed.
- Real remote execution-host wiring remains a manual integration task. v2.7's pilot harness still provisions other services on the same machine by default.
- Operator declarations about distinct administrative domains cannot independently establish custody or physical separation.
- Existing governance status endpoint does not sign a caller nonce, so its signature alone is not a proof of response freshness; the kit combines pinned mTLS with sequential observations.
- Remote witness attests to signed controller-reported state, not a direct observation of a physical outcome.
- No real cross-network partition, long-term key-rotation, correlated compromise, independent durable backup or multi-cloud crash-consistency validation was performed.

## Current acceptance determination

**NOT YET ACCEPTED — REAL THREE-HOST VALIDATION REQUIRED**.

Follow `docs/THREE-HOST-ACCEPTANCE.md` and capture independently approved operator evidence on each host. Only declare a deployed pilot accepted after the described controls, failure injections and independent reviews complete.
