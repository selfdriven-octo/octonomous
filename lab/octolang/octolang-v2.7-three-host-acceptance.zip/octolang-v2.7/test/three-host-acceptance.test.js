'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {issueClaim,validateClaims,verifyEvidence,probe,writePrivateJson}=require('../acceptance/core');
const {setupPilot}=require('../language/v2.7/pilot');
const {fetchJSON}=require('../language/v2.4/remote');
const {compileScore}=require('../language/v2.1');
const scoreDigest=compileScore(fs.readFileSync(path.join(__dirname,'../community-score.octo'),'utf8')).irDigest;
function identities(){
 const home=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-acceptance-keys-'));
 const names=['execution','governance','witness'],key={};
 for(const name of names){const k=crypto.generateKeyPairSync('ed25519'),priv=path.join(home,name+'-private.pem'),pub=path.join(home,name+'-public.pem');
  fs.writeFileSync(priv,k.privateKey.export({format:'pem',type:'pkcs8'}),{mode:0o600});
  fs.writeFileSync(pub,k.publicKey.export({format:'pem',type:'spki'}),{mode:0o600});key[name]={priv,pub};}
 return {home,key,close:()=>fs.rmSync(home,{recursive:true,force:true})};
}
function claimFixture(){const keys=identities(),claims={},trust={};
 for(const [i,role] of ['execution','governance','witness'].entries()){
  const files=keys.key[role];trust[role]=fs.readFileSync(files.pub);
  claims[role]=issueClaim({deploymentId:'pilot1',role,scoreDigest,adminDomain:'admin-'+i,hostLabel:'host-'+i,
    signingPrivateKey:files.priv,signingPublicKey:files.pub});}
 return {...keys,claims,trust,verify:()=>validateClaims({claims,trust,deploymentId:'pilot1',scoreDigest})};
}
test('three independently signed role claims verify without disclosing private keys',()=>{
 const f=claimFixture();try{const result=f.verify();assert.equal(result.valid,true);
  assert.equal(result.physicalSeparationVerified,false);
  for(const c of Object.values(f.claims))assert.equal(JSON.stringify(c).includes('PRIVATE KEY'),false);
 }finally{f.close();}
});
test('tampered claim and wrong role rejected',()=>{const f=claimFixture();try{
  f.claims.governance.payload.adminDomain='attacker';assert.throws(()=>f.verify(),/signature/);
 }finally{f.close();}
});
test('same key and same administrator domains rejected',()=>{const f=claimFixture();try{
  f.claims.governance=f.claims.execution;assert.throws(()=>f.verify(),/role claim type mismatch/);
 }finally{f.close();}
});
test('expired claim rejected',()=>{const f=claimFixture();try{
 const claim=f.claims.execution;
 assert.throws(()=>validateClaims({claims:f.claims,trust:f.trust,deploymentId:'pilot1',scoreDigest,now:Date.parse(claim.payload.expiresAt)+1}),/expired/);
 }finally{f.close();}
});
test('claim issue rejects mismatched signing pair',()=>{const f=identities();try{
  assert.throws(()=>issueClaim({deploymentId:'p',role:'execution',scoreDigest,adminDomain:'a',hostLabel:'h',signingPrivateKey:f.key.execution.priv,
    signingPublicKey:f.key.governance.pub}),/mismatch/);
 }finally{f.close();}
});
test('private result files use exclusive creation with restrictive mode',()=>{const home=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-acceptance-output-'));
 try{const dest=path.join(home,'report.json');writePrivateJson(dest,{ok:true});assert.equal(fs.statSync(dest).mode&0o777,0o600);
  assert.throws(()=>writePrivateJson(dest,{ok:false}),/EEXIST/);
 }finally{fs.rmSync(home,{recursive:true,force:true});}
});
test('read-only probe verifies live independent governance and witness signatures',async()=>{
 const f=await setupPilot();
 try{
  const gHome=path.join(f.base,'governance-host','pki');
  const config={deploymentId:'acceptance-demo',scoreDigest:f.score.irDigest,
    governance:{url:f.governance.url,clientCert:path.join(gHome,'client.crt'),clientKey:path.join(gHome,'client.key'),ca:path.join(gHome,'ca.crt'),
      serverFingerprint:f.governance.pin,governorPublicKey:path.join(f.base,'governance-host','governor-public.pem')},
    witness:{url:f.remote.url,clientCert:f.remote.pki.client.cert,clientKey:f.remote.pki.client.key,ca:f.remote.pki.ca,
      serverFingerprint:f.remote.pki.server.digest,witnessPublicKey:path.join(f.base,'witness-for-acceptance.pem')}
  };
  fs.writeFileSync(config.witness.witnessPublicKey,f.remote.witnessPublicKey,{mode:0o600});
  let first=await probe(config);assert.equal(first.summary.governance.verified,true);
  assert.equal(first.summary.witness.sequence,1);
  await f.controller.execute({...f.decision,missionParams:f.missionParams});
  let after=await probe(config);
  assert.equal(after.summary.witness.sequence,3);
  assert.equal(after.summary.governance.sequence,2);
  assert.equal(verifyEvidence(after.evidence,config,{previous:first.evidence}).previousMonotonic,true);
  const altered=structuredClone(after.evidence);
  altered.governanceResponse.payload.sequence=999;
  assert.throws(()=>verifyEvidence(altered,config),/signature invalid/);
  const alteredHistory=structuredClone(after.evidence);
  alteredHistory.witnessResponse.records+='{"altered":true}\n';
  assert.throws(()=>verifyEvidence(alteredHistory,config),/verification failed|invalid|signature|Unexpected|schema|JSON|bad signed witness checkpoint/);
  const oldGov=structuredClone(after.evidence);
  oldGov.governanceResponse=first.evidence.governanceResponse;
  assert.throws(()=>verifyEvidence(oldGov,config,{previous:after.evidence}),/rollback/);
  const oldWitness=structuredClone(after.evidence);
  oldWitness.witnessResponse=first.evidence.witnessResponse;
  assert.throws(()=>verifyEvidence(oldWitness,config,{previous:after.evidence}),/rollback|fork/);
  const wrongPin={...config,governance:{...config.governance,serverFingerprint:'0'.repeat(64)}};
  await assert.rejects(probe(wrongPin),/pin mismatch/);
  assert.equal(fs.readdirSync(path.join(f.ledgerDirectory,'effects')).length,1);
 }finally{await f.close();}
});
