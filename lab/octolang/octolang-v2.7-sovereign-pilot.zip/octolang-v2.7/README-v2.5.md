# OctoLang v2.5 — Distributed Recovery and Reconciliation

The v2.5 increment adds an **evidence-based recovery coordinator** to the v2.4 remote-witness execution system. It keeps all prior OctoLang language grammars, signed mandates, activation gates and Midnight integration scaffolding.

## New modules

- `language/v2.5/reconcile.js` — independent case inspection, signed observer/governance approvals, recovery coordination, signed reconciliation journal and offline audit.
- `language/v2.5/demo.js` — loss-of-completion recovery, no effect replay.
- `bin/octolang-recovery.js` — read-only, public-key-only inspect/audit CLI.
- `test/language-v2.5.test.js` — recovery and adversarial coverage.
- `docs/RECOVERY-v2.5.md` — threat model, trust domains, classifications, failure modes and operations guide.

## Quick start

```sh
node --version       # >= 22
npm run recovery:demo
npm run recovery:test
npm run test:isolated
```

Older demos remain available: `npm run remote:demo`, `npm run score:check`, `npm run activation:execute-demo` and `npm run studio`.

## Tested safety boundary

Only an *already existing, signed and locally confirmed COMPLETE* can be witnessed later. If an action is ambiguous, it stays under an explicit `HOLD`. The controller never repeats it or refunds reservations during reconciliation. Only the bounded local `intent.record` effect is exercised by the demo.

**Research prototype:** services run on localhost in independent processes, not yet independently administered physical machines. The recovery journal is locally signed, not itself externally witnessed. Read `docs/RECOVERY-v2.5.md` before deploying anything outside a controlled test environment.
