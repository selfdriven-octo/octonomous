# OctoLang v2.1 — Native Unified Scores + Reviewed Refinements

**AI composes → Humans govern → Agents adapt → Evidence verifies.**

This release extends v2.0 with a single-file `score` form and a separate, evidence-triggered, cryptographically reviewed *proposal* mechanism. It does not add tool execution rights, on-chain operations or an adaptive autonomous runtime.

## Quick start (Node.js 22+)

```bash
npm run score:check
npm run score:conformance
npm run score:demo
npm run test:v2.1
npm run test:isolated
```

To compile and verify a native score:

```bash
node bin/octolang-score.js score compile community-score.octo score-artifact.json
node bin/octolang-score.js score verify community-score.octo score-artifact.json
```

`community-score.octo` is a real self-contained example incorporating mission, composition, epistemic policy, assurance policy, contracts and bindings. `score:demo` creates a temporary synthetic observation, a reduced-budget revision and a separately signed human-review statement; its only output is a verified **proposal**.

The older CLI commands for v1.6–v2.0, Octonomous Runtime, browser Studio and Midnight experiments are retained. The Studio has not yet been extended with the native v2.1 authoring/review screen.

**Reference guide:** `docs/OCTOLANG-LANGUAGE-v2.1.md`.  
**Language implementation:** `language/v2.1/`.  
**Frozen conformance tests:** `conformance/v2.1/manifest.json`.

The sample keys, attestations and measurements are synthetic; this release has not been deployed to a public network. Nothing in the new compiled artifacts grants authority to execute.
