# Changelog

## v2.7.0 — Sovereign three-role pilot

- Added separately provisioned governance service with pinned mutual TLS, Ed25519-signed activation decisions and durable independent high-water history checkpoints.
- Added signed approval checks for exact reviewed revision and activation ledger head.
- Added effect-time governor admission after the separately signed remote witness START.
- Added a monotonic signed-ledger, execution and witness history prefix comparison to detect local journal+seal rollback once remotely checkpointed.
- Added public-key-only operator connectivity and signed-history check for independently deployed endpoints.
- Added localhost three-process pilot harness and adversarial tests for failures, partition, replay, forged evidence and TLS transport key rotation.
- Preserved v2.6 safety, v2.5 evidence-only recovery and previous language/runtime APIs; no financial transfers.
- Current limitations: no real three-machine acceptance yet, synthetic observer/reviewer signers, no native v2.2 governor-root signing-key migration.

See `CHANGELOG-v2.6.md` for inherited history.
