# OctoLang v2.3 — Verified Execution Activation

**Status:** research reference implementation, local-only tool profile, 21 October 2026.

## 1. Design objective

The v2.2 compiler, signed refinement reviewer and activation ledger are preserved. v2.3 adds a local tool execution gate that consumes v2.2 VCC reservations and produces auditable, signed local effect records. A separate Ed25519 witness identity signs the ledger and execution-log heads before and after effects. The independent verifier requires both boundaries to have been witnessed.

The relevant invariant is **no tool effect unless all these predicates hold**:

1. The source score compiles, has a pinned digest and has a human-reviewed mission.
2. Task, role, context claims and capability grants pass `planMission()` at admission and at effect time.
3. The current signed activation ledger accepts a *unique* request bound to the correct active revision, VCC decision, capability, context root, target, nonce, budget and time window.
4. The exact reservation is committed to the durable ledger.
5. A `START` execution event cryptographically binds the approved request, current score revision and plan to the reservation journal head.
6. The independent witness signs the `START` execution head and ledger head **before** the local tool runs.
7. Only `intent.record` mapped to `mission.local.record-intent` is available in this profile. A local journal file is created exclusively (`O_EXCL`) and synced; no network, payment, wallet or shell tool is provided.
8. A `COMPLETE` event binds the actual local record digest; the witness signs that completed state before success is reported.

## 2. Durable states

| State | Meaning | On restart |
|---|---|---|
| `RESERVE` | Lifetime budget consumed, nonce reserved, no action attempted yet | Never auto-retry |
| `START` | The tool **may** already have run; signed journal event | Reconciliation required |
| `COMPLETE` | Local record and controller receipt persisted | Offline verifier checks record + witness, no rerun |
| Unwitnessed event / incomplete seal | Crash, outage, tampering or incomplete write | Fail closed; manual reconciliation |

These are not distributed atomic transactions. The tool runner holds the same v2.2 exclusive lock across asynchronous execution, preventing normal concurrent activations or reservations through the same ledger APIs. Locks are not silently broken after a crash.

## 3. Storage and trust boundaries

**Execution host**: v2.2 `events.jsonl`, `state-seal.json`, v2.3 `execution.jsonl`, `execution-seal.json` and `effects/`. Controller private key remains under operator control.

**Witness**: another Ed25519 signing identity, a separate witness directory (`checkpoints.jsonl`) and an externally pinned public key. The example uses `LocalWitness` in the same Node.js environment; separating its signing key and filesystem **does not establish an independently operated witness**. For meaningful operator rollback resistance, the witness must be independently administered on another host or account, with key isolation and an authenticated interface. Even that does not replace external consensus/finality guarantees.

The witness will not sign an event with a non-monotonic local ledger/execution sequence or a fork at the same sequence. The verifier checks the witness's signature chain and exact checkpoint for each execution `START` and `COMPLETE` event, plus the latest high-water mark. A controller operator able to roll back both controller and witness stores (or steal both keys) can still defeat this assurance.

## 4. Signed bindings

The `START` includes:

- immutable score digest, active revision digest, original mission digest and plan digest;
- VCC decision digest, reservation sequence and hash, binding, task, capability, target, context root and nonce;
- fixed local tool identifier.

The `COMPLETE` includes the exact `START` event hash and digest of the real local effect record. Both events are signed and hash-linked with domain-separated SHA-256. The independent verifier checks these bindings against the v2.2 signed ledger and effect file. **Signatures verify attributable records, not real-world outcome truth.**

## 5. Operator and developer commands

```bash
npm run activation:demo
npm run activation:execute-demo
npm run activation:execution-test
npm run test:isolated
```

From a separately provisioned audit machine (requires only public keys and readable copies of the logs):

```bash
node bin/octolang-execution.js verify \
  community-score.octo trusted-pins.json /path/to/controller/ledger \
  /path/to/witness/checkpoints /path/to/witness-public.pem
```

**Never copy private keys into a verification directory.** Treat local effect records as potentially sensitive; keep logs private, apply retention, and avoid anchoring raw identifiers publicly.

## 6. Compatibility and limitations

- v2.2 score and activation digests are unchanged. v2.2's existing ledger events remain valid.
- The v2.3 signed execution log is an additional event channel, not a new language syntax. Its use is **opt-in**.
- The adapter runs the existing Octonomous Runtime 1.0 with a strict one-capability allowlist. The example performs one real local file write, no external API, payments, ADA, Midnight or Groth16 proof.
- No automatically safe retry after `START`; reconciling an ambiguous effect must involve an independently controlled procedure.
- No secure distributed consensus, remote witness deployment, hardware attestation or multi-host test is claimed.
- Synchronous local filesystem fsync is used for a prototype only; multi-host production deployments need transactional data stores, cross-process locks, monitoring, backup/restore policies, independent witness transport and tested disaster recovery.
- `bootstrap()` enrols the initial current signed ledger head; **an independent trust ceremony** is necessary to verify the correct initial state before trusting this first checkpoint.

## 7. Proposed next phase

Test independent witness operation across machines, introduce reconciliation protocols and transaction-aware capability adapters, and include signed receipts from independently administered external services before widening effect capabilities.
