# OctoLang v1.9 — Formal Constraints and Evidence Semantics

**Status:** Experimental language-track specification, 21 October 2026. Compatible overlay on v1.6 typed mission IR. v1.7 composition and v1.8 epistemic overlays remain independent. **No runtime enforcement** is implied by compiling or independently assessing this overlay.

## Purpose

Separate four questions that must not be conflated:

1. **Authorisation:** A pinned issuer attests the request was authorised under an external governance process. Verification of an attestation does not itself evaluate the governance rules or grant a new capability.
2. **Execution:** An independently pinned executor attests an effect occurred, naming the exact declared effect class. The assertion is cryptographically attributable, but still subject to the executor's honesty and correctness.
3. **Observation:** A separately keyed observer attests evidence about the effect. A receipt is not equivalent to independently measured real-world truth.
4. **Outcome:** A separately keyed evaluator attests an assessment of a declared outcome, potentially referring to local measurements and provenance. This does not magically prove objective effectiveness.

The compiler can enforce *formal consistency of declarations*. The independent assessor can enforce *cryptographic provenance, request binding and attested temporal conditions*. Neither executes a capability, verifies a VCC decision, verifies external settlement, establishes oracle truth, or generates a zero-knowledge proof.

## Language grammar (v1.9, normative subset)

```ebnf
Assurance   = "assurance", MissionIdentifier, "{", {Declaration}, "}" ;
Declaration = Effect | Invariant | Temporal | Obligation ;
Effect      = "effect", TaskName, "{", "allow", EffectKind, "}" ;
Invariant   = "invariant", Identifier, "{", "input", InputName,
              "max", NonNegativeInteger, Unit, "}" ;
Temporal    = "temporal", Identifier, "{", "after", TaskName,
              "before", TaskName, "within", PositiveInteger, TimeUnit, "}" ;
Obligation  = "obligation", TaskName, "{", "require", QuotedPhaseCSV, "}" ;
EffectKind  = "LOCAL_CAPABILITY" | "EXTERNAL_SERVICE" ;
TimeUnit    = "m" | "h" | "d" ;
```

Quoting uses standard JSON-style double-quoted strings with the parser's limited escape set. `#` and `//` comments are supported. Identifiers follow `[A-Za-z_][A-Za-z0-9_-]*`. Unknown tokens and declarations fail closed. No generic loops, expressions or network effects are part of this subset.

## Semantic rules

- A declaration binds to one existing v1.6 mission name and SHA-256 typed-IR digest. No new task, effect or permission may be introduced. Every mission task requires exactly one explicit `effect` declaration, with its class *equal to* the already compiled task effect. Unresolved effects are unsupported.
- Every mission numeric maximum must be represented by exactly one invariant over its input. An assurance limit can be equal to or narrower than the mission maximum, never broader. ADA is normalised to lovelace (`1 ADA = 1,000,000 lovelace`); `count` remains in integer units. Runtime `request.inputs` is expressed in these canonical units, not the source units.
- `temporal` statements require a real transitive dependency from the `after` task to the `before` task; the configured interval is positive and <= 30 days, to minute precision. Both tasks must produce signed execution attestations. Runtime timestamps are *issuer assertions*, not trusted ledger or external time.
- Each task has one `obligation` with at least `AUTHORISATION,EXECUTION`. `OBSERVATION` follows `EXECUTION`; `OUTCOME` follows `OBSERVATION`. Any mission task with a declared outcome requires all four. No skipping phases or duplicated phases.
- The assurance IR is sorted deterministically and hashed using `SHA256("OctoLang Assurance IR v1.9\n" + canonicalJson(ir))`. The verifier reconstructs all derived semantic fields against an independently verified v1.6 root IR; merely rehashing altered authority bits must not make them valid.
- An IR digest is a semantic identifier. The *source-bound artifact* additionally pins the exact source bytes and mission source bytes. Formatting and declaration order leave the IR digest unchanged but change the source hashes. Existing execution policy digests remain distinct and unchanged.

## Evidence packet (testable reference semantics)

An assessment needs a precompiled assurance IR, its IR digest, independently verified root mission IR, exact request (`subject`, canonical `inputs`, `actionDigest`), externally pinned issuer public keys and signed claims. Claims use schema `octolang.assurance-claim.v1.9` and bind to mission and assurance digests, task, phase, subject, action and request digest. The immutable signed payload includes a supporting-evidence digest, issuer, attested and expiry times, status, effect class and preceding phase digest.

A validator MUST reject missing/extra phases, duplicate task-phase receipts, incorrect signatures or trust pins, mismatched request and action hashes, expired/future claims, wrong effects, a broken attestation chain, non-monotonic attested phase times, violated task ordering, out-of-bounds typed request inputs and exceeded temporal intervals. An issuer key cannot satisfy more than one stage of the *same task*. Multiple issuer IDs resolving to the same signing key still count as one identity.

The verification output `EVIDENCE_ADMISSIBLE_ONLY` is intentionally not `ALLOW`, `SUCCESS` or `OUTCOME_PROVEN`. A signed `FAILED` status is denied in this reference implementation, rather than interpreted as proof of success.

## Fail-closed behaviour and threat model

- **Compromised but trusted issuers** can create authentic yet false assertions. Cryptographic verification only proves attribution and message integrity. Independent physical observation requires separately engineered instrumentation or adjudication.
- **Attested clocks** can be false or colluding. Time-bound assertions are checked relative to a supplied verifier clock and each other, but no secure hardware or consensus timestamp is asserted.
- **Replay protection is not a feature of this pure assessor.** The same signed evidence may be reassessed for independent audit. The execution VCC must persist one-shot action IDs, enforce revocation/current grants and revalidate context immediately before effects.
- **Bounded request inputs are not observed payment totals.** A proof that an authorised request is <= 100 ADA does not establish that a third-party provider charged <= 100 ADA. Real settlement checking needs trusted custody/accounting evidence.
- **Not formal model checking.** This layer enforces specific decidable static/temporal conditions, not theorem-proven correctness of arbitrary software, the absence of every undesirable execution trace or model behaviour.
- **Not Groth16/PCD.** No general ZK proving/verifier circuits are implemented by this overlay. Midnight functionality from prior releases remains separate.
- **Human governance is external.** `AUTHORISATION` is an issuer attestation; the runtime must still validate current governance resolutions, signatures, expiry and role-specific grants under its own VCC policy.

## Demonstration and conformance

```sh
npm run assurance:check
npm run assurance:demo
npm run assurance:conformance
node bin/octolang-assurance.js compile examples/community-assurance.octo examples/community-proofs.octo assurance.json
node bin/octolang-assurance.js verify examples/community-assurance.octo examples/community-proofs.octo assurance.json
```

The demo generates fresh synthetic Ed25519 identities and evidence **entirely in memory**, with no service or ledger calls. The 20 frozen conformance vectors include canonical ordering and negative examples. JSON Schemas provide portable structural checks but never substitute for semantic reconstruction, source binding or cryptographic verification.

## Deferred integration work

1. Wire v1.8 epistemic context checks and v1.9 assurance admissibility to the existing VCC as *additional* fail-closed prerequisites.
2. Bind real service-authorisation receipts and execution outputs to stable issuer grants, revocation records and durable action identifiers.
3. Define independent observations with provenance-backed measurement acquisition, evaluation criteria and signed counterevidence.
4. Build a trace-specification and model-checking layer if stronger temporal properties (e.g. liveness/fairness or cross-agent safety) are required.
