# OctoLang v2.2 — Governed refinement activation and durable VCC reservations

Status: **experimental local reference implementation**, 21 October 2026. Builds directly on the native `score` and signed `revision` syntax introduced in v2.1; does not alter the `.octo` grammar or the v2.1 semantic hashes.

## Scope and security model

1. The compiled native score defines an immutable upper bound and binds four layers: mission, composition, epistemic guards and assurance obligations. Source text and its typed IR are not authority credentials.
2. A v2.1 revision is a proposed **tightening** of the existing bindings (`runs`, `budgetUnitsPerRun`). Its independent observation and human review are valid **evidence of review**, not execution rights.
3. A distinct governance key issues an activation statement, binding the exact score digest, revision digest, current ledger head, next sequence, and a bounded validity window. The decision string is `ACTIVATE_LIMITS_ONLY`.
4. Activation transitions the *effective* local limits but never grants a tool or wallet capability. Subsequent refinements must not increase any currently active per-binding limit. Lifetime reservations survive transitions and restarts.
5. To reserve a bounded operation, the reference gate requires an independently signed VCC `ALLOW` over the exact request (`scoreDigest`, `activeRevisionDigest`, binding, task, capability, effect, units, nonce, target and context root). The decision is short-lived.
6. A mission preflight bridge can issue the VCC decision only after verifying the existing v0.9/v1.2 mission's signed human review, grants and context claims. The gate only reserves budget and checks authority; it does not call tools. A deployed effect runner must recheck action-critical evidence at the point of actual use.

## Distinct authorities

Five separately pinned Ed25519 public keys are required: `observer`, `reviewer`, `governor`, `vcc`, `controller`. They must identify different keys. The independent verifier needs only public pins and the native source. The controller keeps its private key outside the audit directory; the demo uses temporary synthetic keys.

- `observer` — signs claim of a metric. Signature alone does not prove that measurement reflects reality.
- `reviewer` — signs `APPROVE_PROPOSAL_ONLY` for a concrete revision.
- `governor` — signs `ACTIVATE_LIMITS_ONLY` over a current ledger head and sequence.
- `vcc` — signs `ALLOW` over a complete request after a separate deterministic authority check.
- `controller` — signs every ledger transition and the current state seal.

The identities are deliberately **not** interchangeable. A signed mission or proposal is never treated as an unlimited capability.

## State transitions

`UNINITIALISED --GENESIS--> ACTIVE_BASE --ACTIVATE--> ACTIVE_REFINEMENT --ACTIVATE--> ...`

Reservations may occur at any active version. A reservation consumes one run plus a positive integral number of abstract budget units. The gate checks:

- Request amount ≤ active per-run limit;
- Lifetime run count ≤ current binding run cap;
- Lifetime consumed units ≤ `runs × budgetUnitsPerRun`;
- Future refinements may only tighten existing limits and must accommodate already consumed runs and units;
- Replay nonces are global to the ledger, not reset by version changes.

The original upper bounds remain immutable. Budget units are **abstract policy units**, not lovelace, ADA or fiat; neither a reserved unit nor a signed VCC statement moves money.

## Durable local audit

The controller appends `GENESIS`, `ACTIVATE` and `RESERVE` events to `events.jsonl`, with an Ed25519 controller signature, sequence, predecessor digest and canonical SHA-256 hash. Every event is replay-validated against the original score, time of assertion, role pins, prior limits and already consumed usage. An additional signed `state-seal.json` must match the current ledger head and sequence. Both files are fsynced after changes.

Mutation uses an exclusive filesystem lock directory. A stale lock, incomplete write, missing seal, truncated journal, inconsistent state or invalid signature **fails closed** and needs deliberate operator reconciliation. The gate does not auto-heal, roll back, or rerun uncertain effects.

### Critical local-store limitation

A privileged local operator can delete or replace **both** the journal and the seal or replay an older valid pair. A local signed hash chain cannot prevent complete rollback to an older state without an **externally witnessed checkpoint** or storage immutability. The v2.2 reference does **not** supply such a witness and must not be marketed as production-grade treasury/budget safety. State is single-host and local-filesystem based; it is not a distributed transactional ledger. For production use, anchor heads externally and use a proper transactional persistent store, HSM signing, network authorisation and recovery procedures.

## Verification, runtime and safety

An external auditor can run:

```bash
node bin/octolang-activation.js verify community-score.octo pins.json /absolute/path/to/ledger
```

`pins.json` contains only the five PEM-encoded public keys. The verification program does not take or need any private key.

To demonstrate with ephemeral synthetic identities and an in-memory mission preflight:

```bash
npm run activation:demo
npm run activation:test
npm run test:isolated
```

It activates a narrowing revision, then verifies a separately approved reservation via the existing mission VCC preflight. No external action, wallet invocation, transaction or on-chain proof is performed.

## Not implemented

- Automated actual external tool execution or effect-time VCC integration;
- Automatic v1.8 epistemic overlay checking in this reservation gate (the mission bridge verifies mission claims, not every epistemic guard);
- External witnessed anti-rollback anchors and distributed transaction/recovery coordination;
- Reversal, refund, replenishment or recurring-budget reset semantics;
- Multi-host concurrency and independent physical-machine testing;
- Cardano/Midnight settlement or Groth16 proof generation.

Any future effect runner must obtain a fresh authority decision *immediately* before a specific effect, bind the effect receipt and independent observation to the reservation, and reconcile uncertain outcomes before retries.
