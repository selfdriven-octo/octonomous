# OctoLang v2.5 — Distributed Recovery and Reconciliation

**Version:** 2.5.0 — research / localhost-tested pilot  
**Purpose:** resolve ambiguities in *already-authorised* Octonomous execution using signed evidence, with no automatic re-execution or refunded budget.

## Safety invariants

1. An execution `RESERVE` always consumes cumulative budget. Reconciliation never alters the v2.2 reservation journal or refunds a unit.
2. A signed `START` does **not** prove an effect happened, and the absence of a local file does **not** prove it did not happen.
3. An existing, controller-signed `COMPLETE` record may be independently witnessed later only if the original signed effect, reservation, score version, signature chain and previously witnessed `START` all verify.
4. A case without a valid `COMPLETE` remains **unresolved**. The system may record a signed `HOLD` but never synthesises completion or blindly repeats the tool call.
5. Each recovery case binds the latest observed controller and witness heads. Moving either head invalidates pre-existing case approvals.
6. A separate observer key and governor key must sign the exact case digest and intended resolution. Neither can be the controller or remote witness key.
7. The remote witness signs checkpoint history **over HTTPS with pinned mutual TLS** through the existing v2.4 adapter. All signed remote checkpoints remain append-only and nondecreasing.
8. Reconciliation has its own domain-separated, controller-signed hash-linked journal and signed seal, verified independently without private keys.

## Classifications

| Classification | Meaning | Permitted reconciliation |
| --- | --- | --- |
| `COMPLETE_NEEDS_WITNESS` | Signed START and COMPLETE exist, effect digest matches, witness has signed START but missed COMPLETE | `WITNESS_EXISTING_COMPLETION` or `HOLD` |
| `START_NOT_WITNESSED` | Local START exists but witness has not acknowledged it | `HOLD` only |
| `UNKNOWN_AFTER_START` | Witness signed START; no signed COMPLETE or local effect | `HOLD` only; **absence is not proven** |
| `EFFECT_PRESENT_WITHOUT_COMPLETE` | Local effect file exists, but controller's COMPLETE signature does not | `HOLD` only, manual investigation |
| `ALREADY_WITNESSED` | Signed local COMPLETE and remote witness already agree | No new reconciliation |

## Operators and trust domains

- **Execution community:** controls the activation gate, VCC and signed execution logs. It cannot unilaterally certify recovery: independent observer/governance signatures are required.
- **Independent observer:** inspects exported signed evidence and physical/service state where possible. Its v2.5 `EVIDENCE_INSPECTED_NOT_WORLD_TRUTH` signature means it checked a case; it is *not* a proof of real-world truth.
- **Community governor:** separately signs approval to witness the exact existing completion, or to hold the case.
- **Witness community:** maintains a pinned, separately signed checkpoint log and does not require the execution host's private key. The same witness process from v2.4 is used.
- **Independent auditor:** runs `octolang-recovery audit` with public pins and read-only copies of execution/witness evidence.

The demonstration runs separate witness and execution processes on one machine. Real multi-machine deployment and independently administered operations are **not verified**.

## Flow: lost remote completion acknowledgement

1. Controller reserves budget and signs START.
2. Remote witness signs START.
3. Runtime performs one bounded local record effect. Controller signs COMPLETE.
4. Witness becomes unavailable before acknowledging COMPLETE. **Do not invoke the original tool again.**
5. Operator obtains a fresh signed controller journal, an effect file, and signed witness history.
6. Independent inspector derives the exact case digest, checks the effect digest, and signs a time-limited statement.
7. Independent governor signs `WITNESS_EXISTING_COMPLETION` for that exact case and observer signature.
8. Controller holds its exclusive lock, refreshes the remote witness, checks current state and both approvals, and asks the witness to sign the *existing* signed completion snapshot.
9. Controller records a signed reconciliation event; an offline auditor verifies it and the new remote witness checkpoint.
10. Resource usage remains unchanged; the original nonce stays spent.

If the network fails between steps 8–9, **inspect the witness state first**; do not retry the same reconciliation blindly. The controller may have recovered its original valid completion even if the local reconciliation note was not written. The original execution log and mirror detect that situation.

## Local demonstration

Requirements: Node.js 22+, OpenSSL.

```sh
npm run recovery:demo
npm run recovery:test
npm run test:isolated
```

The demo creates synthetic operator keys and an ephemeral separate witness process. The demonstration intentionally drops the completion response, then repairs only the missing witness acknowledgment. It prints the number of local effects, which must equal **one**.

## Independent CLI

Create a JSON configuration containing **paths to public-key pins**, never private signing keys:

```json
{
  "directory": "/absolute/executor-data",
  "witnessDirectory": "/absolute/copy-of-witness-checkpoints",
  "scoreSource": "/absolute/community-score.octo",
  "pins": {
    "controller": "/absolute/controller-public.pem",
    "observer": "/absolute/observer-public.pem",
    "reviewer": "/absolute/reviewer-public.pem",
    "governor": "/absolute/governor-public.pem",
    "vcc": "/absolute/vcc-public.pem",
    "witness": "/absolute/witness-public.pem"
  }
}
```

```sh
node bin/octolang-recovery.js inspect recovery-config.json NONCE
node bin/octolang-recovery.js audit recovery-config.json
```

The verifier checks signatures, schema, original score, VCC reservation, journal sequence/hash/seals, witness history and recorded local effect digests. It exits nonzero on invalid evidence. For **live** recovery, use the `RecoveryCoordinator` API (not the read-only CLI) with separately signed observer/governance records and remote witness connectivity.

## Limits and unsolved problems

- Not an automatic distributed-transaction protocol. No two-phase commit, no Byzantine consensus, no speculative retry, no rolling back a real-world effect.
- Reconciliation journal's local state seal cannot alone defeat a privileged operator who restores both journal and seal. Witnessing the reconciliation journal itself in another trust domain is future work. Existing remote checkpoints independently anchor the original execution heads, not each local recovery note.
- Neither a valid tool receipt nor an observer's statement establishes objective truth of physical-world events. Real external services need independent, signed receipts and authoritative idempotency queries.
- The v2.5 demonstration executes only `intent.record` to a local file, not payments, funds, wallets, Cardano, Midnight or unrestricted external actions.
- Production operations need hardened disk/database atomicity, key lifecycle, certificate rotation, secure time, out-of-band governor review, offline recovery procedures and independent multi-host testing.
