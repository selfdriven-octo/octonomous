# OctoLang v2.4 — Remote Witnessed Execution

**Research specification (22 October 2026).** This is a security/transport and execution-enforcement extension, **not a new `.octo` source grammar**. v2.3 mission, score, VCC and activation digest formats are preserved. Experimental reference implementation, not independently audited.

## Semantics

1. Human-approved score and the independently signed governance/activation chain determine the *permitted policy*. The VCC authorises exact actions just in time.
2. The execution controller commits a unique lifetime-budget reservation and signed `START` record before invoking a tool.
3. A remote witness, independently provisioned with its **own private signing key**, over mutual TLS, signs the exact controller-reported state `{scoreDigest, activeRevisionDigest, ledgerSequence, ledgerHead, executionSequence, executionHead}` before the effect. The controller verifies the full signed witness history against an externally pinned Ed25519 public key.
4. An additional live HTTPS read of that state must succeed *immediately before* the Octonomous local tool effect. An unreachable or divergent witness prohibits the effect.
5. The sole enabled tool remains `mission.local.record-intent` (`intent.record`), which creates one exclusive local journal record. No payment, transfer, shell, cloud, or arbitrary remote capability is introduced.
6. Completion binds the result digest and `START` hash in a signed execution event; the remote witness signs the resulting checkpoint. An independent auditor requires both `START` and `COMPLETE` heads in the signed witness history.
7. Every failed or ambiguous operation after reservation is **reconciliation-required**, not automatically retried. Cumulative run and unit limits survive process restarts, and duplicate request nonces are rejected.

## Trust and identity

- **Controller machine:** owns the VCC/controller signer, score/mission approvals and v2.2/v2.3 ledger and effects.
- **Witness machine:** owns its *own*, independently provisioned Ed25519 witness private key and append-only journal. It pins the authorised score digest, an exact controller public key, and an allowed client mTLS certificate fingerprint.
- **Mutual TLS:** trusted certificate authority plus pinned exact server leaf-certificate SHA-256 digest; client certificate required and pinned by the witness. All requests use HTTPS. The witness does not receive the controller's private signing key.
- **Signed API requests:** domain-separated Ed25519 signatures over `scoreDigest`, complete snapshot, `expectedHead`, unpredictable nonce and a maximum 60-second validity window. A durable nonce journal is fsynced before signing; replay and concurrent predecessor updates fail closed.
- **Remote history:** the controller retains a verified signed mirror. Updating that mirror requires a strict prefix-extension of the previous history, independent signature checking and an atomic fsync'd replacement. The witness's journal must not be writable from the controller account.

## Remote API

Only two endpoints, authenticated by mTLS:

- `GET /v1/status` — returns the signed checkpoint journal (no secrets). Does not authorise any action.
- `POST /v1/attest` — accepts a signed, expiry-bound, single-use snapshot, and conditionally appends one signed checkpoint. Refuses stale previous heads and nonmonotonic controller state.

Both endpoints must have exposure limited to controlled peers (prefer a private network) and rate limits upstream. A failed write may leave a nonce consumed without a checkpoint: an operator must reconcile; do not automatically retry.

## Independent audit

`RemoteExecutionController.verifyLive()` refreshes the witness history over pinned mutual TLS, then independently verifies the local ledger, signed execution history, `START`/`COMPLETE` checkpoints and exact recorded effect. The offline verifier `bin/octolang-execution.js verify ...` works using the saved witness mirror, controller public keys and signed evidence without private keys. The new `language/v2.4/inspect.js` can fetch a fresh remote witness history and verify a local evidence bundle without a controller signing key (an mTLS client key is still necessary).

## Limitations and unresolved trust questions

- **A remote witness attests to the hash-bound state *reported by the controller*.** It does *not* independently observe a physical effect, guarantee truthful execution, or establish ledger consensus/finality. Signed controller events and local effect files remain separately verified.
- The end-to-end demonstration runs separate processes and isolated identity homes on **one physical machine**. Genuine independent machine/administrator deployment is supported by configuration but **has not been tested here**.
- Witness server configuration pins one controller and one score per witness journal. Rotation/re-enrolment require explicitly creating a new governed epoch; this demo intentionally refuses silent rotation.
- The signed history plus independent controller mirror detects ordinary journal rollbacks, but not a coordinated compromise of both administrators or all retained checkpoints. Copy/checkpoint witness heads to further independent stores before production use.
- A private network, audited certificate lifecycle, key custody, persistent transaction store, monitoring, time synchronisation, admission rate limits, disaster recovery and documented reconciliation are required for meaningful Internet-facing deployments.
- The demo PKI creates temporary **unencrypted** test RSA keys; it is not a production certificate authority. Keep private keys with their respective owner and never commit them to a repository.
- No live multi-host security assessment, penetration test, Cardano/Midnight proof, real ZK witness or payment is claimed.

## Compatibility

No change to the v2.1 source grammar, v2.2 signed ledger or v2.3 execution event formats. This release adds remote witness transport/client/server modules and a separately selectable `RemoteExecutionController`. Legacy v2.3 local-witness execution remains unchanged.
