# OctoLang 2.1 — Native scores and evidence-driven refinement

**Status:** research reference specification and implementation, 21 October 2026. Not a security certification or consensus standard.  
**Compatibility:** extends OctoLang v2.0 without changing its four constituent compiler semantics or existing v2.0 digests.  
**Runtime:** Node.js >= 22, CommonJS, no new runtime dependencies.

## Design goals

1. An AI can author **one readable `.octo` score** instead of referring to four separate source files and imported modules.
2. A deterministic compiler produces a canonical, independently verifiable **semantic digest**.
3. An agent can propose a smaller-budget plan after an observation; it cannot authorise a new role, capability, evidence downgrade, budget increase or tool invocation.
4. Evidence-driven adaptation requires an **independently pinned observer** and a **separate human reviewer**, each with an Ed25519 signature.
5. Formal correctness is confined to what is actually checked. Signed observations are attested claims, not proof of objective real-world truth.

## Source grammar: `score`

The native score is a single top-level container whose direct members are:

```
score Identifier {
  mission Identifier { ... }       # exactly once; unchanged mission grammar
  composition Identifier { ... }   # exactly once; unchanged composition grammar
  epistemic Identifier { ... }     # exactly once; unchanged epistemic grammar
  assurance Identifier { ... }     # exactly once; unchanged assurance grammar
  module Identifier { ... }        # one or more; v2.0 module grammar
  bind module.template as alias {
    node Identifier
    task Identifier
    runs NonNegativeInteger
    budget NonNegativeInteger
  }                                 # one or more; v2.0 binding grammar
}
```

All four layers, every module and every binding live in the **same file**. Any ordering of top-level declarations is permitted. Names and fields are checked by their respective parsers and the v2.0 linker; role, proof, capability, knowledge, bound, and dependency compatibility checks are preserved.

The lexer accepts comments beginning with `#` or `//`, quoted JSON strings with limited escapes, identifiers, digits, braces, dots, commas and angle brackets (for epistemic types). Unknown declarations, duplicated components and unsafe characters fail closed. The maximum source length is 262,144 UTF-16 code units; subordinate layers retain their own limits.

The score compiler extracts each complete constituent declaration, compiles with the four reference compilers, and links using v2.0. It emits:

- `octolang.score-artifact.v2.1`: the original source SHA-256 and complete constituent/legacy semantic artifacts, plus the new native IR.
- `octolang.score-ir.v2.1`: name, four constituent **semantic** digests, sorted modules and bindings, schedule, worst-case declared budget and an explicit non-authority marker.
- SHA-256 digest over `"OctoLang Score IR v2.1\\n" + canonicalJSON(scoreIR)`, using key-sorted UTF-16 JSON canonicalisation.

Unlike the v2.0 linker digest, the v2.1 native *semantic* digest deliberately does not include raw component source digests. Comment-only edits or harmless reordering of the top-level declarations preserve the semantic digest. `sourceSha256` still records the exact bytes supplied to the compiler, so a verifier can independently recompile and check exact source/artifact equality.

**No score, digest or successful verification is authority to execute.** The existing human-mandate, capability-grant, VCG, VCC and runtime gates are separate and must still be applied before real effects.

## Refinement grammar: `revision`

A revision is a distinct file, never an instruction embedded in a running score:

```
revision reduce_supply_cost {
  base "<64-character lowercase score IR digest>"
  evidence "<64-character signed observation payload digest>"
  trigger "cost-per-run" above 3
  tune scout_node runs 1 budget 1
}
```

The reference implementation permits **only narrowing** of existing binding limits. Specifically:

- every `tune` must name an existing score binding, with no repeats;
- `1 <= runs <= original runs`, `0 <= budget <= original budget`;
- at least one limit must strictly decrease;
- the effective binding preserves every original role, capability, contract, effect, proof requirement and source dependency;
- the overall derived worst-case budget cannot increase;
- neither the score nor revision IR contains any execution-authority grant.

Refinement IR is domain-separated and SHA-256 hashed using `"OctoLang Refinement IR v2.1\\n" + canonicalJSON(refinementIR)`.

This is intentionally *not* a general adaptive-program rewriting engine: choosing different suppliers, adding agents, reassigning work or expanding scope requires a newly compiled and governed score. Applying a safe static refinement to an active mission, decrementing cumulative quota, or recovering a distributed effect after a crash are **not implemented**.

## Observation and review evidence

An observation payload uses schema `octolang.refinement-observation.v2.1`:

```
{
  "schema": "octolang.refinement-observation.v2.1",
  "scoreDigest": "...",
  "metric": "cost-per-run",
  "value": 4,
  "unit": "budget-units",
  "sampleDigest": "...",
  "observedAt": "2026-10-21T12:00:00.000Z",
  "validUntil": "2026-10-21T12:10:00.000Z",
  "kind": "OBSERVATION"
}
```

The accepted demo metrics are bounded nonnegative integers in `budget-units`; this is a synthetic measurement model, not a general sensor type system. `sampleDigest` identifies an externally managed sample but the reference verifier does **not** fetch or validate that sample. Its signing key is verified against an independently provisioned pinned observer key. Its hash is SHA-256 of `"OctoLang Refinement Observation v2.1\\n" + canonicalJSON(payload)`.

The revision `trigger` must exactly match the signed observation's metric, and the observed value must strictly exceed the declared `above` threshold. The observation must be within a valid bounded 30-day window and cannot have a reported observation time more than 30 seconds in the verifier's future.

A separately signed human review payload uses schema `octolang.refinement-review.v2.1` and must bind **all three**: original score digest, exact revision digest and observation digest. The decision is the literal `APPROVE_PROPOSAL_ONLY`; the reviewer cannot grant real execution authority through this protocol. The reviewer and observer Ed25519 public keys must be different, even if differently encoded in PEM. Their trust pins must be provisioned by an independently trusted operator—not accepted from agent-generated code or proof files.

Signatures are Ed25519 over domain-separated canonical payload bytes, not raw JSON as serialised in a file. The verifier checks domain, signature encoding, approved identity, binding, trigger, timestamps and complete independent source recompilation.

**Trust assumptions:** Signatures authenticate which keys made a claim; they do not guarantee sensors, incentives, accuracy, correctness of the mission or actual human review. The `now` parameter is supplied by the hosting verification environment; an agent cannot be allowed to select the clock for expiry checks. Revocation, key rotation, signed transparency logs and distributed replay state remain future work.

## CLI usage

```
npm run score:check
npm run score:conformance
npm run score:demo
node bin/octolang-score.js score compile community-score.octo score-artifact.json
node bin/octolang-score.js score verify community-score.octo score-artifact.json
node bin/octolang-score.js revision check community-score.octo revision.octo
node bin/octolang-score.js revision compile community-score.octo revision.octo revision-artifact.json
node bin/octolang-score.js revision verify community-score.octo revision.octo observer.json reviewer.json trusted-pins.json
```

The demo creates ephemeral Ed25519 keys in memory and uses a **synthetic** signed metric. No agent action, wallet, payment, cloud resource, network service or Midnight transaction is invoked.

## Source compatibility and specification limits

Older `program`, `mission`, `composition`, `epistemic` and `assurance` grammars and CLI commands remain available and are not automatically converted or re-authorised. The v2.1 `score` form embeds existing grammar blocks rather than redefining their internal syntax: this is a **single-file native envelope with unified semantics**, not yet a wholly new normalised grammar for every internal construct.

The 24 frozen conformance cases include accepted digest vectors and fail-closed examples, but do not constitute a formal mathematical proof of implementation correctness. JSON structural schemas in `language/v2.1` complement, rather than replace, semantic checks and independent recompilation.

## Threat and limitation summary

| Risk | Mitigation / remaining gap |
|---|---|
| Prompt injection broadens a delegated authority | Mission still requires external policy grant; refinement may only narrow bounds |
| Rehashed malicious score IR | Recompile original source; compare canonical artifact and legacy constituent semantic IRs |
| Signed fabricated measurement | Pinned observer + signature; objective truth and sample provenance remain external responsibilities |
| Compromised reviewer/observer key | Separate keys, explicit pins and bounded expiry; revocation not implemented |
| Replay and double execution | Refinements are non-executable; actual runtime must maintain persistent replay and idempotency state |
| Spending across multiple revisions | No cumulative budget ledger in v2.1; runtime cannot rely on static total alone |
| Changed program semantics across runtimes | Pinned schemas and conformance vectors; third-party compilers should independently validate both vectors and signatures |
| Midnight or Cardano proof integration | No change: existing experimental adapters remain available, not required by native score compilation |
