# OctoLang v2.7 — Sovereign Three-Role Pilot Specification

**Status:** experimental protocol extension over OctoLang v2.6 and the v2.2 activation ledger, v2.4 remote witness and v2.5 recovery coordinator.

## Goal

Keep the governor's long-term Ed25519 signing key off the execution host while ensuring a second independent, append-only state checker cannot be bypassed at effect time. Each approved local effect must still pass an actual VCC check and a previously witnessed START.

## Wire protocol

`octolang.governance-request.v2.7` is signed with `Ed25519("OctoLang v2.7 Governance Request\\n" + canonical(payload))` by a separately pinned controller public key, inside pinned mutual TLS.

Fields: `schema`, `action` (`ACTIVATE` or `PRE_EFFECT`), random 128-bit hex `nonce`, `issuedAt`, `expiresAt` (Unix milliseconds, <=60-second lease), `bundle`, and for `ACTIVATE` a `revision` object containing source, compiler artifact, independently signed observation and review.

`bundle` contains the complete signed `events.jsonl`, signed `state-seal.json`, signed `execution.jsonl`, signed `execution-seal.json`, and separately signed witness `checkpoints.jsonl`. Missing files use empty strings for expected initial states. The verifier independently processes source signatures and typed record consistency from the existing v2.2/v2.3/v2.4 specifications. This is pilot transport; a future protocol should transmit hashed content-addressed segments with explicit retention and privacy rules.

The response is signed under `Ed25519("OctoLang v2.7 Governance Receipt\\n" + canonical(payload))` by the pinned governor key. A receipt includes `action`, nonce, monotonic sequence and a digest covering the current verified source heads. A governed activation additionally contains the original v2.2 `makeActivation()` signature bound to the exact ledger head and reviewed revision.

The governor rejects oversized, expired, forged, replayed or concurrently processed requests. It persists its own high-water checkpoint atomically before responding. In failure or ambiguous timeout cases the caller **must not** assume approval; restart and reconcile externally.

## Invariants

**G1 / Separate authority**: Governor Ed25519 private key is provisioned in the governor's separate process/home. The executor receives only its public key and typed signatures. The test harness creates observer/reviewer demonstration keys on the executor; that is not full real-world identity separation.

**G2 / No AI-created authority**: `ACTIVATE` requires an independently verified signed observation, signed human review, exact canonical score/revision digest, and a signed current ledger head. The governor's signature can only activate tighter policies; the original v2.2 gate checks authority and budget again.

**G3 / Fail-closed effect boundary**: Before an actual local tool call, the executor verifies a signed remote witness START checkpoint, then submits the exact signed ledger, execution and witness histories to governance. Governance must attest to the same current heads. An error, timeout, network partition or mismatch leaves the action unresolved and consumes the existing reservation.

**G4 / Monotonic history**: The governor accepts only histories whose *exact byte representation* extends all of its previously accepted ledger, execution and witness histories. A restored older signed journal and matching signed seal will be rejected if the independent governor has already checkpointed a newer state. Witness history has an additional independently signed monotonic check.

**G5 / Replay and identity**: Exact TLS certificate pins, Ed25519 role pins, nonce replay protection, expiring requests and a governor enrolment file prevent transparent substitution without re-enrolment. Existing v2.4 and v2.5 replay and signed recovery controls remain active.

**G6 / No unsafe retry**: A START with an unknown outcome is never automatically retried. A signed COMPLETE that lost its acknowledgment may be reconciled under existing v2.5 rules without invoking the tool again.

## Validation scope

- Positive: separately running witness and governor services, both using independently generated Ed25519 keys and mutual TLS; reviewed policy activation; one authorised and independently witnessed local intent-recording effect.
- Negative: unsigned/forged/expired requests, forged human review, TLS identity substitution, remote witness outage, partition at pre-effect, persisted nonce replay, local signed-state rollback and service restart.
- Transport rotation: changing the service TLS certificate fails until an operator explicitly installs the new trust pin. **This is not rotation of the pinned v2.2 governor policy key.**
- Independent read-only `operator.js` verifies signed governance status and signed witness journal over their respective mutual-TLS channels without possessing their private signing keys.

## Unresolved production work

1. **Not three physical hosts tested:** a local three-process rehearsal, with isolated directories and signing keys, has been tested. Multi-machine provisioning and connectivity are documented but have not been run.
2. **Controller-as-reporter:** both remote verifiers validate the controller's signed state; they do not directly observe the file write or real-world effects.
3. **Privileged cross-domain compromise:** independent high-water checkpoints mitigate local journal+seal rollback only if the governor/witness checkpoint stores are independently administered and protected.
4. **Governance root rotation:** v2.2 pins a fixed governor public key. Secure changing of the long-term policy-signing root requires a new explicit pin-migration protocol, with old/new co-signing, revocation and independent governance ratification.
5. **Crash and durability:** power-failure recovery, WAL/transactional DB migration and concurrent distributed actors are not production validated. No refunds or automatic re-execution are permitted.
6. **Privacy:** full signed histories are transmitted to the governor; use disclosure minimisation and privacy review for a real deployment.
7. **Formal verification:** v2.6's model checking is bounded. These checks are not a mathematical proof of all possible behaviours or a certification.
