# OctoLang v2.0 — Unified Language and Module Design

**Status:** experimental reference language; source and semantic IR are not execution authorisation.  
**Version:** 2.0.0  
**Platform:** Node.js 22+, CommonJS, no new dependencies for the language compiler.

## 1. Purpose and design principles

OctoLang is an **AI-authored, human-readable and independently verifiable** language for specifying autonomy. The v2.0 design consolidates the independently specified v1.6–v1.9 *language tracks* into a canonical, reproducible **program**:

- **Mission (v1.6):** typed roles, declared capabilities, inputs, constraints, tasks, proof types and outcomes.
- **Composition (v1.7):** bounded nested plan proposals under an independent, signed mandate.
- **Epistemic (v1.8):** provenance-aware knowledge declarations and requirements.
- **Assurance (v1.9):** typed effects, numeric invariants, temporal requirements and different evidence phases.
- **Contracts/templates (v2.0):** reusable, cross-checked role/capability/evidence expectations and parameterised **upper bounds** for plans.

A **program** is a pure *link-time proposal*, never a grant. Agents or AI models may author it, but cannot create permission by compiling, declaring `Verified`, hashing an artifact, or importing a module.

## 2. Source syntax

The default top-level program file is `community-program.octo`.

```text
program learning_community {
  mission "examples/community-proofs.octo"
  composition "examples/community-adaptive.octo"
  epistemic "examples/community-epistemic.octo"
  assurance "examples/community-assurance.octo"
  import "modules/community-contracts.octo" sha256 "<64-lowercase-hex>"
  bind community.scout_stage as scout_node {
    node find_primary
    task find_supplier
    runs 1
    budget 2
  }
  # All remaining composition nodes also require a binding.
}
```

The `module` declaration can also be embedded directly inside the top-level `program` block. An imported `.octo` module contains only a `module` declaration, for example:

```text
module community {
  contract scout {
    role scout
    capability "service.note.record"
    effect EXTERNAL_SERVICE
    knowledge supplier_accreditation
    proof supplier_proof
    phases "AUTHORISATION,EXECUTION"
  }
  template scout_stage {
    contract scout
    parameter runs integer max 2
    parameter budget integer max 5
  }
}
```

A template is reusable: multiple bindings may refer to a template, but each must be checked against its *actual* task and one composition node. The `runs` and `budget` parameters can **only narrow** the permitted maximum. They are integer units of the v1.7 composition plan — **not ADA or other currency**. Spending limits remain defined in mission/assurance input units, which v1.9 normalises (for ADA, to lovelace).

### Grammar subset

```text
program        ::= 'program' ID '{' source+ (import | module | bind)+ '}'
source         ::= ('mission' | 'composition' | 'epistemic' | 'assurance') STRING
import         ::= 'import' STRING 'sha256' STRING
module         ::= 'module' ID '{' (contract | template)+ '}'
contract       ::= 'contract' ID '{'
                     'role' ID
                     'capability' STRING
                     'effect' EFFECT
                     'knowledge' ID
                     'proof' ID
                     'phases' STRING
                   '}'
template       ::= 'template' ID '{' 'contract' ID
                     'parameter' ('runs' | 'budget') 'integer' 'max' NAT
                     'parameter' ('runs' | 'budget') 'integer' 'max' NAT '}'
bind           ::= 'bind' ID '.' ID 'as' ID '{'
                     'node' ID 'task' ID 'runs' NAT 'budget' NAT '}'
EFFECT         ::= 'LOCAL_CAPABILITY' | 'EXTERNAL_SERVICE'
NAT            ::= non-negative base-10 integer (no sign or fractional part)
```

Fields in `contract` and `bind` may be re-ordered, but declarations must appear exactly once. `template` requires `contract` first, followed by both `parameter` declarations in any order. Comments start with `#` or `//`. The parser accepts no general expressions, JS, function calls, implicit conversions, or network imports. Duplicate identifiers/fields are errors. Referenced files must be `.octo` relative paths without `..`, absolute paths, or backslashes.

## 3. Contract typing and refinement rules

An agent contract is not an independent authority. For every bound composition node:

1. The node and task must be from the compiled v1.7/v1.6 IR, and the node's actual task must match the binding.
2. The contract's **role**, **capability**, and **effect** must exactly match the declared task and v1.9 effect.
3. The contract's `proof` must be an existing mission proof for that task.
4. The contract's `knowledge` must match the task's v1.8 guard and reference a `Verified` epistemic requirement. Its actual real-world evidence still requires the separate externally pinned evidence assessor.
5. The contract's evidence `phases` must **exactly** match v1.9's obligation. Phase lists are the ordered prefix `AUTHORISATION, EXECUTION, OBSERVATION, OUTCOME`.
6. `1 <= bound runs <= min(template runs max, composition node maxRuns)`.
7. `0 <= bound budget <= min(template budget max, composition node budgetUnitsPerRun)`.
8. Exactly one binding per composition node is required; duplicate nodes and omitted nodes fail compilation.
9. The sum of `runs * budget` across bindings must not exceed the original composition's worst-case budget.

These rules are **static admissibility checks**. They do **not** reserve or track spending across executions/revisions. Execution-time VCC and current human/community mandate checks remain necessary.

## 4. Canonical typed IR

- Schema: `octolang.unified-ir.v2.0`.
- The IR retains all **four component semantic SHA-256 digests** without changing previous versions' digest algorithms.
- Imports are bound to **exact SHA-256 source bytes**; the IR also contains sorted source digests.
- `modules` are sorted by module name; contracts/templates sorted by name; bindings sorted by binding name.
- The v1.7 composition schedule is retained unchanged; the linked IR includes total narrowed worst-case budget.
- `governance` always includes `grantsImplied:false` and `executionAllowed:false`.
- Domain-separated digest: `SHA-256(UTF8("OctoLang Unified IR v2.0\\n") || canonicalJSON(IR))`, using the existing `src/canonical.js` implementation.
- Program source itself also receives a separate, raw-byte `sourceSha256`. Source whitespace changes this hash but do not necessarily change the *semantic* IR digest.

The compiler output is `octolang.unified-artifact.v2.0`, containing the original four versioned component artifacts, the unified IR and its digest.

**Important:** The canonical JSON algorithm here is a defined JavaScript reference implementation. Cross-language reimplementations require byte-for-byte conformance tests for string escaping, Unicode and number serialisation. Independent review is necessary before relying on hashes as a public interoperability standard.

## 5. Independent verification

The `verify` CLI loads the supplied program, the exact imported and legacy component source files, and the artifact. It recompiles all components and compares the resulting artifact exactly. The standalone IR verifier also reconstructs semantic links and checks the original component validators. A malicious actor can rehash *a new admissible proposal*, but cannot make it into an authorised policy without a separately trusted signature and a pinned source/IR digest.

```bash
npm run program:check
npm run program:conformance
node bin/octolang-program.js compile community-program.octo /tmp/octolang-v2-artifact.json
node bin/octolang-program.js verify community-program.octo /tmp/octolang-v2-artifact.json
```

The source loader refuses symlinks escaping the program directory. It does not fetch HTTPS resources. Imported modules must provide an exact sha256 pin in the program. No module is granted execution privileges by being loaded.

## 6. Threat boundaries

| Threat | v2.0 compilation behaviour | Still required elsewhere |
|---|---|---|
| AI tries to add a new capability | Reject unless already declared and typed in mission | Independent signed grant and VCC |
| AI substitutes a module | Import SHA mismatch | Authenticated distribution of the top-level program |
| AI uses inferred knowledge to enable purchase | Contract requires matching `Verified` guard | Signed, freshness-checked real evidence |
| AI reduces proof obligations | Exact obligation phase match required | Independent observation/outcome evidence |
| AI increases runs or budget | Reject greater-than-template or composition bound | Persistent budget accounting and replay-safe effect execution |
| A forged artifact is rehashed | Independent semantic reconstruction/recompile | Human/community approval pinned to exact digest |
| Legitimately signed source claims a false fact | Compilation cannot determine truth | Evidence validation, independent observation, contestability |
| A valid plan is executed on another community | Compilation grants no execution authority | OFP authentication, local governance, current grants |

## 7. Compatibility, non-goals and roadmap

- v1.6–v1.9 source syntax and tests are preserved; v2.0 links those layers without silently changing their semantics.
- No new wallet/custody or Midnight submission interfaces are added to the language track.
- No actual AI model, external tools or Octonomous runtime are called by the v2.0 compiler/verifier.
- v2.0 does **not** implement general-purpose recursion, automatic plan-revision execution, W3C VC interoperability, formal mathematical proofs of arbitrary behaviour, or objectively verified outcome truth.
- The current `program` is a unified **module system and semantic artifact**, not yet a single self-contained replacement syntax for all four historical source grammars.

Recommended subsequent work: consolidate the four legacy declaration grammars natively into one ergonomic score syntax; introduce generics for contract types; enforce epistemic/assurance guards at the live VCC boundary; add formal small-step operational semantics and property-based/model-checking tests; then progressively generalise reusable modules across different missions. No blockchain dependency is required for those milestones.
