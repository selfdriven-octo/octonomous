# OctoLang v2.6 — Safety Contract, Model and Adversarial Verification

Status: **experimental, non-certifying**. Revision: 2026-10-22.

## Purpose

This is a dedicated language/runtime assurance track. It makes safety constraints independently inspectable and tries to *falsify* them. It does not extend the execution authority of the runtime, perform payments, or deploy on Midnight.

Three complementary evidence layers:

1. **Normative safety properties** below, scoped to approved scores and execution state transitions.
2. **Bounded, explicit transition model** in `safety/v2.6/model.js`. Enumerates reachable states and returns minimal (breadth-first) counterexamples. The model is independent of the production controller and is **not** a formal verification of that controller.
3. **Concrete adversarial probes** in `safety/v2.6/adversary.js`. Mutates authentic, signed v2.2 journal records and calls the **actual** `verifyLedger()` implementation. Reports rejected attacks and one deliberately exposed residual risk.

## Threat model

Defenders: separately pinned reviewer, governor, VCC and controller keys; a governed score; a local activation journal; an independently verified witness start; an effect; and signed recovery evidence.

Adversaries: malicious AI proposals; compromised low-privilege agents; corrupt or replayed messages; ledger modification; missing or forged signatures; process crash; incomplete network acknowledgments; and local privileged rollback.

Explicit trust assumptions: cryptographic keys, public-key pins, clock input, storage filesystem, and runtime dependency tree remain trustworthy except as tested. The reference model assumes atomic state transitions, two agent roles, two nonce values, and no real network or interprocess races.

## Safety contract

| ID | Required invariant | Concrete implementation evidence |
|---|---|---|
| S01 | **Authority is non-expansive**: activated limits never exceed previously effective constraints | v2.2 activation verifier; independent bounded model |
| S02 | **Budget is cumulative** across refinements and restarts; used resources are never reset | v2.2 signed ledger; model accounting |
| S03 | **Unique request identity**: a nonce can only reserve once | v2.2 `RESERVE`; mutation/replay probe |
| S04 | **At most one observable effect per request identity** | v2.3 / v2.5 earlier integration tests; bounded model |
| S05 | **Witnessed admission before effect** | v2.3/v2.4 witness logic; bounded model |
| S06 | **Reconciliation never synthesises completion or repeats uncertain effects** | v2.5 recovery checks; bounded model |
| S07 | **Invalid or inconsistent signed records fail closed** | 90 seeded mutations using real v2.2 verifier |
| S08 | **Verification does not grant new authority** | v2.1-v2.5 approval separation; no new executor in v2.6 |
| S09 | **Real-world outcomes require more than signed execution claims** | epistemic / assurance distinction; outside v2.6 model scope |

Time-oriented sketch (notation is illustrative, not fed into an LTL theorem prover):

```
G( reserve(r) => used(r.actor) <= active_limit(r.actor) )
G( effect(r)  => P(admit(r) AND witnessed_start(r)) )
G( uncertain_after_start(r) => NOT automatic_retry(r) )
G( reconcile(r) => previously_recorded_complete(r) )
G( activate(new) => authority(new) subset_of authority(previous) )
```

Where `G` means “always” and `P` means “previously”. “Previously” includes a required causal chain, not simply wall-clock ordering. These formulas are documentation of intended invariants, not machine-checked temporal logic.

## Model-checking procedure

```bash
npm run safety:model
node safety/v2.6/model.js 7
```

The checker explores the entire finite reference state space reachable **up to a depth of 7**, deduplicates by state serialization, and verifies invariants on accepted transitions. It deliberately attempts both valid and prohibited transitions and reports rejected edges. If `maxStates` is exceeded, the result is **INCONCLUSIVE**, not pass.

Run `node safety/v2.6/report.js --depth 7 --seed 20261022 --count 90 --json reports/safety-report-v2.6.json --markdown reports/SAFETY-REPORT-v2.6.md` to produce exact properties, reproducible parameters, source digests and replayable mutant traces.

Mutants intentionally weaken safeguards:

- `allow-widen`: accepts an increasing mandate limit.
- `skip-witness`: lets a side effect occur without the verified witness start.
- `unsafe-retry`: repeats an effect with the same nonce after an execution may already have occurred.

Their generated minimal counterexamples show that the checker would fail if those faults were introduced in the reference model. They do **not** prove the equivalent production code contains no undiscovered faults.

## Concrete adversarial probes

```bash
npm run safety:attack
node safety/v2.6/adversary.js 20261022 90
```

Authentic signed journal records are generated using the v2.2 implementation. A seeded corpus tampers with spending amounts, nonces, VCC decisions, signatures, sequence numbers, previous hashes, timestamps, scores, context roots, seals and journal truncation. Every modified journal is submitted to the existing `verifyLedger()` under original public-key pins. Separate probes attempt a substituted controller pin and duplicate reservation.

**Known detection limit (F-001 / HIGH):** When a privileged operator restores *both* a previously signed event journal and its matching previous signed state-seal, local verification accepts that stale valid pair. The test intentionally reproduces and reports this vulnerability. An independent, durable, monotonic checkpoint or independently operated witness able to reject equivocation is required. The v2.4 localhost remote witness is not by itself a demonstrated production solution.

## Scope and evidence classification

- `BOUNDED_CHECKS_PASSED` — every explored state of the declared finite model satisfied its invariants, injected mutants had counterexamples, and configured real-verifier mutations were rejected.
- `FAILED_OR_INCONCLUSIVE` — a violation, untested bound exhaustion, unexpected acceptance, or failure to detect an injected mutant.
- `F-001 OPEN` — the joint rollback blindspot remains even if bounded checks pass.

These results are **not** claims of exhaustive security, mathematically proven runtime correctness, independent code implementation, real-world outcome correctness, or production certification.

## Next release gate (v2.7)

Before declaring a deployable distributed system:

1. Run on at least three separately administered physical or cloud hosts (execution, governance, witness).
2. Pin and independently distribute keys; use HSM/isolated signer where appropriate.
3. Persist externally witnessed signed heads, detect rollback and equivocation, and publish recovery policy.
4. Inject process kill, network partition, delayed/missing receipts, simultaneous contenders and compromised-key scenarios.
5. Produce independent read-only evidence bundles, replayable traces, two separately implemented verifiers and a threat-model review.
6. Resolve F-001 rather than treating a locally valid signed seal as sufficient anti-rollback evidence.
