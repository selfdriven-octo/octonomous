# OctoLang v1.8 — Epistemic and Contextual Types (draft normative design)

Status: reference implementation; experimental, compile-only and read-only verification. Compatible with the v1.6 typed mission IR and v1.7 bounded composition IR.

## 1. Intent and trust boundary

An AI may propose **what knowledge a mission needs** and **what quality of evidence will satisfy a task**. It cannot declare that a fact *is true* or authorise a tool. An external trust configuration must pin the keys and permitted attestation types of the sources. The verifier determines the state from signed claims, subject binding, freshness, provenance and conflicts.

There are three different propositions:

1. **Type requirement** — e.g., `Verified<Credential>`: the program requires a pinned issuer's valid credential attestation; this is not proof that the claimed real-world property is true.
2. **Context assessment** — signed/dated/provenance-constrained inputs meet or fail a specified type requirement **for this verification instant**.
3. **Execution authorisation** — independent human mandate, capability grants, VCC, privacy rules, budgets and revocation. **No v1.8 function produces it.**

This separation follows the existing VCG principle: a generated assertion cannot upgrade itself to verified status, and an agent cannot broaden authority by writing new source text.

## 2. Language shape

To preserve existing human approvals and legacy mission digests, v1.8 introduces a standalone *epistemic overlay* compiled with its pinned mission source. Like v1.7's `composition`, the overlay is OctoLang source but is not embedded in the legacy `mission` parser yet. This is intentional backward compatibility, not a hidden extension to v1.5 runtime semantics.

```text
// community-epistemic.octo
 epistemic learning_materials {
   knowledge accreditation {
     type Verified<Credential>
     source "community-registry"
     subject "supplier"
     max_age 30d
   }
   knowledge availability {
     type Observed<Status>
     source "availability-observer"
     subject "supplier"
     max_age 15m
   }
   guard find_supplier {
     require accreditation
     on_unknown DENY
   }
   // Every root-mission task must have exactly one guard.
 }
```

`epistemic`, `knowledge`, `guard`, `type`, `source`, `subject`, `max_age`, `require` and `on_unknown` are case-sensitive. Whitespace and `#` / `//` comments are insignificant. All fields are mandatory, order-independent, and appear once each. Unknown fields or declarations fail compilation. Identifiers are ASCII `[A-Za-z_][A-Za-z0-9_-]*`. Strings are double quoted with JSON-style `\\`, `\\"`, `\\n`, `\\r`, and `\\t` escapes.

```ebnf
Epistemic = "epistemic" Identifier "{" { Knowledge | Guard } "}" ;
Knowledge = "knowledge" Identifier "{" "type" EpistemicType "source" String
            "subject" String "max_age" Natural AgeUnit "}" ;
Guard     = "guard" TaskIdentifier "{" "require" KnowledgeIdentifier
            "on_unknown" ("DENY" | "ESCALATE") "}" ;
EpistemicType = State "<" ValueType ">" ;
State     = "Verified" | "Observed" | "Inferred" | "Disputed" | "Expired" | "Unverified" ;
ValueType = "Credential" | "Status" | "Score" | "Claim" | "Measurement" | "Document" ;
AgeUnit   = "m" | "h" | "d" ;
```

A file may contain at most 32 `knowledge` and 32 `guard` declarations, a total of ≤2,000 tokens and 65,536 code units. All root-mission tasks require exactly one guard; no new task is introduced by an overlay. `max_age` must be within 1 minute to 365 days.

## 3. Meaning of the six epistemic states

| Type tag | Meaning in this implementation | Use as a task guard |
|---|---|---|
| `Verified<T>` | Fresh Ed25519 claim from an independently pinned issuer allowed to assert the specified type for the exact mission, subject and knowledge declaration | Yes; still only context-admissible |
| `Observed<T>` | Fresh signed observation from a pinned observer; does not establish outcome truth | Read-only `research` or `validate` only |
| `Inferred<T>` | Fresh signed inference with required directly signed fresh `Verified`/`Observed` parent evidence | Read-only `research` only |
| `Disputed<T>` | An unresolved disagreement; can also be derived when valid claims for one knowledge name have conflicting value digests | No |
| `Expired<T>` | Older/out-of-window claim; also derived when all known claims are stale | No |
| `Unverified<T>` | No accepted current evidence; also the absence of a claim | No |

Crucially, `Verified` means **attributable to a pinned, permitted issuer under this small trust model**. It is not a mathematical proof of truth, a certificate-chain verifier, W3C VC status evaluation, trusted timestamping, KERI, or a Groth16 proof. The `valueDigest` commits to bytes known to the issuer; the verifier does not possess or inspect the underlying secret or real-world fact.

Signed observation and inference alone **never** promote a requirement of type `Verified<T>`. The compiler additionally rejects weaker types for tasks with external-service effects or `intent.record`/`audit` semantics. An epistemic guard never broadens authority even for read-only operations.

## 4. Proof-carrying context input

The read-only evaluator takes `rootIR`, the epistemic `ir`/`irDigest`, a verifier-supplied clock, an independently specified `expectedSubject`, **trusted issuer public keys and allowed states configured out of band**, and signed claim objects. Each object's signed payload has exactly these fields:

`schema`, `missionIRDigest`, `knowledge`, `kind`, `valueType`, `source`, `subject`, `valueDigest`, `observedAt`, `validUntil`, `parents`.

`schema = octolang.epistemic-claim.v1.8`. Timestamps are Unix milliseconds; `parents` is a sorted array of parent payload SHA-256 digests. Only inferences can carry parents. Parents must be present, fresh, independently authenticated `Verified`/`Observed` claims for the same subject and cannot be disputed. Each claim signature uses Ed25519 over the project's canonical JSON representation of the payload. Duplicate signed payload digests are invalid.

No signed claims: `UNVERIFIED`. All claims stale: `EXPIRED`. Contradictory **fresh signed** value digests for a single knowledge label: `DISPUTED`. Invalid signatures, issuer pins, schema, type/subject/mission binding, future timestamps or inference dependencies: **whole assessment invalid, DENY**. Contradictory sources are not silently picked by confidence or majority vote. This sample model does not implement multi-source policy arbitration.

For a task, matching verified evidence returns `CONTEXT_ADMISSIBLE_ONLY`; otherwise the declared `DENY` or `ESCALATE` response. None of these statuses is an execution token or a VCC `ALLOW` decision. A real tool runner must recompute evidence state and check human-approved scope **immediately before the effect**, not just when the plan was created.

## 5. Typed IR and canonical digest

IR schema: `octolang.epistemic-ir.v1.8`; artifact schema: `octolang.epistemic-artifact.v1.8`.
The IR binds to the v1.6 root typed mission IR digest. It is hash-domain-separated using `SHA256("OctoLang Epistemic IR v1.8\\n" + canonicalJSON(ir))`. Whitespace, comments and declaration order cannot change the digest; changing an issuer, type, guard, freshness ceiling or mission changes it.

The independent structural/semantic verifier recomputes declared guard relationships from the pinned root and forbids injected execution authority, unguarded tasks, unknown knowledge/task references, and weak evidence for effectful tasks, including when an attacker recalculates the hash. The source verifier additionally recompiles source and compares the exact complete artifact, including source hashes.

The JSON schema supplied with this release checks structural shape only. The Node.js semantic verifier is authoritative for cross-references and restrictions. This is a draft conformance specification, not a proven correct implementation.

## 6. Limitations and future design questions

- The v1.8 overlay/evaluator is not yet wired as a mandatory live VCC gate into v1.0–v1.5 execution, remote federation or Midnight. Running those older flows does **not** automatically enforce v1.8 requirements.
- No issuer revocation registry, threshold/multi-party attestation, trusted timestamp service, credential format validation, confidential disclosure protocol or intercommunity consensus is included.
- Trust pins must originate outside the AI and the mission. An issuer can sign false claims; independent fact-checking and real-world measurement are separate concerns.
- Inference provenance is checked by digest and signer, not by reproducing an AI's mathematical or logical reasoning. An inference is never a mathematical proof.
- Cross-agent privacy-flow typing, contested-source resolution policies, stable evidence snapshots, provenance graph validation across federations and revocation-aware VCC checks are future work.

## 7. Commands

```sh
npm test
npm run epistemic:check
npm run epistemic:conformance
npm run epistemic:demo
node bin/octolang-epistemic.js compile examples/community-epistemic.octo examples/community-proofs.octo artifact.json
node bin/octolang-epistemic.js verify examples/community-epistemic.octo examples/community-proofs.octo artifact.json
```
