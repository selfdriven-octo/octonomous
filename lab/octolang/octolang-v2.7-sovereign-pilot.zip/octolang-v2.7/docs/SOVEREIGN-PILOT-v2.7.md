# OctoLang v2.7 — Three-role sovereign deployment and acceptance guide

**Status:** three independent processes with isolated signing keys and mTLS validated on one Linux container. A real three-physical-machine run has **not** been performed. This is a pilot; do not use it for funds or high-consequence actions.

## Trust model

| Host | Responsibility | Secrets that stay on that host |
| --- | --- | --- |
| A — Execution | Canonical score, controller, VCC, ledger, effects, client mTLS identity | Controller Ed25519 key, VCC key, client TLS key |
| B — Governance | Check exact score/revision evidence, sign bounded activation, hold independently stored signed-state high-water checkpoint | Governor Ed25519 key and governance HTTPS key |
| C — Witness | Verify signed controller requests, witness monotonic START/COMPLETE snapshots, store signed checkpoint history | Witness Ed25519 key and witness HTTPS key |

Each role should be under a separate administrator/account on physically separate machines or independent VMs with storage and key custody isolated. Merely using three processes or containers on one host does not provide a separate trust domain.

The local harness also creates synthetic observer and reviewer signing keys on Host A. **Real community governance requires those signing identities and approval workflow to be provisioned independently.** The witness attests to *signed controller-reported state*, not direct observation of real-world effects.

## Run the proven local rehearsal

Requires Node.js >=22 and OpenSSL. No third-party npm install is required for the tested harness.

```bash
npm run sovereign:demo
npm run sovereign:test
npm run test:isolated
```

The demo starts two child Node.js services (governance and witness), each using independently generated persistent Ed25519 signing keys and mutual-TLS certificates, with the executor in the parent process. The signed human review/VCG/VCC inputs are synthetic. It performs one `mission.local.record-intent` file write; it never transfers ADA or initiates a payment.

## Preparing actual machines

1. Provision each machine with Node.js 22+, restricted OS accounts, hardened storage and mutually reachable TCP/TLS endpoints. Do not expose the research services directly to the open Internet; prefer a controlled, authenticated private network.
2. On **Governance host B**, generate the governor key **on B only**:

   ```bash
   node language/v2.7/provision.js /opt/octolang/governance
   ```

   Never export `governor-private.pem` to another host. Copy *only* `governor-public.pem` through a separately authenticated channel. The operator must compare key fingerprints out of band.
3. On **Witness host C**, create a separate witness identity:

   ```bash
   node language/v2.4/provision.js /opt/octolang/witness
   ```

   Keep `witness-private.pem` on C. Compare the public-key fingerprint out of band.
4. Create **two independent service PKIs** or use your existing managed PKI. Provision dedicated HTTPS server certificates on B and C and controller client certificates on A. For each connection pin the *exact server certificate fingerprint* and configure server-side client certificate allowlisting. The local `testPki()` function generates short-lived, unencrypted, test-only keys; **do not distribute that test PKI in production**.
5. On B, create `governance-config.json` with absolute paths. Keys and templates:

   ```json
   {
     "directory":"/opt/octolang/governance/journal",
     "scoreSource":"/opt/octolang/governance/score.octo",
     "governorPrivateKey":"/opt/octolang/governance/governor-private.pem",
     "governorPublicKey":"/opt/octolang/governance/governor-public.pem",
     "controllerPublicKey":"/opt/octolang/governance/controller-public.pem",
     "witnessPublicKey":"/opt/octolang/governance/witness-public.pem",
     "pins": {"observer":"PEM_PUBLIC_KEY", "reviewer":"PEM_PUBLIC_KEY", "governor":"PEM_PUBLIC_KEY", "vcc":"PEM_PUBLIC_KEY", "controller":"PEM_PUBLIC_KEY"},
     "serverKey":"/opt/octolang/governance/tls/server.key",
     "serverCert":"/opt/octolang/governance/tls/server.crt",
     "clientCa":"/opt/octolang/governance/tls/ca.crt",
     "clientFingerprint":"64-char-sha256-client-cert-digest",
     "host":"10.0.0.20", "port":8444
   }
   ```

   Use the exact byte-identical authorised `.octo` score on A and B. The `pins` object must contain actual PEM public keys, not the literal placeholders above. Start B:

   ```bash
   node language/v2.7/service.js /opt/octolang/governance/governance-config.json
   ```

6. On C, follow the existing `docs/REMOTE-WITNESS-v2.4.md` (or `language/v2.4/service.js`) with a witness config containing its absolute journal path, score digest, controller public key, signing keys, TLS paths and pinned controller client certificate digest. Start C:

   ```bash
   node language/v2.4/service.js /opt/octolang/witness/witness-config.json
   ```

7. On A, create a read-only `connectivity.json`, with its own client TLS cert/key paths for each endpoint:

   ```json
   {
     "scoreDigest":"64-char-hex-SHA256",
     "governance":{"url":"https://governance.example.internal:8444/", "clientCert":"/secure/gov-client.crt", "clientKey":"/secure/gov-client.key", "ca":"/secure/gov-ca.crt", "serverFingerprint":"64-char-hex-SHA256", "governorPublicKey":"/secure/governor-public.pem"},
     "witness":{"url":"https://witness.example.internal:8443/", "clientCert":"/secure/witness-client.crt", "clientKey":"/secure/witness-client.key", "ca":"/secure/witness-ca.crt", "serverFingerprint":"64-char-hex-SHA256", "witnessPublicKey":"/secure/witness-public.pem"}
   }
   ```

   ```bash
   node language/v2.7/operator.js /secure/connectivity.json
   ```

   This verifies signed governance status and the witness's signed checkpoint chain over pinned mutual TLS. **It is deliberately read-only and never grants execution authority.**

8. For execution from A, wire the existing `RemoteWitness` and `RemoteExecutionController` to the remote C endpoint, plus `GovernanceClient` to B. The tested wiring is in `language/v2.7/pilot.js`. It requests activation from B using the exact signed review, then calls B's `PRE_EFFECT` gate after C witnesses `START`. The current release provides that integration as source, not a turnkey remote deployment CLI; actual A/B/C integration is a required acceptance task.

## Operational acceptance tests on three machines (not yet executed)

- Verify the three hosts belong to independently controlled OS/cloud accounts and each private Ed25519 key physically remains on its owner host.
- Compare **both** service certificate fingerprints and signing public-key fingerprints out of band. Prevent the controller from re-enrolling its own keys.
- Execute the bounded local intent once. Independently validate the ledger, execution START/COMPLETE, C's signed checkpoints, and B's pre-effect high-water record. Confirm exactly one effect file and one consumed reservation.
- Kill B **before** the pre-effect check. The effect must be denied and marked unresolved without refund or automatic retry.
- Kill C **before** witnessing START. Effect must not happen. Kill C **after** the local effect and before completion acknowledgment; use v2.5 evidence-only reconciliation without a second invocation.
- Revert A's state journal and seal to an older valid pair. B must reject history that no longer extends its previously checkpointed state, while C must independently refuse a witness fork.
- Restart B and C; verify the signed checkpoint high-water marks are monotonic and the existing execution is still independently auditable.
- Rotate a service TLS certificate. The old pin must reject it; install its replacement pin through a separately approved operation and confirm the signed journals are unchanged. **Ed25519 governor root-signing-key rotation is not supported by the v2.2 ledger without an explicit mandate/pin migration.**
- Validate no private signing keys or raw secrets are in any signed network payload or logs. Check process, file and access permissions.
- Arrange durable backups and **independently administered**, append-only checkpoints. Reverting both hosts' trusted checkpoint stores is beyond the demonstrated rollback threat model.

## Safety boundaries / remaining findings

- A remote signature proves that its key signed a bounded state claim. Neither remote witnessing nor a signed outcome establishes objective real-world truth.
- The governance service maintains a monotonic signed-ledger history high-water record. The witness separately maintains a monotonic signed execution history. Safety assumes these **different trust domains cannot both be rewritten or compromised together**.
- The pilot's governance service stores complete signed ledger/witness history; avoid embedding sensitive private context in such records. Hardening requires retention limits, redaction and privacy review.
- `writeDurable()` uses fsync and atomic rename but is not a replacement for a replicated transactional store or power-loss-tested filesystem.
- Failed execution is not automatically retried. Confirmation requires an independent recovery process under v2.5.
- TLS and identity rotation need independently signed pin migrations, revocation and multi-admin lifecycle controls before production deployment.
- No Cardano or Midnight network calls, financial transactions or generic tool execution are enabled by this pilot.
