# OctoLang v2.4 — Remote Witness Deployment Runbook

## A. Tested demonstration on one machine

Requires Node.js 22+, `openssl` on PATH. No npm dependencies, Docker or blockchain required.

```bash
npm run remote:demo
npm run remote:test
npm run test:isolated
```

The demonstration creates a temporary test CA and mTLS client/server certificates, starts an **independent witness process** with its own Ed25519 identity and persistent witness-home directory, then verifies the reviewed score, VCC reservation, remote `START` acknowledgment, local Octonomous action, remote `COMPLETE` acknowledgment and offline public-key audit. It records one local purchase *intent*; it performs no payment. The witness process is not deployed to a different physical host by this test.

## B. Two machines / different administrators (operator integration guide; untested here)

1. Prepare the execution host (A) with a reviewed native score, signed role/governance/VCC keys, an OctoLang activation ledger and local effects directory. Its controller signing public key and score SHA-256 digest must be fixed **before** enrolment.
2. On witness host (B), provision its own Ed25519 key using `node language/v2.4/provision.js /srv/octolang/witness`. The owner of host A must receive and verify the **public** witness key via a separate trusted channel. Do not move B's private key to A.
3. Issue **mutually trusted** TLS credentials to A and B through independently controlled certificate issuance. Pin the B server certificate's SHA-256 digest at A and A client certificate's SHA-256 digest at B. Securely transfer only the appropriate CA roots and public keys. The demo's `testPki()` is for localhost **tests only**.
4. On B, create a configuration from `examples/remote-witness-server.example.json`, referencing files local to B. Set `host` to a specifically controlled interface. Use a private network/VPN and firewall allowlist; do not publish a bare management port to the Internet.
5. On B, start `node language/v2.4/service.js /srv/octolang/witness/config.json` as a least-privilege service with a durable, non-shared data volume, key isolation, logs and backups. Require both mTLS and pinned client identity. The service prints a readiness JSON line.
6. On A, configure `RemoteWitness` with B's exact HTTPS URL (trailing `/`), A's mTLS client key/certificate, B's CA and certificate fingerprint, A's controller Ed25519 signer, B's separately pinned witness public key, the exact score digest and a durable *local mirror* directory. Import `RemoteExecutionController` from `language/v2.4/execution.js` with the pre-existing trusted `ActivationGate`, remote client and pinned witness key. `await controller.bootstrap()` enrols the exact currently approved score/ledger state; subsequent governance mutations require `await controller.syncGovernance()`. Enrolment is an explicit trust ceremony, not a substitute for verifying the starting state.
7. Authorise execution using an independently signed `ALLOW` receipt and fresh mission claims, then call `await controller.execute({request,vccReceipt,missionParams})`. Only the local `intent.record` tool is available. Calls after an ambiguous `START` require reconciliation, not retry.
8. For read-only inspection from a trusted audit host with a permitted mTLS client certificate, fill out `examples/remote-witness-inspect.example.json`, then call `node language/v2.4/inspect.js /secure/inspect.json`. Remove `controllerDirectory`, `scoreSource` and `controllerPins` fields if only the remote signed checkpoint history should be checked.
9. Independently export controller public-key pins, signed ledger/events/effect record and remote signed checkpoints to an auditor. Use the v2.3 verifier or v2.4 inspector. Never export private witness/governance/treasury signing keys.

**Configuration and security checks:**

- TLS must validate both the issuing root and the **exact pinned leaf fingerprint**. Use certificates with the correct SAN hostname or IP and documented validity/rotation.
- The witness enrolment is intentionally immutable per journal (`scoreDigest`, `controllerPublicKey`, `witnessPublicKey`). Rotate via a new governed epoch, not an unreviewed file edit.
- Persist the witness journal and nonce claims on storage B controls. Back up independently. A should durably retain its previous signed witness history to detect rollback and forks, even if B claims an older valid history after restarting.
- Confirm correct time synchronisation (request signatures expire in ≤60 seconds) and protect against clock rollback. Do not retry when the witness returns an ambiguous error after accepting a nonce.
- Operators must test actual two-host mTLS, firewall, restart and partition handling **before** calling the system production-ready. The reference `service.js` does not provide comprehensive rate limiting, load balancing, lifecycle supervision, HSM integration or distributed transactional consensus.

## C. API and security model

See `docs/OCTOLANG-LANGUAGE-v2.4.md` for the exact snapshot, signed request, durability and proof boundaries. The API deliberately does not offer arbitrary tool invocation, signing on behalf of another community, or wallet custody.
