'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const {setupRemote}=require('../language/v2.4/demo');
const {RecoveryCoordinator,attest,approve,inspectCase,recoveryJournal}=require('../language/v2.5/reconcile');
const {readExecution}=require('../language/v2.4/execution');
const {hash}=require('../language/v2.2');
async function fixture(t){
  const f=await setupRemote();t.after(()=>f.remote.close());
  const pins={...f.pins,witness:f.remote.witnessPublicKey};
  const coordinator=new RecoveryCoordinator({controller:f.controller,pins});
  return {f,pins,coordinator};
}
function papers(f,c,action='WITNESS_EXISTING_COMPLETION'){
  const obs=attest(c,f.actors.observer.privateKey);
  return {caseData:c,observer:obs,approval:approve(c,obs,action,f.actors.governor.privateKey)};
}
async function lostCompletion(f){
  const original=f.witness.attest.bind(f.witness);
  f.witness.attest=(snapshot,head)=>snapshot.executionSequence===2?Promise.reject(Error('simulated lost completion')):original(snapshot,head);
  await assert.rejects(f.controller.execute({...f.decision,missionParams:f.missionParams}),/lost completion/);
  f.witness.attest=original;
}
async function lostStart(f){
  const original=f.witness.attest.bind(f.witness);
  f.witness.attest=(snapshot,head)=>snapshot.executionSequence===1?Promise.reject(Error('simulated lost start')):original(snapshot,head);
  await assert.rejects(f.controller.execute({...f.decision,missionParams:f.missionParams}),/lost start/);
  f.witness.attest=original;
}
function effectCount(f){const p=path.join(f.directory,'effects');return fs.existsSync(p)?fs.readdirSync(p).length:0;}
test('v2.5 recover already completed intent with lost witness, NEVER rerun tool',async t=>{
  const {f,coordinator,pins}=await fixture(t);await lostCompletion(f);
  const nonce=f.decision.request.nonce,before=await coordinator.inspect(nonce);
  assert.equal(before.classification,'COMPLETE_NEEDS_WITNESS');assert.equal(effectCount(f),1);
  const result=await coordinator.reconcile(papers(f,before));
  assert.equal(result.status,'EXISTING_COMPLETION_WITNESSED');assert.equal(result.executedAgain,false);
  assert.equal(effectCount(f),1);assert.equal(f.controller.verify().valid,true);
  const audit=await coordinator.audit();assert.equal(audit.valid,true);assert.equal(audit.reconciliationSequence,1);
  assert.equal(audit.outcomes[nonce].witnessHead,result.checkpointHead);
  assert.equal(recoveryJournal({directory:f.directory,pins}).valid,true);
  assert.equal((await coordinator.inspect(nonce)).classification,'ALREADY_WITNESSED');
  await assert.rejects(f.controller.execute({...f.decision,missionParams:f.missionParams}),/replayed reservation/);
});
test('v2.5 unknown effect remains on indefinite hold; no budget refund',async t=>{
  const {f,coordinator}=await fixture(t);await lostStart(f);
  const c=await coordinator.inspect(f.decision.request.nonce);assert.equal(c.classification,'START_NOT_WITNESSED');
  assert.deepEqual(c.allowed,['HOLD']);const before=f.gate.status().state;
  const r=await coordinator.reconcile(papers(f,c,'HOLD'));assert.equal(r.status,'UNRESOLVED_HOLD');
  assert.equal(f.gate.status().state.head,before.head);assert.equal(effectCount(f),0);
  assert.equal((await coordinator.audit()).executionAudit.valid,false);
  await assert.rejects(f.controller.execute({...f.decision,missionParams:f.missionParams}),/witness checkpoint/);
});
test('v2.5 START witnessed but effect unknown is still held',async t=>{
  const {f,coordinator}=await fixture(t);const orig=f.witness.checkLive.bind(f.witness);
  f.witness.checkLive=async()=>{throw Error('after START, tool blocked');};
  await assert.rejects(f.controller.execute({...f.decision,missionParams:f.missionParams}),/tool did not complete|after START/);
  f.witness.checkLive=orig;
  const c=await coordinator.inspect(f.decision.request.nonce);
  assert.equal(c.classification,'UNKNOWN_AFTER_START');
  assert.deepEqual(c.allowed,['HOLD']);
  const r=await coordinator.reconcile(papers(f,c,'HOLD'));assert.equal(r.executedAgain,false);
});
test('v2.5 effect recorded without controller COMPLETE is not automatically finalised',async t=>{
  const {f,coordinator}=await fixture(t);const original=f.controller._append.bind(f.controller);
  f.controller._append=(kind,p)=>{if(kind==='COMPLETE')throw Error('lost controller completion');return original(kind,p);};
  await assert.rejects(f.controller.execute({...f.decision,missionParams:f.missionParams}),/lost controller completion/);
  f.controller._append=original;
  const c=await coordinator.inspect(f.decision.request.nonce);assert.equal(c.classification,'EFFECT_PRESENT_WITHOUT_COMPLETE');
  const r=await coordinator.reconcile(papers(f,c,'HOLD'));assert.equal(r.status,'UNRESOLVED_HOLD');
  assert.equal(effectCount(f),1);assert.equal(readExecution({directory:f.directory,publicKey:f.pins.controller}).actions[c.nonce].status,'IN_PROGRESS');
});
test('v2.5 forged observer or governor cannot witness completion',async t=>{
  const {f,coordinator}=await fixture(t);await lostCompletion(f);const c=await coordinator.inspect(f.decision.request.nonce);
  const p=papers(f,c),evil=crypto.generateKeyPairSync('ed25519');
  const a=attest(c,evil.privateKey),g=approve(c,a,'WITNESS_EXISTING_COMPLETION',f.actors.governor.privateKey);
  await assert.rejects(coordinator.reconcile({caseData:c,observer:a,approval:g}),/observation/);
  await assert.rejects(coordinator.reconcile({...p,approval:approve(c,p.observer,'WITNESS_EXISTING_COMPLETION',evil.privateKey)}),/governance/);
  assert.equal((await coordinator.inspect(c.nonce)).classification,'COMPLETE_NEEDS_WITNESS');
});
test('v2.5 case tampering / stale case fails closed',async t=>{
  const {f,coordinator}=await fixture(t);await lostCompletion(f);const c=await coordinator.inspect(f.decision.request.nonce),p=papers(f,c);
  await assert.rejects(coordinator.reconcile({...p,caseData:{...c,ledgerHead:'0'.repeat(64)}}),/stale/);
  await assert.rejects(coordinator.reconcile({...p,observer:{...p.observer,payload:{...p.observer.payload,effectDigest:'f'.repeat(64)}}}),/observation/);
});
test('v2.5 replayed approval and duplicate reconciliation are refused',async t=>{
  const {f,coordinator}=await fixture(t);await lostCompletion(f);const c=await coordinator.inspect(f.decision.request.nonce),p=papers(f,c);
  await coordinator.reconcile(p);
  await assert.rejects(coordinator.reconcile(p),/stale|already reconciled/);
});
test('v2.5 expired review does not advance remote witness',async t=>{
  const {f,coordinator}=await fixture(t);await lostCompletion(f);const c=await coordinator.inspect(f.decision.request.nonce);
  const obs=attest(c,f.actors.observer.privateKey,Date.now()-700000),approval=approve(c,obs,'WITNESS_EXISTING_COMPLETION',f.actors.governor.privateKey);
  await assert.rejects(coordinator.reconcile({caseData:c,observer:obs,approval}),/expired/);
  assert.equal((await coordinator.inspect(c.nonce)).classification,'COMPLETE_NEEDS_WITNESS');
});
test('v2.5 distinct identities are mandatory',async t=>{
  const {f,coordinator,pins}=await fixture(t);
  assert.throws(()=>new RecoveryCoordinator({controller:f.controller,pins:{...pins,observer:pins.governor}}),/independent/);
  assert.throws(()=>new RecoveryCoordinator({controller:f.controller,pins:{...pins,witness:pins.controller}}),/independent/);
});
test('v2.5 cannot repair complete with modified effect file',async t=>{
  const {f,coordinator}=await fixture(t);await lostCompletion(f);const c=await coordinator.inspect(f.decision.request.nonce);
  const file=path.join(f.directory,'effects',hash('intent-file:'+c.nonce)+'.json'),obj=JSON.parse(fs.readFileSync(file));
  obj.amount='999';fs.writeFileSync(file,JSON.stringify(obj));
  assert.equal((await coordinator.inspect(c.nonce)).valid,false);
  await assert.rejects(coordinator.reconcile(papers(f,c)),/stale|unverifiable/);
});
test('v2.5 signed reconciliation journal detects tampering and seal loss',async t=>{
  const {f,coordinator,pins}=await fixture(t);await lostStart(f);const c=await coordinator.inspect(f.decision.request.nonce);
  await coordinator.reconcile(papers(f,c,'HOLD'));
  const journal=path.join(f.directory,'reconciliations.jsonl'),text=fs.readFileSync(journal,'utf8');
  fs.writeFileSync(journal,text.replace('UNRESOLVED','FAKE').replace('HOLD','RETRY'));
  assert.equal(recoveryJournal({directory:f.directory,pins}).valid,false);
});
test('v2.5 signed reconciliation journal detects missing seal',async t=>{
  const {f,coordinator,pins}=await fixture(t);await lostStart(f);const c=await coordinator.inspect(f.decision.request.nonce);
  await coordinator.reconcile(papers(f,c,'HOLD'));
  fs.unlinkSync(path.join(f.directory,'reconciliation-seal.json'));
  assert.equal(recoveryJournal({directory:f.directory,pins}).valid,false);
});
test('v2.5 remote witness offline leaves signed completion unreconciled',async t=>{
  const {f,coordinator}=await fixture(t);await lostCompletion(f);const c=await coordinator.inspect(f.decision.request.nonce);
  await f.remote.close();
  await assert.rejects(coordinator.reconcile(papers(f,c)),/ECONNREFUSED|socket|connect|timeout/i);
  assert.equal(effectCount(f),1);
  assert.equal(recoveryJournal({directory:f.directory,pins:{...f.pins,witness:f.remote.witnessPublicKey}}).sequence,0);
});
test('v2.5 witnessed complete action is not eligible for another repair',async t=>{
  const {f,coordinator}=await fixture(t);await f.controller.execute({...f.decision,missionParams:f.missionParams});
  const c=await coordinator.inspect(f.decision.request.nonce);
  assert.equal(c.classification,'ALREADY_WITNESSED');assert.deepEqual(c.allowed,[]);
  assert.throws(()=>approve(c,attest(c,f.actors.observer.privateKey),'WITNESS_EXISTING_COMPLETION',f.actors.governor.privateKey),/not allowed/);
});
test('v2.5 independent offline verifier reproduces completed recovery',async t=>{
  const {f,coordinator,pins}=await fixture(t);await lostCompletion(f);const c=await coordinator.inspect(f.decision.request.nonce);
  await coordinator.reconcile(papers(f,c));
  const {verifyRecoveryBundle}=require('../language/v2.5/reconcile');
  const cfg=coordinator.config(),r=verifyRecoveryBundle(cfg);assert.equal(r.valid,true,r.reason);
  assert.equal(r.reconciled,1);assert.equal(r.budgetReleased,false);
});
test('v2.5 offline recovery audit detects altered effect after reconciliation',async t=>{
  const {f,coordinator}=await fixture(t);await lostCompletion(f);const c=await coordinator.inspect(f.decision.request.nonce);
  await coordinator.reconcile(papers(f,c));
  const ef=path.join(f.directory,'effects',hash('intent-file:'+c.nonce)+'.json');
  const x=JSON.parse(fs.readFileSync(ef));x.amount='10000';fs.writeFileSync(ef,JSON.stringify(x));
  const {verifyRecoveryBundle}=require('../language/v2.5/reconcile');
  assert.equal(verifyRecoveryBundle(coordinator.config()).valid,false);
});
test('v2.5 offline recovery audit rejects local ledger rollback relative to remote witness',async t=>{
  const {f,coordinator}=await fixture(t);const before=fs.readFileSync(path.join(f.directory,'events.jsonl'));
  const seal=fs.readFileSync(path.join(f.directory,'state-seal.json'));
  await f.controller.execute({...f.decision,missionParams:f.missionParams});
  fs.writeFileSync(path.join(f.directory,'events.jsonl'),before);
  fs.writeFileSync(path.join(f.directory,'state-seal.json'),seal);
  const {verifyRecoveryBundle}=require('../language/v2.5/reconcile');
  assert.equal(verifyRecoveryBundle(coordinator.config()).valid,false);
});
