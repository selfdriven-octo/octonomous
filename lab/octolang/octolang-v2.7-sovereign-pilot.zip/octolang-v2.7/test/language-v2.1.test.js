'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),crypto=require('node:crypto'),path=require('node:path');
const {compileScore,verifyScore,parseScore,sha}=require('../language/v2.1');
const {OBS_SCHEMA,REVIEW_SCHEMA,digestObservation,compileRevision,verifyRevision,verifyReviewedRevision,createReview,createObservation}=require('../language/v2.1/refinement');
const root=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(root,'community-score.octo'),'utf8');
let baseline;
function base(){return baseline??=compileScore(source);}
const observer=crypto.generateKeyPairSync('ed25519'),reviewer=crypto.generateKeyPairSync('ed25519'),rogue=crypto.generateKeyPairSync('ed25519');
const pem=k=>k.publicKey.export({format:'pem',type:'spki'}).toString();
const pins={observer:pem(observer),reviewer:pem(reviewer)};
const now=Date.UTC(2026,9,21,12,0,0),iso=t=>new Date(t).toISOString();
function fixture({value=4,expired=false,actor=observer,measure='cost-per-run',baseDigest=base().irDigest}={}){
  const payload={schema:OBS_SCHEMA,scoreDigest:baseDigest,metric:measure,value,unit:'budget-units',
    sampleDigest:sha('external sample snapshot'),observedAt:iso(now-60000),validUntil:iso(expired?now-1000:now+600000),kind:'OBSERVATION'};
  const observation=createObservation(payload,actor.privateKey),revisionSource=`revision lower_cost { base "${base().irDigest}" evidence "${digestObservation(payload)}" trigger "cost-per-run" above 3 tune scout_node runs 1 budget 1 }`;
  const revisionArtifact=compileRevision(revisionSource,base());
  const review=createReview({schema:REVIEW_SCHEMA,scoreDigest:base().irDigest,revisionDigest:revisionArtifact.irDigest,evidenceDigest:digestObservation(payload),reviewedAt:iso(now),validUntil:iso(now+300000),decision:'APPROVE_PROPOSAL_ONLY'},reviewer.privateKey);
  return {scoreSource:source,scoreArtifact:base(),revisionSource,revisionArtifact,observation,review,pins,now};
}
test('native score compiles and verifies with four linked languages',()=>{
  const a=base();assert.equal(a.ir.bindings.length,4);assert.equal(a.ir.worstCaseBudgetUnits,7);assert.equal(verifyScore(source,a).valid,true);
  assert.equal(a.ir.governance.executionAllowed,false);
});
test('native score stable semantic digest with comments and harmless declaration reorder',()=>{
  const extra='// harmless\n'+source;
  assert.equal(compileScore(extra).irDigest,base().irDigest);
  const p=parseScore(source);
  const rejoined=['score learning_community {', ...p.bindings.slice().reverse(),...p.modules,...['assurance','mission','epistemic','composition'].map(x=>p.layers[x]),'}'].join('\n');
  assert.equal(compileScore(rejoined).irDigest,base().irDigest);
});
test('score digest changes when a spending constraint changes',()=>{
  assert.notEqual(compileScore(source.replaceAll('max 100 ADA','max 90 ADA')).irDigest,base().irDigest);
});
test('unknown score declarations fail closed',()=>assert.throws(()=>compileScore(source.replace('score learning_community {','score learning_community { grant unlimited { }')),/unknown score declaration/));
test('duplicated layer fails closed',()=>assert.throws(()=>compileScore(source.replace('score learning_community {','score learning_community { mission empty { }')),/duplicate layer/));
test('modified compiled artifacts rejected even if rehashed',()=>{
  const a=structuredClone(base());a.ir.governance.executionAllowed=true;
  a.irDigest=require('../language/v2.1').digestScore(a.ir);
  assert.equal(verifyScore(source,a).valid,false);
});
test('refinement reduces a binding and retains all original roles and capabilities',()=>{
  const f=fixture();const r=f.revisionArtifact.ir;
  assert.equal(r.worstCaseBudgetUnits,6);
  for(const b of r.effectiveBindings){const previous=base().ir.bindings.find(x=>x.name===b.name);assert.equal(b.role,previous.role);assert.equal(b.capability,previous.capability);}
  assert.equal(verifyRevision(f.revisionSource,source,base(),f.revisionArtifact).valid,true);
  assert.equal(r.governance.executionAllowed,false);
});
test('refinements cannot increase budget',()=>{
  const f=fixture();assert.throws(()=>compileRevision(f.revisionSource.replace('budget 1','budget 6'),base()),/widens mandate/);
});
test('refinements cannot add an undeclared binding',()=>{
  const f=fixture();assert.throws(()=>compileRevision(f.revisionSource.replace('scout_node','admin_node'),base()),/unknown binding/);
});
test('refinement cannot grant extra runs',()=>{
  const f=fixture();assert.throws(()=>compileRevision(f.revisionSource.replace('runs 1','runs 2'),base()),/widens mandate/);
});
test('refinement cannot become a no-op',()=>{
  const f=fixture();assert.throws(()=>compileRevision(f.revisionSource.replace('budget 1','budget 2'),base()),/must tighten/);
});
test('signed independent observation and human review accepts matching bounded refinement',()=>{
  assert.equal(verifyReviewedRevision(fixture()).valid,true);
});
test('forged observation rejected by pinned keys',()=>{
  const f=fixture({actor:rogue});assert.equal(verifyReviewedRevision(f).valid,false);
});
test('altered observation payload rejected',()=>{
  const f=fixture();f.observation.payload.value=99;assert.equal(verifyReviewedRevision(f).valid,false);
});
test('observation not meeting numeric trigger rejected',()=>{
  assert.equal(verifyReviewedRevision(fixture({value:3})).valid,false);
});
test('expired observation rejected',()=>{
  assert.equal(verifyReviewedRevision(fixture({expired:true})).valid,false);
});
test('different score-bound observation rejected',()=>{
  assert.equal(verifyReviewedRevision(fixture({baseDigest:'0'.repeat(64)})).valid,false);
});
test('observation cannot use a different metric',()=>{
  assert.equal(verifyReviewedRevision(fixture({measure:'unrelated'})).valid,false);
});
test('forged approval rejected',()=>{
  const f=fixture();f.pins={...pins,reviewer:pem(rogue)};assert.equal(verifyReviewedRevision(f).valid,false);
});
test('same signing identity cannot act as both observer and reviewer even with altered PEM formatting',()=>{
  const f=fixture();f.pins={observer:pem(observer),reviewer:pem(observer)+'\n'};assert.equal(verifyReviewedRevision(f).valid,false);
});
test('altered revision digest rejected with original review',()=>{
  const f=fixture();f.revisionArtifact.irDigest='c'.repeat(64);assert.equal(verifyReviewedRevision(f).valid,false);
});
test('approval cannot be transplanted to altered revision',()=>{
  const f=fixture();f.revisionSource=f.revisionSource.replace('budget 1','budget 0');f.revisionArtifact=compileRevision(f.revisionSource,base());assert.equal(verifyReviewedRevision(f).valid,false);
});
test('review expired rejected',()=>{
  const f=fixture();f.now+=400000;assert.equal(verifyReviewedRevision(f).valid,false);
});
test('no runtime, network or wallet permission is implied by any artifact',()=>{
  const f=fixture(),valid=verifyReviewedRevision(f);
  assert.deepEqual(Object.keys(valid).sort(),['decision','revisionDigest','valid']);
  assert.match(valid.decision,/NOT_EXECUTION_AUTHORITY/);
  assert.equal(f.scoreArtifact.ir.governance.grantsImplied,false);
});
