'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {initial,apply,invariants,explore}=require('../safety/v2.6/model');
const {runAdversarial,CHANGE_TYPES}=require('../safety/v2.6/adversary');
function step(s,a){const r=apply(s,a);assert.equal(r.accepted,true,r.reason);assert.deepEqual(invariants(s,r.state,a),[]);return r.state;}
test('reference model begins with bounded authority, zero consumption',()=>{
  const s=initial();assert.deepEqual(s.usage.buyer,{runs:0,units:0});assert.equal(s.limit.scout.units,3);
});
test('exhaustive exploration passes all invariants up to depth seven',()=>{
  const r=explore({depth:7,maxStates:10000});assert.equal(r.ok,true,JSON.stringify(r.counterexample));
  assert(r.states>2000);assert(r.denied>10000);assert.equal(r.properties.length,10);
});
test('explicit state bound produces INCONCLUSIVE, never success',()=>{
  const r=explore({depth:7,maxStates:20});assert.equal(r.ok,false);assert.equal(r.inconclusive,true);
});
test('mutant wider authority is caught with replayable shortest trace',()=>{
  const r=explore({depth:5,mutant:'allow-widen'});assert.equal(r.ok,false);
  assert(r.counterexample.violations.includes('NO_AUTHORITY_EXPANSION'));
  assert.deepEqual(r.counterexample.trace,[{type:'WIDEN',actor:'scout'}]);
});
test('mutant skipping witness exposes counterexample',()=>{
  const r=explore({depth:5,mutant:'skip-witness'});assert.equal(r.ok,false);
  assert(r.counterexample.violations.includes('WITNESS_BEFORE_EFFECT'));
  assert.equal(r.counterexample.trace.at(-1).type,'EFFECT');
});
test('mutant permitting uncertain retry exposes counterexample',()=>{
  const r=explore({depth:5,mutant:'unsafe-retry'});assert.equal(r.ok,false);
  assert(r.counterexample.violations.includes('NO_RETRY_AFTER_UNCERTAINTY')||r.counterexample.violations.includes('WITNESS_BEFORE_EFFECT'));
});
test('strict model rejects authority widening',()=>{assert.equal(apply(initial(),{type:'WIDEN',actor:'buyer'}).accepted,false);});
test('reservation nonces are unique independent of agent',()=>{
  let s=step(initial(),{type:'RESERVE',actor:'buyer',nonce:'N1',units:1});
  assert.equal(apply(s,{type:'RESERVE',actor:'scout',nonce:'N1',units:1}).accepted,false);
});
test('cumulative budget cannot be reset by refinement',()=>{
  let s=step(initial(),{type:'RESERVE',actor:'buyer',nonce:'N1',units:3});
  const t=apply(s,{type:'TIGHTEN',actor:'buyer'});assert.equal(t.accepted,false);
  assert.equal(s.usage.buyer.units,3);
});
test('normal tightening never expands bounds',()=>{
  const s=step(initial(),{type:'TIGHTEN',actor:'buyer'});
  assert.equal(s.limit.buyer.units,2);assert.equal(s.limit.buyer.runs,1);
});
test('effect cannot happen before a witnessed start',()=>{
  let s=step(initial(),{type:'RESERVE',actor:'scout',nonce:'N1',units:1});
  s=step(s,{type:'START',nonce:'N1'});
  assert.equal(apply(s,{type:'EFFECT',nonce:'N1'}).accepted,false);
  s=step(s,{type:'WITNESS_START',nonce:'N1'});
  s=step(s,{type:'EFFECT',nonce:'N1'});
  assert.equal(s.requests[0].effectCount,1);
});
test('confirmed completion can be witnessed or reconciled without second effect',()=>{
  let s=initial();for(const a of [
    {type:'RESERVE',actor:'buyer',nonce:'N1',units:1},{type:'START',nonce:'N1'},
    {type:'WITNESS_START',nonce:'N1'},{type:'EFFECT',nonce:'N1'},
    {type:'COMPLETE',nonce:'N1'},{type:'RECONCILE',nonce:'N1'}])s=step(s,a);
  assert.equal(s.requests[0].effectCount,1);assert.equal(s.requests[0].completeWitnessed,true);
  assert.equal(apply(s,{type:'RETRY',nonce:'N1'}).accepted,false);
  assert.equal(apply(s,{type:'RECONCILE',nonce:'N1'}).accepted,false);
});
test('uncertain START may HOLD but cannot auto-retry',()=>{
  let s=step(initial(),{type:'RESERVE',actor:'buyer',nonce:'N1',units:1});
  s=step(s,{type:'START',nonce:'N1'});s=step(s,{type:'HOLD',nonce:'N1'});
  assert.equal(s.requests[0].hold,true);assert.equal(apply(s,{type:'RETRY',nonce:'N1'}).accepted,false);
});
test('reference model source actions cannot provide an authorisation grant',()=>{
  assert.throws(()=>apply(initial(),{type:'SELF_AUTHORISE'}),/unknown event/);
});
test('adversarial mutation kinds include signed payload, trust seal, and ledger tail',()=>{
  for(const kind of ['vcc-signature','event-signature','amount','seal-head','tail'])assert(CHANGE_TYPES.includes(kind));
});
test('real ledger verifier rejects 90 signed state mutations',()=>{
  const r=runAdversarial({seed:20261022,count:90});assert.equal(r.ok,true,JSON.stringify(r.failedMutations));
  assert.equal(r.detectedMutations,90);assert.equal(r.extraChecks.pinSubstitutionRejected,true);
  assert.equal(r.extraChecks.duplicateNonceRejected,true);
});
test('mutation checks reproduce across deterministic seeds',()=>{
  for(const seed of [1,2,0xffffffff]){
    const r=runAdversarial({seed,count:30});assert.equal(r.ok,true,JSON.stringify(r.failedMutations));
    assert.equal(r.detectedMutations,30);
  }
});
test('real local ledger explicitly exposes joint rollback residual risk',()=>{
  const r=runAdversarial({seed:5,count:15});
  assert.equal(r.residualRisks[0].id,'UNDETECTABLE_JOINT_LOCAL_ROLLBACK');
  assert.equal(r.residualRisks[0].observed,true);
});
test('reject invalid exploration and mutation bounds',()=>{
  assert.throws(()=>explore({depth:50}));assert.throws(()=>runAdversarial({count:2}));
});
