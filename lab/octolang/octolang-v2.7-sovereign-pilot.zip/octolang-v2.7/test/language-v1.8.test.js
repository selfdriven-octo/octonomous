'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const crypto=require('node:crypto');const fs=require('node:fs');const path=require('node:path');
const {signed,digest}=require('../src/canonical');
const {compileLanguage}=require('../language/v1.6');
const {compileEpistemic,verifyEpistemic,digestIR}=require('../language/v1.8');
const {verifyIR}=require('../language/v1.8/validate');
const {CLAIM,evaluate}=require('../language/v1.8/evidence');
const {run}=require('../conformance/v1.8/runner');
const read=file=>fs.readFileSync(path.join(__dirname,'../examples',file),'utf8');
const mission=read('community-proofs.octo'),source=read('community-epistemic.octo');
const root=compileLanguage(mission),artifact=compileEpistemic(source,mission);
const clone=x=>structuredClone(x);const now=1770000000000;
function harness(){
  const key=crypto.generateKeyPairSync('ed25519'),observer=crypto.generateKeyPairSync('ed25519'),model=crypto.generateKeyPairSync('ed25519');
  const trust={issuers:{
    'community-registry':{publicKey:key.publicKey.export({type:'spki',format:'pem'}),allowedStates:['Verified']},
    'availability-observer':{publicKey:observer.publicKey.export({type:'spki',format:'pem'}),allowedStates:['Observed']},
    'risk-model':{publicKey:model.publicKey.export({type:'spki',format:'pem'}),allowedStates:['Inferred']}
  }};
  const keyBy={'community-registry':key.privateKey,'availability-observer':observer.privateKey,'risk-model':model.privateKey};
  const claim=(knowledge,kind,value,opts={})=>{
    const k=artifact.ir.knowledge.find(x=>x.name===knowledge);assert(k);
    return signed({schema:CLAIM,missionIRDigest:artifact.ir.missionIRDigest,knowledge,kind,valueType:k.valueType,source:k.source,subject:k.subject,
      valueDigest:digest(value),observedAt:opts.observedAt??now-1000,validUntil:opts.validUntil??now+60000,parents:opts.parents??[]},keyBy[k.source]);
  };
  const evaluateWith=(evidence,options={})=>evaluate({ir:artifact.ir,irDigest:artifact.irDigest,rootIR:root.ir,trust,evidence,
    expectedSubject:'supplier',now,...options});
  return {trust,claim,evaluateWith};
}
test('v1.8 frozen positive/rejection conformance cases',()=>assert.equal(run(),22));
test('epistemic artifacts bind mission root, type requirements and source',()=>{
  assert.equal(verifyIR(artifact.ir,root.ir,artifact.irDigest).valid,true);
  assert.equal(verifyEpistemic(source,mission,artifact).valid,true);
  assert.equal(artifact.ir.governance.grantsImplied,false);
  assert.equal(verifyEpistemic(source+'\n',mission,artifact).valid,false);
  assert.equal(verifyEpistemic(source,mission+'\n',artifact).valid,false);
});
test('unchanged semantic declarations preserve digest across comments/order',()=>{
  const variant=source.replace('  knowledge availability {','  // added comment\n  knowledge availability {');
  assert.equal(compileEpistemic(variant,mission).irDigest,artifact.irDigest);
});
test('changed freshness or evidence state changes the hash',()=>{
  assert.notEqual(compileEpistemic(source.replace('max_age 30d','max_age 29d'),mission).irDigest,artifact.irDigest);
  assert.notEqual(compileEpistemic(source.replace('type Observed<Status>','type Verified<Status>'),mission).irDigest,artifact.irDigest);
});
test('independent verifier rejects forged governance, changed guard, changed type despite rehash',()=>{
  const x=clone(artifact.ir);x.governance.grantsImplied=true;
  assert.equal(verifyIR(x,root.ir,digestIR(x)).valid,false);
  const y=clone(artifact.ir);y.guards[0].permitExecution=true;
  assert.equal(verifyIR(y,root.ir,digestIR(y)).valid,false);
  const z=clone(artifact.ir);z.guards[0].requiredState='Verified';
  if(z.guards[0].knowledge==='supplier_accreditation')z.guards[0].requiredState='Observed';
  assert.equal(verifyIR(z,root.ir,digestIR(z)).valid,false);
});
test('positive signed verified source admits context but never grants execution',()=>{
  const h=harness(),s=h.claim('supplier_accreditation','Verified','credential-a');const result=h.evaluateWith([s]);
  assert.equal(result.valid,true);assert.equal(result.statuses.supplier_accreditation.status,'VERIFIED');
  assert(result.guards.every(g=>g.decision==='CONTEXT_ADMISSIBLE_ONLY'));
  assert.equal(Object.hasOwn(result,'executionToken'),false);
});
test('missing, stale, and signed contradictory claims fail closed',()=>{
  const h=harness();const none=h.evaluateWith([]);assert.equal(none.statuses.supplier_accreditation.status,'UNVERIFIED');
  assert(none.guards.every(g=>g.decision==='DENY'));
  const old=h.claim('supplier_accreditation','Verified','a',{observedAt:now-100000,validUntil:now-60000});
  assert.equal(h.evaluateWith([old]).statuses.supplier_accreditation.status,'EXPIRED');
  const disputed=h.evaluateWith([h.claim('supplier_accreditation','Verified','a'),h.claim('supplier_accreditation','Verified','b')]);
  assert.equal(disputed.statuses.supplier_accreditation.status,'DISPUTED');
  assert(disputed.guards.every(g=>g.decision==='DENY'));
});
test('attestation signature substitution, corrupted payload or invented issuer is rejected',()=>{
  const h=harness();const s=h.claim('supplier_accreditation','Verified','a');
  const bad=clone(s);bad.payload.valueDigest=digest('b');assert.equal(h.evaluateWith([bad]).valid,false);
  const wrong=clone(s);wrong.payload.source='unknown';assert.equal(h.evaluateWith([wrong]).valid,false);
  const forged=clone(s);forged.signature=Buffer.alloc(64,3).toString('base64');assert.equal(h.evaluateWith([forged]).valid,false);
});
test('no accidental inference elevation to independently verified knowledge',()=>{
  const h=harness();const observation=h.claim('availability','Observed','available');
  const result=h.evaluateWith([observation]);assert.equal(result.statuses.availability.status,'OBSERVED');
  assert.equal(result.statuses.supplier_accreditation.status,'UNVERIFIED');
  const bad=clone(observation);bad.payload.kind='Verified';assert.equal(h.evaluateWith([bad]).valid,false);
});
test('inference must contain authenticated fresh direct parents',()=>{
  const h=harness();const parent=h.claim('availability','Observed','available');const pd=digest(parent.payload);
  const inferred=h.claim('risk_assessment','Inferred','low-risk',{parents:[pd]});
  assert.equal(h.evaluateWith([parent,inferred]).statuses.risk_assessment.status,'INFERRED');
  assert.equal(h.evaluateWith([inferred]).valid,false);
  const expiredParent=h.claim('availability','Observed','available',{observedAt:now-100000,validUntil:now-60000});
  const inferredWithExpired=h.claim('risk_assessment','Inferred','low-risk',{parents:[digest(expiredParent.payload)]});
  assert.equal(h.evaluateWith([expiredParent,inferredWithExpired]).valid,false);
});
test('missing expected subject and a substituted trust anchor fail closed',()=>{
  const h=harness(),c=h.claim('supplier_accreditation','Verified','a');
  assert.equal(h.evaluateWith([c],{expectedSubject:'another-supplier'}).valid,false);
  const other=crypto.generateKeyPairSync('ed25519');
  const trust=clone(h.trust);trust.issuers['community-registry'].publicKey=other.publicKey.export({type:'spki',format:'pem'});
  assert.equal(h.evaluateWith([c],{trust}).valid,false);
});
test('declaration must not let inferred or observed evidence authorise an effectful task',()=>{
  assert.throws(()=>compileEpistemic(source.replace('guard record_intent { require supplier_accreditation','guard record_intent { require availability'),mission),/observations cannot authorise effectful/);
  assert.throws(()=>compileEpistemic(source.replace('guard record_intent { require supplier_accreditation','guard record_intent { require risk_assessment'),mission),/inferred evidence only/);
});
test('incomplete trust pins and invalid evidence structure deny instead of silently ignoring',()=>{
  const h=harness(),c=h.claim('supplier_accreditation','Verified','a');
  assert.equal(h.evaluateWith([c],{trust:{issuers:{}}}).valid,false);
  assert.equal(h.evaluateWith([{}]).valid,false);
  assert.equal(h.evaluateWith([c,c]).valid,false);
});

test('inference may inform read-only research, never grant an effectful capability',()=>{
  const readOnly=read('community-mission.octo');
  const adapted=source.replace('guard find_supplier { require supplier_accreditation',
    'guard find_supplier { require risk_assessment');
  const a=compileEpistemic(adapted,readOnly);
  assert.equal(verifyIR(a.ir,compileLanguage(readOnly).ir,a.irDigest).valid,true);
  assert.equal(a.ir.guards.find(g=>g.task==='find_supplier').requiredState,'Inferred');
  assert.equal(a.ir.guards.find(g=>g.task==='find_supplier').permitExecution,false);
});
test('future-dated evidence and inference over disputed parents fail closed',()=>{
  const h=harness();const future=h.claim('supplier_accreditation','Verified','a',
    {observedAt:now+5000,validUntil:now+60000});
  assert.equal(h.evaluateWith([future]).valid,false);
  const p1=h.claim('availability','Observed','a');const p2=h.claim('availability','Observed','b');
  const inferred=h.claim('risk_assessment','Inferred','risk',{parents:[digest(p1.payload)]});
  assert.equal(h.evaluateWith([p1,p2,inferred]).valid,false);
});
