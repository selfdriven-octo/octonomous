'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {setup}=require('../language/v2.3/demo');
const {VerifiedExecutionController,verifyWitnessedExecution,readExecution}=require('../language/v2.3');
const {verifyWitness,LocalWitness}=require('../language/v2.3/witness');
const {hash}=require('../language/v2.2');
const {makeVccDecision}=require('../language/v2.2');
const audit=f=>verifyWitnessedExecution({directory:f.directory,scoreSource:f.scoreSource,pins:f.pins,
  witnessDirectory:f.witnessDirectory,witnessPublicKey:f.witnessPublicKey});
const effectFiles=f=>fs.existsSync(path.join(f.directory,'effects'))?fs.readdirSync(path.join(f.directory,'effects')):[];
const run=f=>f.controller.execute({...f.decision,missionParams:f.missionParams});
test('v2.3 runs one real bounded Octonomous local effect and independently verifies both witnessed boundaries',async()=>{
  const f=setup(),r=await run(f),a=audit(f);
  assert.equal(r.status,'WITNESSED_LOCAL_EXECUTION');assert.equal(r.realEffects,1);assert.equal(r.payments,false);
  assert.equal(a.valid,true);assert.equal(a.executionSequence,2);assert.equal(a.checkpointSequence,4);
  assert.equal(effectFiles(f).length,1);
  assert.equal(a.actions[f.decision.request.nonce].revisionDigest,f.revisionArtifact.irDigest);
  assert.equal(f.gate.status().state.used.intent_node.units,2);
});
test('replay and duplicate effect after restart both fail closed',async()=>{
  const f=setup();await run(f);
  const again=new VerifiedExecutionController({gate:f.gate,witness:f.witness,witnessDirectory:f.witnessDirectory,witnessPublicKey:f.witnessPublicKey});
  await assert.rejects(again.execute({...f.decision,missionParams:f.missionParams}),/replayed reservation/);
  assert.equal(effectFiles(f).length,1);
});
test('an unauthorised capability never causes a reservation or tool call',async()=>{
  const f=setup(),bad=structuredClone(f.decision);bad.request.capability='wallet.transfer';
  await assert.rejects(f.controller.execute({...bad,missionParams:f.missionParams}),/only intent.record/);
  assert.equal(effectFiles(f).length,0);assert.equal(f.gate.status().state.sequence,2);
});
test('changed exact request with old VCC signature is rejected by activation ledger',async()=>{
  const f=setup(),bad=structuredClone(f.decision);bad.request.units=3;
  await assert.rejects(f.controller.execute({...bad,missionParams:f.missionParams}),/VCC decision not bound/);
  assert.equal(effectFiles(f).length,0);
});
test('missing or altered signed mission evidence fails before reservation',async()=>{
  const f=setup();await assert.rejects(f.controller.execute({...f.decision,missionParams:{...f.missionParams,claims:[]}}),/effect-time mission review/);
  assert.equal(f.gate.status().state.sequence,2);
});
test('exact score revision is tied to local effect journal and receipts',async()=>{
  const f=setup();await run(f);
  const filename=path.join(f.directory,'effects',hash('intent-file:'+f.decision.request.nonce)+'.json');
  const record=JSON.parse(fs.readFileSync(filename,'utf8'));assert.equal(record.activeRevisionDigest,f.revisionArtifact.irDigest);
  record.scoreDigest='0'.repeat(64);fs.writeFileSync(filename,JSON.stringify(record)+'\n');
  assert.match(audit(f).reason,/local effect differs/);
});
test('deleting effect file is detected by independent verifier',async()=>{
  const f=setup();await run(f);const name=path.join(f.directory,'effects',hash('intent-file:'+f.decision.request.nonce)+'.json');
  fs.unlinkSync(name);assert.match(audit(f).reason,/effect missing/);
});
test('witness signature tampering is detected without controller keys',async()=>{
  const f=setup();await run(f);const name=path.join(f.witnessDirectory,'checkpoints.jsonl');
  const lines=fs.readFileSync(name,'utf8').trimEnd().split('\n');const last=JSON.parse(lines.at(-1));
  last.signature=crypto.sign(null,Buffer.from('wrong'),crypto.generateKeyPairSync('ed25519').privateKey).toString('base64');
  lines[lines.length-1]=JSON.stringify(last);fs.writeFileSync(name,lines.join('\n')+'\n');
  assert.match(audit(f).reason,/bad signed witness checkpoint/);
});
test('controller ledger rollback with historical signed local seal is caught by witness',async()=>{
  const f=setup();const originalJournal=fs.readFileSync(path.join(f.directory,'events.jsonl'));
  const originalSeal=fs.readFileSync(path.join(f.directory,'state-seal.json'));
  await run(f);
  // Restore BOTH locally signed artifacts from an old valid state.
  fs.writeFileSync(path.join(f.directory,'events.jsonl'),originalJournal);
  fs.writeFileSync(path.join(f.directory,'state-seal.json'),originalSeal);
  assert.match(audit(f).reason,/witness checkpoint does not match/);
});
test('read-only verifier refuses an incorrect witness public key',async()=>{
  const f=setup();await run(f);const other=crypto.generateKeyPairSync('ed25519').publicKey;
  const rep=verifyWitnessedExecution({directory:f.directory,scoreSource:f.scoreSource,pins:f.pins,
    witnessDirectory:f.witnessDirectory,witnessPublicKey:other});assert.equal(rep.valid,false);
});
test('witness outage after START causes no local effects, and replay cannot restart action',async()=>{
  const f=setup(),w=f.witness;const original=w.attest.bind(w);
  w.attest=(s,h)=>{if(s.executionSequence>0)throw Error('witness unavailable');return original(s,h);};
  await assert.rejects(run(f),/witness unavailable/);
  assert.equal(effectFiles(f).length,0);assert.equal(f.gate.status().state.used.intent_node.units,2);
  const event=readExecution({directory:f.directory,publicKey:f.pins.controller});assert.equal(event.actions[f.decision.request.nonce].status,'IN_PROGRESS');
  await assert.rejects(run(f),/witness checkpoint does not match|missing independently witnessed/);
});
test('witness outage after COMPLETE creates audit-invalid ambiguous state, never a duplicate effect',async()=>{
  const f=setup(),w=f.witness;const original=w.attest.bind(w);
  w.attest=(s,h)=>{if(s.executionSequence===2)throw Error('witness finalisation unavailable');return original(s,h);};
  await assert.rejects(run(f),/witness finalisation unavailable/);
  assert.equal(effectFiles(f).length,1);assert.equal(audit(f).valid,false);
  await assert.rejects(run(f),/witness checkpoint does not match/);assert.equal(effectFiles(f).length,1);
});
test('real async execution holds the same exclusive lock as governance transitions',async()=>{
  const f=setup(),Octonomous=require('../vendor/octonomous-runtime');
  const original=Octonomous.Runtime.prototype.registerBeing;
  let entered,release;
  const ready=new Promise(resolve=>{entered=resolve;});
  const parked=new Promise(resolve=>{release=resolve;});
  Octonomous.Runtime.prototype.registerBeing=async function(...args){entered();await parked;return original.apply(this,args);};
  try{
    const job=run(f);await ready;
    assert.throws(()=>f.gate.activate({}),/ledger locked/);
    assert.throws(()=>f.gate.reserve(f.decision),/ledger locked/);
    release();await job;
    assert.equal(effectFiles(f).length,1);assert.equal(audit(f).valid,true);
  }finally {Octonomous.Runtime.prototype.registerBeing=original;release?.();}
});
test('tampering with controller-signed execution journal fails closed',async()=>{
  const f=setup();await run(f);const file=path.join(f.directory,'execution.jsonl'),lines=fs.readFileSync(file,'utf8').trimEnd().split('\n');
  const e=JSON.parse(lines[0]);e.payload.tool='wallet.transfer';lines[0]=JSON.stringify(e);fs.writeFileSync(file,lines.join('\n')+'\n');
  assert.match(audit(f).reason,/execution sequence or hash link invalid/);
});
test('head seal protects against truncation and incomplete write',async()=>{
  const f=setup();await run(f);const file=path.join(f.directory,'execution.jsonl'),lines=fs.readFileSync(file,'utf8').trimEnd().split('\n');
  fs.writeFileSync(file,lines[0]+'\n');assert.match(audit(f).reason,/execution seal mismatch/);
});
test('offline CLI checks public keys only',async()=>{
  const f=setup();await run(f);const pins=path.join(f.directory,'trusted-pins.json'),key=path.join(f.directory,'witness-pub.pem');
  fs.writeFileSync(pins,JSON.stringify(f.pins));fs.writeFileSync(key,f.witnessPublicKey);
  const cp=require('node:child_process');const str=cp.execFileSync(process.execPath,[path.join(__dirname,'../bin/octolang-execution.js'),
    'verify',path.join(__dirname,'../community-score.octo'),pins,f.directory,f.witnessDirectory,key],{encoding:'utf8'});
  assert.equal(JSON.parse(str).valid,true);
});
