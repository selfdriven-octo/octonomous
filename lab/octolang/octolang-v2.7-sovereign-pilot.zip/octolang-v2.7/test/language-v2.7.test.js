'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {setupPilot}=require('../language/v2.7/pilot');
const {fileBundle,sign}=require('../language/v2.7/governance');
const {fetchJSON}=require('../language/v2.4/remote');
const {compileScore}=require('../language/v2.1');
const {readExecution}=require('../language/v2.4/execution');
const {verifyLedger}=require('../language/v2.2');
const {verifyWitness}=require('../language/v2.3/witness');
const {canonical}=require('../src/canonical');
const effects=f=>{const p=path.join(f.ledgerDirectory,'effects');return fs.existsSync(p)?fs.readdirSync(p):[];};
const execute=f=>f.controller.execute({...f.decision,missionParams:f.missionParams});

test('v2.7 three distinct roles sign review, witness START and complete one bounded effect',async()=>{
  const f=await setupPilot();try{
    assert.notEqual(process.pid,f.remote.proc.pid);assert.notEqual(process.pid,f.gp.process.pid);
    assert.notEqual(f.remote.proc.pid,f.gp.process.pid);
    const r=await execute(f);assert.equal(r.status,'REMOTE_WITNESSED_LOCAL_EXECUTION');
    assert.equal(effects(f).length,1);assert.equal(f.controller.verify().valid,true);
    const s=await f.governance.status();assert.equal(s.sequence,2);assert.equal(s.lastKind,'PRE_EFFECT');
    const p=path.join(f.base,'governance-host','governor-private.pem');
    assert.equal(fs.existsSync(p),true);assert.equal(fs.existsSync(path.join(f.ledgerDirectory,'governor-private.pem')),false);
    await assert.rejects(execute(f));assert.equal(effects(f).length,1);
  }finally{await f.close();}
});

test('v2.7 partition before effect holds reservation, never runs tool',async()=>{
  const f=await setupPilot({stopBeforeEffect:true});try{
    await assert.rejects(execute(f),/reconciliation required/);assert.equal(effects(f).length,0);
    const e=readExecution({directory:f.ledgerDirectory,publicKey:f.pins.controller});
    assert.equal(e.valid,true);assert.equal(e.sequence,1);
    await assert.rejects(execute(f));assert.equal(effects(f).length,0);
  }finally{await f.close();}
});

test('v2.7 governor crash/restart keeps high water and signed receipts',async()=>{
  const f=await setupPilot();try{
    await execute(f);const before=await f.governance.status();
    await f.restartGovernance();const after=await f.governance.status();assert.deepEqual(after,before);
    await assert.rejects(f.governance.preEffect(fileBundle(f.ledgerDirectory,f.mirrorDirectory)),/requires a signed START/);
    assert.equal(effects(f).length,1);
  }finally{await f.close();}
});

test('v2.7 truncated locally signed ledger and seal cannot evade external high water',async()=>{
  const f=await setupPilot();try{
    const old=fileBundle(f.ledgerDirectory,f.mirrorDirectory);await execute(f);
    await assert.rejects(f.governance.preEffect(old),/rollback or fork/);
    assert.equal(effects(f).length,1);
  }finally{await f.close();}
});

test('v2.7 replaced signed ledger record rejected even with a legitimate controller request',async()=>{
  const f=await setupPilot();try{
    await execute(f);const b=fileBundle(f.ledgerDirectory,f.mirrorDirectory);
    b.ledgerText=b.ledgerText.replace('octolang.activation.v2.2','octolang.activation.v9.9');
    await assert.rejects(f.governance.preEffect(b),/rollback or fork/);
  }finally{await f.close();}
});

test('v2.7 governance mTLS rejects untrusted client certificate',async()=>{
  const f=await setupPilot();try{
    await assert.rejects(fetchJSON({url:new URL('v1/status',f.governance.url).toString(),ca:f.governance.ca,
      pinnedServerFingerprint:f.governance.pin,timeoutMs:1000}),/certificate|alert|socket|handshake/i);
  }finally{await f.close();}
});

test('v2.7 governance pin rejects a substituted server certificate',async()=>{
  const f=await setupPilot();try{
    const old=f.governance.pin;f.governance.pin='0'.repeat(64);
    await assert.rejects(f.governance.status(),/certificate pin mismatch/i);
    f.governance.pin=old;
  }finally{await f.close();}
});

test('v2.7 governance service rejects unsigned and forged Ed25519 pre-effect request',async()=>{
  const f=await setupPilot();try{
    const payload={schema:'octolang.governance-request.v2.7',action:'PRE_EFFECT',nonce:crypto.randomBytes(16).toString('hex'),issuedAt:Date.now(),expiresAt:Date.now()+20000,
      bundle:fileBundle(f.ledgerDirectory,f.mirrorDirectory)};
    await assert.rejects(fetchJSON({url:new URL('v1/pre-effect',f.governance.url).toString(),cert:f.governance.cert,key:f.governance.key,ca:f.governance.ca,
      pinnedServerFingerprint:f.governance.pin,method:'POST',body:{payload,signature:sign(payload,crypto.generateKeyPairSync('ed25519').privateKey)}}),/controller signature rejected/);
  }finally{await f.close();}
});

test('v2.7 refused activation with edited human review',async()=>{
  const f=await setupPilot();try{
    const altered=structuredClone(f.revision);altered.review.signature='AAAA';
    await assert.rejects(f.governance.activate(fileBundle(f.ledgerDirectory,f.mirrorDirectory),altered));
    assert.equal(f.gate.status().state.sequence,2);
  }finally{await f.close();}
});

test('v2.7 remote witness outage blocks a new local effect',async()=>{
  const f=await setupPilot();try{
    await f.remote.close();await assert.rejects(execute(f));assert.equal(effects(f).length,0);
  }finally{await f.close();}
});

test('v2.7 witness restart preserves independently signed journal',async()=>{
  const f=await setupPilot();try{
    await execute(f);const old=await f.witness.refresh();await f.remote.close();await f.remote.launch();
    f.witness.url=f.remote.url;const next=await f.witness.refresh();assert.equal(next.valid,true);assert.equal(next.head,old.head);
    assert.equal(f.controller.verify().valid,true);
  }finally{await f.close();}
});

test('v2.7 policy cannot silently rotate governor identity without new enrolment',async()=>{
  const f=await setupPilot();try{
    const file=path.join(f.governanceDirectory,'enrolment.json'),data=JSON.parse(fs.readFileSync(file,'utf8'));
    const fake=crypto.generateKeyPairSync('ed25519').publicKey.export({format:'pem',type:'spki'}).toString();
    assert.notEqual(data.governorKey,fake);assert.equal(data.governorKey,f.pins.governor);
    const c=JSON.parse(fs.readFileSync(f.governanceConfigFile,'utf8'));c.pins.governor=fake;
    assert.notEqual(canonical(c.pins),canonical(f.pins));
    // Actual key rollover remains an explicit, separately audited process.
  }finally{await f.close();}
});


test('v2.7 completed checkpoint refuses replay of the same signed request nonce',async()=>{
  const f=await setupPilot({stopBeforeEffect:true});try{
    await assert.rejects(execute(f));
    const bundle=fileBundle(f.ledgerDirectory,f.mirrorDirectory),payload={schema:'octolang.governance-request.v2.7',action:'PRE_EFFECT',
      nonce:crypto.randomBytes(16).toString('hex'),issuedAt:Date.now(),expiresAt:Date.now()+30000,bundle};
    const request={payload,signature:sign(payload,f.actors.controller.privateKey)};
    const url=new URL('v1/pre-effect',f.governance.url).toString();
    const cfg={url,cert:f.governance.cert,key:f.governance.key,ca:f.governance.ca,pinnedServerFingerprint:f.governance.pin,method:'POST',body:request};
    const first=await fetchJSON(cfg);assert.equal(first.payload.action,'PRE_EFFECT');
    await assert.rejects(fetchJSON(cfg),/replayed governance request/);assert.equal(effects(f).length,0);
  }finally{await f.close();}
});

test('v2.7 governance refuses expired signed controller request',async()=>{
  const f=await setupPilot();try{
    const payload={schema:'octolang.governance-request.v2.7',action:'PRE_EFFECT',nonce:crypto.randomBytes(16).toString('hex'),
      issuedAt:Date.now()-90000,expiresAt:Date.now()-20000,bundle:fileBundle(f.ledgerDirectory,f.mirrorDirectory)};
    await assert.rejects(fetchJSON({url:new URL('v1/pre-effect',f.governance.url).toString(),cert:f.governance.cert,key:f.governance.key,ca:f.governance.ca,
      pinnedServerFingerprint:f.governance.pin,method:'POST',body:{payload,signature:sign(payload,f.actors.controller.privateKey)}}),/expired request/);
  }finally{await f.close();}
});

test('v2.7 deliberate mTLS transport key rotation requires explicit pin update',async()=>{
  const f=await setupPilot();try{
    const old=await f.governance.status();
    await f.stopGovernance();
    const {testPki}=require('../language/v2.4/provision');
    const newPki=testPki(path.join(f.base,'governance-host','rotated-transport-pki'));
    const conf=JSON.parse(fs.readFileSync(f.governanceConfigFile,'utf8'));
    Object.assign(conf,{serverKey:newPki.server.key,serverCert:newPki.server.cert,clientCa:newPki.ca,clientFingerprint:newPki.client.digest});
    fs.writeFileSync(f.governanceConfigFile,JSON.stringify(conf));
    await f.restartGovernance();
    await assert.rejects(f.governance.status(),/certificate|pin mismatch|verify|self-signed|unable/i);
    f.governance.cert=fs.readFileSync(newPki.client.cert);f.governance.key=fs.readFileSync(newPki.client.key);
    f.governance.ca=fs.readFileSync(newPki.ca);f.governance.pin=newPki.server.digest;
    const current=await f.governance.status();assert.deepEqual(current,old);
    assert.equal(effects(f).length,0);
  }finally{await f.close();}
});

test('v2.7 public-key-only operator independently verifies both remote roles',async()=>{
  const f=await setupPilot();try{
    await execute(f);
    const c=JSON.parse(fs.readFileSync(f.governanceConfigFile,'utf8'));
    const {check}=require('../language/v2.7/operator');
    const r=await check({scoreDigest:f.score.irDigest,
      governance:{url:f.governance.url,clientCert:f.governance.cert&&c.clientCa.replace('ca.crt','client.crt'),
        clientKey:c.clientCa.replace('ca.crt','client.key'),ca:c.clientCa,serverFingerprint:f.governance.pin,
        governorPublicKey:c.governorPublicKey},
      witness:{url:f.remote.url,clientCert:f.remote.pki.client.cert,clientKey:f.remote.pki.client.key,
        ca:f.remote.pki.ca,serverFingerprint:f.remote.pki.server.digest,witnessPublicKey:f.remote.config.witnessPublicKey}});
    assert.equal(r.governance.verified,true);assert.equal(r.witness.verified,true);
    assert.equal(r.executionAuthorised,false);
    assert.equal(r.governance.sequence,2);
  }finally{await f.close();}
});
