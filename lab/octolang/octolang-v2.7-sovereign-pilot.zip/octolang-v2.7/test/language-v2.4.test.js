'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const {setupRemote}=require('../language/v2.4/demo');
const {fetchJSON,sign,certDigest,RemoteWitness,service}=require('../language/v2.4/remote');
const {readExecution}=require('../language/v2.4/execution');
const {hash}=require('../language/v2.2');
const read=p=>fs.readFileSync(p);
const withRemote=async(t)=>{const f=await setupRemote();t.after(()=>f.remote.close());return f;};
const request=f=>({...f.decision,missionParams:f.missionParams});
const effects=f=>{const p=path.join(f.directory,'effects');return fs.existsSync(p)?fs.readdirSync(p):[];};
const raw=(f,method='GET',body)=>fetchJSON({url:f.remote.url+'v1/'+(method==='GET'?'status':'attest'),
  cert:read(f.remote.pki.client.cert),key:read(f.remote.pki.client.key),ca:read(f.remote.pki.ca),
  pinnedServerFingerprint:f.remote.pki.server.digest,method,body});
test('v2.4 executes one local effect only after separate cross-process mTLS witness confirmations',async t=>{
  const f=await withRemote(t);const result=await f.controller.execute(request(f));
  assert.equal(result.status,'REMOTE_WITNESSED_LOCAL_EXECUTION');assert.equal(result.payments,false);
  const audit=f.controller.verify();assert.equal(audit.valid,true,audit.reason);assert.equal(audit.checkpointSequence,3);
  assert.equal(effects(f).length,1);assert.notEqual(f.remote.proc.pid,process.pid);
});
test('v2.4 prevents duplicate local effect across repeated requests',async t=>{
  const f=await withRemote(t);await f.controller.execute(request(f));
  await assert.rejects(f.controller.execute(request(f)),/replayed reservation/);assert.equal(effects(f).length,1);
});
test('v2.4 pinning rejects substituted server identity',async t=>{
  const f=await withRemote(t);
  await assert.rejects(fetchJSON({url:f.remote.url+'v1/status',cert:read(f.remote.pki.client.cert),key:read(f.remote.pki.client.key),
    ca:read(f.remote.pki.ca),pinnedServerFingerprint:'0'.repeat(64)}),/pin mismatch/);
});
test('v2.4 mTLS rejects calls without client identity',async t=>{
  const f=await withRemote(t);
  await assert.rejects(fetchJSON({url:f.remote.url+'v1/status',ca:read(f.remote.pki.ca),
    pinnedServerFingerprint:f.remote.pki.server.digest}),/certificate|required|alert|tls|socket/i);
});
test('v2.4 forged remote attestation requests are rejected',async t=>{
  const f=await withRemote(t);const now=Date.now(),snapshot=f.controller._snapshot(),expectedHead=f.witness.status().head;
  const payload={schema:'octolang.remote-witness-request.v2.4',scoreDigest:f.score.irDigest,snapshot,expectedHead,
    nonce:crypto.randomBytes(16).toString('hex'),issuedAt:now,expiresAt:now+30000};
  const bad=sign(payload,crypto.generateKeyPairSync('ed25519').privateKey);
  await assert.rejects(raw(f,'POST',{payload,signature:bad}),/unsigned request/);
  assert.equal(f.witness.status().sequence,1);
});
test('v2.4 rejects wrong-score and stale remote witness submissions',async t=>{
  const f=await withRemote(t);const now=Date.now(),snapshot=f.controller._snapshot();
  let payload={schema:'octolang.remote-witness-request.v2.4',scoreDigest:'f'.repeat(64),snapshot,
    expectedHead:f.witness.status().head,nonce:crypto.randomBytes(16).toString('hex'),issuedAt:now,expiresAt:now+30000};
  await assert.rejects(raw(f,'POST',{payload,signature:sign(payload,f.actors.controller.privateKey)}),/invalid or unsigned request/);
  payload={...payload,scoreDigest:f.score.irDigest,expectedHead:'a'.repeat(64),nonce:crypto.randomBytes(16).toString('hex')};
  await assert.rejects(raw(f,'POST',{payload,signature:sign(payload,f.actors.controller.privateKey)}),/stale witness predecessor/);
});
test('v2.4 rejects expired remote signatures',async t=>{
  const f=await withRemote(t);const now=Date.now();const payload={schema:'octolang.remote-witness-request.v2.4',
    scoreDigest:f.score.irDigest,snapshot:f.controller._snapshot(),expectedHead:f.witness.status().head,
    nonce:crypto.randomBytes(16).toString('hex'),issuedAt:now-120000,expiresAt:now-100000};
  await assert.rejects(raw(f,'POST',{payload,signature:sign(payload,f.actors.controller.privateKey)}),/invalid or unsigned request/);
});
test('v2.4 remote witness outage before reserve fails closed without effect',async t=>{
  const f=await withRemote(t);await f.remote.close();
  await assert.rejects(f.controller.execute(request(f)),/ECONNREFUSED|socket|timeout|connect/i);
  assert.equal(effects(f).length,0);assert.equal(f.gate.status().state.sequence,2);
});
test('v2.4 network attestation failure after START never invokes local effect',async t=>{
  const f=await withRemote(t),original=f.witness.attest.bind(f.witness);
  f.witness.attest=(snapshot,head)=>snapshot.executionSequence>0?Promise.reject(Error('remote witness network outage')):original(snapshot,head);
  await assert.rejects(f.controller.execute(request(f)),/remote witness network outage/);
  assert.equal(effects(f).length,0);assert.equal(readExecution({directory:f.directory,publicKey:f.pins.controller}).sequence,1);
  await assert.rejects(f.controller.execute(request(f)),/witness checkpoint does not match/);
});
test('v2.4 local valid rollback is detected by independently retained remote mirror',async t=>{
  const f=await withRemote(t),before=read(path.join(f.directory,'events.jsonl')),seal=read(path.join(f.directory,'state-seal.json'));
  await f.controller.execute(request(f));fs.writeFileSync(path.join(f.directory,'events.jsonl'),before);
  fs.writeFileSync(path.join(f.directory,'state-seal.json'),seal);
  assert.match(f.controller.verify().reason,/checkpoint does not match/);
});
test('v2.4 remote journal rollback is rejected by controller mirror on live refresh',async t=>{
  const f=await withRemote(t);const file=path.join(f.remote.config.directory,'checkpoints.jsonl'),old=read(file);
  await f.controller.execute(request(f));fs.writeFileSync(file,old);
  await assert.rejects(f.witness.refresh(),/rollback\/fork/);
});
test('v2.4 tampered remote checkpoint is rejected by pinned witness verifier',async t=>{
  const f=await withRemote(t),file=path.join(f.remote.config.directory,'checkpoints.jsonl');
  const data=read(file).toString().trimEnd().split('\n');const forged=JSON.parse(data[0]);forged.signature='A'.repeat(88);
  fs.writeFileSync(file,JSON.stringify(forged)+'\n');
  await assert.rejects(f.witness.refresh(),/rollback\/fork|bad signed witness checkpoint/);
});
test('v2.4 independently governed enrolment cannot be silently changed',async t=>{
  const f=await withRemote(t);const cfg=f.remote.config,keys=crypto.generateKeyPairSync('ed25519');
  assert.throws(()=>service({directory:cfg.directory,scoreDigest:cfg.scoreDigest,
    signingPrivateKey:read(cfg.witnessPrivateKey),signingPublicKey:read(cfg.witnessPublicKey),
    controllerPublicKey:keys.publicKey,serverKey:read(cfg.serverKey),serverCert:read(cfg.serverCert),
    clientCa:read(cfg.clientCa),clientFingerprint:cfg.clientFingerprint,port:0}),/enrolment identity changed/);
});
test('v2.4 witness blocks concurrent attempts using same predecessor',async t=>{
  const f=await withRemote(t),head=f.witness.status().head,snapshot=f.controller._snapshot();
  const results=await Promise.allSettled([f.witness.attest(snapshot,head),f.witness.attest(snapshot,head)]);
  assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
  assert.equal(results.filter(x=>x.status==='rejected').length,1);
  assert.equal((await f.witness.refresh()).sequence,2);
});

test('v2.4 independent witness survives its own process restart with persistent signed high-water mark',async t=>{
  const f=await withRemote(t);await f.controller.execute(request(f));
  const head=f.witness.status().head;await f.remote.close();await f.remote.launch();
  f.witness.url=f.remote.url;
  assert.equal((await f.witness.refresh()).head,head);
  const audited=await f.controller.verifyLive();assert.equal(audited.valid,true,audited.reason);
  await assert.rejects(f.controller.execute(request(f)),/replayed reservation/);
  assert.equal(effects(f).length,1);
});
test('v2.4 independent read-only inspector checks signed remote history and local effect bundle',async t=>{
  const f=await withRemote(t);await f.controller.execute(request(f));
  const cfg={url:f.remote.url,clientCert:f.remote.pki.client.cert,clientKey:f.remote.pki.client.key,
    ca:f.remote.pki.ca,serverFingerprint:f.remote.pki.server.digest,witnessPublicKey:f.remote.config.witnessPublicKey,
    controllerDirectory:f.directory,scoreSource:path.resolve(__dirname,'../community-score.octo'),
    controllerPins:path.join(f.directory,'controller-pins.json')};
  fs.writeFileSync(cfg.controllerPins,JSON.stringify(f.pins));
  const configPath=path.join(f.directory,'inspect.json');fs.writeFileSync(configPath,JSON.stringify(cfg));
  const cp=require('node:child_process');const result=cp.execFileSync(process.execPath,[path.resolve(__dirname,'../language/v2.4/inspect.js'),configPath],{encoding:'utf8'});
  const inspected=JSON.parse(result);assert.equal(inspected.remoteWitnessVerified,true);
  assert.equal(inspected.localEvidenceAudit.valid,true);assert.equal(inspected.sequence,3);
});
test('v2.4 interrupted completion attestation never repeats a completed physical file write',async t=>{
  const f=await withRemote(t),original=f.witness.attest.bind(f.witness);
  f.witness.attest=(snapshot,head)=>snapshot.executionSequence===2?Promise.reject(Error('lost completion witness')):original(snapshot,head);
  await assert.rejects(f.controller.execute(request(f)),/lost completion witness/);
  assert.equal(effects(f).length,1);assert.equal(f.controller.verify().valid,false);
  await assert.rejects(f.controller.execute(request(f)),/witness checkpoint does not match/);
  assert.equal(effects(f).length,1);
});
test('v2.4 offline audit denies wrong remote witness Ed25519 identity',async t=>{
  const f=await withRemote(t);await f.controller.execute(request(f));
  const wrong=crypto.generateKeyPairSync('ed25519').publicKey;
  const {verifyWitnessedExecution}=require('../language/v2.4/execution');
  const result=verifyWitnessedExecution({directory:f.directory,scoreSource:f.scoreSource,pins:f.pins,
    witnessDirectory:f.mirrorDirectory,witnessPublicKey:wrong});
  assert.equal(result.valid,false);
});
