'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const {compileProgram,verifyProgram,parseProgram,parseModule,sha,digestIR}=require('../language/v2.0');
const {verifyIR}=require('../language/v2.0/validate');
const root=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(root,'community-program.octo'),'utf8');
const parsed=parseProgram(source);
const files=Object.fromEntries([...Object.values(parsed.sources),...parsed.imports.map(x=>x.path)]
  .map(p=>[p,fs.readFileSync(path.join(root,p),'utf8')]));
const cloned=x=>JSON.parse(JSON.stringify(x));
const build=(s=source,edits={})=>compileProgram(s,{...files,...edits});
function throws(s,pattern,edits={}){assert.throws(()=>build(s,edits),pattern);}
const modulePath=parsed.imports[0].path;
const replaceModule=(before,after)=>{
  const content=files[modulePath].replace(before,after);
  assert.notEqual(content,files[modulePath]);
  const adjusted=source.replace(parsed.imports[0].sha256,sha(content));
  return [adjusted,{[modulePath]:content}];
};
test('compiles linked components with one digest and no authority',()=>{
  const a=build();assert.equal(a.ir.schema,'octolang.unified-ir.v2.0');
  assert.equal(a.ir.modules.length,1);assert.equal(a.ir.bindings.length,4);
  assert.equal(a.ir.worstCaseBudgetUnits,7);assert.equal(a.ir.governance.executionAllowed,false);
  assert.equal(verifyIR(a.ir,a.components,a.irDigest).valid,true);
  assert.equal(verifyProgram(source,files,a).valid,true);
});
test('order and comments cannot alter semantic IR digest',()=>{
  const swapped=source.replace(/(  bind community.scout_stage as scout_node \{[\s\S]*?\n  \}\n)(  bind community.review_stage as review_node \{[\s\S]*?\n  \}\n)/,'$2$1');
  assert.notEqual(swapped,source);assert.equal(build(swapped).irDigest,build().irDigest);
  assert.equal(build('# comment\n'+swapped).irDigest,build().irDigest);
});
test('a narrowing of budget creates a new policy digest',()=>{
  const narrowed=source.replace(/node approved_intent\n    task record_intent\n    runs 1\n    budget 3/,'node approved_intent\n    task record_intent\n    runs 1\n    budget 2');
  assert.notEqual(narrowed,source);assert.notEqual(build(narrowed).irDigest,build().irDigest);
});
test('source digest binding rejects modified module',()=>{
  const changed=files[modulePath]+'\n# additional note\n';
  assert.throws(()=>build(source,{[modulePath]:changed}),/import digest mismatch/);
});
test('module capability cannot escalate scope',()=>{
  const [s,f]=replaceModule('capability "service.note.record"','capability "admin.root"');
  throws(s,/contract cannot change role, capability or effect/,f);
});
test('contract cannot assign wrong role or effect',()=>{
  for(const [before,after] of [['role buyer','role auditor'],['effect EXTERNAL_SERVICE','effect LOCAL_CAPABILITY']]){
    const [s,f]=replaceModule(before,after);throws(s,/contract cannot change role, capability or effect/,f);
  }
});
test('proof must be declared on its bound task',()=>{
  const [s,f]=replaceModule('proof supplier_proof','proof audit_proof');throws(s,/contract proof not required/,f);
});
test('epistemic guard must match, cannot replace Verified knowledge',()=>{
  const [s,f]=replaceModule('knowledge supplier_accreditation','knowledge risk_assessment');throws(s,/contract knowledge does not match/,f);
});
test('signed evidence obligation cannot be downgraded',()=>{
  const [s,f]=replaceModule('AUTHORISATION,EXECUTION,OBSERVATION,OUTCOME','AUTHORISATION,EXECUTION');
  throws(s,/contract proof phases must exactly match/,f);
});
test('unbound composition nodes and duplicate binding rejected',()=>{
  const b=source.replace(/  bind community.audit_stage as audit_node \{[\s\S]*?\n  \}\n/,'');
  throws(b,/every composition node/);
  const dup=source.replace('node independent_check','node find_primary');throws(dup,/multiply-bound composition node/);
});
test('template parameter budget/run limits reject growth',()=>{
  throws(source.replace('node find_primary\n    task find_supplier\n    runs 1\n    budget 2','node find_primary\n    task find_supplier\n    runs 2\n    budget 2'),/template runs exceed approved bounds/);
  throws(source.replace('node find_primary\n    task find_supplier\n    runs 1\n    budget 2','node find_primary\n    task find_supplier\n    runs 1\n    budget 6'),/template budget exceeds approved bounds/);
});
test('re-hashed forged authority fails independent semantic verification',()=>{
  const a=cloned(build());a.ir.governance.executionAllowed=true;a.irDigest=digestIR(a.ir);
  assert.equal(verifyIR(a.ir,a.components,a.irDigest).valid,false);
  assert.equal(verifyProgram(source,files,a).valid,false);
});
test('re-hashed forged task binding fails independent semantic verification',()=>{
  const a=cloned(build());a.ir.bindings[0].capability='admin.root';a.irDigest=digestIR(a.ir);
  assert.equal(verifyIR(a.ir,a.components,a.irDigest).valid,false);
});
test('forged source artifact fails full independent recompilation',()=>{
  const a=cloned(build());a.sourceSha256='0'.repeat(64);
  assert.equal(verifyProgram(source,files,a).valid,false);
});
test('unknown identifiers, duplicate fields and JS not accepted by parser',()=>{
  assert.throws(()=>parseProgram(source.replace('program learning_community','program 4bad')),/expected|invalid/);
  assert.throws(()=>parseProgram(source.replace('bind community.scout_stage as scout_node {','bind community.scout_stage as scout_node {\n    task find_supplier')),/duplicate binding field/);
  assert.throws(()=>parseProgram(source+'\nrequire("fs")'),/trailing tokens|invalid token/);
});
test('source map rejects missing dependency and traversal',()=>{
  const fs2={...files};delete fs2['examples/community-proofs.octo'];
  assert.throws(()=>compileProgram(source,fs2),/missing source/);
  assert.throws(()=>parseProgram(source.replace('examples/community-proofs.octo','../secrets.octo')),/invalid source path/);
});
test('module library can be parsed independently and used in multiple programs',()=>{
  const m=parseModule(files[modulePath]);assert.equal(m.name,'community');assert.equal(m.contracts.length,4);
  const alt=source.replace('program learning_community','program learning_alternative');
  assert.equal(build(alt).ir.name,'learning_alternative');
  assert.notEqual(build(alt).irDigest,build().irDigest);
});
test('inline reusable module yields same semantics after removing import',()=>{
  const inline=source.replace(/  import "modules\/community-contracts\.octo" sha256 "[a-f0-9]{64}"/,`  ${files[modulePath].trim()}`);
  const a=build(inline);assert.equal(a.ir.bindings.length,4);
  assert.equal(a.ir.componentDigests.mission,build().ir.componentDigests.mission);
  assert.equal(a.ir.sourceDigests.length,4);
});
test('CLI checks, compiles, verifies and rejects tampering',()=>{
  const cwd=root;const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'octolang20-'));
  try{
    const out=path.join(tmp,'program.json');
    const invoke=(...args)=>cp.spawnSync(process.execPath,['bin/octolang-program.js',...args],{cwd,encoding:'utf8'});
    assert.equal(invoke('check','community-program.octo').status,0);
    assert.equal(invoke('compile','community-program.octo',out).status,0);
    assert.equal(invoke('verify','community-program.octo',out).status,0);
    const art=JSON.parse(fs.readFileSync(out,'utf8'));art.ir.worstCaseBudgetUnits=999;
    fs.writeFileSync(out,JSON.stringify(art));assert.notEqual(invoke('verify','community-program.octo',out).status,0);
  } finally {fs.rmSync(tmp,{recursive:true,force:true});}
});
