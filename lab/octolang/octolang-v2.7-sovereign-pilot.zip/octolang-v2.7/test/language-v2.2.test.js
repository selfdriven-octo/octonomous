'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {compileScore,parseScore,sha}=require('../language/v2.1');
const {OBS_SCHEMA,REVIEW_SCHEMA,digestObservation,compileRevision,createObservation,createReview}=require('../language/v2.1/refinement');
const {ActivationGate,verifyLedger,makeActivation,makeVccDecision,hash}=require('../language/v2.2');
const {decisionFromMission}=require('../language/v2.2/mission-vcc');
const {canonical}=require('../src/canonical');
const {compileMission}=require('../src/mission');
const {fixtures}=require('../mission/demo');
const scoreSource=fs.readFileSync(path.join(__dirname,'../community-score.octo'),'utf8'),scoreArtifact=compileScore(scoreSource);
const clock=Date.UTC(2026,9,21,11,0),iso=ms=>new Date(ms).toISOString();
function fixture(){
  const make=()=>crypto.generateKeyPairSync('ed25519'),actors=Object.fromEntries(['observer','reviewer','governor','vcc','controller'].map(x=>[x,make()]));
  const pins=Object.fromEntries(Object.entries(actors).map(([k,v])=>[k,v.publicKey.export({format:'pem',type:'spki'}).toString()]));
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v22-test-'));
  const params={directory,scoreSource,pins,controllerPrivateKey:actors.controller.privateKey,now:()=>clock};
  const gate=new ActivationGate(params);gate.init();
  const payload={schema:OBS_SCHEMA,scoreDigest:scoreArtifact.irDigest,metric:'cost-per-run',value:4,unit:'budget-units',
    sampleDigest:sha('signed test observation'),observedAt:iso(clock-60000),validUntil:iso(clock+900000),kind:'OBSERVATION'};
  const observation=createObservation(payload,actors.observer.privateKey);
  function refinement(budget=1){
    const revisionSource=`revision lean_supplies { base "${scoreArtifact.irDigest}" evidence "${digestObservation(payload)}" trigger "cost-per-run" above 3 tune scout_node runs 1 budget ${budget} }`;
    const revisionArtifact=compileRevision(revisionSource,scoreArtifact);
    const review=createReview({schema:REVIEW_SCHEMA,scoreDigest:scoreArtifact.irDigest,revisionDigest:revisionArtifact.irDigest,
      evidenceDigest:digestObservation(payload),reviewedAt:iso(clock),validUntil:iso(clock+600000),decision:'APPROVE_PROPOSAL_ONLY'},actors.reviewer.privateKey);
    const status=gate.status().state;
    const activation=makeActivation({schema:'octolang.activation.v2.2',scoreDigest:scoreArtifact.irDigest,revisionDigest:revisionArtifact.irDigest,
      expectedHead:status.head,expectedSequence:status.sequence+1,issuedAt:iso(clock),expiresAt:iso(clock+600000),decision:'ACTIVATE_LIMITS_ONLY'},actors.governor.privateKey);
    return {revisionSource,revisionArtifact,review,observation,activation};
  }
  function request(binding='scout_node',units=1,nonce=crypto.randomUUID(),activeRevisionDigest=gate.status().state.activeRevisionDigest){
    const b=scoreArtifact.ir.bindings.find(x=>x.name===binding);
    const req={scoreDigest:scoreArtifact.irDigest,activeRevisionDigest,binding:b.name,task:b.task,capability:b.capability,
      effect:b.effect,units,nonce,target:'supplier-42',contextRoot:sha('pinned signed context evidence')};
    const vccReceipt=makeVccDecision({schema:'octolang.vcc-decision.v2.2',requestDigest:hash('OctoLang v2.2 Request\n'+canonical(req)),
      decision:'ALLOW',issuedAt:iso(clock),expiresAt:iso(clock+60000)},actors.vcc.privateKey);
    return {request:req,vccReceipt};
  }
  return {actors,pins,params,gate,refinement,request,directory};
}
test('initialise once and verify ledger independently without signing keys',()=>{
  const f=fixture(),r=verifyLedger({directory:f.directory,scoreSource,pins:f.pins});
  assert.equal(r.valid,true);assert.equal(r.state.sequence,1);assert.equal(r.state.activeRevisionDigest,null);
  assert.throws(()=>f.gate.init(),/already initialised/);
});
test('activation requires distinct signed governance authorization, not only review',()=>{
  const f=fixture(),r=f.refinement();assert.throws(()=>f.gate.activate({...r,activation:null}),/signature invalid/);
  f.gate.activate(r);assert.equal(f.gate.status().state.activeBindings.find(x=>x.name==='scout_node').budgetUnitsPerRun,1);
});
test('forged activation key denied',()=>{
  const f=fixture(),r=f.refinement();const other=crypto.generateKeyPairSync('ed25519');
  r.activation=makeActivation(r.activation.payload,other.privateKey);
  assert.throws(()=>f.gate.activate(r),/signature invalid/);
});
test('observation and review proof retained and reverified from disk',()=>{
  const f=fixture();f.gate.activate(f.refinement());const g=new ActivationGate(f.params);
  assert.equal(g.status().state.sequence,2);
  const res=verifyLedger({directory:f.directory,scoreSource,pins:f.pins});assert.equal(res.valid,true);
});
test('stale activation head cannot approve new sequence',()=>{
  const f=fixture(),r=f.refinement();f.gate.reserve(f.request('intent_node',1));assert.throws(()=>f.gate.activate(r),/stale\/wrong activation/);
});
test('multiple refinements must be monotonic, cannot restore original budget',()=>{
  const f=fixture();f.gate.activate(f.refinement(1));
  assert.throws(()=>f.gate.activate(f.refinement(2)),/revision must tighten at least one|must tighten current limits|budget increased/);
  f.gate.activate(f.refinement(0));
  assert.equal(f.gate.status().state.activeBindings.find(x=>x.name==='scout_node').budgetUnitsPerRun,0);
});
test('already consumed funds prohibit tightening below historical spend',()=>{
  const f=fixture();f.gate.reserve(f.request('scout_node',2));assert.throws(()=>f.gate.activate(f.refinement(1)),/below already consumed/);
});
test('reservations stay consumed after process restart and replay is refused',()=>{
  const f=fixture();f.gate.activate(f.refinement());const r=f.request('intent_node',2);
  f.gate.reserve(r);const second=new ActivationGate(f.params);
  assert.equal(second.status().state.used.intent_node.units,2);
  assert.throws(()=>second.reserve(r),/replayed reservation/);
  assert.throws(()=>second.reserve(f.request('intent_node',2)),/cumulative run or budget limit/);
});
test('VCC must bind exact budget, capability, context and active score',()=>{
  const f=fixture(),r=f.request();r.request.capability='wallet.transfer';assert.throws(()=>f.gate.reserve(r),/VCC decision not bound/);
  const invalid=f.request();invalid.request.units=3;assert.throws(()=>f.gate.reserve(invalid),/VCC decision not bound/);
});
test('VCC denied decision, forged VCC key and stale approvals cannot reserve',()=>{
  const f=fixture(),r=f.request();
  r.vccReceipt.payload.decision='DENY';assert.throws(()=>f.gate.reserve(r),/signature invalid/);
  const other=f.request(),rogue=crypto.generateKeyPairSync('ed25519');
  other.vccReceipt=makeVccDecision(other.vccReceipt.payload,rogue.privateKey);
  assert.throws(()=>f.gate.reserve(other),/VCC signature invalid/);
});
test('earlier VCC authorization invalid after revision activation',()=>{
  const f=fixture(),r=f.request();f.gate.activate(f.refinement());assert.throws(()=>f.gate.reserve(r),/stale active revision/);
});
test('ledger rejects tampering and rehashed body without controller signature',()=>{
  const f=fixture();f.gate.reserve(f.request());
  const logfile=path.join(f.directory,'events.jsonl'),lines=fs.readFileSync(logfile,'utf8').trimEnd().split('\n');
  const event=JSON.parse(lines[1]);event.payload.request.units=999;
  event.hash=hash('OctoLang v2.2 Ledger Event\n'+canonical({sequence:event.sequence,previous:event.previous,kind:event.kind,payload:event.payload}));
  lines[1]=JSON.stringify(event);fs.writeFileSync(logfile,lines.join('\n')+'\n');
  const v=verifyLedger({directory:f.directory,scoreSource,pins:f.pins});assert.equal(v.valid,false);
  assert.throws(()=>f.gate.reserve(f.request('intent_node')),/journal signature invalid/);
});
test('truncated ledger fails closed, never silently repairs itself',()=>{
  const f=fixture(),logfile=path.join(f.directory,'events.jsonl');fs.appendFileSync(logfile,'{partial');
  assert.equal(verifyLedger({directory:f.directory,scoreSource,pins:f.pins}).valid,false);
  assert.throws(()=>f.gate.reserve(f.request()),/truncated journal tail/);
});
test('existing exclusive lock fails closed rather than breaking possibly-live writer',()=>{
  const f=fixture();fs.mkdirSync(path.join(f.directory,'.exclusive-lock'));
  assert.throws(()=>f.gate.reserve(f.request()),/ledger locked/);
  fs.rmdirSync(path.join(f.directory,'.exclusive-lock'));
});
test('independent verifier rejects wrong source, pin and signature',()=>{
  const f=fixture(),wrong={...f.pins,controller:f.pins.vcc};
  assert.equal(verifyLedger({directory:f.directory,scoreSource,pins:wrong}).valid,false);
  assert.equal(verifyLedger({directory:f.directory,scoreSource:scoreSource.replace('max 100 ADA','max 90 ADA'),pins:f.pins}).valid,false);
});
test('mission bridge uses independently signed review, grants and claims',()=>{
  const f=fixture(),mission=compileMission(parseScore(scoreSource).layers.mission);
  const inp={amount:'75',priority:'3',project:'Community project',note:'Materials',urgent:false};
  const fx=fixtures(mission,{now:clock,inputs:inp});
  const options={scoreSource,scoreArtifact,binding:'intent_node',units:2,activeRevisionDigest:null,
    missionParams:{mission,request:fx.request,review:fx.review,claims:fx.claims,grants:fx.grants,trust:fx.trust},
    vccPrivateKey:f.actors.vcc.privateKey,now:clock};
  const decision=decisionFromMission(options);f.gate.reserve(decision);assert.equal(f.gate.status().state.used.intent_node.units,2);
  assert.throws(()=>decisionFromMission({...options,missionParams:{...options.missionParams,claims:[]}}),/preflight rejected/);
  assert.throws(()=>decisionFromMission({...options,missionParams:{...options.missionParams,review:null}}),/preflight rejected/);
  assert.throws(()=>decisionFromMission({...options,missionParams:{...options.missionParams,grants:[]}}),/preflight rejected/);
});
test('wrong mission or changed task cannot issue VCC decision',()=>{
  const f=fixture(),mission=compileMission(parseScore(scoreSource).layers.mission),fx=fixtures(mission,{now:clock,inputs:{amount:'75',priority:'3',project:'P',note:'N',urgent:false}});
  const params={scoreSource,binding:'intent_node',units:1,activeRevisionDigest:null,missionParams:{mission:{...mission,goal:'Forged'},request:fx.request,review:fx.review,claims:fx.claims,grants:fx.grants,trust:fx.trust},vccPrivateKey:f.actors.vcc.privateKey,now:clock};
  assert.throws(()=>decisionFromMission(params),/mission does not match/);
});
test('missing state seal or vanished ledger requires manual reconciliation',()=>{
  const f=fixture(),seal=path.join(f.directory,'state-seal.json');fs.unlinkSync(seal);
  assert.match(verifyLedger({directory:f.directory,scoreSource,pins:f.pins}).reason,/head seal missing/);
  assert.throws(()=>f.gate.reserve(f.request()),/head seal missing/);
  const other=fixture();fs.unlinkSync(path.join(other.directory,'events.jsonl'));
  assert.match(verifyLedger({directory:other.directory,scoreSource,pins:other.pins}).reason,/ledger missing while seal remains/);
  assert.throws(()=>other.gate.init(),/ledger missing/);
});
test('a journal truncate while a signed newer seal remains is rejected',()=>{
  const f=fixture();f.gate.reserve(f.request());const logfile=path.join(f.directory,'events.jsonl');
  const lines=fs.readFileSync(logfile,'utf8').trimEnd().split('\n');fs.writeFileSync(logfile,lines[0]+'\n');
  assert.match(verifyLedger({directory:f.directory,scoreSource,pins:f.pins}).reason,/head seal mismatch|rolled back/);
});
test('replayed historical seal cannot conceal a new event',()=>{
  const f=fixture(),seal=path.join(f.directory,'state-seal.json');const old=fs.readFileSync(seal);
  f.gate.reserve(f.request());fs.writeFileSync(seal,old);
  assert.equal(verifyLedger({directory:f.directory,scoreSource,pins:f.pins}).valid,false);
});
test('role pins cannot conflate review and governance authorities',()=>{
  const f=fixture();assert.throws(()=>new ActivationGate({...f.params,pins:{...f.pins,governor:f.pins.reviewer}}),/distinct/);
});
test('expired governance activation and VCC decisions cannot be replayed',()=>{
  const f=fixture(),r=f.refinement();
  r.activation=makeActivation({...r.activation.payload,issuedAt:iso(clock-120000),expiresAt:iso(clock-60000)},f.actors.governor.privateKey);
  assert.throws(()=>f.gate.activate(r),/expired or premature/);
  const req=f.request();req.vccReceipt=makeVccDecision({...req.vccReceipt.payload,issuedAt:iso(clock-120000),expiresAt:iso(clock-60000)},f.actors.vcc.privateKey);
  assert.throws(()=>f.gate.reserve(req),/expired or premature/);
});
test('a backwards local clock cannot produce a valid later journal transition',()=>{
  const f=fixture();const earlier=new ActivationGate({...f.params,now:()=>clock-1000});
  assert.throws(()=>earlier.reserve(f.request()),/timestamp moved backwards/);
});
test('forged signed state seal rejected even when head and sequence match',()=>{
  const f=fixture(),seal=path.join(f.directory,'state-seal.json');let s=JSON.parse(fs.readFileSync(seal,'utf8'));
  s.signature=crypto.sign(null,Buffer.from('not-the-real-seal'),crypto.generateKeyPairSync('ed25519').privateKey).toString('base64');
  fs.writeFileSync(seal,JSON.stringify(s));assert.match(verifyLedger({directory:f.directory,scoreSource,pins:f.pins}).reason,/invalid signed head seal/);
});
test('overlong VCC lifetime is rejected despite a valid VCC signature',()=>{
  const f=fixture(),r=f.request();r.vccReceipt=makeVccDecision({...r.vccReceipt.payload,expiresAt:iso(clock+3600000)},f.actors.vcc.privateKey);
  assert.throws(()=>f.gate.reserve(r),/invalid signature time range/);
});
test('standalone auditor CLI accepts only source, public pins and ledger directory',()=>{
  const f=fixture(),cp=require('node:child_process'),pinsFile=path.join(f.directory,'pins.json');fs.writeFileSync(pinsFile,JSON.stringify(f.pins),{mode:0o600});
  const out=cp.execFileSync(process.execPath,[path.join(__dirname,'../bin/octolang-activation.js'),'verify',path.join(__dirname,'../community-score.octo'),pinsFile,f.directory],{encoding:'utf8'});
  const a=JSON.parse(out);assert.equal(a.valid,true);assert.equal(a.sequence,1);assert.equal(a.activeWorstCaseBudgetUnits,7);
});
