'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const crypto=require('node:crypto');
const {canonical,signed,digest}=require('../src/canonical');
const {compileLanguage}=require('../language/v1.6');
const {compileAssurance,verifyAssurance,hashIR19}=require('../language/v1.9');
const {verifyIR}=require('../language/v1.9/validate');
const {evaluate}=require('../language/v1.9/evidence');
const {makeDemoEvidence}=require('../language/v1.9/demo');
const {run:runVectors}=require('../conformance/v1.9/runner');
const root=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(root,'examples/community-assurance.octo'),'utf8');
const mission=fs.readFileSync(path.join(root,'examples/community-proofs.octo'),'utf8');
const rootIR=compileLanguage(mission).ir,artifact=compileAssurance(source,mission);
const change=(a,b)=>source.replace(a,b);
const clone=x=>structuredClone(x);
const attempt=h=>evaluate({ir:h.art.ir,irDigest:h.art.irDigest,rootIR:h.root,request:h.request,trust:h.trust,claims:h.claims,now:h.now});
function reSign(h,index,changes){const old=h.claims[index];h.claims[index]=signed({...old.payload,...changes},h.identities[old.payload.phase]);}
function indexOf(h,task,phase){return h.claims.findIndex(x=>x.payload.task===task&&x.payload.phase===phase);}

test('v1.9 baseline compiles to typed, independently verifiable artifact',()=>{
  assert.equal(artifact.ir.effects.length,4);assert.equal(artifact.ir.obligations.length,4);
  assert.equal(artifact.ir.invariants.find(x=>x.input==='amount').max,100000000);
  assert.equal(verifyAssurance(source,mission,artifact).valid,true);
  assert.equal(verifyIR(artifact.ir,rootIR,artifact.irDigest).valid,true);
});
test('comments and order changes preserve semantic digest',()=>{
  const changed=source.replace('  effect find_supplier { allow EXTERNAL_SERVICE }\n','').replace('  effect independent_audit { allow LOCAL_CAPABILITY }','  effect independent_audit { allow LOCAL_CAPABILITY }\n  effect find_supplier { allow EXTERNAL_SERVICE }');
  assert.equal(compileAssurance(changed,mission).irDigest,artifact.irDigest);
  assert.equal(compileAssurance('# comment\n'+source,mission).irDigest,artifact.irDigest);
});
test('tighter bounds change digest but cannot broaden mission limits',()=>{
  const tighter=compileAssurance(change('max 100 ADA','max 80 ADA'),mission);
  assert.notEqual(tighter.irDigest,artifact.irDigest);
  assert.equal(tighter.ir.invariants.find(x=>x.input==='amount').max,80000000);
  assert.throws(()=>compileAssurance(change('max 100 ADA','max 101 ADA'),mission),/weakens/);
  assert.throws(()=>compileAssurance(change('max 100 ADA','max 100 count'),mission),/weakens/);
});
test('cannot authorise different or undeclared tool effects',()=>{
  assert.throws(()=>compileAssurance(change('effect find_supplier { allow EXTERNAL_SERVICE }','effect find_supplier { allow LOCAL_CAPABILITY }'),mission),/effect mismatch/);
  assert.throws(()=>compileAssurance(source.replace('effect vet_supplier { allow LOCAL_CAPABILITY }','effect surprise { allow EXTERNAL_SERVICE }'),mission),/undeclared effect/);
  assert.throws(()=>compileAssurance(change('  effect find_supplier { allow EXTERNAL_SERVICE }',''),mission),/each task/);
});
test('temporal constraints must follow the mission dependency graph',()=>{
  assert.throws(()=>compileAssurance(change('after record_intent before independent_audit','after independent_audit before record_intent'),mission),/dependencies/);
  assert.throws(()=>compileAssurance(change('within 60 m','within 100 d'),mission),/long/);
});
test('every task has an unbroken chain with independent observation for outcomes',()=>{
  assert.throws(()=>compileAssurance(change('"AUTHORISATION,EXECUTION,OBSERVATION,OUTCOME"','"AUTHORISATION,EXECUTION,OUTCOME"'),mission),/unbroken/);
  assert.throws(()=>compileAssurance(change('obligation find_supplier { require "AUTHORISATION,EXECUTION" }','obligation find_supplier { require "EXECUTION" }'),mission),/AUTHORISATION/);
  assert.throws(()=>compileAssurance(change('obligation record_intent { require "AUTHORISATION,EXECUTION,OBSERVATION,OUTCOME" }','obligation record_intent { require "AUTHORISATION,EXECUTION" }'),mission),/independent observation/);
});
test('IR reconstruction rejects additional permissions even after re-hashing',()=>{
  let altered=clone(artifact.ir);altered.governance.executionAllowed=true;
  assert.equal(verifyIR(altered,rootIR,hashIR19(altered)).valid,false);
  altered=clone(artifact.ir);altered.effects[0].requiredEffect='LOCAL_CAPABILITY';
  assert.equal(verifyIR(altered,rootIR,hashIR19(altered)).valid,false);
  altered=clone(artifact.ir);altered.temporal[0].maxMs=-1;
  assert.equal(verifyIR(altered,rootIR,hashIR19(altered)).valid,false);
});
test('source-bound verifier rejects substitution of source even with identical IR',()=>{
  assert.equal(verifyAssurance('# comment\n'+source,mission,artifact).valid,false);
  assert.equal(verifyAssurance(source,mission+'\n# changed',artifact).valid,false);
});
test('baseline independent receipt assessment admits only evidence',()=>{
  const h=makeDemoEvidence();const result=attempt(h);
  assert.equal(result.valid,true);assert.equal(result.decision,'EVIDENCE_ADMISSIBLE_ONLY');assert.equal(result.phasesVerified,12);
  assert.match(result.note,/not independent proof/);
});
test('bounded inputs use typed base units and fail closed',()=>{
  const h=makeDemoEvidence();h.request.inputs.amount=100000001;assert.equal(attempt(h).valid,false);
  h.request.inputs.amount=75;assert.equal(attempt(h).valid,false); // signed request mismatch cannot bypass context binding
});
test('unrecognised and missing input fields are rejected',()=>{
  const h=makeDemoEvidence();h.request.inputs.extra=true;assert.equal(attempt(h).valid,false);
  const k=makeDemoEvidence();delete k.request.inputs.priority;assert.equal(attempt(k).valid,false);
});
test('invalid signatures and substituted trusted public keys are rejected',()=>{
  const h=makeDemoEvidence();h.claims[0].signature=h.claims[0].signature.replace(/^./,h.claims[0].signature[0]==='A'?'B':'A');assert.equal(attempt(h).valid,false);
  const k=makeDemoEvidence();k.trust.issuers['demo-execution'].publicKey=crypto.generateKeyPairSync('ed25519').publicKey.export({type:'spki',format:'pem'});
  assert.equal(attempt(k).valid,false);
});
test('issuer aliases sharing the same key cannot simulate independent observation',()=>{
  const h=makeDemoEvidence();h.trust.issuers['demo-observation'].publicKey=h.trust.issuers['demo-execution'].publicKey;
  for(let i=0;i<h.claims.length;i++)if(h.claims[i].payload.phase==='OBSERVATION')h.claims[i]=signed(h.claims[i].payload,h.identities.EXECUTION);
  assert.equal(attempt(h).valid,false);
});
test('missing, extra, and duplicate proof phases are rejected',()=>{
  const h=makeDemoEvidence();h.claims.pop();assert.equal(attempt(h).valid,false);
  const j=makeDemoEvidence();j.claims[0]=j.claims[1];assert.equal(attempt(j).valid,false);
});
test('tampered phase links and changed evidence digests fail',()=>{
  const h=makeDemoEvidence(),idx=indexOf(h,'record_intent','EXECUTION');reSign(h,idx,{previousDigest:'0'.repeat(64)});
  assert.equal(attempt(h).valid,false);
  const q=makeDemoEvidence();q.claims[0].payload.evidenceDigest='f'.repeat(64);assert.equal(attempt(q).valid,false);
});
test('a signed FAILED outcome never becomes accepted proof',()=>{
  const h=makeDemoEvidence(),i=indexOf(h,'record_intent','OUTCOME');reSign(h,i,{status:'FAILED'});
  assert.equal(attempt(h).valid,false);
});
test('execution effect cannot be misrepresented even in a valid signature',()=>{
  const h=makeDemoEvidence(),i=indexOf(h,'find_supplier','EXECUTION');reSign(h,i,{effect:'LOCAL_CAPABILITY'});
  assert.equal(attempt(h).valid,false);
});
test('wrong subject or action commitment is rejected',()=>{
  const h=makeDemoEvidence();reSign(h,0,{subject:'another-project'});assert.equal(attempt(h).valid,false);
  const k=makeDemoEvidence();reSign(k,0,{actionDigest:'0'.repeat(64)});assert.equal(attempt(k).valid,false);
});
test('expired and future-dated proofs are denied',()=>{
  const h=makeDemoEvidence();reSign(h,0,{validUntil:h.now-1});assert.equal(attempt(h).valid,false);
  const k=makeDemoEvidence();reSign(k,0,{attestedAt:k.now+60000});assert.equal(attempt(k).valid,false);
});
test('signed temporal attestations are checked, not blindly accepted',()=>{
  const h=makeDemoEvidence(),idx=indexOf(h,'independent_audit','EXECUTION');
  const old=h.claims[idx].payload;
  reSign(h,idx,{attestedAt:h.now-10000});
  // Exact latest evidence remains valid but signed event-time comparison fails after shifting upstream.
  const r=attempt(h);assert.equal(r.valid,false); // successor signed receipts still point to older digest
  assert.equal(!!old,true);
});
test('full signed chain can be semantically late yet cryptographically valid',()=>{
  const h=makeDemoEvidence();
  const stamp={find_supplier:h.now-4500000,vet_supplier:h.now-4400000,record_intent:h.now-4300000,independent_audit:h.now-50000};
  for(const obligation of h.art.ir.obligations){let previous=null;
    for(let idx=0;idx<obligation.phases.length;idx++){
      const phase=obligation.phases[idx],i=indexOf(h,obligation.task,phase),p=h.claims[i].payload;
      const next={...p,attestedAt:stamp[obligation.task]+idx*1000,previousDigest:previous};
      h.claims[i]=signed(next,h.identities[phase]);previous=digest(next);
    }
  }
  assert.match(attempt(h).reason,/temporal invariant/);
});
test('frozen v1.9 conformance vectors',()=>{assert.equal(runVectors(),20);});
