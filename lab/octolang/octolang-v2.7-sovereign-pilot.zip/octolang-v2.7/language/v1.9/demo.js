'use strict';
const crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const {signed,digest}=require('../../src/canonical');
const {compileLanguage}=require('../v1.6');
const {compileAssurance}=require('./index');
const {evaluate,CLAIM}=require('./evidence');
const dir=path.join(__dirname,'../..');
const mission=fs.readFileSync(path.join(dir,'examples/community-proofs.octo'),'utf8');
const source=fs.readFileSync(path.join(dir,'examples/community-assurance.octo'),'utf8');
const root=compileLanguage(mission).ir,art=compileAssurance(source,mission);
function makeDemoEvidence({now=Date.now(),amount=75000000,priority=5,lateAudit=false}={}){
  const identities={};const trust={issuers:{}};
  for(const phase of ['AUTHORISATION','EXECUTION','OBSERVATION','OUTCOME']){
    const key=crypto.generateKeyPairSync('ed25519');identities[phase]=key.privateKey;
    trust.issuers['demo-'+phase.toLowerCase()]={publicKey:key.publicKey.export({type:'spki',format:'pem'}),phases:[phase]};
  }
  const request={subject:'community-project',inputs:{amount,priority},actionDigest:digest({id:'local-research-demo',mission:art.irDigest})};
  const timed={find_supplier:now-120000,vet_supplier:now-100000,record_intent:now-80000,independent_audit:lateAudit?now+8000000:now-50000};
  const claims=[];
  for(const o of art.ir.obligations){let previous=null;
    for(let idx=0;idx<o.phases.length;idx++){
      const phase=o.phases[idx],attestedAt=timed[o.task]+idx*1000;
      const payload={schema:CLAIM,missionIRDigest:art.ir.missionIRDigest,assuranceIRDigest:art.irDigest,task:o.task,phase,
        subject:request.subject,actionDigest:request.actionDigest,requestDigest:digest(request),issuer:'demo-'+phase.toLowerCase(),
        attestedAt,validUntil:now+3600000,previousDigest:previous,status:'ATTESTED',
        effect:phase==='EXECUTION'?art.ir.effects.find(x=>x.task===o.task).requiredEffect:'NONE',
        evidenceDigest:digest({task:o.task,phase,source:'synthetic-demo-evidence'})};
      claims.push(signed(payload,identities[phase]));previous=digest(payload);
    }
  }
  return {root,art,request,claims,trust,now,identities};
}
function run(){
  const h=makeDemoEvidence(),result=evaluate({ir:h.art.ir,irDigest:h.art.irDigest,rootIR:h.root,claims:h.claims,trust:h.trust,request:h.request,now:h.now});
  console.log(JSON.stringify(result,null,2));if(!result.valid)process.exitCode=1;return result;
}
if(require.main===module)run();
module.exports={run,makeDemoEvidence};
