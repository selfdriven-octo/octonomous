'use strict';
// Independent checking of authored typed IR. Rebuilds semantic fields from mission root.
const {canonical}=require('../../src/canonical');
const {verifyIR:verifyRoot}=require('../v1.6/validate');
const {SCHEMA,makeIR,hashIR19}=require('./index');
const exact=(x,keys)=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype&&Object.keys(x).length===keys.length&&keys.every(k=>Object.hasOwn(x,k));
function need(x,s){if(!x)throw new Error('Invalid assurance IR: '+s);}
function validateIR(ir,rootIR){
  need(exact(ir,['schema','kind','missionName','missionIRDigest','governance','effects','invariants','temporal','obligations']),'outer shape');
  need(ir.schema===SCHEMA&&ir.kind==='assurance-policy','wrong schema');
  need(verifyRoot(rootIR,ir.missionIRDigest).valid,'invalid pinned mission IR');
  need(exact(ir.governance,['grantsImplied','executionAllowed','decision']),'governance shape');
  need(ir.governance.grantsImplied===false&&ir.governance.executionAllowed===false&&ir.governance.decision==='EVIDENCE_ASSESSMENT_ONLY','fabricated execution authority');
  for(const [key,fields] of Object.entries({effects:['task','requiredEffect','source'],invariants:['name','input','max','unit','interpretation'],temporal:['name','afterTask','beforeTask','maxMs','clock'],obligations:['task','phases','independentActors','assertsObjectiveTruth']})){
    need(Array.isArray(ir[key])&&ir[key].every(x=>exact(x,fields)),'invalid '+key+' shape');
  }
  const projected=makeIR({missionName:ir.missionName,
    effects:ir.effects.map(x=>({task:x.task,effect:x.requiredEffect})),
    invariants:ir.invariants.map(x=>({name:x.name,input:x.input,max:x.max,unit:x.unit})),
    temporal:ir.temporal.map(x=>({name:x.name,after:x.afterTask,before:x.beforeTask,maxMs:x.maxMs})),
    obligations:ir.obligations.map(x=>({task:x.task,phases:x.phases}))},rootIR);
  need(canonical(projected)===canonical(ir),'semantic fields altered or unsorted');
  return true;
}
function verifyIR(ir,rootIR,expectedDigest){try{
  validateIR(ir,rootIR);need(hashIR19(ir)===expectedDigest,'digest mismatch');
  return {valid:true,irDigest:expectedDigest};
}catch(e){return {valid:false,reason:e.message};}}
module.exports={validateIR,verifyIR};
