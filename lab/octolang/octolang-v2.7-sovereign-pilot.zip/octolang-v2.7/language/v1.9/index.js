'use strict';
// v1.9: Pure authoring, compilation, and semantic verification. Never grants execution authority.
const crypto=require('node:crypto');
const {canonical}=require('../../src/canonical');
const {compileLanguage,hashIR}=require('../v1.6');
const SCHEMA='octolang.assurance-ir.v1.9', ARTIFACT='octolang.assurance-artifact.v1.9';
const PREFIX='OctoLang Assurance IR v1.9\n';
const PHASES=['AUTHORISATION','EXECUTION','OBSERVATION','OUTCOME'];
const EFFECTS=['LOCAL_CAPABILITY','EXTERNAL_SERVICE'];
const IDENT=/^[A-Za-z_][A-Za-z0-9_-]*$/;
const sha=x=>crypto.createHash('sha256').update(x,'utf8').digest('hex');
const hashIR19=ir=>sha(PREFIX+canonical(ir));
const cmp=(a,b)=>a<b?-1:a>b?1:0;
const need=(x,msg)=>{if(!x)throw new Error('OctoLang assurance: '+msg);};
function tokenize(source){
  need(typeof source==='string'&&source.length<=65536,'source must be <= 65536 characters');
  const out=[];let at=0;
  while(at<source.length){
    const tail=source.slice(at),skip=tail.match(/^(?:\s+|#[^\n]*|\/\/[^\n]*)/);
    if(skip){at+=skip[0].length;continue;}
    const m=tail.match(/^(?:"(?:\\["\\nrt]|[^"\\\n\r])*"|[A-Za-z_][A-Za-z0-9_-]*|(?:0|[1-9][0-9]*)|[{}])/);
    need(!!m,'unrecognised token at offset '+at);out.push(m[0]);at+=m[0].length;
    need(out.length<=2500,'too many tokens');
  }
  return out;
}
function parse(source){
  const ts=tokenize(source);let i=0;
  const pop=expected=>{need(i<ts.length,'unexpected EOF');const s=ts[i++];if(expected)need(s===expected,`expected ${expected}, found ${s}`);return s;};
  const ident=()=>{const s=pop();need(IDENT.test(s),'invalid identifier '+s);return s;};
  const num=()=>{const s=pop();need(/^(0|[1-9][0-9]{0,12})$/.test(s),'invalid integer');return Number(s);};
  const str=()=>{const s=pop();need(s.startsWith('"'),'expected string');return JSON.parse(s);};
  pop('assurance');const missionName=ident();pop('{');
  const effects=[],invariants=[],temporal=[],obligations=[];const seen=new Set();
  while(ts[i]!=='}'){
    need(i<ts.length,'missing closing brace');const kind=ident(),name=ident();
    need(['effect','invariant','temporal','obligation'].includes(kind),'unknown declaration '+kind);
    need(!seen.has(kind+':'+name),'duplicate '+kind+' '+name);seen.add(kind+':'+name);
    pop('{');
    if(kind==='effect'){pop('allow');effects.push({task:name,effect:ident()});}
    if(kind==='invariant'){pop('input');const input=ident();pop('max');const max=num(),unit=ident();invariants.push({name,input,max,unit});}
    if(kind==='temporal'){
      pop('after');const after=ident();pop('before');const before=ident();pop('within');const duration=num(),unit=ident();
      need(['m','h','d'].includes(unit)&&duration>0,'invalid duration unit');
      const maxMs=duration*({m:60000,h:3600000,d:86400000})[unit];
      need(Number.isSafeInteger(maxMs)&&maxMs<=30*86400000,'temporal rule too long');
      temporal.push({name,after,before,maxMs});
    }
    if(kind==='obligation'){
      pop('require');const phases=str().split(',').map(x=>x.trim());
      need(phases.length>0&&new Set(phases).size===phases.length&&phases.every(x=>PHASES.includes(x)),'unknown or duplicate proof phase');
      obligations.push({task:name,phases});
    }
    pop('}');need(effects.length+invariants.length+temporal.length+obligations.length<=96,'too many declarations');
  }
  pop('}');need(i===ts.length,'trailing text');
  return {missionName,effects,invariants,temporal,obligations};
}
function makeIR(parsed,root){
  need(parsed.missionName===root.name,'mission mismatch');
  const tasks=new Map(root.tasks.map(t=>[t.name,t]));
  need(parsed.effects.length===tasks.size,'must declare each task effect once');
  const effects=parsed.effects.map(x=>{const task=tasks.get(x.task);need(!!task,'undeclared effect task '+x.task);
    need(EFFECTS.includes(x.effect)&&x.effect===task.effect,`effect mismatch for ${x.task}`);
    return {task:x.task,requiredEffect:x.effect,source:'PINNED_MISSION_IR_NOT_AGENT_AUTHORITY'};
  }).sort((a,b)=>cmp(a.task,b.task));
  need(new Set(effects.map(x=>x.task)).size===tasks.size,'duplicate effect task');
  const constraints=new Map(root.constraints.filter(c=>c.kind==='MAXIMUM').map(x=>[x.input,x]));
  const invariants=parsed.invariants.map(x=>{
    const constraint=constraints.get(x.input);
    need(!!constraint,`undeclared bounded input ${x.input}`);
    const normalized=x.unit==='ADA'&&constraint.unit==='lovelace'?x.max*1000000:x.max;
    need((x.unit===constraint.unit||(x.unit==='ADA'&&constraint.unit==='lovelace'))&&Number.isSafeInteger(normalized)&&normalized<=Number(constraint.maxValue)&&normalized>=0,`invariant weakens or changes bound ${x.name}`);
    return {name:x.name,input:x.input,max:normalized,unit:constraint.unit,interpretation:'REQUEST_INPUT_BOUND_NOT_OBSERVED_REAL_WORLD_AMOUNT'};
  }).sort((a,b)=>cmp(a.name,b.name));
  need(invariants.length===constraints.size,'all mission maximums must be preserved');
  need(new Set(invariants.map(x=>x.input)).size===constraints.size,'duplicate invariant input');
  const obligations=parsed.obligations.map(x=>{
    need(tasks.has(x.task),'obligation for undeclared task');
    need(x.phases.includes('AUTHORISATION')&&x.phases.includes('EXECUTION'),'every task needs AUTHORISATION and EXECUTION');
    const prefix=PHASES.slice(0,x.phases.length);
    need(prefix.every((p,i)=>x.phases.includes(p)),'phases must form an unbroken chain');
    const outcome=root.outcomes.some(y=>y.task===x.task);
    if(outcome)need(x.phases.includes('OBSERVATION')&&x.phases.includes('OUTCOME'),'outcome task requires independent observation and outcome');
    return {task:x.task,phases:[...prefix],independentActors:true,assertsObjectiveTruth:false};
  }).sort((a,b)=>cmp(a.task,b.task));
  need(obligations.length===tasks.size&&new Set(obligations.map(x=>x.task)).size===tasks.size,'every task requires exactly one obligation');
  const obligationMap=new Map(obligations.map(x=>[x.task,x]));
  const temporal=parsed.temporal.map(x=>{
    const earlier=tasks.get(x.after),later=tasks.get(x.before);
    need(earlier&&later&&x.after!==x.before,'invalid temporal task references');
    need(Number.isSafeInteger(x.maxMs)&&x.maxMs>=60000&&x.maxMs<=30*86400000&&x.maxMs%60000===0,'invalid temporal maximum');
    const visited=new Set();function depends(name){if(visited.has(name))return false;visited.add(name);
      return tasks.get(name).dependencies.some(dep=>dep===x.after||depends(dep));
    }
    need(depends(x.before),'temporal order contradicts declared dependencies');
    need(obligationMap.get(x.after).phases.includes('EXECUTION')&&obligationMap.get(x.before).phases.includes('EXECUTION'),'temporal endpoints require execution evidence');
    return {name:x.name,afterTask:x.after,beforeTask:x.before,maxMs:x.maxMs,clock:'SIGNED_ATTESTER_TIMESTAMPS_NOT_TRUSTED_WALL_CLOCK'};
  }).sort((a,b)=>cmp(a.name,b.name));
  return {schema:SCHEMA,kind:'assurance-policy',missionName:root.name,missionIRDigest:hashIR(root),
    governance:{grantsImplied:false,executionAllowed:false,decision:'EVIDENCE_ASSESSMENT_ONLY'},
    effects,invariants,temporal,obligations};
}
function compileAssurance(source,missionSource){
  const root=compileLanguage(missionSource),ir=makeIR(parse(source),root.ir);
  return {schema:ARTIFACT,sourceSha256:sha(source),missionSourceSha256:sha(missionSource),missionIRDigest:root.irDigest,ir,irDigest:hashIR19(ir)};
}
function verifyAssurance(source,missionSource,artifact){
  try{
    const expected=compileAssurance(source,missionSource);
    const {verifyIR}=require('./validate');const result=verifyIR(artifact.ir,compileLanguage(missionSource).ir,artifact.irDigest);
    need(result.valid,result.reason);need(canonical(expected)===canonical(artifact),'artifact differs from source');
    return {valid:true,irDigest:expected.irDigest};
  }catch(e){return {valid:false,reason:e.message};}
}
module.exports={SCHEMA,ARTIFACT,PREFIX,PHASES,parse,makeIR,compileAssurance,verifyAssurance,hashIR19};
