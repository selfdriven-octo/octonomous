'use strict';
// Independent, fail-closed verifier for signed phase attestations. Does NOT perform actions,
// verify hardware telemetry, transfer assets, or establish real-world truth.
const crypto=require('node:crypto');
const {digest,verifiedSigned}=require('../../src/canonical');
const {verifyIR}=require('./validate');
const {PHASES}=require('./index');
const CLAIM='octolang.assurance-claim.v1.9', HEX=/^[0-9a-f]{64}$/;
const exact=(o,ks)=>o&&typeof o==='object'&&!Array.isArray(o)&&Object.getPrototypeOf(o)===Object.prototype&&Object.keys(o).length===ks.length&&ks.every(k=>Object.hasOwn(o,k));
const need=(condition,message)=>{if(!condition)throw new Error('Assurance verification: '+message);};
function keyId(pem){return crypto.createHash('sha256').update(crypto.createPublicKey(pem).export({format:'der',type:'spki'})).digest('hex');}
function evaluate({ir,irDigest,rootIR,claims,trust,request,now=Date.now()}){
  try{
    const checked=verifyIR(ir,rootIR,irDigest);need(checked.valid,checked.reason);
    need(Number.isSafeInteger(now)&&now>=0,'invalid verifier clock');
    need(exact(request,['subject','inputs','actionDigest']),'invalid request shape');
    need(typeof request.subject==='string'&&request.subject.length>0&&request.subject.length<=128,'missing expected subject');
    need(typeof request.actionDigest==='string'&&HEX.test(request.actionDigest),'invalid action digest');
    need(request.inputs&&Object.getPrototypeOf(request.inputs)===Object.prototype&&!Array.isArray(request.inputs),'invalid typed input map');
    const expectedInputs=ir.invariants.map(x=>x.input).sort();
    need(Object.keys(request.inputs).sort().join('|')===expectedInputs.join('|'),'unexpected or missing request inputs');
    for(const rule of ir.invariants){const value=request.inputs[rule.input];
      need(Number.isSafeInteger(value)&&value>=0&&value<=rule.max,'request invariant exceeded: '+rule.name);
    }
    const reqDigest=digest(request);
    need(exact(trust,['issuers'])&&trust.issuers&&Object.getPrototypeOf(trust.issuers)===Object.prototype,'external issuer pins required');
    const n=ir.obligations.reduce((sum,o)=>sum+o.phases.length,0);
    need(Array.isArray(claims)&&claims.length===n,'required proof phases missing or extra');
    const map=new Map(),trustedPublicKeys=new Map();
    for(const signed of claims){
      need(exact(signed,['payload','signature']),'invalid signed envelope');
      const p=signed.payload;
      need(exact(p,['schema','missionIRDigest','assuranceIRDigest','task','phase','subject','actionDigest','requestDigest','issuer','attestedAt','validUntil','previousDigest','status','effect','evidenceDigest']),'invalid claim payload fields');
      need(p.schema===CLAIM&&p.missionIRDigest===ir.missionIRDigest&&p.assuranceIRDigest===irDigest,'claim not bound to exact approved mission/assurance');
      need(p.subject===request.subject&&p.actionDigest===request.actionDigest&&p.requestDigest===reqDigest,'claim not bound to request');
      const obligation=ir.obligations.find(o=>o.task===p.task);
      need(obligation&&obligation.phases.includes(p.phase),'claim phase not required for declared task');
      need(p.status==='ATTESTED','non-successful attestation');
      need(typeof p.evidenceDigest==='string'&&HEX.test(p.evidenceDigest),'invalid supporting evidence digest');
      need(Number.isSafeInteger(p.attestedAt)&&Number.isSafeInteger(p.validUntil)&&p.attestedAt>=0&&p.attestedAt<=now+30000&&p.validUntil>now&&p.validUntil>p.attestedAt,'expired or future-dated attestation');
      need(p.previousDigest===null||typeof p.previousDigest==='string'&&HEX.test(p.previousDigest),'invalid previous digest');
      const expectEffect=ir.effects.find(e=>e.task===p.task).requiredEffect;
      need(p.effect===(p.phase==='EXECUTION'?expectEffect:'NONE'),'undeclared effect or phase');
      const pin=Object.hasOwn(trust.issuers,p.issuer)?trust.issuers[p.issuer]:null;
      need(exact(pin,['publicKey','phases'])&&typeof pin.publicKey==='string'&&Array.isArray(pin.phases)&&pin.phases.includes(p.phase),'untrusted issuer or phase');
      need(verifiedSigned(signed,pin.publicKey),'invalid signature');
      const key=p.task+':'+p.phase;need(!map.has(key),'duplicate proof phase');
      map.set(key,{p,d:digest(p),keyId:keyId(pin.publicKey)});trustedPublicKeys.set(p.issuer,keyId(pin.publicKey));
    }
    for(const o of ir.obligations){
      const agents=new Set();let last=null;
      for(const phase of o.phases){
        const claim=map.get(o.task+':'+phase);need(!!claim,'missing phase '+o.task+' '+phase);
        need(claim.p.previousDigest===(last?last.d:null),'broken phase evidence chain');
        if(last)need(claim.p.attestedAt>=last.p.attestedAt,'phase timestamps out of order');
        need(!agents.has(claim.keyId),'phase attester not independent');
        agents.add(claim.keyId);last=claim;
      }
    }
    // Signed clocks are attestations, not independently witnessed time.
    for(const task of rootIR.tasks){
      const observed=map.get(task.name+':EXECUTION').p.attestedAt;
      for(const name of task.dependencies)
        need(map.get(name+':EXECUTION').p.attestedAt<=observed,'mission dependency timing violated');
    }
    for(const rule of ir.temporal){
      const start=map.get(rule.afterTask+':EXECUTION').p.attestedAt;
      const end=map.get(rule.beforeTask+':EXECUTION').p.attestedAt;
      need(end>=start&&end-start<=rule.maxMs,'temporal invariant violated: '+rule.name);
    }
    return {valid:true,decision:'EVIDENCE_ADMISSIBLE_ONLY',assuranceIRDigest:irDigest,
      phasesVerified:map.size,temporalChecks:ir.temporal.length,invariantsChecked:ir.invariants.length,
      note:'Trusted signed attestations and claimed times are not independent proof that physical outcomes happened, nor VCC authorisation.'};
  }catch(e){return {valid:false,decision:'DENY',reason:e.message};}
}
module.exports={CLAIM,evaluate};
