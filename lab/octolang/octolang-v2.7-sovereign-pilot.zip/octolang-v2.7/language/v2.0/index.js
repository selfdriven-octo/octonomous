'use strict';
/**
 * OctoLang v2.0: a pure, declarative programme/linker. No network, disk, key
 * access, AI calls, policy approval, or execution. Imported sources are supplied
 * explicitly by caller; CLI owns the separate filesystem trust boundary.
 */
const crypto = require('node:crypto');
const {canonical} = require('../../src/canonical');
const {compileLanguage} = require('../v1.6');
const {compileComposition} = require('../v1.7');
const {compileEpistemic} = require('../v1.8');
const {compileAssurance} = require('../v1.9');
const SCHEMA='octolang.unified-ir.v2.0';
const ARTIFACT='octolang.unified-artifact.v2.0';
const PREFIX='OctoLang Unified IR v2.0\n';
const ID=/^[A-Za-z_][A-Za-z0-9_-]*$/;
const HEX=/^[a-f0-9]{64}$/;
const TYPES=['integer'];
const EFFECTS=['LOCAL_CAPABILITY','EXTERNAL_SERVICE'];
const PHASES=['AUTHORISATION','EXECUTION','OBSERVATION','OUTCOME'];
const cmp=(a,b)=>a<b?-1:a>b?1:0;
const sort=(a,b)=>cmp(a.name,b.name);
const sha=s=>crypto.createHash('sha256').update(s,'utf8').digest('hex');
const digestIR=ir=>sha(PREFIX+canonical(ir));
function need(ok,msg){if(!ok)throw new Error('OctoLang v2.0: '+msg);}
function sourcePath(s){
  need(typeof s==='string'&&s.length>0&&s.length<=180&&s.endsWith('.octo')&&
    !s.startsWith('/')&&!s.startsWith('\\')&&!s.includes('\\')&&!s.includes('//')&&
    !s.split('/').some(x=>x==='.'||x==='..'||!x)&&!s.includes(':'), 'invalid source path: '+s);
  return s;
}
function lex(source){
  need(typeof source==='string'&&source.length<=131072,'source must be <=131072 characters');
  const ts=[];let i=0;
  while(i<source.length){
    const tail=source.slice(i);
    const skip=tail.match(/^(?:\s+|#[^\n]*|\/\/[^\n]*)/);
    if(skip){i+=skip[0].length;continue;}
    const m=tail.match(/^(?:"(?:\\["\\nrt]|[^"\\\n\r])*"|[A-Za-z_][A-Za-z0-9_-]*|(?:0|[1-9][0-9]*)|[{}.])/);
    need(!!m,`invalid token at offset ${i}`);
    ts.push(m[0]);i+=m[0].length;
    need(ts.length<=6000,'too many tokens');
  }
  return ts;
}
function parser(source){
  const ts=lex(source);let i=0;
  function pop(want){const s=ts[i++];need(s!==undefined,'unexpected EOF');if(want!==undefined)need(s===want,`expected ${want} but found ${s}`);return s;}
  function peek(){return ts[i];}
  function id(){const s=pop();need(ID.test(s),'invalid identifier '+s);return s;}
  function str(){const s=pop();need(s.startsWith('"'),'expected quoted string');const decoded=JSON.parse(s);need(decoded.length>0&&decoded.length<=256,'invalid string length');return decoded;}
  function number(){const s=pop();need(/^(0|[1-9][0-9]{0,8})$/.test(s),'expected nonnegative integer');return Number(s);}
  function dotted(){const first=id();pop('.');return `${first}.${id()}`;}
  function fields(kind,allowed){pop('{');const result={};while(peek()!=='}'){
    need(peek()!==undefined,'unterminated '+kind);const field=id();need(allowed.includes(field),'unknown '+kind+' field '+field);need(!Object.hasOwn(result,field),'duplicate '+kind+' field '+field);
    result[field]=['role','effect','knowledge','proof','contract','node','task'].includes(field)?id():
      ['runs','budget'].includes(field)?number():str();
  }pop('}');need(allowed.every(x=>Object.hasOwn(result,x)),'incomplete '+kind);return result;}
  function moduleBody(){const name=id();pop('{');const contracts=[],templates=[],used=new Set();
    while(peek()!=='}'){
      need(peek()!==undefined,'unterminated module');const kind=id(),label=id();need(['contract','template'].includes(kind),'unknown module declaration '+kind);
      need(!used.has(kind+':'+label),'duplicate module declaration');used.add(kind+':'+label);
      if(kind==='contract'){
        const f=fields(kind,['role','capability','effect','knowledge','proof','phases']);
        contracts.push({name:label,...f});
      }else{
        pop('{');const f={};pop('contract');f.contract=id();
        while(peek()!=='}'){
          pop('parameter');const key=id();need(['runs','budget'].includes(key),'invalid template parameter');need(!Object.hasOwn(f,key),'duplicate template parameter');
          pop('integer');pop('max');f[key]=number();
        }pop('}');need(Object.hasOwn(f,'runs')&&Object.hasOwn(f,'budget'),'template requires runs and budget');
        templates.push({name:label,...f});
      }
      need(contracts.length<=64&&templates.length<=64,'too many declarations');
    }pop('}');need(contracts.length>0&&templates.length>0,'module requires contract and template');
    return {name,contracts,templates};
  }
  function finish(){need(i===ts.length,'trailing tokens');}
  function parseModule(){pop('module');const m=moduleBody();finish();return m;}
  function parseProgram(){pop('program');const name=id();pop('{');const sources={},imports=[],modules=[],bindings=[];const used=new Set();
    while(peek()!=='}'){
      need(peek()!==undefined,'unterminated program');const kind=id();
      if(['mission','composition','epistemic','assurance'].includes(kind)){
        need(!Object.hasOwn(sources,kind),'duplicate component '+kind);sources[kind]=sourcePath(str());
      }else if(kind==='import'){
        const p=sourcePath(str());pop('sha256');const digest=str();need(HEX.test(digest),'import sha256 must be lowercase hex');
        need(!used.has('import:'+p),'duplicate import');used.add('import:'+p);imports.push({path:p,sha256:digest});
      }else if(kind==='module'){
        const m=moduleBody();need(!used.has('module:'+m.name),'duplicate module');used.add('module:'+m.name);modules.push(m);
      }else if(kind==='bind'){
        const template=dotted();pop('as');const name=id();need(!used.has('bind:'+name),'duplicate binding');used.add('bind:'+name);
        bindings.push({name,template,...fields('binding',['node','task','runs','budget'])});
      }else need(false,'unknown program declaration '+kind);
      need(imports.length<=32&&modules.length<=32&&bindings.length<=64,'program too large');
    }pop('}');finish();
    need(['mission','composition','epistemic','assurance'].every(k=>Object.hasOwn(sources,k)),'four component sources required');
    need(new Set(Object.values(sources)).size===4,'component files must be distinct');
    need(bindings.length>0,'program must bind templates');
    return {name,sources,imports,modules,bindings};
  }
  return {parseProgram,parseModule};
}
function parseProgram(s){return parser(s).parseProgram();}
function parseModule(s){return parser(s).parseModule();}
function normalizeModule(m){
  need(ID.test(m.name),'invalid module name');const contracts=m.contracts.map(c=>{
    need(ID.test(c.name)&&ID.test(c.role)&&ID.test(c.knowledge)&&ID.test(c.proof)&&
      typeof c.capability==='string'&&c.capability.length<=128&&EFFECTS.includes(c.effect),'invalid contract');
    const phases=c.phases.split(',').map(s=>s.trim());
    need(phases.length>=2&&phases.length<=4&&new Set(phases).size===phases.length&&
      PHASES.slice(0,phases.length).every((s,i)=>s===phases[i]),'contract phases must form contiguous prefix');
    return {name:c.name,role:c.role,capability:c.capability,effect:c.effect,knowledge:c.knowledge,proof:c.proof,phases};
  }).sort(sort);
  const templates=m.templates.map(t=>{
    need(ID.test(t.name)&&ID.test(t.contract)&&contracts.some(c=>c.name===t.contract),'template requires declared contract');
    need(Number.isSafeInteger(t.runs)&&t.runs>=1&&t.runs<=16&&Number.isSafeInteger(t.budget)&&t.budget>=0&&t.budget<=1000000,'invalid template bounds');
    return {name:t.name,contract:t.contract,maxRuns:t.runs,maxBudgetPerRun:t.budget};
  }).sort(sort);
  need(new Set(contracts.map(c=>c.name)).size===contracts.length,'duplicate contract');
  need(new Set(templates.map(t=>t.name)).size===templates.length,'duplicate template');
  return {name:m.name,contracts,templates};
}
function compileParts(parsed,files){
  need(files&&typeof files==='object'&&!Array.isArray(files),'source map required');
  const sources=parsed.sources;
  const paths=[...Object.values(sources),...parsed.imports.map(x=>x.path)];
  need(new Set(paths).size===paths.length,'duplicate source/import path');
  for(const p of paths)need(Object.hasOwn(files,p)&&typeof files[p]==='string'&&files[p].length<=131072,`missing source ${p}`);
  for(const imp of parsed.imports)need(sha(files[imp.path])===imp.sha256,`import digest mismatch for ${imp.path}`);
  const mission=compileLanguage(files[sources.mission]);
  const composition=compileComposition(files[sources.composition],files[sources.mission]);
  const epistemic=compileEpistemic(files[sources.epistemic],files[sources.mission]);
  const assurance=compileAssurance(files[sources.assurance],files[sources.mission]);
  const modules=parsed.modules.map(normalizeModule);
  for(const imp of parsed.imports)modules.push(normalizeModule(parseModule(files[imp.path])));
  need(modules.length>0&&new Set(modules.map(x=>x.name)).size===modules.length,'missing or duplicate modules');
  return {components:{mission,composition,epistemic,assurance},modules:modules.sort(sort),sourceDigests:paths.map(path=>({path,sha256:sha(files[path])})).sort((a,b)=>cmp(a.path,b.path))};
}
function projectIR(parsed,parts){
  const {components,modules,sourceDigests}=parts;
  const m=components.mission.ir,c=components.composition.ir,e=components.epistemic.ir,a=components.assurance.ir;
  need(c.missionIRDigest===components.mission.irDigest&&e.missionIRDigest===components.mission.irDigest&&a.missionIRDigest===components.mission.irDigest,'unbound layer');
  const nodes=new Map(c.nodes.map(x=>[x.name,x]));
  const tasks=new Map(m.tasks.map(x=>[x.name,x]));
  const guard=new Map(e.guards.map(x=>[x.task,x]));
  const obligation=new Map(a.obligations.map(x=>[x.task,x]));
  const effects=new Map(a.effects.map(x=>[x.task,x]));
  const mods=new Map(modules.map(x=>[x.name,x]));
  need(parsed.bindings.length===nodes.size,'every composition node must bind exactly one agent contract/template');
  const seen=new Set();const bindings=parsed.bindings.map(b=>{
    const [modName,templateName]=b.template.split('.');const mod=mods.get(modName);
    need(!!mod,'undeclared module '+modName);
    const tmpl=mod.templates.find(x=>x.name===templateName);
    need(!!tmpl,'unknown template '+b.template);
    const contract=mod.contracts.find(x=>x.name===tmpl.contract);
    const node=nodes.get(b.node),task=tasks.get(b.task);
    need(node&&!seen.has(b.node),'unknown or multiply-bound composition node '+b.node);seen.add(b.node);
    need(task&&node.task===b.task,'bound task does not match composition node');
    need(task.role===contract.role&&task.requiredCapability===contract.capability&&task.effect===contract.effect,
      `contract cannot change role, capability or effect for ${b.task}`);
    need(task.declaredProofs.includes(contract.proof),`contract proof not required by ${b.task}`);
    need(guard.get(task.name)?.knowledge===contract.knowledge,'contract knowledge does not match epistemic guard');
    const epKnowledge=e.knowledge.find(k=>k.name===contract.knowledge);
    need(epKnowledge?.state==='Verified','effectful contract requires Verified knowledge');
    need(effects.get(task.name)?.requiredEffect===contract.effect,'contract assurance effect mismatch');
    const required=obligation.get(task.name)?.phases;
    need(Array.isArray(required)&&contract.phases.length===required.length&&required.every((x,i)=>x===contract.phases[i]),
      'contract proof phases must exactly match assurance obligation');
    need(Number.isSafeInteger(b.runs)&&b.runs>0&&b.runs<=tmpl.maxRuns&&b.runs<=node.maxRuns,'template runs exceed approved bounds');
    need(Number.isSafeInteger(b.budget)&&b.budget>=0&&b.budget<=tmpl.maxBudgetPerRun&&b.budget<=node.budgetUnitsPerRun,
      'template budget exceeds approved bounds');
    return {name:b.name,template:b.template,node:b.node,task:b.task,role:contract.role,capability:contract.capability,
      effect:contract.effect,knowledge:contract.knowledge,proof:contract.proof,phases:[...contract.phases],runs:b.runs,
      budgetUnitsPerRun:b.budget,worstCaseBudget:b.runs*b.budget,
      originalNodeMaxRuns:node.maxRuns,originalNodeBudgetUnitsPerRun:node.budgetUnitsPerRun};
  }).sort(sort);
  need(new Set(bindings.map(x=>x.name)).size===bindings.length,'duplicate binding');
  const total=bindings.reduce((sum,b)=>sum+b.worstCaseBudget,0);
  need(Number.isSafeInteger(total)&&total<=c.worstCaseBudgetUnits,'budget overflow or escalation');
  return {
    schema:SCHEMA,kind:'unified-program',name:parsed.name,
    componentDigests:{mission:components.mission.irDigest,composition:components.composition.irDigest,
      epistemic:components.epistemic.irDigest,assurance:components.assurance.irDigest},
    sourceDigests,modules,bindings,
    compositionSchedule:[...c.schedule],worstCaseBudgetUnits:total,
    governance:{grantsImplied:false,executionAllowed:false,requiresIndependentEvidence:true,
      decision:'LINKED_POLICY_PROPOSAL_NOT_EXECUTION_AUTHORITY'}
  };
}
function compileProgram(programSource,files){
  const parsed=parseProgram(programSource),parts=compileParts(parsed,files),ir=projectIR(parsed,parts);
  return {schema:ARTIFACT,sourceSha256:sha(programSource),components:parts.components,ir,irDigest:digestIR(ir)};
}
function verifyProgram(programSource,files,artifact){
  try{
    need(artifact&&typeof artifact==='object'&&!Array.isArray(artifact),'invalid artifact');
    const expected=compileProgram(programSource,files);
    const {verifyIR}=require('./validate');
    const valid=verifyIR(artifact.ir,artifact.components,artifact.irDigest);
    need(valid.valid,valid.reason);
    need(canonical(artifact)===canonical(expected),'artifact does not match independently recompiled sources');
    return {valid:true,irDigest:expected.irDigest};
  }catch(e){return {valid:false,reason:e.message};}
}
module.exports={SCHEMA,ARTIFACT,PREFIX,sha,digestIR,parseProgram,parseModule,normalizeModule,compileParts,projectIR,
  compileProgram,verifyProgram,sourcePath};
