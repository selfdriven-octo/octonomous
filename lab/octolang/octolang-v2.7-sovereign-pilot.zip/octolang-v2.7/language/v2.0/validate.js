'use strict';
// Independent validation of v2.0 IR and constituent semantic IRs. Do not trust
// a supplied digest as signature, authority, source provenance or execution right.
const {canonical}=require('../../src/canonical');
const {verifyIR:verifyMission}=require('../v1.6/validate');
const {validateIR:validateComposition}=require('../v1.7/validate');
const {validateIR:validateEpistemic}=require('../v1.8/validate');
const {validateIR:validateAssurance}=require('../v1.9/validate');
const {SCHEMA,digestIR,projectIR}=require('./index');
const exact=(x,keys)=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype&&
  Object.keys(x).length===keys.length&&keys.every(k=>Object.hasOwn(x,k));
function need(v,msg){if(!v)throw new Error('Invalid v2.0 IR: '+msg);}
function validateIR(ir,components){
  need(exact(ir,['schema','kind','name','componentDigests','sourceDigests','modules','bindings','compositionSchedule','worstCaseBudgetUnits','governance']), 'outer shape');
  need(ir.schema===SCHEMA&&ir.kind==='unified-program','schema mismatch');
  need(components&&exact(components,['mission','composition','epistemic','assurance']),'four components required');
  const m=components.mission,c=components.composition,e=components.epistemic,a=components.assurance;
  need(verifyMission(m.ir,m.irDigest).valid,'invalid mission semantic IR');
  need(validateComposition(c.ir,m.ir)===true,'invalid composition IR');
  need(validateEpistemic(e.ir,m.ir)===true,'invalid epistemic IR');
  need(validateAssurance(a.ir,m.ir)===true,'invalid assurance IR');
  const {digestIR:d17}=require('../v1.7');
  const {digestIR:d18}=require('../v1.8');
  const {hashIR19:d19}=require('../v1.9');
  need(d17(c.ir)===c.irDigest&&d18(e.ir)===e.irDigest&&d19(a.ir)===a.irDigest,'invalid component digest');
  need(exact(ir.componentDigests,['mission','composition','epistemic','assurance']),'invalid component digests');
  for(const label of Object.keys(ir.componentDigests))need(ir.componentDigests[label]===components[label].irDigest,'component binding mismatch');
  need(exact(ir.governance,['grantsImplied','executionAllowed','requiresIndependentEvidence','decision'])&&
    ir.governance.executionAllowed===false&&ir.governance.grantsImplied===false&&
    ir.governance.requiresIndependentEvidence===true&&
    ir.governance.decision==='LINKED_POLICY_PROPOSAL_NOT_EXECUTION_AUTHORITY','forged governance');
  need(Array.isArray(ir.sourceDigests)&&ir.sourceDigests.length>=4&&ir.sourceDigests.length<=36,'missing sources');
  for(const s of ir.sourceDigests)need(exact(s,['path','sha256'])&&/^[a-f0-9]{64}$/.test(s.sha256),'bad source digest');
  const {sourcePath,normalizeModule}=require('./index');
  for(const s of ir.sourceDigests)sourcePath(s.path);
  need(new Set(ir.sourceDigests.map(s=>s.path)).size===ir.sourceDigests.length,'duplicate source');
  need(Array.isArray(ir.modules)&&ir.modules.length>0&&ir.modules.length<=32,'modules count');
  const modules=ir.modules.map(mod=>{
    need(exact(mod,['name','contracts','templates']),'module shape');
    need(Array.isArray(mod.contracts)&&Array.isArray(mod.templates),'module declarations');
    for(const x of mod.contracts)need(exact(x,['name','role','capability','effect','knowledge','proof','phases']),'contract shape');
    for(const x of mod.templates)need(exact(x,['name','contract','maxRuns','maxBudgetPerRun']),'template shape');
    const normal=normalizeModule({name:mod.name,contracts:mod.contracts.map(x=>({...x,phases:x.phases.join(',')})),
      templates:mod.templates.map(x=>({name:x.name,contract:x.contract,runs:x.maxRuns,budget:x.maxBudgetPerRun}))});
    need(canonical(normal)===canonical(mod),'non-canonical module');return mod;
  });
  need(new Set(modules.map(x=>x.name)).size===modules.length,'duplicate module');
  need(Array.isArray(ir.bindings)&&ir.bindings.length>0&&ir.bindings.length<=64,'invalid bindings');
  for(const b of ir.bindings)need(exact(b,['name','template','node','task','role','capability','effect','knowledge','proof','phases','runs','budgetUnitsPerRun','worstCaseBudget','originalNodeMaxRuns','originalNodeBudgetUnitsPerRun']),'binding shape');
  const parsed={name:ir.name,bindings:ir.bindings.map(b=>({name:b.name,template:b.template,node:b.node,task:b.task,runs:b.runs,budget:b.budgetUnitsPerRun}))};
  const expected=projectIR(parsed,{components,modules,sourceDigests:ir.sourceDigests});
  need(canonical(expected)===canonical(ir),'semantic mismatch or unsorted fields');
  return true;
}
function verifyIR(ir,components,digest){
  try{validateIR(ir,components);need(digestIR(ir)===digest,'digest mismatch');return {valid:true,irDigest:digest};}
  catch(e){return {valid:false,reason:e.message};}
}
module.exports={validateIR,verifyIR};
