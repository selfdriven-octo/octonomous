'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process');
const {certDigest}=require('./remote');
function write(file,value){fs.writeFileSync(file,value,{flag:'wx',mode:0o600});}
function dir(root){fs.mkdirSync(root,{recursive:true,mode:0o700});}
function run(...args){cp.execFileSync('openssl',args,{stdio:'pipe'});}
function provisionWitness(root){
  dir(root);const keys=crypto.generateKeyPairSync('ed25519');
  write(path.join(root,'witness-private.pem'),keys.privateKey.export({format:'pem',type:'pkcs8'}));
  write(path.join(root,'witness-public.pem'),keys.publicKey.export({format:'pem',type:'spki'}));
  return path.join(root,'witness-public.pem');
}
function testPki(root){
  dir(root);const caKey=path.join(root,'ca.key'),caCrt=path.join(root,'ca.crt');
  run('req','-new','-x509','-newkey','rsa:2048','-nodes','-days','2','-subj','/CN=OctoLang v2.4 local test CA','-keyout',caKey,'-out',caCrt);
  const out={ca:caCrt};
  for(const role of ['server','client']){
    const key=path.join(root,role+'.key'),csr=path.join(root,role+'.csr'),crt=path.join(root,role+'.crt');
    run('req','-new','-newkey','rsa:2048','-nodes','-subj',role==='server'?'/CN=localhost':'/CN=octolang-controller',
      '-keyout',key,'-out',csr);
    const ext=path.join(root,role+'.ext');
    fs.writeFileSync(ext,role==='server'?'subjectAltName=DNS:localhost,IP:127.0.0.1\nextendedKeyUsage=serverAuth\n':'extendedKeyUsage=clientAuth\n');
    run('x509','-req','-in',csr,'-CA',caCrt,'-CAkey',caKey,'-CAcreateserial','-out',crt,'-days','2','-extfile',ext);
    out[role]={key,cert:crt,digest:certDigest(new crypto.X509Certificate(fs.readFileSync(crt)).raw)};
  }
  return out;
}
module.exports={provisionWitness,testPki};
if(require.main===module){const root=process.argv[2];if(!root){console.error('Usage: node language/v2.4/provision.js ABSOLUTE_WITNESS_HOME');process.exit(2);}console.log('Witness public key:',provisionWitness(path.resolve(root)));}
