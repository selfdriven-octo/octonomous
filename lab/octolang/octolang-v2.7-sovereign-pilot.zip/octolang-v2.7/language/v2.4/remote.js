'use strict';
/** Remote witness: independent Ed25519 signing authority + pinned mutual TLS.
 * Attests to a controller-REPORTED, hash-bound snapshot, not physical effects.
 * Never send private signing keys to the controller/coordinator. */
const https=require('node:https');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {canonical}=require('../../src/canonical');
const {hash}=require('../v2.2');
const {LocalWitness,verifyWitness,snapshotOf,matches}=require('../v2.3/witness');
const PREFIX='OctoLang v2.4 Remote Witness Request\n';
const fail=m=>{throw Error('Remote witness: '+m);};
const hex=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
const pem=k=>(k?.type==='public'?k:crypto.createPublicKey(k)).export({type:'spki',format:'pem'}).toString();
function keyMatch(prv,pub){return pem(crypto.createPublicKey(prv))===pem(pub);}
function sign(payload,key){return crypto.sign(null,Buffer.from(PREFIX+canonical(payload)),key).toString('base64');}
function verify(payload,signature,key){try{const b=Buffer.from(signature||'','base64');return b.length===64&&b.toString('base64')===signature&&crypto.verify(null,Buffer.from(PREFIX+canonical(payload)),key,b);}catch{return false;}}
function certDigest(raw){return crypto.createHash('sha256').update(raw).digest('hex');}
function assertSnapshot(s,expectedScore){
  if(!s||Object.keys(s).sort().join(',')!==['activeRevisionDigest','executionHead','executionSequence','ledgerHead','ledgerSequence','scoreDigest'].sort().join(',')||
    s.scoreDigest!==expectedScore||!hex(s.ledgerHead)||!Number.isSafeInteger(s.ledgerSequence)||s.ledgerSequence<1||
    !Number.isSafeInteger(s.executionSequence)||s.executionSequence<0||
    (s.executionHead!==null&&!hex(s.executionHead))||
    (s.activeRevisionDigest!==null&&!hex(s.activeRevisionDigest)))fail('invalid witness snapshot or score scope');
}
const send=(res,code,obj)=>{const body=JSON.stringify(obj);res.writeHead(code,{'content-type':'application/json','cache-control':'no-store','content-length':Buffer.byteLength(body)});res.end(body);};
function service({directory,signingPrivateKey,signingPublicKey,controllerPublicKey,scoreDigest,
  serverKey,serverCert,clientCa,clientFingerprint,host='127.0.0.1',port=0,now=()=>Date.now()}){
  if(!path.isAbsolute(directory)||!hex(scoreDigest)||!hex(clientFingerprint)||!keyMatch(signingPrivateKey,signingPublicKey))fail('invalid server configuration');
  fs.mkdirSync(directory,{recursive:true,mode:0o700});
  const witness=new LocalWitness({directory,privateKey:signingPrivateKey,publicKey:signingPublicKey,now});
  // The witness operator pins a score AND a separate controller public key.
  const configPath=path.join(directory,'enrolment.json');
  const enrolled={schema:'octolang.witness-enrolment.v2.4',scoreDigest,controllerKey:pem(controllerPublicKey),witnessKey:pem(signingPublicKey)};
  if(fs.existsSync(configPath)){
    if(canonical(JSON.parse(fs.readFileSync(configPath)))!==canonical(enrolled))fail('enrolment identity changed');
  }else {fs.writeFileSync(configPath,JSON.stringify(enrolled)+'\n',{flag:'wx',mode:0o600});}
  const nonceFile=path.join(directory,'requests.jsonl');
  const server=https.createServer({key:serverKey,cert:serverCert,ca:clientCa,requestCert:true,rejectUnauthorized:true,minVersion:'TLSv1.2'},(req,res)=>{
    if(!req.socket.authorized||certDigest(req.socket.getPeerCertificate(true).raw)!==clientFingerprint){send(res,403,{error:'client identity rejected'});return;}
    if(req.method==='GET'&&req.url==='/v1/status'){const journal=path.join(directory,'checkpoints.jsonl');send(res,200,{schema:'octolang.witness-history.v2.4',records:fs.existsSync(journal)?fs.readFileSync(journal,'utf8'):''});return;}
    if(req.method!=='POST'||req.url!=='/v1/attest'){send(res,404,{error:'not found'});return;}
    let raw='',aborted=false;
    req.on('data',chunk=>{raw+=chunk;if(raw.length>16384){aborted=true;req.destroy();}});
    req.on('end',()=>{
      if(aborted)return;
      const lock=path.join(directory,'.request-lock');
      try{
        let o;try{o=JSON.parse(raw);}catch{fail('invalid JSON');}
        const p=o?.payload;
        if(!p||p.schema!=='octolang.remote-witness-request.v2.4'||!hex(p.scoreDigest)||p.scoreDigest!==scoreDigest||
          !p.snapshot||p.snapshot.scoreDigest!==scoreDigest||!(p.expectedHead===null||hex(p.expectedHead))||
          typeof p.nonce!=='string'||!/^[a-f0-9]{32}$/.test(p.nonce)||!Number.isSafeInteger(p.issuedAt)||
          !Number.isSafeInteger(p.expiresAt)||p.expiresAt<=p.issuedAt||p.expiresAt-p.issuedAt>60000||
          now()<p.issuedAt-30000||now()>=p.expiresAt||!verify(p,o.signature,controllerPublicKey))fail('invalid or unsigned request');
        assertSnapshot(p.snapshot,scoreDigest);
        try{fs.mkdirSync(lock,{mode:0o700});}catch{fail('concurrent update or stale lock');}
        try{
          if(fs.existsSync(nonceFile)&&fs.readFileSync(nonceFile,'utf8').split('\n').some(x=>x===p.nonce))fail('replayed request nonce');
          // Durable nonce claim BEFORE side effect. Ambiguity fails closed; do not retry blindly.
          const fd=fs.openSync(nonceFile,'a',0o600);try{fs.writeSync(fd,p.nonce+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
          const result=witness.attest(p.snapshot,p.expectedHead);
          send(res,200,{ok:true,checkpointHead:result.head,checkpointSequence:result.sequence});
        }finally{fs.rmdirSync(lock);}
      }catch(e){send(res,409,{error:e.message});}
    });
  });
  return {server,start:()=>new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,()=>{server.off('error',reject);resolve(server.address());});}),close:()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))};
}
function fetchJSON({url,cert,key,ca,pinnedServerFingerprint,method='GET',body,timeoutMs=5000}){
  const target=new URL(url);
  if(target.protocol!=='https:'||!hex(pinnedServerFingerprint))fail('HTTPS and pinned remote certificate required');
  return new Promise((resolve,reject)=>{
    const bytes=body?Buffer.from(JSON.stringify(body)):null;
    const req=https.request(target,{agent:false,method,cert,key,ca,servername:target.hostname==='127.0.0.1'?'localhost':target.hostname,rejectUnauthorized:true,timeout:timeoutMs,
      checkServerIdentity:(host,peer)=>{
        const err=require('node:tls').checkServerIdentity(host,peer);if(err)return err;
        if(certDigest(peer.raw)!==pinnedServerFingerprint)return Error('remote TLS certificate pin mismatch');
      },headers:bytes?{'content-type':'application/json','content-length':bytes.length}:{}},res=>{
      const serverCert=res.socket.getPeerCertificate(true);if(!serverCert?.raw||certDigest(serverCert.raw)!==pinnedServerFingerprint){res.destroy(Error('remote TLS certificate pin mismatch'));reject(Error('remote TLS certificate pin mismatch'));return;}
      let data='';res.on('data',chunk=>{data+=chunk;if(data.length>12*1024*1024)req.destroy(Error('response too large'));});
      res.on('end',()=>{try{const parsed=JSON.parse(data);if(res.statusCode!==200)throw Error(parsed.error||'status '+res.statusCode);resolve(parsed);}catch(e){reject(e);}});
    });
    req.on('socket',socket=>socket.once('secureConnect',()=>{try{const peer=socket.getPeerCertificate(true);if(!peer?.raw||certDigest(peer.raw)!==pinnedServerFingerprint)req.destroy(Error('remote TLS certificate pin mismatch'));}catch(e){req.destroy(e);}}));
    req.on('timeout',()=>req.destroy(Error('remote witness timeout')));req.on('error',reject);if(bytes)req.write(bytes);req.end();
  });
}
class RemoteWitness {
  constructor({url,cert,key,ca,pinnedServerFingerprint,controllerPrivateKey,controllerPublicKey,witnessPublicKey,scoreDigest,mirrorDirectory,now=()=>Date.now()}){
    if(!path.isAbsolute(mirrorDirectory)||!keyMatch(controllerPrivateKey,controllerPublicKey)||!hex(scoreDigest)||!url.endsWith('/'))fail('invalid remote client config');
    this.url=url;this.cert=cert;this.key=key;this.ca=ca;this.pin=pinnedServerFingerprint;
    this.signer=controllerPrivateKey;this.controllerPublicKey=controllerPublicKey;this.witnessPublicKey=witnessPublicKey;
    this.scoreDigest=scoreDigest;this.directory=mirrorDirectory;this.now=now;
    fs.mkdirSync(mirrorDirectory,{recursive:true,mode:0o700});
  }
  _request(route,method,body){return fetchJSON({url:new URL(route,this.url).toString(),cert:this.cert,key:this.key,ca:this.ca,pinnedServerFingerprint:this.pin,method,body});}
  status(){return verifyWitness({directory:this.directory,publicKey:this.witnessPublicKey});}
  async refresh(){
    // A crash or concurrent refresh must not roll a local high-water mark backwards.
    const lock=path.join(this.directory,'.refresh-lock');
    try{fs.mkdirSync(lock,{mode:0o700});}catch{fail('concurrent mirror refresh or stale lock');}
    try{
      const response=await this._request('v1/status','GET');
      if(response.schema!=='octolang.witness-history.v2.4'||typeof response.records!=='string')fail('unexpected witness history');
      const pathFile=path.join(this.directory,'checkpoints.jsonl');
      const old=fs.existsSync(pathFile)?fs.readFileSync(pathFile,'utf8'):'';
      if(!response.records.startsWith(old))fail('remote history rollback/fork');
      if(response.records===old)return this.status();
      const tmp=path.join(this.directory,'.mirror-'+crypto.randomUUID());
      const probe=path.join(this.directory,'.probe-'+crypto.randomUUID());
      fs.mkdirSync(probe,{mode:0o700});
      try{
        fs.writeFileSync(path.join(probe,'checkpoints.jsonl'),response.records,{flag:'wx',mode:0o600});
        const latest=verifyWitness({directory:probe,publicKey:this.witnessPublicKey});if(!latest.valid)fail(latest.reason);
        fs.writeFileSync(tmp,response.records,{flag:'wx',mode:0o600});
        const f=fs.openSync(tmp,'r');try{fs.fsyncSync(f);}finally{fs.closeSync(f);}
        fs.renameSync(tmp,pathFile);
        const fd=fs.openSync(this.directory,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
        return latest;
      }finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp);fs.rmSync(probe,{recursive:true,force:true});}
    }finally{fs.rmdirSync(lock);}
  }
  async attest(snapshot,expectedHead){
    assertSnapshot(snapshot,this.scoreDigest);
    const before=await this.refresh();if(!before.valid||before.head!==expectedHead)fail('stale witness predecessor');
    const p={schema:'octolang.remote-witness-request.v2.4',scoreDigest:this.scoreDigest,
      snapshot,expectedHead,nonce:crypto.randomBytes(16).toString('hex'),issuedAt:this.now(),expiresAt:this.now()+30000};
    const result=await this._request('v1/attest','POST',{payload:p,signature:sign(p,this.signer)});
    const after=await this.refresh();
    if(!after.valid||after.head!==result.checkpointHead||after.sequence!==result.checkpointSequence||!matches(after,snapshot))fail('remote witness result mismatch');
    return after;
  }
  async checkLive(expected){const s=await this.refresh();if(!matches(s,expected))fail('remote witness unavailable or wrong checkpoint');return s;}
}
module.exports={service,RemoteWitness,fetchJSON,certDigest,sign,verify};
