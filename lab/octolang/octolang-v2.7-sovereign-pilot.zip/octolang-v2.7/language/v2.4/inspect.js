#!/usr/bin/env node
'use strict';
/** Read-only remote witness inspector. Needs mTLS client certificate but NO signing key. */
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {fetchJSON}=require('./remote');
const {verifyWitness}=require('../v2.3/witness');
const {verifyWitnessedExecution}=require('./execution');
const get=p=>fs.readFileSync(path.resolve(p));
(async()=>{
  const file=process.argv[2];if(!file)throw Error('Usage: node language/v2.4/inspect.js CONFIG_JSON');
  const cfg=JSON.parse(get(file));
  const r=await fetchJSON({url:new URL('v1/status',cfg.url).toString(),cert:get(cfg.clientCert),key:get(cfg.clientKey),
    ca:get(cfg.ca),pinnedServerFingerprint:cfg.serverFingerprint});
  if(r.schema!=='octolang.witness-history.v2.4'||typeof r.records!=='string')throw Error('invalid remote status');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-witness-readonly-'));
  try{
    if(r.records)fs.writeFileSync(path.join(dir,'checkpoints.jsonl'),r.records,{mode:0o600});
    const key=get(cfg.witnessPublicKey);const verified=verifyWitness({directory:dir,publicKey:key});
    if(!verified.valid)throw Error(verified.reason);
    const output={remoteWitnessVerified:true,sequence:verified.sequence,head:verified.head,scoreDigest:verified.snapshot?.scoreDigest};
    if(cfg.controllerDirectory&&cfg.scoreSource&&cfg.controllerPins){
      const pins=JSON.parse(get(cfg.controllerPins));
      output.localEvidenceAudit=verifyWitnessedExecution({directory:path.resolve(cfg.controllerDirectory),
        scoreSource:get(cfg.scoreSource).toString(),pins,witnessDirectory:dir,witnessPublicKey:key.toString()});
      if(!output.localEvidenceAudit.valid)throw Error('local evidence audit denied: '+output.localEvidenceAudit.reason);
    }
    process.stdout.write(JSON.stringify(output,null,2)+'\n');
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
})().catch(e=>{console.error(e.message);process.exitCode=1;});
