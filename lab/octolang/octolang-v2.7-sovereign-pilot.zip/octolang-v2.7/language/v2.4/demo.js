'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {setup}=require('../v2.3/demo');
const {compileScore}=require('../v2.1');
const {RemoteWitness}=require('./remote');
const {RemoteExecutionController}=require('./execution');
const {testPki,provisionWitness}=require('./provision');
const read=p=>fs.readFileSync(p);
async function startup({scoreDigest,controllerPublicKey}){
  const base=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v24-remote-demo-'));
  const home=path.join(base,'remote-witness'),trust=path.join(base,'test-pki'),pki=testPki(trust);
  // Separate witness process provisions and holds its own private Ed25519 key.
  const provision=spawn(process.execPath,[path.join(__dirname,'provision.js'),home],{stdio:['ignore','pipe','pipe']});
  await new Promise((resolve,reject)=>{provision.once('exit',code=>code===0?resolve():reject(Error('witness provision failed')));provision.once('error',reject);});
  const controllerPin=path.join(home,'controller-public.pem');fs.writeFileSync(controllerPin,controllerPublicKey,{mode:0o600});
  const config={directory:path.join(home,'journal'),scoreDigest,
    witnessPrivateKey:path.join(home,'witness-private.pem'),witnessPublicKey:path.join(home,'witness-public.pem'),
    controllerPublicKey:controllerPin,serverKey:pki.server.key,serverCert:pki.server.cert,
    clientCa:pki.ca,clientFingerprint:pki.client.digest,host:'127.0.0.1',port:0};
  const configPath=path.join(home,'config.json');fs.writeFileSync(configPath,JSON.stringify(config),{mode:0o600});
  const remote={base,config,pki,witnessPublicKey:read(config.witnessPublicKey).toString()};
  remote.launch=async()=>{
    const proc=spawn(process.execPath,[path.join(__dirname,'service.js'),configPath],{stdio:['ignore','pipe','pipe']});
    const ready=await new Promise((resolve,reject)=>{
      let buf='',err='';proc.stderr.on('data',x=>{err+=x;});
      proc.stdout.on('data',x=>{buf+=x;const line=buf.split('\n')[0];try{const data=JSON.parse(line);if(data.ready)resolve(data);}catch{}});
      proc.once('exit',code=>reject(Error('witness exited '+code+': '+err)));proc.once('error',reject);
      setTimeout(()=>reject(Error('remote witness start timeout')),10000).unref();
    });
    remote.proc=proc;remote.ready=ready;remote.url=`https://127.0.0.1:${ready.port}/`;
    return ready;
  };
  remote.close=()=>new Promise(resolve=>{const proc=remote.proc;if(!proc||proc.exitCode!==null||proc.signalCode!==null)return resolve();
    proc.once('exit',resolve);proc.kill();setTimeout(()=>{proc.kill('SIGKILL');resolve();},1200).unref();});
  await remote.launch();return remote;
}
async function setupRemote(){
  const f=setup();const remote=await startup({scoreDigest:compileScore(f.scoreSource).irDigest,controllerPublicKey:f.pins.controller});
  const mirrorDirectory=path.join(f.directory,'remote-public-checkpoints');
  const witness=new RemoteWitness({url:remote.url,cert:read(remote.pki.client.cert),key:read(remote.pki.client.key),ca:read(remote.pki.ca),
    pinnedServerFingerprint:remote.pki.server.digest,controllerPrivateKey:f.actors.controller.privateKey,
    controllerPublicKey:f.pins.controller,witnessPublicKey:remote.witnessPublicKey,
    scoreDigest:f.score.irDigest,mirrorDirectory});
  const controller=new RemoteExecutionController({gate:f.gate,witness,witnessDirectory:mirrorDirectory,witnessPublicKey:remote.witnessPublicKey});
  await controller.bootstrap();
  return {...f,remote,witness,controller,mirrorDirectory};
}
async function demo(){const f=await setupRemote();try{
  const result=await f.controller.execute({...f.decision,missionParams:f.missionParams});
  const audit=f.controller.verify();if(!audit.valid)throw Error(audit.reason);
  console.log(JSON.stringify({result,audit,remoteProcessPid:f.remote.proc.pid,witnessDirectory:f.remote.config.directory,
    localMirror:f.mirrorDirectory,paymentExecuted:false,independentlyOperatedOnSeparateMachine:false},null,2));
}finally{await f.remote.close();}}
if(require.main===module)demo().catch(e=>{console.error(e.stack);process.exitCode=1;});
module.exports={startup,setupRemote,demo};
