'use strict';
/** Standalone witness service. Config paths are local to WITNESS host. */
const fs=require('node:fs'),path=require('node:path');
const {service}=require('./remote');
(async()=>{
  if(!process.argv[2])throw Error('Usage: node language/v2.4/service.js WITNESS_CONFIG_JSON');
  const config=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
  const get=p=>fs.readFileSync(p);
  const app=service({directory:config.directory,scoreDigest:config.scoreDigest,
    signingPrivateKey:get(config.witnessPrivateKey),signingPublicKey:get(config.witnessPublicKey),
    controllerPublicKey:get(config.controllerPublicKey),serverKey:get(config.serverKey),
    serverCert:get(config.serverCert),clientCa:get(config.clientCa),
    clientFingerprint:config.clientFingerprint,host:config.host||'127.0.0.1',port:config.port??8443});
  const addr=await app.start();console.log(JSON.stringify({ready:true,port:addr.port,witnessPublicKey:config.witnessPublicKey}));
})().catch(e=>{console.error(e.stack);process.exit(1);});
