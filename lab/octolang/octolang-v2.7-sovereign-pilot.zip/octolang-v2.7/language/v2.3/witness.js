'use strict';
/** Separate, append-only witness authority. Keep its signing key and store OUTSIDE
 * the execution host. A caller supplies only a pinned public key and witness API.
 * This local file implementation is an integration test adapter, not a remote witness. */
const fs=require('node:fs'), path=require('node:path'), crypto=require('node:crypto');
const {canonical}=require('../../src/canonical');
const {hash}=require('../v2.2');
const PFX='OctoLang v2.3 Independent Witness\n';
const fail=s=>{throw Error('Witness: '+s);};
const same=(a,b)=>canonical(a)===canonical(b);
const validHash=x=>typeof x==='string'&&/^[0-9a-f]{64}$/.test(x);
function sign(payload,privateKey){return crypto.sign(null,Buffer.from(PFX+canonical(payload)),privateKey).toString('base64');}
function validSignature(payload,signature,key){try{const b=Buffer.from(signature||'','base64');return b.length===64&&b.toString('base64')===signature&&crypto.verify(null,Buffer.from(PFX+canonical(payload)),key,b);}catch{return false;}}
function snapshotOf({ledger,execution}){
  if(!ledger?.head||!Number.isSafeInteger(ledger.sequence)||!validHash(ledger.scoreDigest)||
    !Number.isSafeInteger(execution.sequence)||execution.sequence<0||
    (execution.head!==null&&!validHash(execution.head)))fail('invalid snapshot');
  return {scoreDigest:ledger.scoreDigest,ledgerHead:ledger.head,ledgerSequence:ledger.sequence,
    activeRevisionDigest:ledger.activeRevisionDigest,executionHead:execution.head,executionSequence:execution.sequence};
}
function verifyWitness({directory,publicKey}){
  try{
    const file=path.join(directory,'checkpoints.jsonl');
    if(!fs.existsSync(file))return {valid:true,sequence:0,head:null,snapshot:null};
    const content=fs.readFileSync(file,'utf8');if(!content.endsWith('\n'))fail('truncated witness journal');
    const lines=content.trimEnd().split('\n');if(lines.length>100000)fail('too many witness events');
    let last={sequence:0,head:null,snapshot:null}, checkpoints=[];
    for(const line of lines){
      if(line.length>8192)fail('oversize checkpoint');
      const obj=JSON.parse(line),p=obj.payload;
      if(!p||p.schema!=='octolang.witness.v2.3'||p.sequence!==last.sequence+1||p.previous!==last.head||
        typeof p.at!=='string'||!Number.isFinite(Date.parse(p.at))||!p.snapshot||
        !Number.isSafeInteger(p.snapshot.ledgerSequence)||!Number.isSafeInteger(p.snapshot.executionSequence)||
        !validHash(p.snapshot.ledgerHead)||!validHash(p.snapshot.scoreDigest)||
        (p.snapshot.executionHead!==null&&!validHash(p.snapshot.executionHead))||
        !validSignature(p,obj.signature,publicKey))fail('bad signed witness checkpoint');
      if(last.snapshot&&(p.snapshot.scoreDigest!==last.snapshot.scoreDigest||
         p.snapshot.ledgerSequence<last.snapshot.ledgerSequence||
         p.snapshot.executionSequence<last.snapshot.executionSequence||
         (p.snapshot.ledgerSequence===last.snapshot.ledgerSequence&&p.snapshot.ledgerHead!==last.snapshot.ledgerHead)||
         (p.snapshot.executionSequence===last.snapshot.executionSequence&&p.snapshot.executionHead!==last.snapshot.executionHead)))
        fail('witness state rolled back or forked');
      const head=hash(PFX+canonical(obj));last={sequence:p.sequence,head,snapshot:p.snapshot,checkpoint:obj};
      checkpoints.push({sequence:p.sequence,head,snapshot:p.snapshot});
    }
    return {valid:true,...last,checkpoints};
  }catch(e){return {valid:false,reason:e.message};}
}
function matches(checkpoint,snapshot){return checkpoint?.valid===true&&checkpoint.sequence>0&&same(checkpoint.snapshot,snapshot);}
class LocalWitness {
  constructor({directory,privateKey,publicKey,now=()=>Date.now()}){
    if(!path.isAbsolute(directory))fail('witness directory must be absolute');
    if(!crypto.verify(null,Buffer.from('witness-key-test'),publicKey,crypto.sign(null,Buffer.from('witness-key-test'),privateKey)))fail('key mismatch');
    this.directory=directory;this.privateKey=privateKey;this.publicKey=publicKey;this.now=now;
    fs.mkdirSync(directory,{recursive:true,mode:0o700});
  }
  status(){return verifyWitness({directory:this.directory,publicKey:this.publicKey});}
  attest(snapshot,expectedHead){
    const lock=path.join(this.directory,'.witness-lock');
    try{fs.mkdirSync(lock,{mode:0o700});}catch{fail('concurrent witness update or stale lock');}
    try{
      const last=this.status();if(!last.valid)fail(last.reason);
      if(last.head!==expectedHead)fail('stale witness predecessor');
      if(last.snapshot&&(snapshot.scoreDigest!==last.snapshot.scoreDigest||
        snapshot.ledgerSequence<last.snapshot.ledgerSequence||snapshot.executionSequence<last.snapshot.executionSequence||
        (snapshot.ledgerSequence===last.snapshot.ledgerSequence&&snapshot.ledgerHead!==last.snapshot.ledgerHead)||
        (snapshot.executionSequence===last.snapshot.executionSequence&&snapshot.executionHead!==last.snapshot.executionHead)))
        fail('refusing rollback or fork');
      const payload={schema:'octolang.witness.v2.3',sequence:last.sequence+1,previous:last.head,
        snapshot,at:new Date(this.now()).toISOString()};
      const entry={payload,signature:sign(payload,this.privateKey)};
      const f=fs.openSync(path.join(this.directory,'checkpoints.jsonl'),'a',0o600);
      try{fs.writeSync(f,JSON.stringify(entry)+'\n');fs.fsyncSync(f);}finally{fs.closeSync(f);}
      return this.status();
    }finally{fs.rmdirSync(lock);}
  }
}
module.exports={LocalWitness,verifyWitness,snapshotOf,matches};
