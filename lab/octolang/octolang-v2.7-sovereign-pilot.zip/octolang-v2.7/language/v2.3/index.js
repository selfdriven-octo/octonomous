'use strict';
/** v2.3: bounded, witnessed execution of one approved local intent.record effect.
 * The v2.2 ledger retains cumulative limits and signed VCC RESERVE semantics.
 * A separate execution journal records START before the effect and COMPLETE after.
 * All ambiguity remains reserved and must be manually reconciled (never retried).
 */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const Octonomous=require('../../vendor/octonomous-runtime');
const {canonical}=require('../../src/canonical');
const {compileScore,parseScore}=require('../v2.1');
const {compileMission,planMission}=require('../../src/mission');
const {ActivationGate,verifyLedger,hash}=require('../v2.2');
const {snapshotOf,verifyWitness,matches}=require('./witness');
const EXEC='OctoLang v2.3 Execution Event\n';
const SEAL='OctoLang v2.3 Execution Seal\n';
const allowed='mission.local.record-intent';
const chk=(v,msg)=>{if(!v)throw Error('OctoLang v2.3: '+msg);};
const eq=(a,b)=>canonical(a)===canonical(b);
function signature(payload,key,prefix){return crypto.sign(null,Buffer.from(prefix+canonical(payload)),key).toString('base64');}
function signatureOk(payload,sig,key,prefix){try{const x=Buffer.from(sig,'base64');return x.length===64&&x.toString('base64')===sig&&crypto.verify(null,Buffer.from(prefix+canonical(payload)),key,x);}catch{return false;}}
function fsyncDir(dir){const f=fs.openSync(dir,'r');try{fs.fsyncSync(f);}finally{fs.closeSync(f);}}
function writeOnce(file,obj){const f=fs.openSync(file,'wx',0o600);try{fs.writeSync(f,JSON.stringify(obj)+'\n');fs.fsyncSync(f);}finally{fs.closeSync(f);}fsyncDir(path.dirname(file));}
function empty(){return {head:null,sequence:0,actions:{}};}
function readExecution({directory,publicKey,requireEffects=true}){
  try{
    const file=path.join(directory,'execution.jsonl'),sealFile=path.join(directory,'execution-seal.json');
    if(!fs.existsSync(file)){chk(!fs.existsSync(sealFile),'execution journal lost while seal exists');return {valid:true,...empty()};}
    const content=fs.readFileSync(file,'utf8');chk(content.endsWith('\n'),'truncated execution journal');
    const lines=content.trimEnd().split('\n');chk(lines.length>0&&lines.length<=100000,'empty or oversized journal');
    let state=empty();let lastAt=0;const events=[];
    for(const line of lines){
      chk(line.length<65536,'execution event oversized');const e=JSON.parse(line),p=e.payload;
      const basis={sequence:e.sequence,previous:e.previous,kind:e.kind,payload:p};
      chk(e.sequence===state.sequence+1&&e.previous===state.head&&e.hash===hash(EXEC+canonical(basis)),'execution sequence or hash link invalid');
      chk(signatureOk({...basis,hash:e.hash},e.signature,publicKey,EXEC),'execution controller signature invalid');
      const at=Date.parse(p.at);chk(Number.isFinite(at)&&at>=lastAt,'execution clock moved backwards');lastAt=at;
      if(e.kind==='START'){
        chk(p.schema==='octolang.effect-start.v2.3'&&typeof p.nonce==='string'&&p.tool===allowed&&
          typeof p.scoreDigest==='string'&&typeof p.reservationHead==='string'&&
          Number.isSafeInteger(p.reservationSequence)&&p.reservationSequence>0&&
          !Object.hasOwn(state.actions,p.nonce),'duplicate/invalid START');
        state.actions[p.nonce]={status:'IN_PROGRESS',start:p,startHash:e.hash};
      }else if(e.kind==='COMPLETE'){
        const action=state.actions[p.nonce];
        chk(p.schema==='octolang.effect-complete.v2.3'&&action?.status==='IN_PROGRESS'&&
          p.startHash===action.startHash&&p.scoreDigest===action.start.scoreDigest&&
          p.activeRevisionDigest===action.start.activeRevisionDigest&&p.tool===allowed&&
          typeof p.recordDigest==='string'&&p.recordDigest.length===64,'orphaned/mismatched completion');
        if(requireEffects){
          const effectFile=path.join(directory,'effects',hash('intent-file:'+p.nonce)+'.json');
          chk(fs.existsSync(effectFile),'recorded local effect missing');
          const obj=JSON.parse(fs.readFileSync(effectFile,'utf8'));
          chk(hash(canonical(obj))===p.recordDigest&&obj?.schema==='octolang.local-intent.v2.3'&&
            obj.nonce===p.nonce&&obj.scoreDigest===p.scoreDigest&&
            obj.activeRevisionDigest===p.activeRevisionDigest&&obj.tool===allowed&&
            obj.contextRoot===action.start.contextRoot&&obj.planDigest===action.start.planDigest,
            'local effect differs from signed completion');
        }
        action.status='COMPLETED';action.complete=p;action.completeHash=e.hash;
      }else chk(false,'unknown execution event');
      state.sequence=e.sequence;state.head=e.hash;events.push({sequence:e.sequence,hash:e.hash,kind:e.kind});
    }
    chk(fs.existsSync(sealFile),'missing execution seal');
    const seal=JSON.parse(fs.readFileSync(sealFile,'utf8'));
    chk(eq(seal.payload,{head:state.head,sequence:state.sequence})&&
      signatureOk(seal.payload,seal.signature,publicKey,SEAL),'execution seal mismatch');
    return {valid:true,...state,events};
  }catch(e){return {valid:false,reason:e.message};}
}
function snapshot(ledger,exec){return snapshotOf({ledger:ledger.state,execution:exec});}
/** Read-only auditor. No secrets and no reliance on the controller's claims. */
function verifyWitnessedExecution({directory,scoreSource,pins,witnessDirectory,witnessPublicKey}){
  try{
    chk(path.resolve(witnessDirectory)!==path.resolve(directory),'witness and execution directories must differ');
    const ledger=verifyLedger({directory,scoreSource,pins});chk(ledger.valid&&ledger.initialised,ledger.reason||'ledger missing');
    const execution=readExecution({directory,publicKey:pins.controller});chk(execution.valid,execution.reason);
    const wit=verifyWitness({directory:witnessDirectory,publicKey:witnessPublicKey});chk(wit.valid,wit.reason);
    chk(matches(wit,snapshot(ledger,execution)),'witness checkpoint does not match current ledger and effect log');
    const reserved=fs.readFileSync(path.join(directory,'events.jsonl'),'utf8').trimEnd().split('\n').map(JSON.parse).filter(e=>e.kind==='RESERVE');
    const byNonce=new Map(reserved.map(e=>[e.payload.request.nonce,e]));
    // Every START and COMPLETE must be witnessed independently at the exact
    // execution journal head, not merely included in a later summary.
    for(const event of execution.events||[]){
      chk(wit.checkpoints.some(c=>c.snapshot.executionSequence===event.sequence&&
        c.snapshot.executionHead===event.hash&&c.snapshot.scoreDigest===ledger.state.scoreDigest),
        'missing independently witnessed '+event.kind+' execution boundary');
    }
    for(const [nonce,a] of Object.entries(execution.actions)){
      const r=byNonce.get(nonce);chk(r&&a.start.reservationHead===r.hash&&a.start.reservationSequence===r.sequence&&
        a.start.scoreDigest===r.payload.request.scoreDigest&&
        a.start.activeRevisionDigest===r.payload.request.activeRevisionDigest&&
        a.start.contextRoot===r.payload.request.contextRoot&&
        a.start.binding===r.payload.request.binding&&a.start.capability===r.payload.request.capability&&
        a.start.task===r.payload.request.task&&a.start.target===r.payload.request.target&&
        a.start.vccReceiptDigest===hash(canonical(r.payload.vccReceipt)),
        'effect not tied to authorised reservation and score revision');
      if(a.status==='COMPLETED'){
        const file=path.join(directory,'effects',hash('intent-file:'+nonce)+'.json');
        const record=JSON.parse(fs.readFileSync(file,'utf8'));
        chk(record.subject===r.payload.request.target&&record.budgetUnits===r.payload.request.units&&
          record.missionDigest===a.start.missionDigest,
          'completed effect inputs do not match authorised reservation');
      }
    }
    return {valid:true,scoreDigest:ledger.state.scoreDigest,activeRevisionDigest:ledger.state.activeRevisionDigest,
      ledgerHead:ledger.state.head,ledgerSequence:ledger.state.sequence,
      executionHead:execution.head,executionSequence:execution.sequence,
      checkpointHead:wit.head,checkpointSequence:wit.sequence,
      actions:Object.fromEntries(Object.entries(execution.actions).map(([k,v])=>[k,{status:v.status,recordDigest:v.complete?.recordDigest||null,scoreDigest:v.start.scoreDigest,revisionDigest:v.start.activeRevisionDigest}]))};
  }catch(e){return {valid:false,reason:e.message};}
}
class VerifiedExecutionController {
  constructor({gate,witness,witnessDirectory,witnessPublicKey}){
    chk(gate instanceof ActivationGate,'ActivationGate required');
    chk(witness&&typeof witness.attest==='function','independent witness API required');
    chk(witnessDirectory&&witnessPublicKey,'pinned witness key and path required');
    chk(path.resolve(gate.directory)!==path.resolve(witnessDirectory),'separate witness storage required');
    this.gate=gate;this.witness=witness;this.witnessDirectory=witnessDirectory;this.witnessPublicKey=witnessPublicKey;
  }
  _audit(){return verifyWitnessedExecution({directory:this.gate.directory,scoreSource:this.gate.scoreSource,pins:this.gate.pins,
    witnessDirectory:this.witnessDirectory,witnessPublicKey:this.witnessPublicKey});}
  _state(){const l=this.gate.status();chk(l.valid&&l.initialised,l.reason||'ledger missing');
    const e=readExecution({directory:this.gate.directory,publicKey:this.gate.pins.controller});chk(e.valid,e.reason);return {ledger:l,execution:e};}
  /** Explicit initial witness enrolment; only permitted before a first checkpoint. */
  bootstrap(){const s=this._state(),w=verifyWitness({directory:this.witnessDirectory,publicKey:this.witnessPublicKey});
    chk(w.valid&&w.sequence===0,'witness already enrolled or invalid');
    return this.witness.attest(snapshot(s.ledger,s.execution),null).head;
  }
  _snapshot(){const s=this._state();return snapshot(s.ledger,s.execution);}
  _witnessLatest(){const s=this._state(),w=verifyWitness({directory:this.witnessDirectory,publicKey:this.witnessPublicKey});
    chk(matches(w,snapshot(s.ledger,s.execution)),'witness high-water mark mismatch; reconciliation required');return w;}
  /** Explicitly witness a governance activation performed outside the runner.
   * This cannot reduce the witness high-water mark and must be authorised separately. */
  syncGovernance(){const s=this._state(),w=verifyWitness({directory:this.witnessDirectory,publicKey:this.witnessPublicKey});
    chk(w.valid&&w.sequence>0,'bootstrap required');
    chk(s.execution.head===w.snapshot.executionHead&&s.execution.sequence===w.snapshot.executionSequence,
      'unwitnessed execution mutation');
    chk(s.ledger.state.sequence>w.snapshot.ledgerSequence,'no newer governance event');
    const events=fs.readFileSync(path.join(this.gate.directory,'events.jsonl'),'utf8').trimEnd().split('\n').map(JSON.parse);
    chk(events.filter(e=>e.sequence>w.snapshot.ledgerSequence).every(e=>e.kind==='ACTIVATE'),
      'new non-governance events may not be implicitly witnessed');
    return this.witness.attest(snapshot(s.ledger,s.execution),w.head).head;
  }
  _append(kind,payload){
    const e=readExecution({directory:this.gate.directory,publicKey:this.gate.pins.controller});chk(e.valid,e.reason);
    const row={sequence:e.sequence+1,previous:e.head,kind,payload};row.hash=hash(EXEC+canonical(row));
    row.signature=signature({sequence:row.sequence,previous:row.previous,kind,payload,hash:row.hash},this.gate.controllerPrivateKey,EXEC);
    const file=path.join(this.gate.directory,'execution.jsonl');const f=fs.openSync(file,'a',0o600);
    try{fs.writeSync(f,JSON.stringify(row)+'\n');fs.fsyncSync(f);}finally{fs.closeSync(f);}
    const seal={payload:{head:row.hash,sequence:row.sequence}};
    seal.signature=signature(seal.payload,this.gate.controllerPrivateKey,SEAL);
    const tmp=path.join(this.gate.directory,'.execution-seal-'+crypto.randomUUID());
    try{writeOnce(tmp,seal);fs.renameSync(tmp,path.join(this.gate.directory,'execution-seal.json'));fsyncDir(this.gate.directory);}
    finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}
    return row;
  }
  async execute({request,vccReceipt,missionParams}){
    const gate=this.gate;
    // Existing v2.2 exclusive lock remains held across async Octonomous tool invocation.
    return gate._lockAsync(async()=>{
      const prior=this._audit();chk(prior.valid,prior.reason);
      chk(request?.capability==='intent.record'&&request.effect==='LOCAL_CAPABILITY',
        'only intent.record LOCAL_CAPABILITY enabled in v2.3');
      chk(request.target===missionParams?.request?.subject&&request.nonce===missionParams?.request?.nonce,
        'request subject/nonce mismatch');
      const mission=compileMission(parseScore(gate.scoreSource).layers.mission);
      chk(eq(mission,missionParams?.mission),'mission does not match approved score');
      const fresh=planMission({...missionParams,now:gate.now()});
      chk(fresh.status==='READY_FOR_SIMULATION'&&fresh.plan.contextRoot===request.contextRoot,
        'effect-time mission review, grants or context denied');
      const task=mission.tasks.find(x=>x.label===request.task);
      const role=mission.roles.find(x=>x.label===task?.role);
      chk(task&&role&&role.capability==='intent.record'&&
        mission.inputs.some(i=>i.label==='amount'&&i.type==='ada')&&
        mission.inputs.some(i=>i.label==='project'&&i.type==='text'),
        'wrong task or missing typed local intent inputs');
      chk(request.scoreDigest===compileScore(gate.scoreSource).irDigest,'score mismatch');
      // The request signature, expiry, active score and total lifetime budget
      // are checked by v2.2's deterministic journal transition before reservation.
      const ledger=gate._read();gate._write(ledger.state,'RESERVE',{at:new Date(gate.now()).toISOString(),request,vccReceipt});
      const reserved=gate._read().state;
      const start=this._append('START',{schema:'octolang.effect-start.v2.3',at:new Date(gate.now()).toISOString(),
        nonce:request.nonce,scoreDigest:request.scoreDigest,activeRevisionDigest:request.activeRevisionDigest,
        task:request.task,binding:request.binding,capability:request.capability,target:request.target,
        contextRoot:request.contextRoot,tool:allowed,reservationHead:reserved.head,reservationSequence:reserved.sequence,
        planDigest:fresh.plan.digest,missionDigest:mission.digest,vccReceiptDigest:hash(canonical(vccReceipt))});
      // Witness MUST durably sign the in-progress state before any tool effects.
      const before=this._witnessLatestOrPrevious(prior.checkpointHead);
      const checkpoint=this.witness.attest(this._snapshot(),before.head);
      chk(matches(checkpoint,this._snapshot()),'witness did not confirm START');
      // Runtime re-check happens inside registered tool callback as well.
      const token=crypto.randomUUID(),eventId=crypto.randomUUID(),beingId='score_'+hash(request.nonce).slice(0,22);
      const toolRegistry=new Octonomous.ToolRegistry();let used=false;
      toolRegistry.register({name:allowed,description:'Bounded, authorised local intent journal'},async(input,ctx)=>{
        chk(!used&&input?.token===token&&ctx?.event?.id===eventId&&ctx?.being?.id===beingId&&
          ctx?.governance?.allowed===true&&ctx?.decision?.action?.tool===allowed,'Octonomous tool admission failed');
        used=true;
        const recheck=planMission({...missionParams,now:gate.now()});
        const right=gate._read().state, w=this._witnessLatest();
        chk(recheck.status==='READY_FOR_SIMULATION'&&recheck.plan.digest===fresh.plan.digest&&
          right.head===reserved.head&&right.activeRevisionDigest===request.activeRevisionDigest&&
          matches(w,this._snapshot()),'effect-time VCC or checkpoint mismatch');
        chk(gate.now()<Date.parse(vccReceipt.payload.expiresAt),'VCC decision expired before effect');
        const record={schema:'octolang.local-intent.v2.3',nonce:request.nonce,
          scoreDigest:request.scoreDigest,activeRevisionDigest:request.activeRevisionDigest,
          contextRoot:request.contextRoot,planDigest:fresh.plan.digest,missionDigest:mission.digest,
          tool:allowed,subject:request.target,project:missionParams.request.inputs.project,
          amount:missionParams.request.inputs.amount,budgetUnits:request.units,recordedAt:new Date(gate.now()).toISOString()};
        fs.mkdirSync(path.join(gate.directory,'effects'),{recursive:true,mode:0o700});
        writeOnce(path.join(gate.directory,'effects',hash('intent-file:'+request.nonce)+'.json'),record);
        return {ok:true,outcome:'RECORDED_LOCAL_INTENT',record};
      });
      const runtime=new Octonomous.Runtime({store:new Octonomous.stores.FileStore({basePath:path.join(gate.directory,'octonomous-beings')}),
        tools:toolRegistry,policy:new Octonomous.Policy(),cognition:{
          consider:()=>Promise.resolve({relevant:true}),
          decide:()=>Promise.resolve({shouldAct:true,action:{enabled:true,tool:allowed,input:{token}},commitment:{enabled:false}}),
          reflect:({actionResult})=>Promise.resolve({kind:'OCTOLANG_V23',success:actionResult?.ok===true})
        }});
      await runtime.registerBeing({id:beingId,identity:{kind:'octolang-v2.3',agent:'local-buyer'},purpose:'Record approved community intent',
        subscriptions:['octolang.verified-intent'],authority:{allowedTools:[allowed],requiresApproval:[]},memory:{}});
      const run=await runtime.handleEventForBeing(beingId,{id:eventId,type:'octolang.verified-intent',sourceBeingId:beingId,payload:{token}});
      chk(used&&run?.governance?.allowed===true&&run?.actionResult?.ok===true&&
        run.actionResult.outcome==='RECORDED_LOCAL_INTENT','tool did not complete; reconciliation required');
      const result=run.actionResult.record;
      const completed=this._append('COMPLETE',{schema:'octolang.effect-complete.v2.3',at:new Date(gate.now()).toISOString(),
        nonce:request.nonce,startHash:start.hash,scoreDigest:request.scoreDigest,
        activeRevisionDigest:request.activeRevisionDigest,tool:allowed,recordDigest:hash(canonical(result))});
      const after=this.witness.attest(this._snapshot(),checkpoint.head);
      chk(matches(after,this._snapshot()),'completion witness did not confirm');
      const audit=this._audit();chk(audit.valid,audit.reason);
      return {status:'WITNESSED_LOCAL_EXECUTION',scoreDigest:request.scoreDigest,
        activeRevisionDigest:request.activeRevisionDigest,planDigest:fresh.plan.digest,
        effectDigest:hash(canonical(result)),executionReceiptHash:completed.hash,
        witnessCheckpoint:after.head,ledgerHead:reserved.head,nonce:request.nonce,
        payments:false,realEffects:1};
    });
  }
  _witnessLatestOrPrevious(head){const w=verifyWitness({directory:this.witnessDirectory,publicKey:this.witnessPublicKey});
    chk(w.valid&&w.head===head,'witness moved while awaiting execution; reconcile');return w;}
  verify(){return this._audit();}
}
module.exports={VerifiedExecutionController,verifyWitnessedExecution,readExecution};
