'use strict';
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {compileScore,parseScore,sha}=require('../v2.1');
const {compileMission}=require('../../src/mission');
const {fixtures}=require('../../mission/demo');
const {ActivationGate,makeActivation}=require('../v2.2');
const {decisionFromMission}=require('../v2.2/mission-vcc');
const {OBS_SCHEMA,REVIEW_SCHEMA,digestObservation,compileRevision,createObservation,createReview}=require('../v2.1/refinement');
const {LocalWitness}=require('./witness');
const {VerifiedExecutionController}=require('./index');
const iso=ms=>new Date(ms).toISOString();
function setup({now=Date.now()}={}){
  const scoreSource=fs.readFileSync(path.join(__dirname,'../../community-score.octo'),'utf8'),score=compileScore(scoreSource);
  const names=['observer','reviewer','governor','vcc','controller'];
  const actors=Object.fromEntries(names.map(x=>[x,crypto.generateKeyPairSync('ed25519')]));
  const pins=Object.fromEntries(names.map(x=>[x,actors[x].publicKey.export({format:'pem',type:'spki'}).toString()]));
  const witnessKeys=crypto.generateKeyPairSync('ed25519'),directory=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v23-ledger-'));
  const witnessDirectory=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v23-witness-'));
  const witnessPublicKey=witnessKeys.publicKey.export({format:'pem',type:'spki'}).toString();
  const params={directory,scoreSource,pins,controllerPrivateKey:actors.controller.privateKey,now:()=>now};
  const gate=new ActivationGate(params);gate.init();
  const witness=new LocalWitness({directory:witnessDirectory,privateKey:witnessKeys.privateKey,publicKey:witnessPublicKey,now:()=>now});
  const controller=new VerifiedExecutionController({gate,witness,witnessDirectory,witnessPublicKey});
  controller.bootstrap();
  const op={schema:OBS_SCHEMA,scoreDigest:score.irDigest,metric:'cost-per-run',value:4,unit:'budget-units',
    sampleDigest:sha('synthetic local cost sample'),observedAt:iso(now-60000),validUntil:iso(now+3600000),kind:'OBSERVATION'};
  const observation=createObservation(op,actors.observer.privateKey);
  const revisionSource=`revision reduce_scout { base "${score.irDigest}" evidence "${digestObservation(op)}" trigger "cost-per-run" above 3 tune scout_node runs 1 budget 1 }`;
  const revisionArtifact=compileRevision(revisionSource,score);
  const review=createReview({schema:REVIEW_SCHEMA,scoreDigest:score.irDigest,revisionDigest:revisionArtifact.irDigest,
    evidenceDigest:digestObservation(op),reviewedAt:iso(now),validUntil:iso(now+300000),decision:'APPROVE_PROPOSAL_ONLY'},actors.reviewer.privateKey);
  const head=gate.status().state;
  const activation=makeActivation({schema:'octolang.activation.v2.2',scoreDigest:score.irDigest,revisionDigest:revisionArtifact.irDigest,
    expectedHead:head.head,expectedSequence:head.sequence+1,issuedAt:iso(now),expiresAt:iso(now+300000),decision:'ACTIVATE_LIMITS_ONLY'},actors.governor.privateKey);
  gate.activate({revisionSource,revisionArtifact,observation,review,activation});
  controller.syncGovernance();
  const mission=compileMission(parseScore(scoreSource).layers.mission);
  const fx=fixtures(mission,{subject:'supplier-42',inputs:{amount:'75',priority:'3',project:'Community learning',note:'Verified request',urgent:false},now});
  const missionParams={mission,request:fx.request,review:fx.review,claims:fx.claims,grants:fx.grants,trust:fx.trust};
  const decision=decisionFromMission({scoreSource,binding:'intent_node',units:2,activeRevisionDigest:revisionArtifact.irDigest,
    missionParams,vccPrivateKey:actors.vcc.privateKey,now});
  return {actors,pins,gate,params,scoreSource,score,controller,witness,witnessDirectory,witnessPublicKey,decision,missionParams,directory,now,revisionArtifact};
}
async function demo(){const f=setup();const result=await f.controller.execute({...f.decision,missionParams:f.missionParams});
  const audit=f.controller.verify();if(!audit.valid)throw Error(audit.reason);
  console.log(JSON.stringify({result,audit,witnessDirectory:f.witnessDirectory,localDataDirectory:f.directory},null,2));return {result,audit};}
if(require.main===module)demo().catch(e=>{console.error(e.stack);process.exitCode=1;});
module.exports={setup,demo};
