'use strict';
/** OctoLang v2.5: evidence-only distributed recovery.
 * No method in this module invokes Octonomous tools, refunds reservations,
 * synthesizes COMPLETE events, or treats a missing effect as proof of absence.
 */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {canonical}=require('../../src/canonical');
const {hash,verifyLedger}=require('../v2.2');
const {readExecution}=require('../v2.4/execution');
const {verifyWitness,snapshotOf}=require('../v2.3/witness');
const PREFIX='OctoLang v2.5 Recovery Evidence\n';
const JOURNAL='OctoLang v2.5 Recovery Journal\n';
const SEAL='OctoLang v2.5 Recovery Seal\n';
const isDigest=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
function chk(test,msg){if(!test)throw Error('OctoLang v2.5: '+msg);}
function sign(payload,key,prefix=PREFIX){return {payload,signature:crypto.sign(null,Buffer.from(prefix+canonical(payload)),key).toString('base64')};}
function verify(record,key,prefix=PREFIX){try{const b=Buffer.from(record?.signature||'','base64');return b.length===64&&b.toString('base64')===record.signature&&crypto.verify(null,Buffer.from(prefix+canonical(record.payload)),key,b);}catch{return false;}}
function keys(pins){chk(pins?.controller&&pins?.observer&&pins?.governor&&pins?.witness,'controller, observer, governor and witness pins required');const pubs=Object.values(pins).map(p=>crypto.createPublicKey(p).export({format:'der',type:'spki'}).toString('hex'));chk(new Set(pubs).size===pubs.length,'independent signing identities required');}
function getFiles(cfg){
  keys(cfg.pins);
  chk(path.resolve(cfg.directory)!==path.resolve(cfg.witnessDirectory),'witness storage must be independent');
  const ledgerPins=Object.fromEntries(['observer','reviewer','governor','vcc','controller'].map(k=>[k,cfg.pins[k]]));
  const ledger=verifyLedger({directory:cfg.directory,scoreSource:cfg.scoreSource,pins:ledgerPins});
  chk(ledger.valid&&ledger.initialised,ledger.reason||'ledger invalid');
  const execution=readExecution({directory:cfg.directory,publicKey:cfg.pins.controller});chk(execution.valid,execution.reason||'execution invalid');
  const witness=verifyWitness({directory:cfg.witnessDirectory,publicKey:cfg.pins.witness});chk(witness.valid&&witness.sequence>0,witness.reason||'witness missing');
  chk(witness.snapshot.scoreDigest===ledger.state.scoreDigest&&witness.snapshot.ledgerSequence<=ledger.state.sequence&&
    witness.snapshot.executionSequence<=execution.sequence,'cross-domain rollback or score mismatch');
  const eventFile=fs.readFileSync(path.join(cfg.directory,'events.jsonl'),'utf8');
  const ledgerEvents=eventFile.trimEnd().split('\n').map(JSON.parse);
  for(const checkpoint of witness.checkpoints){
    const snap=checkpoint.snapshot;
    const le=ledgerEvents[snap.ledgerSequence-1];
    chk(le&&le.sequence===snap.ledgerSequence&&le.hash===snap.ledgerHead&&
      snap.scoreDigest===ledger.state.scoreDigest,'witnessed ledger fork or rollback');
    const xe=snap.executionSequence===0?null:execution.events[snap.executionSequence-1];
    chk(snap.executionSequence===0?snap.executionHead===null:
      xe&&xe.sequence===snap.executionSequence&&xe.hash===snap.executionHead,
      'witnessed execution fork or rollback');
  }
  const reservations=ledgerEvents.filter(x=>x.kind==='RESERVE');
  return {ledger,execution,witness,reservations};
}
function inspectCase(cfg,nonce){
  try{
    chk(typeof nonce==='string'&&nonce.length>0&&nonce.length<=128,'invalid nonce');
    const {ledger,execution,witness,reservations}=getFiles(cfg);
    const action=execution.actions[nonce];chk(action,'no signed START for nonce');
    const r=reservations.filter(x=>x.payload?.request?.nonce===nonce);
    chk(r.length===1,'missing or duplicate reservation');
    const reserve=r[0],rq=reserve.payload.request,s=action.start;
    chk(s.reservationHead===reserve.hash&&s.reservationSequence===reserve.sequence&&s.scoreDigest===rq.scoreDigest&&
      s.activeRevisionDigest===rq.activeRevisionDigest&&s.contextRoot===rq.contextRoot&&
      s.task===rq.task&&s.binding===rq.binding&&s.capability===rq.capability&&s.target===rq.target&&
      s.vccReceiptDigest===hash(canonical(reserve.payload.vccReceipt)),'START mismatches VCC reservation');
    const present=Object.hasOwn(action,'complete');
    const effectFile=path.join(cfg.directory,'effects',hash('intent-file:'+nonce)+'.json');
    let effectDigest=null;
    if(fs.existsSync(effectFile)){
      const record=JSON.parse(fs.readFileSync(effectFile,'utf8'));
      chk(record.schema==='octolang.local-intent.v2.3'&&record.nonce===nonce&&record.scoreDigest===s.scoreDigest&&
        record.activeRevisionDigest===s.activeRevisionDigest&&record.contextRoot===s.contextRoot&&
        record.planDigest===s.planDigest&&record.missionDigest===s.missionDigest&&
        record.tool===s.tool&&record.subject===s.target&&record.budgetUnits===rq.units,'local effect content mismatch');
      effectDigest=hash(canonical(record));
    }
    if(present)chk(effectDigest===action.complete.recordDigest,'signed COMPLETE does not match effect');
    const witnessedStart=witness.checkpoints.some(c=>c.snapshot.executionHead===action.startHash&&
      c.snapshot.executionSequence===execution.events.find(x=>x.hash===action.startHash)?.sequence&&
      c.snapshot.ledgerHead===s.reservationHead);
    const witnessedComplete=present&&witness.checkpoints.some(c=>c.snapshot.executionHead===action.completeHash);
    let classification;
    if(!witnessedStart)classification='START_NOT_WITNESSED';
    else if(witnessedComplete)classification='ALREADY_WITNESSED';
    else if(present)classification='COMPLETE_NEEDS_WITNESS';
    else if(effectDigest)classification='EFFECT_PRESENT_WITHOUT_COMPLETE';
    else classification='UNKNOWN_AFTER_START';
    const evidence={schema:'octolang.recovery-case.v2.5',nonce,classification,
      scoreDigest:s.scoreDigest,activeRevisionDigest:s.activeRevisionDigest,
      ledgerHead:ledger.state.head,ledgerSequence:ledger.state.sequence,
      reservationHead:reserve.hash,startHash:action.startHash,completeHash:action.completeHash||null,
      executionHead:execution.head,executionSequence:execution.sequence,
      witnessHead:witness.head,witnessSequence:witness.sequence,effectDigest};
    return {valid:true,...evidence,caseDigest:hash(PREFIX+canonical(evidence)),allowed:classification==='COMPLETE_NEEDS_WITNESS'?['WITNESS_EXISTING_COMPLETION','HOLD']:
      classification==='ALREADY_WITNESSED'?[]:['HOLD']};
  }catch(e){return {valid:false,reason:e.message};}
}
function attest(caseData,privateKey,now=Date.now()){
  chk(caseData?.valid&&isDigest(caseData.caseDigest),'verified case required');
  const p={schema:'octolang.recovery-observer.v2.5',caseDigest:caseData.caseDigest,
    classification:caseData.classification,effectDigest:caseData.effectDigest,
    issuedAt:new Date(now).toISOString(),expiresAt:new Date(now+300000).toISOString(),decision:'EVIDENCE_INSPECTED_NOT_WORLD_TRUTH'};
  return sign(p,privateKey);
}
function approve(caseData,observer,action,privateKey,now=Date.now()){
  chk(caseData?.valid&&caseData.allowed.includes(action),'action not allowed for case');
  const p={schema:'octolang.recovery-governance.v2.5',caseDigest:caseData.caseDigest,
    observerDigest:hash(PREFIX+canonical(observer)),action,
    issuedAt:new Date(now).toISOString(),expiresAt:new Date(now+300000).toISOString()};
  return sign(p,privateKey);
}
function checkApproval(c,observer,approval,pins,now){
  keys(pins);chk(c?.valid&&isDigest(c.caseDigest),'case must be verified');
  chk(verify(observer,pins.observer)&&observer.payload.schema==='octolang.recovery-observer.v2.5'&&
    observer.payload.caseDigest===c.caseDigest&&observer.payload.classification===c.classification&&
    observer.payload.effectDigest===c.effectDigest&&observer.payload.decision==='EVIDENCE_INSPECTED_NOT_WORLD_TRUTH',
    'invalid independent observation');
  chk(verify(approval,pins.governor)&&approval.payload.schema==='octolang.recovery-governance.v2.5'&&
    approval.payload.caseDigest===c.caseDigest&&approval.payload.observerDigest===hash(PREFIX+canonical(observer))&&
    c.allowed.includes(approval.payload.action),'invalid governance decision');
  for(const s of [observer.payload,approval.payload]){
    const issued=Date.parse(s.issuedAt),expires=Date.parse(s.expiresAt);
    chk(Number.isFinite(issued)&&Number.isFinite(expires)&&issued<=now&&now<expires&&expires-issued<=300000&&now-issued<=300000,
      'expired or future recovery approval');
  }
  return true;
}
function fsyncDir(dir){const fd=fs.openSync(dir,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
function recoveryJournal({directory,pins}){
  try{
    const file=path.join(directory,'reconciliations.jsonl'),sealFile=path.join(directory,'reconciliation-seal.json');
    if(!fs.existsSync(file)){chk(!fs.existsSync(sealFile),'recovery journal lost');return {valid:true,head:null,sequence:0,cases:{},rows:[]};}
    const content=fs.readFileSync(file,'utf8');chk(content.endsWith('\n'),'truncated recovery journal');
    const rows=content.trimEnd().split('\n');chk(rows.length<=100000,'recovery journal oversized');
    let head=null,sequence=0;const cases={},verifiedRows=[];
    for(const line of rows){chk(line.length<32768,'recovery record oversized');const row=JSON.parse(line);
      const b={sequence:row.sequence,previous:row.previous,payload:row.payload};
      chk(row.sequence===sequence+1&&row.previous===head&&row.hash===hash(JOURNAL+canonical(b))&&
        verify({payload:{...b,hash:row.hash},signature:row.signature},pins.controller,JOURNAL),'recovery record signature/link invalid');
      const p=row.payload,c=p.caseData;
      chk(c?.schema==='octolang.recovery-case.v2.5'&&c.valid===true&&isDigest(c.caseDigest),'recovery case shape invalid');
      const material={...c};delete material.valid;delete material.caseDigest;delete material.allowed;
      chk(hash(PREFIX+canonical(material))===c.caseDigest,'recovery case digest invalid');
      checkApproval(c,p.observer,p.approval,pins,Date.parse(p.resolvedAt));
      chk(!Object.hasOwn(cases,c.nonce),'reconciliation already recorded');
      if(p.approval.payload.action==='WITNESS_EXISTING_COMPLETION'){
        chk(c.classification==='COMPLETE_NEEDS_WITNESS'&&isDigest(p.resultWitnessHead),
          'witness completion certificate missing');
      }else chk(p.approval.payload.action==='HOLD'&&p.resultWitnessHead===null,'invalid hold decision');
      cases[c.nonce]={action:p.approval.payload.action,caseDigest:c.caseDigest,witnessHead:p.resultWitnessHead};
      head=row.hash;sequence=row.sequence;verifiedRows.push(row);
    }
    chk(fs.existsSync(sealFile),'recovery seal missing');const seal=JSON.parse(fs.readFileSync(sealFile,'utf8'));
    chk(canonical(seal.payload)===canonical({head,sequence})&&verify(seal,pins.controller,SEAL),'recovery seal invalid');
    return {valid:true,head,sequence,cases,rows:verifiedRows};
  }catch(e){return {valid:false,reason:e.message};}
}
function appendRecord(directory,pins,privateKey,state,payload){
  const b={sequence:state.sequence+1,previous:state.head,payload},row={...b,hash:hash(JOURNAL+canonical(b))};
  row.signature=sign({...b,hash:row.hash},privateKey,JOURNAL).signature;
  const file=path.join(directory,'reconciliations.jsonl'),fd=fs.openSync(file,'a',0o600);
  try{fs.writeSync(fd,JSON.stringify(row)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
  const seal=sign({head:row.hash,sequence:row.sequence},privateKey,SEAL);
  const temp=path.join(directory,'.reconciliation-seal-'+crypto.randomUUID());
  try{fs.writeFileSync(temp,JSON.stringify(seal)+'\n',{flag:'wx',mode:0o600});
    const f=fs.openSync(temp,'r');try{fs.fsyncSync(f);}finally{fs.closeSync(f);}
    fs.renameSync(temp,path.join(directory,'reconciliation-seal.json'));fsyncDir(directory);
  }finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}
  return row;
}

/** Standalone public-key-only audit; revalidates source journals, remote witness,
 * original case snapshots and all reconciliation signatures. */
function verifyRecoveryBundle(cfg){
  try{
    const state=getFiles(cfg),j=recoveryJournal({directory:cfg.directory,pins:cfg.pins});chk(j.valid,j.reason);
    const {ledger,execution,witness,reservations}=state;
    const byNonce=new Map(reservations.map(e=>[e.payload.request.nonce,e]));
    for(const row of j.rows){
      const p=row.payload,c=p.caseData,action=execution.actions[c.nonce],r=byNonce.get(c.nonce);
      chk(action&&r&&c.reservationHead===r.hash&&c.startHash===action.startHash&&
        c.scoreDigest===ledger.state.scoreDigest&&c.activeRevisionDigest===action.start.activeRevisionDigest&&
        c.executionSequence<=execution.sequence&&c.ledgerSequence<=ledger.state.sequence,
        'reconciliation does not bind to real signed execution and reservation');
      chk(witness.checkpoints.some(w=>w.head===c.witnessHead&&w.sequence===c.witnessSequence),
        'original remote witness predecessor missing');
      const before=witness.checkpoints.find(w=>w.head===c.witnessHead);
      chk(!before.snapshot.executionHead||before.snapshot.executionSequence<=c.executionSequence,
        'reconciliation preceding checkpoint diverges');
      const ef=path.join(cfg.directory,'effects',hash('intent-file:'+c.nonce)+'.json');
      if(c.effectDigest){chk(fs.existsSync(ef)&&hash(canonical(JSON.parse(fs.readFileSync(ef,'utf8'))))===c.effectDigest,
        'reconciliation effect altered or removed');}
      if(p.approval.payload.action==='WITNESS_EXISTING_COMPLETION'){
        chk(action.status==='COMPLETED'&&action.completeHash===c.completeHash&&
          witness.checkpoints.some(w=>w.head===p.resultWitnessHead&&w.snapshot.executionHead===c.completeHash&&
            w.snapshot.executionSequence===c.executionSequence),'recovered completion was not witnessed');
      }else{
        chk(p.approval.payload.action==='HOLD'&&p.resultWitnessHead===null&&
          c.classification!=='ALREADY_WITNESSED','invalid indefinite hold case');
      }
    }
    return {valid:true,scoreDigest:ledger.state.scoreDigest,executionSequence:execution.sequence,
      witnessSequence:witness.sequence,reconciliationSequence:j.sequence,reconciled:Object.keys(j.cases).length,
      outcomes:j.cases,automaticRetries:false,budgetReleased:false};
  }catch(e){return {valid:false,reason:e.message};}
}

class RecoveryCoordinator {
  constructor({controller,pins,now=()=>Date.now()}){
    chk(controller?.gate?._lockAsync&&controller?.witness?.refresh,'v2.4 remote execution controller required');keys(pins);
    chk(crypto.createPublicKey(controller.gate.controllerPrivateKey).export({format:'der',type:'spki'}).toString('hex')===
      crypto.createPublicKey(pins.controller).export({format:'der',type:'spki'}).toString('hex'),'controller key mismatch');
    chk(controller.witnessPublicKey===pins.witness,'witness key mismatch');
    this.controller=controller;this.pins=pins;this.now=now;
  }
  config(){const c=this.controller;return {directory:c.gate.directory,scoreSource:c.gate.scoreSource,pins:this.pins,
    witnessDirectory:c.witnessDirectory};}
  async inspect(nonce){await this.controller.witness.refresh();return inspectCase(this.config(),nonce);}
  async reconcile({caseData,observer,approval}){
    const c=this.controller,gate=c.gate;
    return gate._lockAsync(async()=>{
      await c.witness.refresh();
      const fresh=inspectCase(this.config(),caseData.nonce);
      chk(fresh.valid&&canonical(fresh)===canonical(caseData),'recovery case stale or unverifiable');
      checkApproval(fresh,observer,approval,this.pins,this.now());
      const prior=recoveryJournal({directory:gate.directory,pins:this.pins});chk(prior.valid,prior.reason);
      chk(!Object.hasOwn(prior.cases,fresh.nonce),'case already reconciled');
      let resultWitnessHead=null;
      if(approval.payload.action==='WITNESS_EXISTING_COMPLETION'){
        // A previously controller-signed COMPLETE and exact local effect already exist.
        // This ONLY asks the independent witness to attest EXISTING ledger state.
        const completed=c._snapshot();
        chk(completed.executionHead===fresh.completeHash&&completed.ledgerHead===fresh.ledgerHead,'completion changed');
        const a=await c.witness.attest(completed,fresh.witnessHead);
        chk(a.valid&&a.snapshot.executionHead===fresh.completeHash&&a.snapshot.ledgerHead===fresh.ledgerHead,
          'remote witness did not confirm original completion');
        resultWitnessHead=a.head;
      }
      // No new execution, no budget release, no synthetic COMPLETE.
      const payload={schema:'octolang.reconciliation.v2.5',caseData:fresh,observer,approval,
        resolvedAt:new Date(this.now()).toISOString(),resultWitnessHead};
      const row=appendRecord(gate.directory,this.pins,gate.controllerPrivateKey,prior,payload);
      const checked=recoveryJournal({directory:gate.directory,pins:this.pins});chk(checked.valid,checked.reason);
      return {status:approval.payload.action==='HOLD'?'UNRESOLVED_HOLD':'EXISTING_COMPLETION_WITNESSED',
        nonce:fresh.nonce,caseDigest:fresh.caseDigest,recoveryReceiptHash:row.hash,checkpointHead:resultWitnessHead,
        reservationRetained:true,executedAgain:false};
    });
  }
  async audit(){
    await this.controller.witness.refresh();
    const evidence=verifyRecoveryBundle(this.config());
    if(!evidence.valid)return evidence;
    return {...evidence,executionAudit:this.controller.verify()};
  }
}
module.exports={inspectCase,attest,approve,checkApproval,recoveryJournal,verifyRecoveryBundle,RecoveryCoordinator};
