'use strict';
const {setupRemote}=require('../v2.4/demo');
const {RecoveryCoordinator,attest,approve}=require('./reconcile');
async function demo(){
  const f=await setupRemote();
  try{
    const pins={...f.pins,witness:f.remote.witnessPublicKey};
    const coordinator=new RecoveryCoordinator({controller:f.controller,pins});
    // Deliberately lose the remote completion response AFTER the local tool and
    // controller-signed COMPLETE event. Never trigger the effect again.
    const original=f.witness.attest.bind(f.witness);
    f.witness.attest=(s,h)=>s.executionSequence===2?Promise.reject(Error('DEMO: completion checkpoint unavailable')):original(s,h);
    let interruption;
    try{await f.controller.execute({...f.decision,missionParams:f.missionParams});}
    catch(e){interruption=e.message;}
    f.witness.attest=original;
    const nonce=f.decision.request.nonce,caseData=await coordinator.inspect(nonce);
    if(caseData.classification!=='COMPLETE_NEEDS_WITNESS')throw Error('unexpected demo recovery case '+JSON.stringify(caseData));
    // Synthetic demo keys: in deployment, different organisations independently
    // inspect the evidence and sign observer/governance decisions.
    const observer=attest(caseData,f.actors.observer.privateKey);
    const approval=approve(caseData,observer,'WITNESS_EXISTING_COMPLETION',f.actors.governor.privateKey);
    const recovered=await coordinator.reconcile({caseData,observer,approval});
    const audit=await coordinator.audit();if(!audit.valid)throw Error(audit.reason);
    const out={version:'2.5',interruption,classification:caseData.classification,recovered,
      audit:{valid:audit.valid,reconciled:audit.reconciled,executionValid:audit.executionAudit.valid},
      actualLocalEffects:require('node:fs').readdirSync(require('node:path').join(f.directory,'effects')).length,
      transfer:false,autoRetry:false,machinesActuallyUsed:1};
    console.log(JSON.stringify(out,null,2));return out;
  }finally{await f.remote.close();}
}
if(require.main===module)demo().catch(e=>{console.error(e.stack);process.exitCode=1;});
module.exports={demo};
