'use strict';
// OctoLang epistemic/contextual types v1.8: declarative compile, pure semantics, no authority.
const crypto=require('node:crypto');
const {canonical}=require('../../src/canonical');
const {compileLanguage}=require('../v1.6');
const {verifyIR: verifyRoot}=require('../v1.6/validate');
const SCHEMA='octolang.epistemic-ir.v1.8';
const ARTIFACT='octolang.epistemic-artifact.v1.8';
const PREFIX='OctoLang Epistemic IR v1.8\n';
const HASH=s=>crypto.createHash('sha256').update(s,'utf8').digest('hex');
const digestIR=ir=>HASH(PREFIX+canonical(ir));
const ID=/^[A-Za-z_][A-Za-z0-9_-]*$/;
const TYPES=['Verified','Observed','Inferred','Disputed','Expired','Unverified'];
const VALUES=['Credential','Status','Score','Claim','Measurement','Document'];
const cmp=(a,b)=>a<b?-1:a>b?1:0;
const need=(v,msg)=>{if(!v)throw new Error('OctoLang epistemic: '+msg);};
function tokenize(source){
  need(typeof source==='string'&&source.length<=65536,'source must be text, maximum 65536 code units');
  const result=[];let at=0;
  while(at<source.length){
    const s=source.slice(at);
    const skip=s.match(/^(?:\s+|#[^\n]*|\/\/[^\n]*)/);
    if(skip){at+=skip[0].length;continue;}
    const match=s.match(/^(?:"(?:\\["\\nrt]|[^"\\\n\r])*"|[A-Za-z_][A-Za-z0-9_-]*|(?:0|[1-9][0-9]*)|[{}<>])/);
    need(!!match,`unknown token at offset ${at}`);
    const raw=match[0];result.push(raw);at+=raw.length;
    need(result.length<=2000,'too many tokens');
  }
  return result;
}
function parse(source){
  const tokens=tokenize(source);let p=0;
  const pop=expected=>{need(p<tokens.length,'unexpected end');const v=tokens[p++];if(expected)need(v===expected,`expected ${expected}, got ${v}`);return v;};
  const identifier=()=>{const v=pop();need(ID.test(v),'invalid identifier');return v;};
  const string=()=>{const v=pop();need(v.startsWith('"'),'expected quoted string');const decoded=JSON.parse(v);need(decoded.length>0&&decoded.length<=128,'string size invalid');return decoded;};
  const duration=()=>{const n=pop(),unit=identifier();need(/^[1-9][0-9]{0,5}$/.test(n)&&['m','h','d'].includes(unit),'invalid max_age');const ms=Number(n)*({m:60000,h:3600000,d:86400000})[unit];need(ms<=365*86400000,'max_age over 365 days');return ms;};
  pop('epistemic');const missionName=identifier();pop('{');
  const knowledge=[],guards=[];
  while(p<tokens.length&&tokens[p]!=='}'){
    const kind=pop(),name=identifier();pop('{');const fields={};
    while(p<tokens.length&&tokens[p]!=='}'){
      const key=identifier();need(!Object.hasOwn(fields,key),`duplicate field ${key}`);
      if(kind==='knowledge'){
        need(['type','source','subject','max_age'].includes(key),`unknown knowledge field ${key}`);
        if(key==='type'){const state=identifier();pop('<');const valueType=identifier();pop('>');fields.type={state,valueType};}
        else fields[key]=key==='max_age'?duration():string();
      } else if(kind==='guard'){
        need(['require','on_unknown'].includes(key),`unknown guard field ${key}`);
        fields[key]=identifier();
      } else throw new Error('OctoLang epistemic: unknown declaration '+kind);
    }
    pop('}');
    if(kind==='knowledge'){
      need(Object.keys(fields).length===4,'knowledge requires type, source, subject, max_age');
      knowledge.push({name,...fields});need(knowledge.length<=32,'too many knowledge declarations');
    }else if(kind==='guard'){
      need(Object.keys(fields).length===2,'guard requires require and on_unknown');
      guards.push({task:name,...fields});need(guards.length<=32,'too many guards');
    }else need(false,'unknown declaration '+kind);
  }
  pop('}');need(p===tokens.length,'trailing tokens');
  need(knowledge.length>0&&guards.length>0,'knowledge and guard declarations required');
  return {missionName,knowledge,guards};
}
function makeIR(parsed,rootIR){
  need(parsed.missionName===rootIR.name,'wrong mission name');
  const kn=new Set();const taskMap=new Map(rootIR.tasks.map(t=>[t.name,t]));
  const knowledge=parsed.knowledge.map(k=>{
    need(ID.test(k.name)&&!kn.has(k.name),'duplicate or invalid knowledge declaration');kn.add(k.name);
    need(k.type&&TYPES.includes(k.type.state)&&VALUES.includes(k.type.valueType),'unsupported epistemic type');
    need(typeof k.source==='string'&&/^[A-Za-z0-9._:-]{2,128}$/.test(k.source),'invalid source identity');
    need(typeof k.subject==='string'&&/^[A-Za-z0-9._:-]{2,128}$/.test(k.subject),'invalid subject');
    need(Number.isSafeInteger(k.max_age)&&k.max_age>=60000&&k.max_age<=365*86400000,'invalid knowledge freshness');
    return {name:k.name,state:k.type.state,valueType:k.type.valueType,source:k.source,subject:k.subject,freshnessMaxMs:k.max_age,
      trust:'EXTERNAL_PINNED_ED25519_EVIDENCE',assertsTruth:false};
  }).sort((a,b)=>cmp(a.name,b.name));
  const guardNames=new Set();const guards=parsed.guards.map(g=>{
    need(taskMap.has(g.task)&&!guardNames.has(g.task),'invalid or duplicate guarded task');guardNames.add(g.task);
    const k=knowledge.find(x=>x.name===g.require),task=taskMap.get(g.task);
    need(!!k,'guard names undeclared knowledge');
    need(['DENY','ESCALATE'].includes(g.on_unknown),'on_unknown must be DENY or ESCALATE');
    const nonEffectful=['research','validate'].includes(task.requiredCapability)&&task.effect==='LOCAL_CAPABILITY';
    // An inference can help draft a research plan, not authorise an effect or audit result.
    if(k.state==='Inferred') need(nonEffectful&&task.requiredCapability==='research','inferred evidence only for read-only research');
    if(k.state==='Observed') need(nonEffectful,'observations cannot authorise effectful tasks');
    need(!['Disputed','Expired','Unverified'].includes(k.state),'uncertain/expired types cannot satisfy executable guards');
    return {task:g.task,knowledge:g.require,requiredState:k.state,onUnknown:g.on_unknown,permitExecution:false};
  }).sort((a,b)=>cmp(a.task,b.task));
  need(guards.length===rootIR.tasks.length,'every task must have an epistemic guard');
  return {schema:SCHEMA,kind:'epistemic-policy',missionName:rootIR.name,missionIRDigest:require('../v1.6').hashIR(rootIR),
    governance:{grantsImplied:false,requiresIndependentContextVerification:true,decision:'ADMISSIBILITY_NOT_EXECUTION'},knowledge,guards};
}
function compileEpistemic(source,missionSource){
  const root=compileLanguage(missionSource);
  const parsed=parse(source),ir=makeIR(parsed,root.ir);
  return {schema:ARTIFACT,sourceSha256:HASH(source),missionSourceSha256:HASH(missionSource),missionIRDigest:root.irDigest,ir,irDigest:digestIR(ir)};
}
function verifyEpistemic(source,missionSource,artifact){
  try{
    const expected=compileEpistemic(source,missionSource);
    const {verifyIR}=require('./validate');const checked=verifyIR(artifact.ir,compileLanguage(missionSource).ir,artifact.irDigest);
    need(checked.valid,checked.reason);
    need(canonical(expected)===canonical(artifact),'source/mission/IR mismatch');
    return {valid:true,irDigest:expected.irDigest};
  }catch(e){return {valid:false,reason:e.message};}
}
module.exports={SCHEMA,ARTIFACT,PREFIX,TYPES,VALUES,parse,makeIR,compileEpistemic,verifyEpistemic,digestIR,HASH};
