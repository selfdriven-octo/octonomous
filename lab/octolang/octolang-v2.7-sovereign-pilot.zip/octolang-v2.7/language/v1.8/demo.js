'use strict';
const fs=require('node:fs');const path=require('node:path');
const crypto=require('node:crypto');
const {signed,digest}=require('../../src/canonical');
const {compileLanguage}=require('../v1.6');
const {compileEpistemic}=require('./index');
const {CLAIM,evaluate}=require('./evidence');
function run(){
  const read=name=>fs.readFileSync(path.join(__dirname,'../../examples',name),'utf8');
  const mission=read('community-proofs.octo');const epistemic=read('community-epistemic.octo');
  const compiled=compileEpistemic(epistemic,mission),rootIR=compileLanguage(mission).ir;
  const {publicKey,privateKey}=crypto.generateKeyPairSync('ed25519');
  const trust={issuers:{'community-registry':{publicKey:publicKey.export({type:'spki',format:'pem'}),allowedStates:['Verified']}}};
  const now=Date.now();
  const payload=value=>({schema:CLAIM,missionIRDigest:compiled.ir.missionIRDigest,knowledge:'supplier_accreditation',kind:'Verified',
    valueType:'Credential',source:'community-registry',subject:'supplier',valueDigest:digest(value),observedAt:now-1000,validUntil:now+60000,parents:[]});
  const a=signed(payload('supplier-credential-A'),privateKey);
  const scenarios={
    verified:evaluate({ir:compiled.ir,irDigest:compiled.irDigest,rootIR,trust,evidence:[a],expectedSubject:'supplier',now}),
    missing:evaluate({ir:compiled.ir,irDigest:compiled.irDigest,rootIR,trust,evidence:[],expectedSubject:'supplier',now}),
    disputed:evaluate({ir:compiled.ir,irDigest:compiled.irDigest,rootIR,trust,evidence:[a,signed(payload('supplier-credential-B'),privateKey)],expectedSubject:'supplier',now})
  };
  for(const [name,x] of Object.entries(scenarios))console.log(name,x.valid,x.statuses?.supplier_accreditation?.status,x.guards?.[0]?.decision);
  console.log('NOTE: CONTEXT_ADMISSIBLE_ONLY is not execution authority. No external effect, transaction or proof generated.');
  return scenarios;
}
if(require.main===module)run();module.exports={run};
