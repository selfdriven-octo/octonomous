'use strict';
const {canonical}=require('../../src/canonical');
const {makeIR,digestIR,SCHEMA}=require('./index');
const {verifyIR:verifyRoot}=require('../v1.6/validate');
function need(ok,msg){if(!ok)throw new Error('Invalid epistemic IR: '+msg);}
const plain=x=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
function shape(value,required){need(plain(value),'plain object required');need(Object.keys(value).length===required.length&&required.every(k=>Object.hasOwn(value,k)),'unknown or missing fields');}
function validateIR(ir,rootIR){
  shape(ir,['schema','kind','missionName','missionIRDigest','governance','knowledge','guards']);
  need(ir.schema===SCHEMA&&ir.kind==='epistemic-policy','wrong schema');
  shape(ir.governance,['grantsImplied','requiresIndependentContextVerification','decision']);
  need(ir.governance.grantsImplied===false&&ir.governance.requiresIndependentContextVerification===true&&ir.governance.decision==='ADMISSIBILITY_NOT_EXECUTION','fabricated authorisation');
  need(verifyRoot(rootIR,ir.missionIRDigest).valid,'invalid pinned mission root');
  need(Array.isArray(ir.knowledge)&&Array.isArray(ir.guards),'declarations not arrays');
  let last='';for(const k of ir.knowledge){
    shape(k,['name','state','valueType','source','subject','freshnessMaxMs','trust','assertsTruth']);
    need(k.name>last,'knowledge order');last=k.name;
    need(k.trust==='EXTERNAL_PINNED_ED25519_EVIDENCE'&&k.assertsTruth===false,'false claims about evidence');
  }
  last='';for(const g of ir.guards){shape(g,['task','knowledge','requiredState','onUnknown','permitExecution']);need(g.task>last,'guard order');last=g.task;need(g.permitExecution===false,'execution authority injection');}
  const projected=makeIR({missionName:ir.missionName,knowledge:ir.knowledge.map(k=>({name:k.name,type:{state:k.state,valueType:k.valueType},source:k.source,subject:k.subject,max_age:k.freshnessMaxMs})),guards:ir.guards.map(g=>({task:g.task,require:g.knowledge,on_unknown:g.onUnknown}))},rootIR);
  need(canonical(projected)===canonical(ir),'derived semantic fields changed');
  return true;
}
function verifyIR(ir,rootIR,expectedDigest){try{validateIR(ir,rootIR);need(digestIR(ir)===expectedDigest,'digest mismatch');return {valid:true,irDigest:expectedDigest};}catch(e){return {valid:false,reason:e.message};}}
module.exports={validateIR,verifyIR};
