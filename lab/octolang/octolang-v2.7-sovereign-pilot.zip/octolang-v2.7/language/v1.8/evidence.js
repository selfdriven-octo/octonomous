'use strict';
// Verifier-owned assessment. Labels in agent-authored plans or unsigned data confer NO trust.
const {canonical,digest,verifiedSigned}=require('../../src/canonical');
const {verifyIR}=require('./validate');
const CLAIM='octolang.epistemic-claim.v1.8';
const HEX=/^[0-9a-f]{64}$/;
const isObject=x=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
const fields=(x,n)=>isObject(x)&&Object.keys(x).length===n.length&&n.every(k=>Object.hasOwn(x,k));
const validTime=n=>Number.isSafeInteger(n)&&n>=0&&n<=8640000000000000;
function evaluate({ir,irDigest,rootIR,trust,evidence,expectedSubject,now=Date.now()}){
  try{
    const valid=verifyIR(ir,rootIR,irDigest);if(!valid.valid)throw new Error(valid.reason);
    if(!Number.isSafeInteger(now)||now<0)throw new Error('invalid verifier clock');
    if(typeof expectedSubject!=='string'||expectedSubject.length>128||!expectedSubject)throw new Error('missing expected subject');
    if(!isObject(trust)||!isObject(trust.issuers))throw new Error('external trust pins required');
    if(!Array.isArray(evidence)||evidence.length>128)throw new Error('invalid evidence bundle');
    const knowledgeByName=new Map(ir.knowledge.map(k=>[k.name,k]));
    const prepared=new Map();const matching=new Map(ir.knowledge.map(k=>[k.name,[]]));
    for(const signed of evidence){
      if(!fields(signed,['payload','signature']))throw new Error('malformed signed claim');
      const p=signed.payload;
      if(!fields(p,['schema','missionIRDigest','knowledge','kind','valueType','source','subject','valueDigest','observedAt','validUntil','parents']))throw new Error('claim schema fields invalid');
      if(p.schema!==CLAIM||p.missionIRDigest!==ir.missionIRDigest||p.subject!==expectedSubject)throw new Error('claim not bound to mission or subject');
      const requirement=knowledgeByName.get(p.knowledge);
      if(!requirement||p.kind!==requirement.state||p.valueType!==requirement.valueType||p.source!==requirement.source||p.subject!==requirement.subject)throw new Error('claim conflicts with declared type or subject');
      if(!HEX.test(p.valueDigest)||!validTime(p.observedAt)||!validTime(p.validUntil)||p.validUntil<=p.observedAt||p.observedAt>now)throw new Error('invalid observation/expiry or future-dated evidence');
      if(!Array.isArray(p.parents)||p.parents.length>8||p.parents.some(x=>typeof x!=='string'||!HEX.test(x))||p.parents.some((x,i)=>i>0&&p.parents[i-1]>=x))throw new Error('invalid sorted parent digests');
      if(p.kind!=='Inferred'&&p.parents.length)throw new Error('only inference may contain parent claims');
      if(p.kind==='Inferred'&&p.parents.length===0)throw new Error('inference lacks supporting claims');
      const pin=trust.issuers[p.source];
      if(!isObject(pin)||typeof pin.publicKey!=='string'||!Array.isArray(pin.allowedStates)||!pin.allowedStates.includes(p.kind))throw new Error('untrusted issuer or unsupported attestation kind');
      if(!verifiedSigned(signed,pin.publicKey))throw new Error('bad Ed25519 signature');
      const d=digest(p);if(prepared.has(d))throw new Error('duplicated attestation digest');
      const fresh=p.observedAt<=now&&now<p.validUntil&&now-p.observedAt<=requirement.freshnessMaxMs;
      prepared.set(d,{payload:p,fresh});matching.get(p.knowledge).push({payload:p,fresh,digest:d});
    }
    // An inference is only admitted if its named parents are present, authenticated,
    // fresh, and are direct observations or source verifications of the same subject.
    for(const {payload:p,fresh} of prepared.values()){
      if(!fresh||p.kind!=='Inferred')continue;
      for(const parent of p.parents){const x=prepared.get(parent);
        if(!x||!x.fresh||!['Verified','Observed'].includes(x.payload.kind)||x.payload.subject!==p.subject)
          throw new Error('inference parent missing, stale or not independently sourced');
        const peers=matching.get(x.payload.knowledge).filter(c=>c.fresh);
        if(new Set(peers.map(c=>c.payload.valueDigest)).size>1)throw new Error('inference rests on disputed evidence');
      }
    }
    const statuses={};
    for(const k of ir.knowledge){
      const all=matching.get(k.name);const fresh=all.filter(x=>x.fresh);
      const values=new Set(fresh.map(x=>x.payload.valueDigest));
      const status=values.size>1?'DISPUTED':fresh.length?k.state.toUpperCase():all.length?'EXPIRED':'UNVERIFIED';
      statuses[k.name]={status,claimDigests:fresh.map(x=>x.digest).sort(),valueDigest:fresh.length&&values.size===1?[...values][0]:null,
        note:'Cryptographic provenance is not proof of objective real-world truth'};
    }
    const guards=ir.guards.map(g=>{
      const current=statuses[g.knowledge].status;
      const expected=g.requiredState.toUpperCase();
      const accepted=current===expected;
      return {task:g.task,knowledge:g.knowledge,status:current,decision:accepted?'CONTEXT_ADMISSIBLE_ONLY':g.onUnknown,
        note:'This is not tool execution authority. Recheck context and grants at effect time.'};
    });
    return {valid:true,irDigest,statuses,guards};
  }catch(e){return {valid:false,reason:e.message,guards:[],status:'DENY'};}
}
module.exports={CLAIM,evaluate};
