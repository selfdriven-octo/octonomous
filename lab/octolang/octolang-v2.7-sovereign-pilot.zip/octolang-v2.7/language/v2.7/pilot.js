'use strict';
/** Local rehearsal of three independent roles: execution process (this process),
 * witness child process and governance child process. No payment capability.
 * Remote governance key never loads into this coordinator's memory. */
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {spawn,execFileSync}=require('node:child_process');
const {compileScore,parseScore,sha}=require('../v2.1');
const {compileMission}=require('../../src/mission');
const {fixtures}=require('../../mission/demo');
const {ActivationGate}=require('../v2.2');
const {decisionFromMission}=require('../v2.2/mission-vcc');
const {OBS_SCHEMA,REVIEW_SCHEMA,digestObservation,compileRevision,createObservation,createReview}=require('../v2.1/refinement');
const {startup}=require('../v2.4/demo');
const {testPki}=require('../v2.4/provision');
const {RemoteWitness}=require('../v2.4/remote');
const {RemoteExecutionController}=require('../v2.4/execution');
const {GovernanceClient,fileBundle}=require('./governance');
const iso=ms=>new Date(ms).toISOString();
const pem=k=>k.publicKey.export({format:'pem',type:'spki'}).toString();
async function launch(script,cfg){const cp=spawn(process.execPath,[script,cfg],{stdio:['ignore','pipe','pipe']});
  try{const ready=await new Promise((resolve,reject)=>{let log='';let stderr='';const t=setTimeout(()=>reject(Error('service launch timed out: '+stderr)),12000);t.unref();
    cp.stdout.on('data',x=>{log+=x;try{const line=log.split('\n')[0],v=JSON.parse(line);if(v.ready){clearTimeout(t);resolve(v);}}catch{}});
    cp.stderr.on('data',x=>{stderr+=x.toString();});cp.once('exit',code=>{clearTimeout(t);reject(Error('service exited: '+code+' '+stderr));});cp.once('error',e=>{clearTimeout(t);reject(e);});});
    return {process:cp,ready};
  }catch(e){cp.kill();throw e;}}
function stop(cp){return new Promise(resolve=>{if(!cp||cp.exitCode!==null||cp.signalCode!==null)return resolve();const killer=setTimeout(()=>{cp.kill('SIGKILL');resolve();},1800);killer.unref();cp.once('exit',()=>{clearTimeout(killer);resolve();});cp.kill();});}
async function setupPilot({base=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v27-pilot-')),stopBeforeEffect=false}={}){
  fs.mkdirSync(base,{recursive:true,mode:0o700});
  const scoreSource=fs.readFileSync(path.join(__dirname,'../../community-score.octo'),'utf8');
  const score=compileScore(scoreSource),actors=Object.fromEntries(['observer','reviewer','vcc','controller'].map(n=>[n,crypto.generateKeyPairSync('ed25519')]));
  const govHome=path.join(base,'governance-host'),execHome=path.join(base,'execution-host'),witnessHome=path.join(base,'witness-host');
  for(const d of [govHome,execHome,witnessHome])fs.mkdirSync(d,{recursive:true,mode:0o700});
  // Provision governor identity in its own PROCESS; private key is never read here.
  execFileSync(process.execPath,[path.join(__dirname,'provision.js'),govHome]);
  const read=p=>fs.readFileSync(p),pins={observer:pem(actors.observer),reviewer:pem(actors.reviewer),governor:read(path.join(govHome,'governor-public.pem')).toString(),
    vcc:pem(actors.vcc),controller:pem(actors.controller)};
  const ledgerDirectory=path.join(execHome,'ledger');
  const gate=new ActivationGate({directory:ledgerDirectory,scoreSource,pins,controllerPrivateKey:actors.controller.privateKey});gate.init();
  const remote=await startup({scoreDigest:score.irDigest,controllerPublicKey:pins.controller});
  let gp;
  try{
    const gpki=testPki(path.join(govHome,'pki')),scoreFile=path.join(govHome,'score.octo'),controllerFile=path.join(govHome,'controller-public.pem'),witnessFile=path.join(govHome,'witness-public.pem');
    fs.writeFileSync(scoreFile,scoreSource,{mode:0o600});fs.writeFileSync(controllerFile,pins.controller,{mode:0o600});
    fs.writeFileSync(witnessFile,remote.witnessPublicKey,{mode:0o600});
    const gcfg={directory:path.join(govHome,'journal'),scoreSource:scoreFile,governorPrivateKey:path.join(govHome,'governor-private.pem'),
      governorPublicKey:path.join(govHome,'governor-public.pem'),controllerPublicKey:controllerFile,witnessPublicKey:witnessFile,
      pins,serverKey:gpki.server.key,serverCert:gpki.server.cert,clientCa:gpki.ca,clientFingerprint:gpki.client.digest,host:'127.0.0.1',port:0};
    const cfgFile=path.join(govHome,'service-config.json');fs.writeFileSync(cfgFile,JSON.stringify(gcfg),{mode:0o600});
    gp=await launch(path.join(__dirname,'service.js'),cfgFile);
    const governance=new GovernanceClient({url:`https://127.0.0.1:${gp.ready.port}/`,cert:read(gpki.client.cert),key:read(gpki.client.key),ca:read(gpki.ca),
      pinnedServerFingerprint:gpki.server.digest,controllerPrivateKey:actors.controller.privateKey,
      controllerPublicKey:pins.controller,governorPublicKey:pins.governor,scoreDigest:score.irDigest});
    const mirrorDirectory=path.join(execHome,'witness-mirror');
    const witness=new RemoteWitness({url:remote.url,cert:read(remote.pki.client.cert),key:read(remote.pki.client.key),ca:read(remote.pki.ca),
      pinnedServerFingerprint:remote.pki.server.digest,controllerPrivateKey:actors.controller.privateKey,controllerPublicKey:pins.controller,
      witnessPublicKey:remote.witnessPublicKey,scoreDigest:score.irDigest,mirrorDirectory});
    // Sign and approve a specific scored revision remotely, with two independent evidence keys.
    const now=Date.now(),observationPayload={schema:OBS_SCHEMA,scoreDigest:score.irDigest,metric:'cost-per-run',value:4,unit:'budget-units',
      sampleDigest:sha('synthetic three-host pilot'),observedAt:iso(now-60000),validUntil:iso(now+3600000),kind:'OBSERVATION'};
    const observation=createObservation(observationPayload,actors.observer.privateKey);
    const revisionSource=`revision reduce_scout { base "${score.irDigest}" evidence "${digestObservation(observationPayload)}" trigger "cost-per-run" above 3 tune scout_node runs 1 budget 1 }`;
    const revisionArtifact=compileRevision(revisionSource,score);
    const review=createReview({schema:REVIEW_SCHEMA,scoreDigest:score.irDigest,revisionDigest:revisionArtifact.irDigest,
      evidenceDigest:digestObservation(observationPayload),reviewedAt:iso(now),validUntil:iso(now+300000),decision:'APPROVE_PROPOSAL_ONLY'},actors.reviewer.privateKey);
    const revision={revisionSource,revisionArtifact,observation,review};
    const first=await governance.activate(fileBundle(ledgerDirectory,mirrorDirectory),revision);
    gate.activate({...revision,activation:first.activation});
    const controller=new RemoteExecutionController({gate,witness,witnessDirectory:mirrorDirectory,witnessPublicKey:remote.witnessPublicKey});
    await controller.bootstrap();
    const originalCheck=witness.checkLive.bind(witness);
    witness.checkLive=async snapshot=>{await originalCheck(snapshot);
      if(stopBeforeEffect)throw Error('DEMO governance partition before effect');
      await governance.preEffect(fileBundle(ledgerDirectory,mirrorDirectory));
      // A second read of the signed current snapshot blocks a race with new revisions.
      if(JSON.stringify(controller._snapshot())!==JSON.stringify(snapshot))throw Error('pre-effect state changed');
      return true;
    };
    const mission=compileMission(parseScore(scoreSource).layers.mission);
    const f=fixtures(mission,{subject:'supplier-42',inputs:{amount:'75',priority:'3',project:'Community learning',note:'Pilot note',urgent:false},now});
    const missionParams={mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust};
    const decision=decisionFromMission({scoreSource,binding:'intent_node',units:2,activeRevisionDigest:revisionArtifact.irDigest,
      missionParams,vccPrivateKey:actors.vcc.privateKey,now});
    return {base,scoreSource,score,actors,pins,gate,controller,witness,remote,governance,gp,revision,decision,missionParams,ledgerDirectory,
      governanceDirectory:gcfg.directory,governanceConfigFile:cfgFile,mirrorDirectory,
      stopGovernance:()=>stop(gp.process),
      restartGovernance:async()=>{await stop(gp.process);gp=await launch(path.join(__dirname,'service.js'),cfgFile);governance.url=`https://127.0.0.1:${gp.ready.port}/`;return gp.ready;},
      close:async()=>{await stop(gp.process);await remote.close();}};
  }catch(e){if(gp)await stop(gp.process);await remote.close();throw e;}
}
async function demo(){const f=await setupPilot();try{
  const result=await f.controller.execute({...f.decision,missionParams:f.missionParams});
  const audit=f.controller.verify(),governance=await f.governance.status();if(!audit.valid)throw Error(audit.reason);
  const effects=fs.readdirSync(path.join(f.ledgerDirectory,'effects')).length;
  const out={version:'2.7',status:'LOCAL_THREE_PROCESS_REHEARSAL',execution:{pid:process.pid},governance:{pid:f.gp.process.pid,checkpointSequence:governance.sequence},
    witness:{pid:f.remote.proc.pid},effects,executionAudited:audit.valid,governancePrivateKeyOnExecutionHost:false,
    network:'loopback mTLS, pinned keys',separatePhysicalMachines:false,payments:false,result:{status:result.status,nonce:result.nonce}};
  console.log(JSON.stringify(out,null,2));return out;
}finally{await f.close();}}
if(require.main===module)demo().catch(e=>{console.error(e.stack);process.exitCode=1;});
module.exports={setupPilot,demo};
