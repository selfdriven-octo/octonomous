'use strict';
/** Standalone governance-host key provisioning; refuses overwrites. */
const crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const root=process.argv[2];if(!root||!path.isAbsolute(root))throw Error('Provide an absolute governance home');
fs.mkdirSync(root,{recursive:true,mode:0o700});
const k=crypto.generateKeyPairSync('ed25519');
fs.writeFileSync(path.join(root,'governor-private.pem'),k.privateKey.export({format:'pem',type:'pkcs8'}),{flag:'wx',mode:0o600});
fs.writeFileSync(path.join(root,'governor-public.pem'),k.publicKey.export({format:'pem',type:'spki'}),{flag:'wx',mode:0o600});
console.log(JSON.stringify({governanceHome:root,publicKey:path.join(root,'governor-public.pem')}));
