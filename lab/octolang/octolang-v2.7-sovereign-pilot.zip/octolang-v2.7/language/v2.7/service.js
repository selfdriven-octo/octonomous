'use strict';
const fs=require('node:fs');const {service}=require('./governance');
async function main(){if(!process.argv[2])throw Error('Usage: node language/v2.7/service.js GOVERNANCE_CONFIG_JSON');
  const c=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
  const read=p=>fs.readFileSync(p);
  const server=service({...c,governorPrivateKey:read(c.governorPrivateKey),governorPublicKey:read(c.governorPublicKey),
    controllerPublicKey:read(c.controllerPublicKey),witnessPublicKey:read(c.witnessPublicKey),
    scoreSource:read(c.scoreSource).toString(),serverKey:read(c.serverKey),serverCert:read(c.serverCert),clientCa:read(c.clientCa)});
  const addr=await server.start();console.log(JSON.stringify({ready:true,port:addr.port,role:'governance'}));}
main().catch(e=>{console.error(e.stack);process.exitCode=1;});
