'use strict';
/** OctoLang v2.7 sovereign governance gateway. Runs with its own Ed25519 signing key
 * on a distinct service process/host. No tool capability is exposed by this service.
 * It verifies exact signatures/history before either activation or pre-effect release.
 * Research pilot: single pinned governor signing key (rotation requires re-enrolment).
 */
const https=require('node:https'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {canonical}=require('../../src/canonical');
const {compileScore}=require('../v2.1');
const {verifyReviewedRevision}=require('../v2.1/refinement');
const {verifyLedger,makeActivation,hash}=require('../v2.2');
const {readExecution}=require('../v2.4/execution');
const {verifyWitness}=require('../v2.3/witness');
const {fetchJSON,certDigest}=require('../v2.4/remote');
const PFX='OctoLang v2.7 Governance Request\n', RECEIPT='OctoLang v2.7 Governance Receipt\n';
function requireThat(ok,msg){if(!ok)throw Error('OctoLang v2.7 governance: '+msg);}
function keyOf(k){return crypto.createPublicKey(k).export({format:'pem',type:'spki'}).toString();}
function sign(payload,key,prefix=PFX){return crypto.sign(null,Buffer.from(prefix+canonical(payload)),key).toString('base64');}
function signatureOk(payload,sig,key,prefix=PFX){try{const b=Buffer.from(sig||'','base64');return b.length===64&&b.toString('base64')===sig&&crypto.verify(null,Buffer.from(prefix+canonical(payload)),key,b);}catch{return false;}}
function writeDurable(file,value,exclusive=false){const tmp=file+'.tmp-'+crypto.randomUUID();const f=fs.openSync(tmp,'wx',0o600);try{fs.writeSync(f,typeof value==='string'?value:JSON.stringify(value)+'\n');fs.fsyncSync(f);}finally{fs.closeSync(f);}try{if(exclusive&&fs.existsSync(file))throw Error('checkpoint exists');fs.renameSync(tmp,file);const d=fs.openSync(path.dirname(file),'r');try{fs.fsyncSync(d);}finally{fs.closeSync(d);}}finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}}
function materialize({ledgerText,sealText,executionText,executionSealText,witnessText},scoreSource,pins,witnessKey){
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-governor-verify-'));
  try{
    for(const [file,content] of Object.entries({'events.jsonl':ledgerText,'state-seal.json':sealText,'execution.jsonl':executionText,'execution-seal.json':executionSealText})){
      if(content)fs.writeFileSync(path.join(tmp,file),content);
    }
    const wd=path.join(tmp,'witness');fs.mkdirSync(wd);
    if(witnessText)fs.writeFileSync(path.join(wd,'checkpoints.jsonl'),witnessText);
    const ledger=verifyLedger({directory:tmp,scoreSource,pins});requireThat(ledger.valid&&ledger.initialised,ledger.reason||'ledger missing');
    const execution=readExecution({directory:tmp,publicKey:pins.controller,requireEffects:false});requireThat(execution.valid,execution.reason||'execution invalid');
    const witness=verifyWitness({directory:wd,publicKey:witnessKey});requireThat(witness.valid,witness.reason||'witness invalid');
    return {ledger,execution,witness};
  }finally{fs.rmSync(tmp,{recursive:true,force:true});}
}
function fileBundle(dir,witnessDir){const read=(base,n)=>fs.existsSync(path.join(base,n))?fs.readFileSync(path.join(base,n),'utf8'):'';
  return {ledgerText:read(dir,'events.jsonl'),sealText:read(dir,'state-seal.json'),executionText:read(dir,'execution.jsonl'),executionSealText:read(dir,'execution-seal.json'),witnessText:read(witnessDir,'checkpoints.jsonl')};}
function service({directory,scoreSource,governorPrivateKey,governorPublicKey,pins,witnessPublicKey,controllerPublicKey,
  serverKey,serverCert,clientCa,clientFingerprint,host='127.0.0.1',port=0,now=()=>Date.now()}){
  requireThat(path.isAbsolute(directory)&&keyOf(governorPrivateKey)===keyOf(governorPublicKey),'bad governance key or home');
  requireThat(keyOf(controllerPublicKey)===keyOf(pins.controller),'controller key differs from policy pin');
  requireThat(keyOf(governorPublicKey)===keyOf(pins.governor),'governor key differs from policy pin');
  const scoreDigest=compileScore(scoreSource).irDigest;
  fs.mkdirSync(directory,{recursive:true,mode:0o700});
  const identity={scoreDigest,governorKey:keyOf(governorPublicKey),controllerKey:keyOf(controllerPublicKey),witnessKey:keyOf(witnessPublicKey),pins};
  const idFile=path.join(directory,'enrolment.json');
  if(fs.existsSync(idFile))requireThat(canonical(JSON.parse(fs.readFileSync(idFile,'utf8')))===canonical(identity),'enrolment cannot be modified');
  else writeDurable(idFile,identity,true);
  const stateFile=path.join(directory,'checkpoint.json');
  const initial=()=>({sequence:0,ledgerText:'',executionText:'',witnessText:'',lastHead:null,lastKind:null,usedNonces:[],governedActivationHeads:[]});
  const load=()=>fs.existsSync(stateFile)?JSON.parse(fs.readFileSync(stateFile,'utf8')):initial();
  const serve=(res,code,obj)=>{const body=JSON.stringify(obj);res.writeHead(code,{'content-type':'application/json','cache-control':'no-store','content-length':Buffer.byteLength(body)});res.end(body);};
  let busy=false;
  const server=https.createServer({key:serverKey,cert:serverCert,ca:clientCa,requestCert:true,rejectUnauthorized:true,minVersion:'TLSv1.2'},(req,res)=>{
    if(!req.socket.authorized||certDigest(req.socket.getPeerCertificate(true).raw)!==clientFingerprint)return serve(res,403,{error:'client certificate not enrolled'});
    if(req.url==='/v1/status'&&req.method==='GET'){
      const state=load();const payload={schema:'octolang.governance-status.v2.7',sequence:state.sequence,lastHead:state.lastHead,lastKind:state.lastKind,scoreDigest};
      return serve(res,200,{payload,signature:sign(payload,governorPrivateKey,RECEIPT)});
    }
    if(req.method!=='POST'||!['/v1/activate','/v1/pre-effect'].includes(req.url))return serve(res,404,{error:'not found'});
    let data='',tooLarge=false;
    req.on('data',chunk=>{data+=chunk;if(data.length>4*1024*1024){tooLarge=true;req.destroy();}});
    req.on('end',()=>{
      if(tooLarge)return;
      if(busy)return serve(res,409,{error:'concurrent governance decision'});
      busy=true;
      try{
        const m=JSON.parse(data),p=m.payload;
        requireThat(p?.schema==='octolang.governance-request.v2.7'&&p.action===(req.url==='/v1/activate'?'ACTIVATE':'PRE_EFFECT'), 'request schema or action mismatch');
        requireThat(typeof p.nonce==='string'&&/^[0-9a-f]{32}$/.test(p.nonce)&&Number.isSafeInteger(p.issuedAt)&&Number.isSafeInteger(p.expiresAt)&&
          p.issuedAt<=now()+30000&&now()<p.expiresAt&&p.expiresAt-p.issuedAt<=60000,'expired request');
        requireThat(signatureOk(p,m.signature,controllerPublicKey),'controller signature rejected');
        const s=load();requireThat(!s.usedNonces.includes(p.nonce),'replayed governance request');
        const b=p.bundle;requireThat(b&&Object.values(b).every(x=>typeof x==='string')&&Object.values(b).reduce((n,v)=>n+v.length,0)<3500000,'oversized/invalid signed history');
        // The governor is a monotonic, externally durable history witness. Restoring an older
        // locally signed ledger+seal cannot override a newer previously enrolled state.
        requireThat(b.ledgerText.startsWith(s.ledgerText)&&b.executionText.startsWith(s.executionText)&&b.witnessText.startsWith(s.witnessText),'history rollback or fork');
        const checked=materialize(b,scoreSource,pins,witnessPublicKey);
        requireThat(checked.ledger.state.scoreDigest===scoreDigest,'different governed score');
        let result,kind;
        if(p.action==='ACTIVATE'){
          requireThat(checked.execution.sequence===0&&checked.witness.sequence===0,'activation not in initial state');
          requireThat(!s.governedActivationHeads.includes(checked.ledger.state.head),'activation already issued for this head');
          const r=p.revision;
          requireThat(r&&verifyReviewedRevision({scoreSource,scoreArtifact:compileScore(scoreSource),...r,pins,now:now()}).valid,
            'revision review or observation rejected');
          const activation=makeActivation({schema:'octolang.activation.v2.2',scoreDigest,revisionDigest:r.revisionArtifact.irDigest,
            expectedHead:checked.ledger.state.head,expectedSequence:checked.ledger.state.sequence+1,
            issuedAt:new Date(now()).toISOString(),expiresAt:new Date(now()+120000).toISOString(),decision:'ACTIVATE_LIMITS_ONLY'},governorPrivateKey);
          result={activation};kind='ACTIVATE';s.governedActivationHeads.push(checked.ledger.state.head);
        }else{
          const l=checked.ledger.state,e=checked.execution,w=checked.witness;
          requireThat(e.sequence>0&&e.events[e.events.length-1].kind==='START','pre-effect requires a signed START');
          requireThat(w.sequence>0&&w.snapshot.scoreDigest===scoreDigest&&w.snapshot.ledgerHead===l.head&&w.snapshot.ledgerSequence===l.sequence&&
            w.snapshot.executionHead===e.head&&w.snapshot.executionSequence===e.sequence,'signed witness and execution histories disagree');
          const starts=Object.values(e.actions).filter(a=>a.status==='IN_PROGRESS');
          requireThat(starts.length===1&&starts[0].start.reservationHead===l.head,'exactly one current reservation required');
          result={granted:true,ledgerHead:l.head,executionHead:e.head,witnessHead:w.head};kind='PRE_EFFECT';
        }
        s.sequence++;s.ledgerText=b.ledgerText;s.executionText=b.executionText;s.witnessText=b.witnessText;s.lastKind=kind;s.lastHead=hash(canonical({ledgerHead:checked.ledger.state.head,executionHead:checked.execution.head,witnessHead:checked.witness.head,sequence:s.sequence}));
        s.usedNonces.push(p.nonce);requireThat(s.usedNonces.length<=20000,'nonce state exceeds pilot limit');
        const receipt={schema:'octolang.governance-receipt.v2.7',action:kind,nonce:p.nonce,sequence:s.sequence,head:s.lastHead,scoreDigest,approvedAt:new Date(now()).toISOString(),...result};
        writeDurable(stateFile,s);
        serve(res,200,{payload:receipt,signature:sign(receipt,governorPrivateKey,RECEIPT)});
      }catch(e){serve(res,409,{error:e.message});}finally{busy=false;}
    });
  });
  return {start:()=>new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,()=>{server.off('error',reject);resolve(server.address());});}),close:()=>new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()))};
}
class GovernanceClient{
  constructor({url,cert,key,ca,pinnedServerFingerprint,controllerPrivateKey,controllerPublicKey,governorPublicKey,scoreDigest}){
    requireThat(keyOf(controllerPrivateKey)===keyOf(controllerPublicKey),'controller private key mismatch');
    this.url=url;this.cert=cert;this.key=key;this.ca=ca;this.pin=pinnedServerFingerprint;this.keySigner=controllerPrivateKey;
    this.governorPublicKey=governorPublicKey;this.scoreDigest=scoreDigest;
  }
  async request(action,bundle,revision){const payload={schema:'octolang.governance-request.v2.7',action,
    nonce:crypto.randomBytes(16).toString('hex'),issuedAt:Date.now(),expiresAt:Date.now()+30000,bundle};
    if(revision)payload.revision=revision;
    const route=action==='ACTIVATE'?'v1/activate':'v1/pre-effect';
    const result=await fetchJSON({url:new URL(route,this.url).toString(),cert:this.cert,key:this.key,ca:this.ca,pinnedServerFingerprint:this.pin,
      method:'POST',body:{payload,signature:sign(payload,this.keySigner)}});
    requireThat(result.payload?.nonce===payload.nonce&&result.payload?.action===action&&result.payload.scoreDigest===this.scoreDigest&&
      signatureOk(result.payload,result.signature,this.governorPublicKey,RECEIPT),'invalid governor receipt signature');
    return result.payload;
  }
  activate(bundle,revision){return this.request('ACTIVATE',bundle,revision);}
  preEffect(bundle){return this.request('PRE_EFFECT',bundle);}
  async status(){const r=await fetchJSON({url:new URL('v1/status',this.url).toString(),cert:this.cert,key:this.key,ca:this.ca,pinnedServerFingerprint:this.pin});
    requireThat(signatureOk(r.payload,r.signature,this.governorPublicKey,RECEIPT)&&r.payload.scoreDigest===this.scoreDigest,'governance status signature');return r.payload;}
}
module.exports={service,GovernanceClient,fileBundle,sign,signatureOk,materialize};
