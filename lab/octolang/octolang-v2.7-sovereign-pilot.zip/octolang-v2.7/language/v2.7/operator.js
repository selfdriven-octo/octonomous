'use strict';
/** Public-key-only cross-host identity check. Requires client TLS material but no
 * governance/witness private signing key. Never authorises execution. */
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {fetchJSON}=require('../v2.4/remote');
const {verifyWitness}=require('../v2.3/witness');
const {signatureOk}=require('./governance');
const read=p=>fs.readFileSync(p);
async function check(config){
  const g=config.governance,w=config.witness;
  if(!g||!w||!config.scoreDigest)throw Error('governance, witness and scoreDigest required');
  const connection=part=>({cert:read(part.clientCert),key:read(part.clientKey),ca:read(part.ca),pinnedServerFingerprint:part.serverFingerprint});
  const res=await fetchJSON({url:new URL('v1/status',g.url).toString(),...connection(g)});
  if(!signatureOk(res.payload,res.signature,read(g.governorPublicKey),'OctoLang v2.7 Governance Receipt\n')||res.payload.scoreDigest!==config.scoreDigest)
    throw Error('governance signed status invalid');
  const witness=await fetchJSON({url:new URL('v1/status',w.url).toString(),...connection(w)});
  if(witness.schema!=='octolang.witness-history.v2.4'||typeof witness.records!=='string')throw Error('unexpected witness history');
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-v27-remote-check-'));
  try{
    if(witness.records)fs.writeFileSync(path.join(temp,'checkpoints.jsonl'),witness.records);
    const verified=verifyWitness({directory:temp,publicKey:read(w.witnessPublicKey)});
    if(!verified.valid)throw Error(verified.reason);
    if(verified.snapshot&&verified.snapshot.scoreDigest!==config.scoreDigest)throw Error('witness score mismatch');
    return {governance:{verified:true,sequence:res.payload.sequence,head:res.payload.lastHead},
      witness:{verified:true,sequence:verified.sequence,head:verified.head},
      executionAuthorised:false,physicalSeparation:'operator must verify'};
  }finally{fs.rmSync(temp,{force:true,recursive:true});}
}
if(require.main===module){const f=process.argv[2];if(!f)throw Error('Usage: node language/v2.7/operator.js CONNECTIVITY_CONFIG_JSON');
  check(JSON.parse(fs.readFileSync(f,'utf8'))).then(x=>console.log(JSON.stringify(x,null,2))).catch(e=>{console.error(e.message);process.exitCode=1;});}
module.exports={check};
