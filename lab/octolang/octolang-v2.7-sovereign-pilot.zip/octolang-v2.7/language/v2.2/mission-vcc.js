'use strict';
/** Bridge: compile native mission and run existing deterministic mission preflight.
 * This signs a bounded VCC reservation decision, NOT an execution receipt.
 * The actual tool runner must independently recheck authority immediately before effects.
 */
const {canonical}=require('../../src/canonical');
const {compileMission,planMission}=require('../../src/mission');
const {parseScore,compileScore,verifyScore}=require('../v2.1');
const {makeVccDecision,hash}=require('./index');
function decisionFromMission({scoreSource,scoreArtifact,binding,units,activeRevisionDigest=null,
  missionParams,vccPrivateKey,now=Date.now()}){
  const score=scoreArtifact||compileScore(scoreSource);
  if(!verifyScore(scoreSource,score).valid)throw Error('invalid native score');
  const compiled=compileMission(parseScore(scoreSource).layers.mission);
  if(canonical(compiled)!==canonical(missionParams?.mission))throw Error('mission does not match native score');
  const b=score.ir.bindings.find(x=>x.name===binding);
  if(!b)throw Error('undeclared score binding');
  if(!Number.isSafeInteger(units)||units<1||units>b.budgetUnitsPerRun)throw Error('invalid amount for binding');
  const task=compiled.tasks.find(x=>x.label===b.task),role=compiled.roles.find(x=>x.label===b.role);
  if(!task||!role||task.role!==role.label||role.capability!==b.capability)throw Error('score mission role binding mismatch');
  const result=planMission({...missionParams,now});
  if(result.status!=='READY_FOR_SIMULATION')throw Error('VCC preflight rejected: '+result.reason);
  if(!result.plan.steps.some(x=>x.label===b.task&&x.role===b.role))throw Error('task not in verified plan');
  const req=missionParams.request;
  const request={scoreDigest:score.irDigest,activeRevisionDigest,binding:b.name,task:b.task,capability:b.capability,
    effect:b.effect,units,nonce:req.nonce,target:req.subject,contextRoot:result.plan.contextRoot};
  const date=ms=>new Date(ms).toISOString();
  const vccReceipt=makeVccDecision({schema:'octolang.vcc-decision.v2.2',
    requestDigest:hash('OctoLang v2.2 Request\n'+canonical(request)),decision:'ALLOW',
    issuedAt:date(now),expiresAt:date(now+60000)},vccPrivateKey);
  return {request,vccReceipt,planDigest:result.plan.digest};
}
module.exports={decisionFromMission};
