'use strict';
/**
 * OctoLang v2.2 bounded activation + lifetime reservation ledger.
 * Experimental local VCC admission bridge. No tool execution, keys or funds here.
 * All changes persist as individually signed, hash-linked append-only records.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {canonical} = require('../../src/canonical');
const {compileScore,verifyScore,sha}=require('../v2.1');
const {verifyReviewedRevision}=require('../v2.1/refinement');
const PREFIX='OctoLang v2.2 Ledger Event\n';
const ACT='OctoLang v2.2 Governance Activation\n';
const VCC='OctoLang v2.2 VCC Decision\n';
const HEX=/^[0-9a-f]{64}$/;
const ID=/^[A-Za-z_][A-Za-z0-9_-]*$/;
const ISO=/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/;
const err=msg=>{throw new Error('OctoLang v2.2: '+msg);};
const check=(test,msg)=>{if(!test)err(msg);};
const fields=(o,ks)=>o&&typeof o==='object'&&!Array.isArray(o)&&Object.getPrototypeOf(o)===Object.prototype&&Object.keys(o).length===ks.length&&ks.every(k=>Object.hasOwn(o,k));
const hash=x=>sha(x);
function publicKey(key){const k=key?.type==='public'?key:crypto.createPublicKey(key);check(k.asymmetricKeyType==='ed25519','Ed25519 key required');return k;}
function pem(key){return publicKey(key).export({format:'pem',type:'spki'}).toString();}
function keyId(key){return crypto.createHash('sha256').update(publicKey(key).export({format:'der',type:'spki'})).digest('hex');}
function sign(payload,key,prefix){return {payload,signature:crypto.sign(null,Buffer.from(prefix+canonical(payload)),key).toString('base64')};}
function verify(s,key,prefix){try{if(!fields(s,['payload','signature'])||typeof s.signature!=='string')return false;const b=Buffer.from(s.signature,'base64');return b.length===64&&b.toString('base64')===s.signature&&crypto.verify(null,Buffer.from(prefix+canonical(s.payload)),publicKey(key),b);}catch{return false;}}
function timeRange(start,end,now,maxMs=86400000){check(ISO.test(start)&&ISO.test(end),'ISO UTC millisecond times required');const a=Date.parse(start),b=Date.parse(end);check(Number.isFinite(a)&&Number.isFinite(b)&&b>a&&b-a<=maxMs,'invalid signature time range');check(a<=now+30000&&now<b,'signature expired or premature');}
function keysValid(pins){check(fields(pins,['observer','reviewer','governor','vcc','controller']),'exact role public-key pins required');const ids=Object.values(pins).map(keyId);check(new Set(ids).size===ids.length,'role keys must be distinct');}
function checkActivation(s,pins,scoreDigest,revisionDigest,head,nextSequence,now){
  check(verify(s,pins.governor,ACT),'activation governance signature invalid');
  const p=s.payload;
  check(fields(p,['schema','scoreDigest','revisionDigest','expectedHead','expectedSequence','issuedAt','expiresAt','decision']),'activation shape');
  check(p.schema==='octolang.activation.v2.2'&&p.decision==='ACTIVATE_LIMITS_ONLY','activation scope mismatch');
  check(p.scoreDigest===scoreDigest&&p.revisionDigest===revisionDigest&&p.expectedHead===head&&p.expectedSequence===nextSequence,'stale/wrong activation target');
  timeRange(p.issuedAt,p.expiresAt,now);
}
function makeActivation(payload,key){return sign(payload,key,ACT);}
function makeVccDecision(payload,key){return sign(payload,key,VCC);}
function bindingMap(list){return new Map(list.map(b=>[b.name,b]));}
function limited(b,previous,used){
  const orig=previous.get(b.name);
  check(orig,'unknown binding');
  check(b.role===orig.role&&b.task===orig.task&&b.capability===orig.capability&&b.effect===orig.effect&&b.node===orig.node,'binding authority changed');
  check(Number.isSafeInteger(b.runs)&&b.runs>=1&&b.runs<=orig.runs,'runs increased');
  check(Number.isSafeInteger(b.budgetUnitsPerRun)&&b.budgetUnitsPerRun>=0&&b.budgetUnitsPerRun<=orig.budgetUnitsPerRun,'budget increased');
  check(b.worstCaseBudget===b.runs*b.budgetUnitsPerRun,'invalid total bound');
  const spent=used[b.name]??{runs:0,units:0};
  check(spent.runs<=b.runs&&spent.units<=b.worstCaseBudget,'revision below already consumed limits');
}
function newState(score){return {scoreDigest:score.irDigest,head:null,sequence:0,lastAt:null,activeRevisionDigest:null,activeBindings:structuredClone(score.ir.bindings),used:Object.fromEntries(score.ir.bindings.map(x=>[x.name,{runs:0,units:0}])),nonces:[]};}
function stateView(s){return {scoreDigest:s.scoreDigest,head:s.head,sequence:s.sequence,lastAt:s.lastAt,activeRevisionDigest:s.activeRevisionDigest,activeBindings:structuredClone(s.activeBindings),used:structuredClone(s.used),nonces:structuredClone(s.nonces)};}
function nextState(current,event,params){
  const {scoreSource,scoreArtifact,pins}=params;
  const s=structuredClone(current), p=event.payload,now=Date.parse(p.at);
  check(ISO.test(p.at)&&Number.isFinite(now),'bad event timestamp');
  check(!s.lastAt||now>=Date.parse(s.lastAt),'journal timestamp moved backwards');
  check(event.sequence===s.sequence+1&&event.previous===s.head,'journal sequence/link incorrect');
  if(event.kind==='GENESIS'){
    check(s.sequence===0&&fields(p,['at','scoreDigest'])&&p.scoreDigest===scoreArtifact.irDigest,'invalid genesis');
  }else if(event.kind==='ACTIVATE'){
    check(fields(p,['at','revisionSource','revisionArtifact','observation','review','activation']),'activation payload shape');
    check(s.sequence>0,'not initialised');
    const verified=verifyReviewedRevision({scoreSource,scoreArtifact,revisionSource:p.revisionSource,revisionArtifact:p.revisionArtifact,
      observation:p.observation,review:p.review,pins,now});
    check(verified.valid,'unreviewed revision: '+verified.reason);
    checkActivation(p.activation,pins,s.scoreDigest,p.revisionArtifact.irDigest,s.head,s.sequence+1,now);
    check(p.revisionArtifact.ir.effectiveBindings.length===s.activeBindings.length,'bindings missing');
    const old=bindingMap(s.activeBindings);
    for(const b of p.revisionArtifact.ir.effectiveBindings) limited(b,old,s.used);
    check(p.revisionArtifact.ir.worstCaseBudgetUnits<=s.activeBindings.reduce((n,b)=>n+b.worstCaseBudget,0),'total budget widened');
    check(p.revisionArtifact.irDigest!==s.activeRevisionDigest,'already active');
    check(p.revisionArtifact.ir.effectiveBindings.some(b=>b.runs<old.get(b.name).runs||b.budgetUnitsPerRun<old.get(b.name).budgetUnitsPerRun),'must tighten current limits');
    s.activeBindings=structuredClone(p.revisionArtifact.ir.effectiveBindings);
    s.activeRevisionDigest=p.revisionArtifact.irDigest;
  }else if(event.kind==='RESERVE'){
    check(fields(p,['at','request','vccReceipt']),'reservation payload shape');
    check(s.sequence>0,'not initialised');
    check(verify(p.vccReceipt,pins.vcc,VCC),'VCC signature invalid');
    const r=p.request,d=p.vccReceipt.payload;
    check(fields(r,['scoreDigest','activeRevisionDigest','binding','task','capability','effect','units','nonce','target','contextRoot']),'request shape');
    check(fields(d,['schema','requestDigest','decision','issuedAt','expiresAt']),'VCC decision shape');
    check(d.schema==='octolang.vcc-decision.v2.2'&&d.decision==='ALLOW'&&d.requestDigest===hash('OctoLang v2.2 Request\n'+canonical(r)),'VCC decision not bound to request');
    timeRange(d.issuedAt,d.expiresAt,now,300000);
    check(r.scoreDigest===s.scoreDigest&&r.activeRevisionDigest===s.activeRevisionDigest,'stale active revision');
    check(ID.test(r.binding)&&ID.test(r.task)&&typeof r.capability==='string'&&r.capability.length<=128,'invalid request identity');
    check(typeof r.effect==='string'&&typeof r.target==='string'&&r.target.length>0&&r.target.length<=256,'invalid effect target');
    check(HEX.test(r.contextRoot)&&typeof r.nonce==='string'&&/^[A-Za-z0-9_-]{16,128}$/.test(r.nonce),'nonce or context invalid');
    check(Number.isSafeInteger(r.units)&&r.units>=1&&r.units<=1000000,'invalid units');
    check(!s.nonces.includes(r.nonce),'replayed reservation');
    const b=s.activeBindings.find(x=>x.name===r.binding);check(b,'binding missing');
    check(r.task===b.task&&r.capability===b.capability&&r.effect===b.effect,'VCC request exceeds binding');
    const used=s.used[r.binding];
    check(r.units<=b.budgetUnitsPerRun&&used.runs+1<=b.runs&&used.units+r.units<=b.worstCaseBudget,'cumulative run or budget limit exceeded');
    used.runs++;used.units+=r.units;s.nonces.push(r.nonce);
  }else err('unknown journal event type');
  s.sequence=event.sequence;s.lastAt=p.at;s.head=hash(PREFIX+canonical({sequence:event.sequence,previous:event.previous,kind:event.kind,payload:event.payload}));
  check(event.hash===s.head,'event hash invalid');
  return s;
}
/** Independent, read-only verification. Reject truncated, corrupted or forged audit journals. */
function verifyLedger({directory,scoreSource,pins}){
  try{
    keysValid(pins);
    const scoreArtifact=compileScore(scoreSource),v=verifyScore(scoreSource,scoreArtifact);
    check(v.valid,'invalid score source');
    let s=newState(scoreArtifact);
    const logfile=path.join(directory,'events.jsonl');
    const sealPath=path.join(directory,'state-seal.json');
    if(!fs.existsSync(logfile)){check(!fs.existsSync(sealPath),'ledger missing while seal remains');return {valid:true,initialised:false,state:stateView(s)};}
    const input=fs.readFileSync(logfile,'utf8');check(input.endsWith('\n'),'truncated journal tail');
    const lines=input.split('\n').filter(Boolean);check(lines.length<=100000,'journal too long');
    for(const line of lines){
      check(line.length<=1024*1024,'event too large');const entry=JSON.parse(line);
      check(fields(entry,['sequence','previous','kind','payload','hash','signature']),'journal entry shape');
      check(verify({payload:{sequence:entry.sequence,previous:entry.previous,kind:entry.kind,payload:entry.payload,hash:entry.hash},signature:entry.signature},pins.controller,PREFIX),'journal signature invalid');
      s=nextState(s,entry,{scoreSource,scoreArtifact,pins});
    }
    check(s.sequence>0,'empty ledger');
    check(fs.existsSync(sealPath),'signed head seal missing; reconciliation required');
    const seal=JSON.parse(fs.readFileSync(sealPath,'utf8'));
    check(verify(seal,pins.controller,'OctoLang v2.2 State Seal\n'),'invalid signed head seal');
    check(fields(seal.payload,['scoreDigest','head','sequence']),'head seal shape');
    check(seal.payload.scoreDigest===s.scoreDigest&&seal.payload.head===s.head&&seal.payload.sequence===s.sequence,'ledger rolled back or state seal mismatch');
    return {valid:true,initialised:true,state:stateView(s)};
  }catch(e){return {valid:false,reason:e.message};}
}
/** On first use this creates an EXCLUSIVE lock directory; stale locks fail closed. */
class ActivationGate {
  constructor({directory,scoreSource,pins,controllerPrivateKey,now=()=>Date.now()}){
    keysValid(pins);check(typeof directory==='string'&&path.isAbsolute(directory),'absolute data directory required');
    check(typeof scoreSource==='string'&&typeof controllerPrivateKey!=='undefined','source and controller signer required');
    check(keyId(crypto.createPublicKey(controllerPrivateKey))===keyId(pins.controller),'controller private key does not match pin');
    this.directory=directory;this.scoreSource=scoreSource;this.pins=pins;this.controllerPrivateKey=controllerPrivateKey;this.now=now;
    fs.mkdirSync(directory,{recursive:true,mode:0o700});
  }
  _lock(fn){
    const lock=path.join(this.directory,'.exclusive-lock');
    try{fs.mkdirSync(lock,{mode:0o700});}catch(e){err('ledger locked; manual recovery required: '+e.code);}
    try{return fn();}finally{fs.rmdirSync(lock);}
  }
  async _lockAsync(fn){
    const lock=path.join(this.directory,'.exclusive-lock');
    try{fs.mkdirSync(lock,{mode:0o700});}catch(e){err('ledger locked; manual recovery required: '+e.code);}
    try{return await fn();}finally{fs.rmdirSync(lock);}
  }
  _read(){const r=verifyLedger({directory:this.directory,scoreSource:this.scoreSource,pins:this.pins});check(r.valid,r.reason);return r;}
  _write(state,kind,payload){
    const entry={sequence:state.sequence+1,previous:state.head,kind,payload};
    entry.hash=hash(PREFIX+canonical(entry));
    const sig=sign({sequence:entry.sequence,previous:entry.previous,kind,payload,hash:entry.hash},this.controllerPrivateKey,PREFIX);
    entry.signature=sig.signature;
    const next=nextState(state,entry,{scoreSource:this.scoreSource,scoreArtifact:compileScore(this.scoreSource),pins:this.pins});
    const fd=fs.openSync(path.join(this.directory,'events.jsonl'),'a',0o600);
    try{const bytes=Buffer.from(JSON.stringify(entry)+'\n');let at=0;while(at<bytes.length)at+=fs.writeSync(fd,bytes,at,bytes.length-at);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
    const seal=sign({scoreDigest:next.scoreDigest,head:next.head,sequence:next.sequence},this.controllerPrivateKey,'OctoLang v2.2 State Seal\n');
    const tmp=path.join(this.directory,'.seal-'+crypto.randomUUID());
    try {fs.writeFileSync(tmp,JSON.stringify(seal)+'\n',{flag:'wx',mode:0o600});const sf=fs.openSync(tmp,'r');try{fs.fsyncSync(sf);}finally{fs.closeSync(sf);}fs.renameSync(tmp,path.join(this.directory,'state-seal.json'));const df=fs.openSync(this.directory,'r');try{fs.fsyncSync(df);}finally{fs.closeSync(df);}}
    finally {if(fs.existsSync(tmp))fs.unlinkSync(tmp);}
    return {head:next.head,sequence:next.sequence,activeRevisionDigest:next.activeRevisionDigest,used:next.used};
  }
  init(){return this._lock(()=>{const x=this._read();check(!x.initialised,'ledger already initialised');return this._write(x.state,'GENESIS',{at:new Date(this.now()).toISOString(),scoreDigest:x.state.scoreDigest});});}
  activate({revisionSource,revisionArtifact,observation,review,activation}){
    return this._lock(()=>{const x=this._read();check(x.initialised,'run init first');
      return this._write(x.state,'ACTIVATE',{at:new Date(this.now()).toISOString(),revisionSource,revisionArtifact,observation,review,activation});});
  }
  reserve({request,vccReceipt}){
    return this._lock(()=>{const x=this._read();check(x.initialised,'run init first');
      return this._write(x.state,'RESERVE',{at:new Date(this.now()).toISOString(),request,vccReceipt});});
  }
  status(){return this._read();}
}
module.exports={ActivationGate,verifyLedger,makeActivation,makeVccDecision,hash,ACT,VCC};
