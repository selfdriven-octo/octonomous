'use strict';
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {compileScore,sha}=require('../v2.1');
const {OBS_SCHEMA,REVIEW_SCHEMA,digestObservation,compileRevision,createObservation,createReview}=require('../v2.1/refinement');
const {ActivationGate,verifyLedger,makeActivation}=require('./index');
const {decisionFromMission}=require('./mission-vcc');
const {compileMission}=require('../../src/mission');
const {parseScore}=require('../v2.1');
const {fixtures}=require('../../mission/demo');
function demo(){
  const scoreSource=fs.readFileSync(path.join(__dirname,'../../community-score.octo'),'utf8'),score=compileScore(scoreSource);
  const key=()=>crypto.generateKeyPairSync('ed25519');
  const actors=Object.fromEntries(['observer','reviewer','governor','vcc','controller'].map(x=>[x,key()]));
  const pins=Object.fromEntries(Object.entries(actors).map(([name,k])=>[name,k.publicKey.export({format:'pem',type:'spki'}).toString()]));
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-activation-demo-'));
  const now=Date.now(),iso=ms=>new Date(ms).toISOString();
  const params={directory,scoreSource,pins,controllerPrivateKey:actors.controller.privateKey,now:()=>now};
  const gate=new ActivationGate(params);gate.init();
  const observationPayload={schema:OBS_SCHEMA,scoreDigest:score.irDigest,metric:'cost-per-run',value:4,
    unit:'budget-units',sampleDigest:sha('synthetic cost observation'),observedAt:iso(now-60000),validUntil:iso(now+3600000),kind:'OBSERVATION'};
  const observation=createObservation(observationPayload,actors.observer.privateKey);
  const revisionSource=`revision lean_supplies { base "${score.irDigest}" evidence "${digestObservation(observationPayload)}" trigger "cost-per-run" above 3 tune scout_node runs 1 budget 1 }`;
  const revisionArtifact=compileRevision(revisionSource,score);
  const review=createReview({schema:REVIEW_SCHEMA,scoreDigest:score.irDigest,revisionDigest:revisionArtifact.irDigest,
    evidenceDigest:digestObservation(observationPayload),reviewedAt:iso(now),validUntil:iso(now+300000),decision:'APPROVE_PROPOSAL_ONLY'},actors.reviewer.privateKey);
  const before=gate.status().state;
  const activation=makeActivation({schema:'octolang.activation.v2.2',scoreDigest:score.irDigest,revisionDigest:revisionArtifact.irDigest,
    expectedHead:before.head,expectedSequence:before.sequence+1,issuedAt:iso(now),expiresAt:iso(now+300000),decision:'ACTIVATE_LIMITS_ONLY'},actors.governor.privateKey);
  gate.activate({revisionSource,revisionArtifact,observation,review,activation});
  const mission=compileMission(parseScore(scoreSource).layers.mission);
  const f=fixtures(mission,{subject:'supplier-42',inputs:{amount:'75',priority:'3',project:'School learning project',note:'Evidence note',urgent:false},now});
  const decision=decisionFromMission({scoreSource,scoreArtifact:score,binding:'intent_node',units:2,
    activeRevisionDigest:revisionArtifact.irDigest,missionParams:{mission,request:f.request,review:f.review,claims:f.claims,grants:f.grants,trust:f.trust},
    vccPrivateKey:actors.vcc.privateKey,now});
  gate.reserve(decision);
  const reopened=new ActivationGate(params),checked=verifyLedger({directory,scoreSource,pins});
  if(!checked.valid)throw Error(checked.reason);
  const state=reopened.status().state;
  console.log(JSON.stringify({status:'VERIFIED_LOCAL_ADMISSION_ONLY',scoreDigest:score.irDigest,activeRevisionDigest:state.activeRevisionDigest,
    originalWorstCaseBudget:score.ir.worstCaseBudgetUnits,activeWorstCaseBudget:state.activeBindings.reduce((n,b)=>n+b.worstCaseBudget,0),
    reservedUnits:state.used.intent_node.units,sequence:state.sequence,head:state.head,
    journal:directory,independentlyVerified:checked.valid,externalActions:0},null,2));
  return {directory,state};
}
if(require.main===module)try{demo();}catch(e){console.error(e.stack);process.exitCode=1;}
module.exports={demo};
