'use strict';
/**
 * Refinements are NON-EXECUTABLE signed PROPOSALS. A revision may only tighten
 * runs/budget of existing, reviewed bindings. Independent observer & reviewer
 * signatures are mandatory to label it as a reviewed evidence-based revision.
 */
const crypto=require('node:crypto');
const {canonical}=require('../../src/canonical');
const {compileScore,verifyScore,sha}=require('./index');
const REF_SCHEMA='octolang.refinement-ir.v2.1';
const OBS_SCHEMA='octolang.refinement-observation.v2.1';
const REVIEW_SCHEMA='octolang.refinement-review.v2.1';
const REF_PREFIX='OctoLang Refinement IR v2.1\n';
const OBS_PREFIX='OctoLang Refinement Observation v2.1\n';
const REVIEW_PREFIX='OctoLang Refinement Review v2.1\n';
const HEX=/^[0-9a-f]{64}$/;
const ID=/^[A-Za-z_][A-Za-z0-9_-]*$/;
const bad=x=>{throw new Error('OctoLang refinement: '+x);};
const need=(x,y)=>{if(!x)bad(y);};
const exact=(a,fields)=>a&&typeof a==='object'&&!Array.isArray(a)&&
  Object.getPrototypeOf(a)===Object.prototype&&Object.keys(a).length===fields.length&&fields.every(x=>Object.hasOwn(a,x));
function parseRevision(source){
  need(typeof source==='string'&&source.length<=8192,'revision source size');
  const raw=source.replace(/#[^\n]*|\/\/[^\n]*/g,' ').trim();
  const matcher=/"(?:\\["\\nrt]|[^"\\\n\r])*"|[A-Za-z_][A-Za-z0-9_-]*|(?:0|[1-9][0-9]*)|[{}]/gy;
  const t=[];let at=0;
  while(at<raw.length){if(/\s/.test(raw[at])){at++;continue;}matcher.lastIndex=at;const m=matcher.exec(raw);need(m&&m.index===at,`invalid token at ${at}`);t.push(m[0]);at=matcher.lastIndex;need(t.length<160,'too many revision tokens');}
  let p=0;const pop=k=>{const v=t[p++];need(v!==undefined,'unexpected EOF');if(k!==undefined)need(v===k,`expected ${k}, got ${v}`);return v;};
  const identifier=()=>{const x=pop();need(ID.test(x),'invalid identifier');return x;};
  const string=()=>{const x=pop();need(x.startsWith('"'),'expected quoted string');const s=JSON.parse(x);need(s.length<=256,'string length');return s;};
  const number=()=>{const x=pop();need(/^(0|[1-9][0-9]{0,6})$/.test(x),'invalid number');return Number(x);};
  pop('revision');const name=identifier();pop('{');
  const properties={},tunes=[];
  while(t[p]!=='}'){
    need(p<t.length,'unterminated revision');const k=identifier();
    if(k==='tune'){
      const binding=identifier();pop('runs');const runs=number();pop('budget');const budget=number();
      need(!tunes.some(x=>x.binding===binding),'duplicate tune');tunes.push({binding,runs,budget});
    }else{
      need(['base','evidence','trigger'].includes(k),'unknown revision field '+k);
      need(!Object.hasOwn(properties,k),'duplicate revision field '+k);
      if(k==='trigger'){const metric=string();pop('above');properties.trigger={metric,threshold:number()};}
      else properties[k]=string();
    }
  }
  pop('}');need(p===t.length,'trailing revision tokens');
  need(HEX.test(properties.base)&&HEX.test(properties.evidence),'base and evidence must be 64 hex');
  need(properties.trigger&&/^[A-Za-z][A-Za-z0-9_-]{0,63}$/.test(properties.trigger.metric),'metric required');
  need(tunes.length>0&&tunes.length<=64,'tune count');
  return {name,baseDigest:properties.base,evidenceDigest:properties.evidence,trigger:properties.trigger,tunes};
}
const digestRevision=ir=>sha(REF_PREFIX+canonical(ir));
const digestObservation=payload=>sha(OBS_PREFIX+canonical(payload));
function compileRevision(source,scoreArtifact){
  need(scoreArtifact?.ir?.schema==='octolang.score-ir.v2.1','v2.1 score required');
  const p=parseRevision(source);
  need(p.baseDigest===scoreArtifact.irDigest,'base digest mismatch');
  need(scoreArtifact.irDigest===require('./index').digestScore(scoreArtifact.ir),'invalid base IR digest');
  const current=new Map(scoreArtifact.ir.bindings.map(x=>[x.name,x]));
  let reduced=false;
  const changes=p.tunes.map(x=>{
    const b=current.get(x.binding);need(!!b,'unknown binding '+x.binding);
    need(x.runs>=1&&x.runs<=b.runs&&x.budget<=b.budgetUnitsPerRun,'revision widens mandate');
    need(x.budget>=0,'negative budget');
    if(x.runs<b.runs||x.budget<b.budgetUnitsPerRun)reduced=true;
    return {...x,originalRuns:b.runs,originalBudget:b.budgetUnitsPerRun};
  }).sort((a,b)=>(a.binding<b.binding?-1:a.binding>b.binding?1:0));
  need(reduced,'revision must tighten at least one limit');
  const reductions=new Map(changes.map(x=>[x.binding,x]));
  const effectiveBindings=scoreArtifact.ir.bindings.map(b=>{
    const c=reductions.get(b.name);if(!c)return b;
    return {...b,runs:c.runs,budgetUnitsPerRun:c.budget,worstCaseBudget:c.runs*c.budget};
  });
  const worstCaseBudgetUnits=effectiveBindings.reduce((sum,b)=>sum+b.worstCaseBudget,0);
  need(worstCaseBudgetUnits<=scoreArtifact.ir.worstCaseBudgetUnits,'budget widened');
  const ir={schema:REF_SCHEMA,kind:'bounded-refinement',name:p.name,
    baseDigest:p.baseDigest,evidenceDigest:p.evidenceDigest,trigger:p.trigger,
    changes,effectiveBindings,worstCaseBudgetUnits,
    governance:{grantsImplied:false,executionAllowed:false,decision:'EVIDENCE_BASED_PROPOSAL_ONLY'}};
  return {schema:'octolang.refinement-artifact.v2.1',sourceSha256:sha(source),ir,irDigest:digestRevision(ir)};
}
function verifyRevision(source,scoreSource,scoreArtifact,revisionArtifact){
  try{
    const base=verifyScore(scoreSource,scoreArtifact);
    need(base.valid,base.reason);
    const expected=compileRevision(source,scoreArtifact);
    need(digestRevision(revisionArtifact.ir)===revisionArtifact.irDigest,'revision digest mismatch');
    need(canonical(revisionArtifact)===canonical(expected),'revised artifact not reproducible');
    return {valid:true,irDigest:expected.irDigest};
  }catch(e){return {valid:false,reason:e.message};}
}
function checkTime(observed,valid,now){
  need(typeof observed==='string'&&typeof valid==='string'&& /^\d{4}-\d\d-\d\dT/.test(observed)&&/^\d{4}-\d\d-\d\dT/.test(valid),'ISO times required');
  const o=Date.parse(observed),v=Date.parse(valid);
  need(Number.isFinite(o)&&Number.isFinite(v)&&Number.isFinite(now)&&v>o&&v-o<=30*86400000,'invalid bounded validity period');
  need(o<=now+30000&&now<v,'statement outside validity window');
}
function observePayload(input){
  need(exact(input,['schema','scoreDigest','metric','value','unit','sampleDigest','observedAt','validUntil','kind']), 'observation payload shape');
  need(input.schema===OBS_SCHEMA&&HEX.test(input.scoreDigest)&&HEX.test(input.sampleDigest),'invalid observation digest');
  need(/^[A-Za-z][A-Za-z0-9_-]{0,63}$/.test(input.metric)&&input.unit==='budget-units', 'invalid observation metric/unit');
  need(Number.isSafeInteger(input.value)&&input.value>=0&&input.value<=1000000,'invalid observation value');
  need(['OBSERVATION','OUTCOME'].includes(input.kind),'invalid observation kind');
  return input;
}
function signStatement(payload,privateKey,prefix){
  const signature=crypto.sign(null,Buffer.from(prefix+canonical(payload),'utf8'),privateKey).toString('base64');
  return {payload,signature};
}
function verifyStatement(statement,publicKey,prefix){
  try{
    need(exact(statement,['payload','signature']),'signed statement shape');
    const s=Buffer.from(statement.signature,'base64');
    need(s.length===64&&s.toString('base64')===statement.signature,'signature encoding');
    const key=crypto.createPublicKey(publicKey);
    need(key.asymmetricKeyType==='ed25519','expected Ed25519 key');
    return crypto.verify(null,Buffer.from(prefix+canonical(statement.payload),'utf8'),key,s);
  }catch{return false;}
}
function createObservation(input,privateKey){observePayload(input);return signStatement(input,privateKey,OBS_PREFIX);}
function createReview(input,privateKey){
  need(exact(input,['schema','scoreDigest','revisionDigest','evidenceDigest','reviewedAt','validUntil','decision']),'review shape');
  need(input.schema===REVIEW_SCHEMA&&input.decision==='APPROVE_PROPOSAL_ONLY','review semantics');
  for(const k of ['scoreDigest','revisionDigest','evidenceDigest'])need(HEX.test(input[k]),'bad '+k);
  return signStatement(input,privateKey,REVIEW_PREFIX);
}
function verifyReviewedRevision({scoreSource,scoreArtifact,revisionSource,revisionArtifact,observation,review,pins,now=Date.now()}){
  try{
    const rv=verifyRevision(revisionSource,scoreSource,scoreArtifact,revisionArtifact);
    need(rv.valid,rv.reason);
    need(pins&&typeof pins.observer==='string'&&typeof pins.reviewer==='string','observer and reviewer pins required');
    const keyBytes=s=>crypto.createPublicKey(s).export({format:'der',type:'spki'});
    need(!keyBytes(pins.observer).equals(keyBytes(pins.reviewer)),'observer and reviewer must be independent keys');
    need(verifyStatement(observation,pins.observer,OBS_PREFIX),'observer signature rejected');
    observePayload(observation.payload);
    const o=observation.payload,r=revisionArtifact.ir;
    need(o.scoreDigest===scoreArtifact.irDigest,'observation score mismatch');
    need(digestObservation(o)===r.evidenceDigest,'observation digest mismatch');
    need(o.metric===r.trigger.metric&&o.value>r.trigger.threshold,'observation does not satisfy refinement trigger');
    checkTime(o.observedAt,o.validUntil,now);
    need(verifyStatement(review,pins.reviewer,REVIEW_PREFIX),'reviewer signature rejected');
    const ap=review.payload;
    need(exact(ap,['schema','scoreDigest','revisionDigest','evidenceDigest','reviewedAt','validUntil','decision']),'review payload shape');
    need(ap.schema===REVIEW_SCHEMA&&ap.decision==='APPROVE_PROPOSAL_ONLY','review cannot grant execution');
    need(ap.scoreDigest===scoreArtifact.irDigest&&ap.revisionDigest===revisionArtifact.irDigest&&ap.evidenceDigest===r.evidenceDigest,'approval binds wrong proposal');
    checkTime(ap.reviewedAt,ap.validUntil,now);
    need(Date.parse(ap.reviewedAt)>=Date.parse(o.observedAt),'review predates evidence');
    return {valid:true,revisionDigest:revisionArtifact.irDigest,decision:'REVIEWED_PROPOSAL_NOT_EXECUTION_AUTHORITY'};
  }catch(e){return {valid:false,reason:e.message};}
}
module.exports={REF_SCHEMA,OBS_SCHEMA,REVIEW_SCHEMA,REF_PREFIX,OBS_PREFIX,REVIEW_PREFIX,
  parseRevision,compileRevision,verifyRevision,digestRevision,digestObservation,
  createObservation,createReview,verifyReviewedRevision,observePayload};
