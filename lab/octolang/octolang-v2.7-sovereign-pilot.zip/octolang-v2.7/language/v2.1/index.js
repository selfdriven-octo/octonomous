'use strict';
/**
 * Native OctoLang v2.1: source-only, strictly parsed, pure language pipeline.
 * One score contains all four established language dialects and inline modules.
 * It compiles through v2.0's linker; no permissions are granted.
 */
const crypto = require('node:crypto');
const {canonical} = require('../../src/canonical');
const v2 = require('../v2.0');
const {verifyIR:verifyLegacyIR} = require('../v2.0/validate');
const SCHEMA='octolang.score-ir.v2.1';
const ARTIFACT='octolang.score-artifact.v2.1';
const PREFIX='OctoLang Score IR v2.1\n';
const KINDS=['mission','composition','epistemic','assurance'];
const ID=/^[A-Za-z_][A-Za-z0-9_-]*$/;
const sha=x=>crypto.createHash('sha256').update(x,'utf8').digest('hex');
const fail=message=>{throw new Error('OctoLang v2.1: '+message);};
const requireThat=(yes,message)=>{if(!yes)fail(message);};
const cmp=(a,b)=>a<b?-1:a>b?1:0;
function tokens(source){
  requireThat(typeof source==='string'&&source.length<=262144,'score source must be text <= 262144 characters');
  const result=[];let cursor=0;
  while(cursor<source.length){
    const tail=source.slice(cursor),skip=tail.match(/^(?:\s+|#[^\n]*|\/\/[^\n]*)/);
    if(skip){cursor+=skip[0].length;continue;}
    const m=tail.match(/^(?:"(?:\\["\\nrt]|[^"\\\n\r])*"|[A-Za-z_][A-Za-z0-9_-]*|(?:0|[1-9][0-9]*)|[{}.,<>])/);
    requireThat(!!m,`unknown score token at ${cursor}`);
    result.push({v:m[0],start:cursor,end:cursor+m[0].length});
    cursor+=m[0].length;
    requireThat(result.length<=16000,'too many score tokens');
  }
  return result;
}
function parseScore(source){
  const ts=tokens(source);let pos=0;
  function pop(want){const o=ts[pos++];requireThat(!!o,'unexpected end of score');if(want!==undefined)requireThat(o.v===want,`expected ${want}, got ${o.v}`);return o;}
  function id(){const t=pop();requireThat(ID.test(t.v),'invalid identifier '+t.v);return t;}
  pop('score');const name=id().v;pop('{');
  const layers={},modules=[],bindings=[];
  function declaration(first,kind){
    id();
    if(kind==='bind'){pop('.');id();pop('as');id();}
    pop('{');let level=1;
    while(level){const t=pop();if(t.v==='{')level++;if(t.v==='}')level--;}
    return source.slice(first.start,ts[pos-1].end);
  }
  while(ts[pos]&&ts[pos].v!=='}'){
    const first=pop();const kind=first.v;
    requireThat([...KINDS,'module','bind'].includes(kind),'unknown score declaration '+kind);
    const body=declaration(first,kind);
    if(KINDS.includes(kind)){
      requireThat(!Object.hasOwn(layers,kind),'duplicate layer '+kind);layers[kind]=body;
    }else if(kind==='module')modules.push(body);
    else bindings.push(body);
    requireThat(modules.length<=32&&bindings.length<=64,'score too large');
  }
  pop('}');requireThat(pos===ts.length,'trailing score tokens');
  requireThat(KINDS.every(k=>Object.hasOwn(layers,k)),'four language layers required');
  requireThat(modules.length>0&&bindings.length>0,'module and bindings required');
  return {name,layers,modules,bindings};
}
function generateLegacySource(parsed){
  const files=Object.create(null);
  for(const kind of KINDS)files[`native/${kind}.octo`]=parsed.layers[kind];
  const programme=[`program ${parsed.name} {`,...KINDS.map(k=>`  ${k} "native/${k}.octo"`),...parsed.modules,...parsed.bindings,'}'].join('\n');
  return {programme,files};
}
function scoreIR(legacyIR){
  return {schema:SCHEMA,kind:'native-score',name:legacyIR.name,
    componentDigests:legacyIR.componentDigests,
    modules:legacyIR.modules,bindings:legacyIR.bindings,
    compositionSchedule:legacyIR.compositionSchedule,
    worstCaseBudgetUnits:legacyIR.worstCaseBudgetUnits,
    governance:{...legacyIR.governance}};
}
function digestScore(ir){return sha(PREFIX+canonical(ir));}
function compileScore(source){
  const parsed=parseScore(source),{programme,files}=generateLegacySource(parsed);
  const legacy=v2.compileProgram(programme,files);
  const r=verifyLegacyIR(legacy.ir,legacy.components,legacy.irDigest);
  requireThat(r.valid,'legacy linker rejected: '+r.reason);
  const ir=scoreIR(legacy.ir);
  return {schema:ARTIFACT,sourceSha256:sha(source),legacy,ir,irDigest:digestScore(ir)};
}
function verifyScore(source,artifact){
  try{
    requireThat(artifact&&typeof artifact==='object','artifact required');
    const expected=compileScore(source);
    const leg=verifyLegacyIR(artifact.legacy.ir,artifact.legacy.components,artifact.legacy.irDigest);
    requireThat(leg.valid,'legacy semantic verifier: '+leg.reason);
    requireThat(digestScore(artifact.ir)===artifact.irDigest,'score digest mismatch');
    requireThat(canonical(expected)===canonical(artifact),'score artifact differs from independently recompiled source');
    return {valid:true,irDigest:expected.irDigest};
  }catch(e){return {valid:false,reason:e.message};}
}
module.exports={SCHEMA,ARTIFACT,parseScore,generateLegacySource,scoreIR,digestScore,compileScore,verifyScore,sha};
