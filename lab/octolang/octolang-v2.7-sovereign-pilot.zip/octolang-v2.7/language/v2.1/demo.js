'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {compileScore,verifyScore,sha}=require('./index');
const {OBS_SCHEMA,REVIEW_SCHEMA,digestObservation,compileRevision,verifyReviewedRevision,createReview,createObservation}=require('./refinement');
function demo(){
  const scoreSource=fs.readFileSync(path.join(__dirname,'../../community-score.octo'),'utf8');
  const scoreArtifact=compileScore(scoreSource);
  if(!verifyScore(scoreSource,scoreArtifact).valid)throw new Error('score verification failed');
  const observer=crypto.generateKeyPairSync('ed25519'),reviewer=crypto.generateKeyPairSync('ed25519');
  const now=Date.now(),date=t=>new Date(t).toISOString();
  const payload={schema:OBS_SCHEMA,scoreDigest:scoreArtifact.irDigest,metric:'cost-per-run',value:4,unit:'budget-units',
    sampleDigest:sha('synthetic signed example measurement'),observedAt:date(now-60000),validUntil:date(now+3600000),kind:'OBSERVATION'};
  const observation=createObservation(payload,observer.privateKey);
  const revisionSource=`revision lean_supplies {\n  base "${scoreArtifact.irDigest}"\n  evidence "${digestObservation(payload)}"\n  trigger "cost-per-run" above 3\n  tune scout_node runs 1 budget 1\n}\n`;
  const revisionArtifact=compileRevision(revisionSource,scoreArtifact);
  const review=createReview({schema:REVIEW_SCHEMA,scoreDigest:scoreArtifact.irDigest,revisionDigest:revisionArtifact.irDigest,
    evidenceDigest:digestObservation(payload),reviewedAt:date(now),validUntil:date(now+1800000),decision:'APPROVE_PROPOSAL_ONLY'},reviewer.privateKey);
  const pins={observer:observer.publicKey.export({format:'pem',type:'spki'}).toString(),reviewer:reviewer.publicKey.export({format:'pem',type:'spki'}).toString()};
  const result=verifyReviewedRevision({scoreSource,scoreArtifact,revisionSource,revisionArtifact,observation,review,pins,now});
  if(!result.valid)throw new Error(result.reason);
  console.log(JSON.stringify({nativeScoreDigest:scoreArtifact.irDigest,originalBudget:scoreArtifact.ir.worstCaseBudgetUnits,
    revisionDigest:revisionArtifact.irDigest,proposedBudget:revisionArtifact.ir.worstCaseBudgetUnits,
    signedObservation:true,independentReview:true,decision:result.decision,executionOccurred:false},null,2));
  return {scoreSource,scoreArtifact,revisionSource,revisionArtifact,observation,review,pins,now};
}
if(require.main===module)demo();
module.exports={demo};
