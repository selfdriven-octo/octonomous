# OctoLang v2.1 — 21 October 2026

### Added

- Native, single-file `score` grammar hosting four existing language layers, inline modules and parameterised bindings.
- Canonical v2.1 score IR and domain-separated semantic digest, stable across comments and harmless top-level declaration reordering.
- Independent score verifier that recompiles source and validates constituent v2.0 semantics.
- Detached, narrow-only `revision` grammar for immutable score-bound refinement proposals.
- Metric-triggered signed observations and separate pinned Ed25519 human reviews.
- Anti-escalation, timestamp, tampering and signature-substitution tests.
- `octolang-score` CLI commands and synthetic local demo.
- 24 frozen v2.1 conformance vectors and 24 new automated language/security tests.

### Preserved

- All v2.0 and earlier language interfaces and source compatibility.
- Octonomous Runtime, federated demo, Studio and experimental Midnight adapters without changed authority.

### Not yet implemented

- Runtime activation and enforcement of revisions, cumulative spending across retries, on-chain ZK proofs for native scores or active AI optimisation loops.

### Assurance

Test totals are documented in `ACCEPTANCE-STATUS-v2.1.md`. Compiler success and signed review do **not** imply tool authority or factual correctness.
