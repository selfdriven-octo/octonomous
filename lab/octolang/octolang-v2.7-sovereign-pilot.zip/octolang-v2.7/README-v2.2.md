# OctoLang v2.2 — Verified Refinement Activation

**AI composes → Humans govern → Agents adapt → Evidence verifies.**

This release builds on v2.1's native scores and signed refinement proposals by adding a separately governed **activation** process and a durable, local **cumulative-resource reservation gate**. A reviewed proposal alone is insufficient to activate a score. An activation alone is insufficient to authorise a tool invocation.

## Quick start

Requires Node.js 22+ and only standard libraries for the new activation subsystem.

```bash
npm run activation:demo
npm run activation:test
npm run test:isolated
```

`activation:demo` creates ephemeral keys and a temporary local journal. It exercises the existing mission preflight, signed VCC decision, bounded reservation and independent auditor; it **does not run any external tool** or transfer funds.

### Read-only audit

```bash
node bin/octolang-activation.js verify community-score.octo pins.json /absolute/path/to/ledger
```

Do not include signing keys in `pins.json`. Public keys are separate from the independently held keys used to approve refinements, issue VCC decisions and sign ledger events.

### What's in v2.2

- `language/v2.2/index.js` — signed activation transitions, replay-safe budget admission and independent audit;
- `language/v2.2/mission-vcc.js` — bridge from the existing mission `planMission()` evaluator to the bounded VCC decision format;
- `language/v2.2/demo.js` — end-to-end local demonstration;
- `bin/octolang-activation.js` — independent read-only CLI;
- `test/language-v2.2.test.js` — signing, rollback, replay, cumulative-limit and mission-preflight tests;
- `docs/OCTOLANG-LANGUAGE-v2.2.md` — detailed state machine, trust model and limitations.

Earlier OctoLang language, Studio, Octonomous, federation and Midnight examples are retained. The v2.2 activation gate is **not yet wired into the browser Studio's real execution path**, and no claimed production use is implied.

**Safety boundary:** v2.2 supports durable authorisation *reservations*, not completed work or real-world proof of an outcome. Local signed logs can be rolled back together without an external checkpoint; see the specification before considering production use.
