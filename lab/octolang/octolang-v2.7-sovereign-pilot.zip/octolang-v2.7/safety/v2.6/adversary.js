'use strict';
/** Signature/ledger mutation probes against the REAL OctoLang v2.2 verifier.
 * This is adversarial testing, NOT a formal security proof or a pen test.
 * All changes occur in temporary, disposable ledger directories.
 */
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {compileScore,sha}=require('../../language/v2.1');
const {ActivationGate,verifyLedger,makeVccDecision,hash}=require('../../language/v2.2');
const {canonical}=require('../../src/canonical');
const scoreSource=fs.readFileSync(path.join(__dirname,'../../community-score.octo'),'utf8');
const score=compileScore(scoreSource);
const iso=x=>new Date(x).toISOString();
function makeFixture(){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'octolang-safety-'));
  const actors=Object.fromEntries(['observer','reviewer','governor','vcc','controller'].map(role=>[role,crypto.generateKeyPairSync('ed25519')]));
  const pins=Object.fromEntries(Object.entries(actors).map(([role,keys])=>[role,keys.publicKey.export({format:'pem',type:'spki'}).toString()]));
  const now=Date.UTC(2026,9,22,12);
  const directory=path.join(root,'baseline');fs.mkdirSync(directory);
  const gate=new ActivationGate({directory,scoreSource,pins,controllerPrivateKey:actors.controller.privateKey,now:()=>now});
  gate.init();
  const binding=score.ir.bindings.find(x=>x.name==='scout_node');
  if(!binding)throw Error('baseline fixture binding absent');
  const request={scoreDigest:score.irDigest,activeRevisionDigest:null,binding:binding.name,task:binding.task,
    capability:binding.capability,effect:binding.effect,units:1,nonce:'SAFETY_NONCE_00001',target:'supplier-42',contextRoot:sha('v2.6 synthetic signed context')};
  const vccReceipt=makeVccDecision({schema:'octolang.vcc-decision.v2.2',requestDigest:hash('OctoLang v2.2 Request\n'+canonical(request)),
    decision:'ALLOW',issuedAt:iso(now),expiresAt:iso(now+60000)},actors.vcc.privateKey);
  // Save genuine pre-effect snapshot to demonstrate simultaneous local rollback limits.
  const previousJournal=fs.readFileSync(path.join(directory,'events.jsonl')),
        previousSeal=fs.readFileSync(path.join(directory,'state-seal.json'));
  gate.reserve({request,vccReceipt});
  if(!verifyLedger({directory,scoreSource,pins}).valid)throw Error('baseline verification failed');
  return {root,directory,actors,pins,request,previousJournal,previousSeal};
}
function copyFixture(f,name){
  const dest=path.join(f.root,name);fs.mkdirSync(dest);
  for(const file of ['events.jsonl','state-seal.json'])fs.copyFileSync(path.join(f.directory,file),path.join(dest,file));
  return dest;
}
function random(seed){let x=(seed>>>0)||0x6d2b79f5;return ()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0);};}
const CHANGE_TYPES=['amount','nonce','decision','vcc-signature','event-signature','event-kind','event-sequence','event-link',
  'event-hash','score-digest','context-root','time','seal-signature','seal-head','tail'];
function mutate(dir,kind,n){
  const file=path.join(dir,'events.jsonl'),sealFile=path.join(dir,'state-seal.json');
  const lines=fs.readFileSync(file,'utf8').trimEnd().split('\n'),event=JSON.parse(lines[1]);
  if(kind==='tail'){fs.appendFileSync(file,'{"unexpected":');return;}
  if(kind==='seal-signature'||kind==='seal-head'){
    const s=JSON.parse(fs.readFileSync(sealFile));
    if(kind==='seal-head')s.payload.head='0'.repeat(64);else s.signature=Buffer.alloc(64,n%256).toString('base64');
    fs.writeFileSync(sealFile,JSON.stringify(s)+'\n');return;
  }
  switch(kind){
    case 'amount':event.payload.request.units=2+n;break;
    case 'nonce':event.payload.request.nonce='FORGED_NONCE_000'+n;break;
    case 'decision':event.payload.vccReceipt.payload.decision='DENY';break;
    case 'vcc-signature':event.payload.vccReceipt.signature=Buffer.alloc(64,n%256).toString('base64');break;
    case 'event-signature':event.signature=Buffer.alloc(64,n%256).toString('base64');break;
    case 'event-kind':event.kind='ACTIVATE';break;
    case 'event-sequence':event.sequence=99;break;
    case 'event-link':event.previous='b'.repeat(64);break;
    case 'event-hash':event.hash='d'.repeat(64);break;
    case 'score-digest':event.payload.request.scoreDigest='a'.repeat(64);break;
    case 'context-root':event.payload.request.contextRoot='f'.repeat(64);break;
    case 'time':event.payload.at='2020-01-01T00:00:00.000Z';break;
    default:throw Error('unknown mutation: '+kind);
  }
  lines[1]=JSON.stringify(event);fs.writeFileSync(file,lines.join('\n')+'\n');
}
function runAdversarial({seed=20261022,count=90}={}){
  if(!Number.isInteger(seed)||seed<0||seed>0xffffffff)throw Error('seed must be uint32');
  if(!Number.isInteger(count)||count<15||count>1000)throw Error('count must be 15..1000');
  const f=makeFixture(),rng=random(seed),failures=[],detections=[];
  try{
    for(let i=0;i<count;i++){
      const kind=CHANGE_TYPES[i<CHANGE_TYPES.length?i:rng()%CHANGE_TYPES.length];
      const dir=copyFixture(f,'case-'+i);
      mutate(dir,kind,i+1);
      const r=verifyLedger({directory:dir,scoreSource,pins:f.pins});
      if(r.valid)failures.push({case:i,kind,problem:'tampered ledger accepted'});
      else detections.push({case:i,kind,reason:r.reason});
    }
    const wrongPin=verifyLedger({directory:f.directory,scoreSource,pins:{...f.pins,controller:f.pins.vcc}});
    if(wrongPin.valid)failures.push({kind:'trust pin substitution',problem:'accepted'});
    const changedSource=verifyLedger({directory:f.directory,scoreSource:scoreSource+'\n# unsafe additional note',pins:f.pins});
    // A comment is semantically inert, so report only as an informational check.
    const replayError=(()=>{try{const gate=new ActivationGate({directory:f.directory,scoreSource,pins:f.pins,
      controllerPrivateKey:f.actors.controller.privateKey,now:()=>Date.UTC(2026,9,22,12)});
      const b=score.ir.bindings.find(x=>x.name==='scout_node'),request=f.request;
      const vccReceipt=makeVccDecision({schema:'octolang.vcc-decision.v2.2',requestDigest:hash('OctoLang v2.2 Request\n'+canonical(request)),
        decision:'ALLOW',issuedAt:iso(Date.UTC(2026,9,22,12)),expiresAt:iso(Date.UTC(2026,9,22,12,1))},f.actors.vcc.privateKey);
      void b;gate.reserve({request,vccReceipt});return null;
    }catch(e){return e.message;}})();
    if(!replayError||!/replayed reservation/.test(replayError))failures.push({kind:'duplicate reservation',problem:'not rejected'});
    // No trusted external checkpoint means replaying *both* previously valid files is undetectable locally.
    const restored=copyFixture(f,'joint-valid-rollback');
    fs.writeFileSync(path.join(restored,'events.jsonl'),f.previousJournal);
    fs.writeFileSync(path.join(restored,'state-seal.json'),f.previousSeal);
    const rollbackCheck=verifyLedger({directory:restored,scoreSource,pins:f.pins});
    const residual={id:'UNDETECTABLE_JOINT_LOCAL_ROLLBACK',observed:rollbackCheck.valid,
      severity:'HIGH',explanation:'An operator who restores BOTH a previously signed journal and its signed seal can evade the local-only verifier. An external durable checkpoint is needed.'};
    if(!rollbackCheck.valid)failures.push({kind:'blind spot regression',problem:'baseline of rollback threat changed; re-evaluate assumptions'});
    return {ok:failures.length===0,seed,requestedMutations:count,detectedMutations:detections.length,
      failedMutations:failures,extraChecks:{pinSubstitutionRejected:!wrongPin.valid,duplicateNonceRejected:!!replayError,
      benignCommentAccepted:changedSource.valid},residualRisks:[residual],mutationKinds:CHANGE_TYPES};
  }finally{fs.rmSync(f.root,{recursive:true,force:true});}
}
module.exports={runAdversarial,CHANGE_TYPES};
if(require.main===module){const r=runAdversarial({seed:Number(process.argv[2]||20261022),count:Number(process.argv[3]||90)});console.log(JSON.stringify(r,null,2));process.exitCode=r.ok?0:1;}
