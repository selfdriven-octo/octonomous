'use strict';
/**
 * OctoLang 2.6 bounded reference transition model.
 * The model is deliberately small and independent of the v2.2-v2.5 runtime.
 * Exhaustive checks hold only for declared bounds, not for unbounded deployment.
 */
const assert=require('node:assert/strict');
const ACTORS=['scout','buyer'];
const NONCES=['N1','N2'];
const LIMIT={scout:{runs:2,units:3},buyer:{runs:2,units:3}};
function initial(){return {limit:structuredClone(LIMIT),usage:{scout:{runs:0,units:0},buyer:{runs:0,units:0}},requests:[],revision:0};}
const clone=x=>structuredClone(x);
function actions(){
  const a=[];
  for(const actor of ACTORS){
    a.push({type:'TIGHTEN',actor},{type:'WIDEN',actor});
    for(const nonce of NONCES)for(const units of [1,2])a.push({type:'RESERVE',actor,nonce,units});
  }
  for(const nonce of NONCES)for(const type of ['START','WITNESS_START','EFFECT','COMPLETE','WITNESS_COMPLETE','RECONCILE','HOLD','RETRY'])a.push({type,nonce});
  return a;
}
function apply(prev,action,{mutant=null}={}){
  const s=clone(prev),bad=reason=>({accepted:false,state:prev,reason});
  const a=action.actor,r=s.requests.find(x=>x.nonce===action.nonce);
  switch(action.type){
    case 'TIGHTEN':{
      const lim=s.limit[a],used=s.usage[a];
      const proposed={runs:Math.max(1,lim.runs-1),units:Math.max(1,lim.units-1)};
      if(proposed.runs===lim.runs&&proposed.units===lim.units)return bad('already tight');
      if(used.runs>proposed.runs||used.units>proposed.units)return bad('cannot tighten below spent');
      s.limit[a]=proposed;s.revision++;break;
    }
    case 'WIDEN':
      if(mutant!=='allow-widen')return bad('authority expansion');
      s.limit[a]={runs:s.limit[a].runs+1,units:s.limit[a].units+1};s.revision++;break;
    case 'RESERVE':{
      if(s.requests.some(x=>x.nonce===action.nonce))return bad('replay');
      const usage=s.usage[a],lim=s.limit[a];
      if(usage.runs+1>lim.runs||usage.units+action.units>lim.units)return bad('cumulative bound');
      usage.runs++;usage.units+=action.units;
      s.requests.push({nonce:action.nonce,actor:a,units:action.units,started:false,startWitnessed:false,
        effectCount:0,effectWitnessedAtCall:false,completed:false,completeWitnessed:false,reconciled:false,hold:false});
      break;
    }
    case 'START':
      if(!r||r.started)return bad('missing/duplicate start');r.started=true;break;
    case 'WITNESS_START':
      if(!r||!r.started||r.startWitnessed)return bad('invalid start checkpoint');r.startWitnessed=true;break;
    case 'EFFECT':
      if(!r||!r.started||r.effectCount>0||(!r.startWitnessed&&mutant!=='skip-witness'))return bad('effect not authorised');
      r.effectCount++;r.effectWitnessedAtCall=r.startWitnessed;break;
    case 'COMPLETE':
      if(!r||!r.started||r.completed||r.effectCount!==1)return bad('invalid completion');r.completed=true;break;
    case 'WITNESS_COMPLETE':
      if(!r||!r.completed||r.completeWitnessed)return bad('invalid completion checkpoint');r.completeWitnessed=true;break;
    case 'RECONCILE':
      if(!r||!r.completed||r.completeWitnessed||!r.startWitnessed)return bad('not confirmed completion');
      r.completeWitnessed=true;r.reconciled=true;break;
    case 'HOLD':
      if(!r||!r.started||r.completed||r.hold)return bad('not uncertain');r.hold=true;break;
    case 'RETRY':
      if(!r||!r.started)return bad('no start');
      if(mutant!=='unsafe-retry'||!r.startWitnessed||r.effectCount===0)return bad('may have happened');
      r.effectCount++;break;
    default:throw Error('unknown event '+action.type);
  }
  return {accepted:true,state:s};
}
function invariants(prev,next,action){
  const fail=[];
  for(const actor of ACTORS){
    const old=prev.limit[actor],lim=next.limit[actor],used=next.usage[actor],before=prev.usage[actor];
    if(lim.runs>old.runs||lim.units>old.units||lim.runs>LIMIT[actor].runs||lim.units>LIMIT[actor].units)fail.push('NO_AUTHORITY_EXPANSION');
    if(used.runs<before.runs||used.units<before.units)fail.push('NO_BUDGET_RESET');
    if(used.runs>lim.runs||used.units>lim.units)fail.push('CUMULATIVE_LIMIT');
    const requests=next.requests.filter(r=>r.actor===actor);
    if(used.runs!==requests.length||used.units!==requests.reduce((n,r)=>n+r.units,0))fail.push('RESERVATION_ACCOUNTING');
  }
  if(new Set(next.requests.map(r=>r.nonce)).size!==next.requests.length)fail.push('UNIQUE_NONCE');
  for(const r of next.requests){
    if(r.effectCount>1)fail.push('AT_MOST_ONCE_EFFECT');
    if(r.effectCount>0&&!r.effectWitnessedAtCall)fail.push('WITNESS_BEFORE_EFFECT');
    if(r.completed&&(r.effectCount!==1||!r.started))fail.push('COMPLETE_REQUIRES_EFFECT');
    if(r.reconciled&&(!r.completed||r.effectCount!==1))fail.push('RECOVERY_NEVER_INVENTS_EFFECT');
  }
  if(action.type==='RETRY'&&next.requests.some(r=>r.effectCount>1))fail.push('NO_RETRY_AFTER_UNCERTAINTY');
  return [...new Set(fail)];
}
function explore({depth=7,maxStates=6000,mutant=null}={}){
  assert(Number.isInteger(depth)&&depth>=1&&depth<=12,'depth must be 1..12');
  assert(Number.isInteger(maxStates)&&maxStates>=1&&maxStates<=100000,'maxStates must be 1..100000');
  const start=initial(),queue=[{s:start,trace:[]}],seen=new Set([JSON.stringify(start)]),all=actions();
  let explored=0,transitions=0,denied=0,edges=0;
  for(let q=0;q<queue.length;q++){
    const {s,trace}=queue[q];explored++;
    if(trace.length===depth)continue;
    for(const a of all){
      const result=apply(s,a,{mutant});edges++;
      if(!result.accepted){denied++;continue;}
      transitions++;
      const nextTrace=[...trace,a];const violations=invariants(s,result.state,a);
      if(violations.length)return {ok:false,mutant,depth,maxStates,explored,transitions,denied,edges,
        counterexample:{violations,trace:nextTrace,priorState:s,nextState:result.state}};
      const key=JSON.stringify(result.state);
      if(!seen.has(key)){
        seen.add(key);
        if(seen.size>maxStates)return {ok:false,inconclusive:true,reason:'state bound reached',mutant,depth,maxStates,explored,transitions,denied,edges,states:seen.size};
        queue.push({s:result.state,trace:nextTrace});
      }
    }
  }
  return {ok:true,mutant,depth,maxStates,states:seen.size,explored,transitions,denied,edges,
    properties:['NO_AUTHORITY_EXPANSION','NO_BUDGET_RESET','CUMULATIVE_LIMIT','RESERVATION_ACCOUNTING','UNIQUE_NONCE',
      'AT_MOST_ONCE_EFFECT','WITNESS_BEFORE_EFFECT','COMPLETE_REQUIRES_EFFECT','RECOVERY_NEVER_INVENTS_EFFECT','NO_RETRY_AFTER_UNCERTAINTY']};
}
module.exports={initial,actions,apply,invariants,explore};
if(require.main===module){const r=explore({depth:Number(process.argv[2]||7)});console.log(JSON.stringify(r,null,2));process.exitCode=r.ok?0:1;}
