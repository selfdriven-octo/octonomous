'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {explore}=require('./model');
const {runAdversarial}=require('./adversary');
const root=path.resolve(__dirname,'../..');
const readSha=relative=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,relative))).digest('hex');
function run({depth=7,seed=20261022,count=90}={}){
  const model=explore({depth,maxStates:50000});
  const mutation=runAdversarial({seed,count});
  const mutants={};
  for(const mutant of ['allow-widen','skip-witness','unsafe-retry']){
    const result=explore({depth:Math.max(5,depth),maxStates:50000,mutant});
    mutants[mutant]={detected:!result.ok&&!result.inconclusive,
      violations:result.counterexample?.violations||[],minimalCounterexample:result.counterexample?.trace||null};
  }
  const success=model.ok&&mutation.ok&&Object.values(mutants).every(x=>x.detected);
  return {
    schema:'octolang.safety-report.v2.6',release:'2.6.0',generatedAt:new Date().toISOString(),
    classification:success?'BOUNDED_CHECKS_PASSED':'FAILED_OR_INCONCLUSIVE',success,
    scope:{
      model:'Independent finite reference model, two agent roles, two nonce values, units 1 or 2, BFS depth '+depth+', no concurrent interleaving inside a transition',
      realCode:'Mutation probes on actual v2.2 signed activation journal verifier and replay enforcement',
      excluded:['Unbounded system behaviour','Remote physical host administration','Real-world truth of signed claims',
        'Compromised signing keys','Remote witness equivocation','OS-level concurrent crash/power-failure atomicity',
        'Network partitions across actual machines','Midnight proof generation or Cardano settlement']
    },
    sourceDigests:{
      model:readSha('safety/v2.6/model.js'),adversary:readSha('safety/v2.6/adversary.js'),
      activationVerifier:readSha('language/v2.2/index.js'),recovery:readSha('language/v2.5/reconcile.js')
    },
    model,mutants,mutation,
    findings:[{
      id:'F-001',severity:'HIGH',status:'OPEN',name:'Local rollback of signed journal and seal together',
      observed:mutation.residualRisks[0]?.observed===true,
      consequence:'Previously consumed budget may become invisible after a privileged disk rollback.',
      proposedMitigation:'Independently administered append-only witness/checkpoint, anti-equivocation and recovery on disagreement.'
    }],
    assuranceBoundary:'Tests and bounded model exploration support the stated properties under the stated assumptions; this report is not a formal proof of the OctoLang implementation or a security certification.'
  };
}
function markdown(r){
  const lines=[
    '# OctoLang v2.6 — Safety Evidence Report',
    '',`Generated (UTC): ${r.generatedAt}`,
    '',`**Overall:** ${r.classification}`,
    '',`**Reference model:** ${r.model.ok?'bounded pass':'failed or inconclusive'} — ${r.model.states??'-'} reachable states, ${r.model.edges} explored edges, ${r.model.denied} rejected transitions (depth ${r.model.depth}).`,
    '',`**Real verifier mutation checks:** ${r.mutation.detectedMutations}/${r.mutation.requestedMutations} detected (seed ${r.mutation.seed}).`,
    '',`**Deliberately weakened models:** ${Object.entries(r.mutants).filter(([,v])=>v.detected).length}/3 caught with a replayable trace.`,
    '', '## Safety properties checked in the bounded model',
    ...r.model.properties.map(x=>`- ${x}`),
    '', '## Deliberately introduced faults / shortest counterexamples',
    ...Object.entries(r.mutants).flatMap(([name,value])=>[
      `### ${name}`,`Detected: ${value.detected}; violated: ${value.violations.join(', ')}`, '```json', JSON.stringify(value.minimalCounterexample,null,2),'```',''
    ]),
    '## Open finding — F-001 (HIGH)',
    '', 'A local attacker who rolls back **both** a previously valid signed journal and its matching seal can make the local verifier accept the stale head. This is reproduced by the test harness and is **not resolved** in v2.6.',
    '', 'Mitigation: externally operated, durable and monotonic checkpoints; compare heads during startup and reconciliation. The v2.4 witness is a research prototype, not a verified independent production anchor.',
    '', '## Boundaries',
    '', 'This is a **bounded reference model**, not a mathematical proof that the production implementation always meets these properties.',
    '', 'The mutation campaign exercises the real v2.2 signed-journal verifier; it does not cover arbitrary parser, dependency, network, key custody or remote witness compromise paths.',
    '', 'Untested or out-of-scope items:',...r.scope.excluded.map(x=>`- ${x}`),
    '',`Source SHA-256 (model): \`${r.sourceDigests.model}\``,
    '',`Source SHA-256 (activation verifier): \`${r.sourceDigests.activationVerifier}\``,
    '', '## Reproduce',
    '', '```sh',`npm run safety:model`,`npm run safety:attack`,`npm run safety:report`,'```','',
    'The JSON report contains the full property list, the rejected mutation categories, and replayable counterexample traces.'
  ];
  return lines.join('\n')+'\n';
}
function parseArgs(argv){
  const o={};for(let i=0;i<argv.length;i++){
    const k=argv[i];if(!['--depth','--seed','--count','--json','--markdown'].includes(k))throw Error('unknown option '+k);
    if(!argv[i+1])throw Error('missing argument for '+k);
    o[k.slice(2)]=argv[++i];
  }
  return o;
}
if(require.main===module){
  try{
    const o=parseArgs(process.argv.slice(2));
    const r=run({depth:Number(o.depth||7),seed:Number(o.seed||20261022),count:Number(o.count||90)});
    if(o.json){fs.mkdirSync(path.dirname(path.resolve(o.json)),{recursive:true});fs.writeFileSync(o.json,JSON.stringify(r,null,2)+'\n');}
    if(o.markdown){fs.mkdirSync(path.dirname(path.resolve(o.markdown)),{recursive:true});fs.writeFileSync(o.markdown,markdown(r));}
    if(!o.json&&!o.markdown)console.log(markdown(r));
    else console.log(JSON.stringify({status:r.classification,states:r.model.states,detectedMutations:r.mutation.detectedMutations,report:o.json,markdown:o.markdown}));
    process.exitCode=r.success?0:1;
  }catch(e){console.error(e.stack);process.exitCode=1;}
}
module.exports={run,markdown,parseArgs};
