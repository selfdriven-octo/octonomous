# Acceptance status — OctoLang v2.4

- Local Node.js 22.16.0 and OpenSSL available.
- 328 tests across 24 test files passed when run separately, including 18 new v2.4 tests. The aggregate `test:isolated` command was interrupted after 21 test files on the final run; the remaining three test files passed when run individually. This is not reported as a successful single uninterrupted full-suite run.
- Separate-process witness with its own generated Ed25519 key: demonstrated on localhost.
- HTTPS mutual TLS and independent server/client fingerprint pins: tested.
- Controller rejects tampered, stale and rolled-back witness histories: tested.
- Only bounded, authorised local `intent.record` effect permitted: demonstrated.
- Witness process restart retains the signed checkpoint high-water mark: tested.
- Actual two-physical-machine deployment: **not tested**.
- Third-party service effects, ADA transfers, Midnight proofs: **not enabled**.

See `docs/REMOTE-WITNESS-v2.4.md` for operator setup and `docs/OCTOLANG-LANGUAGE-v2.4.md` for the security model.
