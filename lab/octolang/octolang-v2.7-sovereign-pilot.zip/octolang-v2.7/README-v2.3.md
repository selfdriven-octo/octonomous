# OctoLang v2.3 — Witnessed local execution

v2.3 connects native OctoLang score refinements to the actual Octonomous Runtime tool registry, with an execution-time VCC gate and independent public-key audit. One bounded local file effect is enabled; no wallet, network or payment action is permitted.

## Quick start

Requires Node.js >=22. No third-party npm installation required for this demonstration.

```sh
npm run activation:execute-demo
npm run activation:execution-test
npm run test:isolated
```

The demonstration provisions **temporary, synthetic** Ed25519 identities in separate controller and witness directories, activates a budget-tightening refinement, verifies the authorised mission and writes exactly one local intent record through Octonomous Runtime. It independently checks witnessed `START`/`COMPLETE` receipts and reports where the temporary audit files were written.

See [`docs/OCTOLANG-LANGUAGE-v2.3.md`](docs/OCTOLANG-LANGUAGE-v2.3.md) for trust boundaries, signature semantics, offline CLI usage and recovery limitations.

**Important:** The example witness uses a separately signed local filesystem journal but runs on the same physical host and trust domain. It is *not* an independently operated remote witness. Live payments, external service calls and production-grade rollback resistance remain unavailable in this v2.3 execution path.
