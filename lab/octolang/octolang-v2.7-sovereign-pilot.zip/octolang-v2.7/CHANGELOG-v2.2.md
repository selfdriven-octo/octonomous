# v2.2 — Verified Refinement Activation

- Added separate, pinned governance signatures for activating independently reviewed v2.1 refinements.
- Added monotonic effective limits and persistent cumulative reservations across score refinements and restarts.
- Added short-lived, exact-request signed VCC decisions and existing mission `planMission()` review/grant/context bridge.
- Added signed and hash-linked append-only ledger, signed state seal, strict journal replay validation and fail-closed locking.
- Added independent read-only audit CLI, regression tests and an executable local demonstration.
- Kept score and revision syntax unchanged, and preserved earlier OctoLang integrations without broadening execution rights.

**Research limitations:** no execution-time tool hookup, no distributed transactional store, no external anti-rollback witness, no public-chain deployment, and no guarantee that observations represent real-world truth.
