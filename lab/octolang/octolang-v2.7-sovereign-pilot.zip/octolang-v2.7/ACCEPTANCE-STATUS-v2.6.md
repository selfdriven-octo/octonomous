# OctoLang v2.6 acceptance status

The canonical machine-readable record for this release is `reports/safety-report-v2.6.json`; regenerate using `npm run safety:report`.

Checks required for release:

- [x] Bounded reference model accepts valid transitions and rejects forbidden transitions through depth 7.
- [x] Three deliberately weakened reference models fail with replayable counterexamples.
- [x] Seeded signed-record mutations are rejected by the real v2.2 verifier.
- [x] F-001 joint rollback is reproduced and remains OPEN.
- [x] v2.6 focused tests pass.
- [ ] Independent proof of the full runtime (not claimed).
- [ ] Production-grade external rollback checkpoint (not implemented).
- [ ] Three-host independent operation test (not performed).

## Verification on 2026-10-22

- Full inherited regression: **364/364 tests pass**, across **26 independent test files**.
- New v2.6 focused suite: **19/19 tests pass**.
- Reference model: **3,901 states**, **64,204 transitions attempted**, depth 7; no invariant counterexamples within bounds.
- 90/90 signed-ledger mutation probes rejected; three deliberately weakened models produce counterexamples.
- Open finding **F-001/HIGH** remains unresolved.
- Clean-archive test status: see final release notes.

Do not treat a timed-out suite as passed.

## Clean-archive verification qualification

The release archive passed ZIP integrity checks and, after extraction into a fresh directory, the 19 new safety tests and safety report generator passed. A second attempt to run the entire isolated regression suite from the fresh extraction stalled at the older remote-witness tests after passing the first 14 files; it was stopped and **must not be counted as a second 364-test pass**. The full 364/364 result is from the source-tree run recorded above.
