'use strict';
const fs=require('node:fs'),path=require('node:path');
const {compileScore,verifyScore}=require('../../language/v2.1');
const dir=__dirname,manifest=JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'),'utf8'));
let passed=0;
for(const entry of manifest.cases){
  const source=fs.readFileSync(path.join(dir,'cases',entry.file),'utf8');
  try{
    const artifact=compileScore(source);
    if(!entry.accept)throw new Error('invalid programme accepted');
    if(artifact.irDigest!==entry.digest)throw new Error('semantic digest changed');
    if(!verifyScore(source,artifact).valid)throw new Error('verification rejected good source');
    console.log('PASS',entry.file,artifact.irDigest.slice(0,12));passed++;
  }catch(err){
    if(entry.accept){console.error('FAIL',entry.file,err.message);process.exitCode=1;}
    else if(/invalid programme accepted/.test(err.message)){console.error('FAIL',entry.file,err.message);process.exitCode=1;}
    else{console.log('PASS (rejected)',entry.file);passed++;}
  }
}
console.log(`${passed}/${manifest.cases.length} conformance cases passed`);
if(passed!==manifest.cases.length)process.exitCode=1;
