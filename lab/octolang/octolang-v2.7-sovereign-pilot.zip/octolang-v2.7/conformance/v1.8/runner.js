#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {compileEpistemic,verifyEpistemic}=require('../../language/v1.8');
const {compileLanguage}=require('../../language/v1.6');
const {verifyIR}=require('../../language/v1.8/validate');
const manifest=require('./manifest.json');
function run(){
  assert.equal(manifest.schema,'octolang.conformance.v1.8');assert.equal(manifest.vectors.length,22);
  const mission=fs.readFileSync(path.join(__dirname,'../../examples/community-proofs.octo'),'utf8');
  const root=compileLanguage(mission);const files=new Set();
  for(const item of manifest.vectors){
    assert.match(item.file,/^[a-z-]+\.octo$/);assert(!files.has(item.file));files.add(item.file);
    const text=fs.readFileSync(path.join(__dirname,'cases',item.file),'utf8');
    if(item.accepted){const a=compileEpistemic(text,mission);
      assert.equal(a.irDigest,item.irDigest,item.file);assert.equal(verifyIR(a.ir,root.ir,a.irDigest).valid,true,item.file);
      assert.equal(verifyEpistemic(text,mission,a).valid,true,item.file);
    } else assert.throws(()=>compileEpistemic(text,mission),err=>err.message.includes(item.errorIncludes),item.file);
  }
  return files.size;
}
if(require.main===module)Promise.resolve().then(run).then(n=>console.log(`PASS ${n} frozen OctoLang v1.8 epistemic cases`)).catch(e=>{console.error(e);process.exitCode=1;});
module.exports={run};
