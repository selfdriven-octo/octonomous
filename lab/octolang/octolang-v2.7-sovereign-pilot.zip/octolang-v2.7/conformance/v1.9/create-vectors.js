'use strict';
// Maintainer-only generator for frozen test fixtures. Do NOT rerun on release without review.
const fs=require('node:fs'),path=require('node:path');
const {compileAssurance}=require('../../language/v1.9');
const root=path.join(__dirname,'../..');
const mission=fs.readFileSync(path.join(root,'examples/community-proofs.octo'),'utf8');
const base=fs.readFileSync(path.join(root,'examples/community-assurance.octo'),'utf8');
const replace=(a,b)=>base.replace(a,b);
const inputs=[
  ['base',base,true],
  ['comment',`# additional comment\n${base}`,true],
  ['tighter',replace('max 100 ADA','max 80 ADA'),true],
  ['more-specific-temporal',replace('within 60 m','within 30 m'),true],
  ['reorder-effect',replace('  effect find_supplier { allow EXTERNAL_SERVICE }\n','').replace('  effect independent_audit { allow LOCAL_CAPABILITY }','  effect independent_audit { allow LOCAL_CAPABILITY }\n  effect find_supplier { allow EXTERNAL_SERVICE }'),true],
  ['wrong-mission',replace('assurance learning_materials','assurance another_mission'),false],
  ['broad-limit',replace('max 100 ADA','max 101 ADA'),false],
  ['bad-unit',replace('max 100 ADA','max 100 count'),false],
  ['unbounded-task',replace('  effect find_supplier { allow EXTERNAL_SERVICE }',''),false],
  ['wrong-effect',replace('effect find_supplier { allow EXTERNAL_SERVICE }','effect find_supplier { allow LOCAL_CAPABILITY }'),false],
  ['unknown-task',replace('effect vet_supplier','effect evil_tool'),false],
  ['backwards-time',replace('after record_intent before independent_audit','after independent_audit before record_intent'),false],
  ['too-much-time',replace('within 60 m','within 100 d'),false],
  ['no-approval',replace('obligation find_supplier { require "AUTHORISATION,EXECUTION" }','obligation find_supplier { require "EXECUTION" }'),false],
  ['missing-task-obligation',replace('  obligation vet_supplier { require "AUTHORISATION,EXECUTION" }',''),false],
  ['outcome-without-observation',replace('obligation record_intent { require "AUTHORISATION,EXECUTION,OBSERVATION,OUTCOME" }','obligation record_intent { require "AUTHORISATION,EXECUTION" }'),false],
  ['gapped-proof-chain',replace('"AUTHORISATION,EXECUTION,OBSERVATION,OUTCOME"','"AUTHORISATION,EXECUTION,OUTCOME"'),false],
  ['duplicate-proof',replace('"AUTHORISATION,EXECUTION"','"AUTHORISATION,EXECUTION,EXECUTION"'),false],
  ['unknown-phase',replace('"AUTHORISATION,EXECUTION"','"AUTHORISATION,TRANSFER"'),false],
  ['unknown-declaration',replace('effect vet_supplier','unsafe vet_supplier'),false]
];
const result={schema:'octolang.conformance.v1.9',mission:'examples/community-proofs.octo',vectors:[]};
for(const [name,source,accepted] of inputs){const file=name+'.octo';fs.writeFileSync(path.join(__dirname,'cases',file),source);
  if(accepted){const compiled=compileAssurance(source,mission);result.vectors.push({file,accepted:true,irDigest:compiled.irDigest});}
  else {let reason='';try{compileAssurance(source,mission);throw new Error('ACCEPTED INVALID '+file);}catch(e){reason=e.message;}
    result.vectors.push({file,accepted:false,errorIncludes:reason.slice(reason.indexOf(': ')+2)});
  }
}
fs.writeFileSync(path.join(__dirname,'manifest.json'),JSON.stringify(result,null,2)+'\n');
console.log('Created '+result.vectors.length+' frozen vectors');
