#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {compileAssurance,verifyAssurance}=require('../../language/v1.9');
const {compileLanguage}=require('../../language/v1.6');
const {verifyIR}=require('../../language/v1.9/validate');
const manifest=require('./manifest.json');
function run(){
  assert.equal(manifest.schema,'octolang.conformance.v1.9');assert.equal(manifest.vectors.length,20);
  const mission=fs.readFileSync(path.join(__dirname,'../../examples/community-proofs.octo'),'utf8');
  const root=compileLanguage(mission),seen=new Set();
  for(const item of manifest.vectors){
    assert.match(item.file,/^[a-z-]+\.octo$/);assert(!seen.has(item.file));seen.add(item.file);
    const source=fs.readFileSync(path.join(__dirname,'cases',item.file),'utf8');
    if(item.accepted){const art=compileAssurance(source,mission);
      assert.equal(art.irDigest,item.irDigest,item.file);
      assert.equal(verifyIR(art.ir,root.ir,art.irDigest).valid,true,item.file);
      assert.equal(verifyAssurance(source,mission,art).valid,true,item.file);
    } else assert.throws(()=>compileAssurance(source,mission),e=>e.message.includes(item.errorIncludes),item.file);
  }
  return seen.size;
}
if(require.main===module)Promise.resolve().then(run).then(n=>console.log(`PASS ${n} OctoLang v1.9 frozen conformance vectors`)).catch(e=>{console.error(e);process.exitCode=1;});
module.exports={run};
