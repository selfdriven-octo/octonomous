#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {compileProgram,verifyProgram}=require('../../language/v2.0');
const {verifyIR}=require('../../language/v2.0/validate');
const manifest=require('./manifest.json');
const ROOT=path.join(__dirname,'../..');
function run(){
  assert.equal(manifest.schema,'octolang.conformance.v2.0');
  assert.equal(manifest.vectors.length,20);
  const base=require('../../language/v2.0').parseProgram(fs.readFileSync(path.join(ROOT,'community-program.octo'),'utf8'));
  const files=Object.fromEntries([...Object.values(base.sources),...base.imports.map(x=>x.path)].map(p=>[p,fs.readFileSync(path.join(ROOT,p),'utf8')]));
  for(const v of manifest.vectors){
    assert.match(v.file,/^[a-z-]+\.octo$/);
    const source=fs.readFileSync(path.join(__dirname,'cases',v.file),'utf8');
    if(v.accepted){const artifact=compileProgram(source,files);
      assert.equal(artifact.irDigest,v.irDigest,v.file);
      assert.equal(verifyIR(artifact.ir,artifact.components,artifact.irDigest).valid,true,v.file);
      assert.equal(verifyProgram(source,files,artifact).valid,true,v.file);
    } else assert.throws(()=>compileProgram(source,files),e=>e.message.includes(v.errorIncludes),v.file);
  }
  return manifest.vectors.length;
}
if(require.main===module){try{console.log(`PASS ${run()} OctoLang v2.0 frozen conformance vectors`);}catch(e){console.error(e);process.exitCode=1;}}
module.exports={run};
