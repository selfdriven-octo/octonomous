# v2.5.0 — 22 October 2026

- Added distributed evidence reconciliation over the existing v2.4 independently signed remote-witness transport.
- Added strict case classifications, independent observer attestations and governor signatures tied to exact case and witness heads.
- Added recovery of **existing** signed COMPLETE records after lost witness acknowledgments, with no second invocation.
- Added explicit indefinite HOLD for unknown or unsigned effects; cumulative spent budget remains reserved.
- Added controller-signed, hash-linked recovery log with state seal and independent read-only auditor.
- Added public-key-only inspection/audit CLI, localhost demo and fault-injection tests.
- Existing v2.4 controller, tool registry, witness protocol and OctoLang compiler are unchanged.
