# OctoLang v2.6 — Formal Safety & Adversarial Verification

See **[README-v2.6.md](README-v2.6.md)** and **[docs/SAFETY-v2.6.md](docs/SAFETY-v2.6.md)**.

# OctoLang v2.5 — distributed recovery and reconciliation

Start with [README-v2.5.md](README-v2.5.md) and [docs/RECOVERY-v2.5.md](docs/RECOVERY-v2.5.md).

# OctoLang v2.4 — Remote Witnessed Execution

Start with [README-v2.4.md](README-v2.4.md) and [docs/OCTOLANG-LANGUAGE-v2.4.md](docs/OCTOLANG-LANGUAGE-v2.4.md).

Earlier reference releases, original language modules, federation, browser Studio and Midnight experimental adapters remain included. This release is **not a production deployment**.
