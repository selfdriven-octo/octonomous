# OctoLang v2.0 — Unified Language Track

A reproducible *linker* for v1.6 mission, v1.7 composition, v1.8 epistemic and v1.9 assurance layers, with reusable agent contracts, parameterised templates and one canonical IR. Pure compilation and verification. **No tool invocation or authority is created**.

## Quickstart (Node.js 22+)

```bash
npm run program:check
npm run program:conformance
node bin/octolang-program.js compile community-program.octo program-artifact.json
node bin/octolang-program.js verify community-program.octo program-artifact.json
node --test test/language-v2.0.test.js
```

Example files: `community-program.octo`, `modules/community-contracts.octo` and the previously shipped source overlays under `examples/`.

See `docs/OCTOLANG-LANGUAGE-v2.0.md` for grammar, typing, IR hashing, signature/authority caveats, compatibility, and threat model.
