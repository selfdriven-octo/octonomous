# OctoLang v2.4 — 22 October 2026

- Added separately deployable Ed25519-signed remote witness over mutual TLS with exact server and client certificate fingerprint pinning.
- Added immutable witness enrolment scoped to one score and controller signer.
- Added signed, non-replayable attestation requests with 60-second maximum window, fsynced nonce claims and monotonic expected-head checks.
- Added controller-side durable mirror of the full independently signed witness journal, rejecting rollback and fork.
- Added `RemoteExecutionController` requiring a fresh live witness check immediately before the only permitted local effect.
- Added read-only remote inspection and offline independent verification workflow.
- Added demo in independent Node.js processes and operator runbook for independently managed machines (not yet validated across machines).
- Preserved existing v2.1-v2.3 score syntax, VCC controls, activation ledger, effect journal and tests.
- Security tests cover transport identity substitution, forged requests, expiry, replay, concurrent predecessor updates, process restart, tampering, outage and controller/witness rollback.
- No arbitrary external effect, payment, blockchain ZK proof or real-world outcome guarantee.
