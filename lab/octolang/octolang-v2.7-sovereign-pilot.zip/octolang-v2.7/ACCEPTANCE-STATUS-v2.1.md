# OctoLang 2.1 — Acceptance status

Date: 21 October 2026  
Platform: Node.js 22.16.0, CommonJS  
Scope: language compilation, canonical IR, independently checked *proposals*, signed synthetic observations and human-review demonstration.

| Acceptance item | Result |
|---|---|
| Native score produces four constituent IRs with unified semantic digest | PASS |
| Native score verified through independent recompilation | PASS |
| Comments and harmless declaration reorder preserve digest | PASS |
| Material constraint change affects semantics or is rejected | PASS |
| Refinement cannot add roles, bindings, grants, proofs or capabilities | PASS |
| Refinement cannot increase runs or per-run budget | PASS |
| Observer Ed25519 signature and operator-pinned identity required | PASS |
| Separate reviewer signature bound to score, observation and revision required | PASS |
| Different PEM encodings of same public key cannot bypass separation | PASS |
| Invalid, expired, conflicting or forged inputs fail closed | PASS |
| 24 frozen score conformance cases | PASS |
| 24 new v2.1 automated tests | PASS |
| All 21 inherited+new test files via isolated runner | PASS — 268/268 tests |
| Actual execution of revisions | NOT IMPLEMENTED |
| Live sensors, production identity governance, external proof systems | NOT VERIFIED |
| Live Midnight proof, Cardano transaction or remote agent execution in v2.1 | NOT TESTED |

The compiler and reviewer produce non-executable policy proposals. Real-world outcome truth and runtime action authorisation require additional independent systems.
