# OctoLang v2.6 — Safety Evidence Report

Generated (UTC): 2026-10-22T05:39:01.802Z

**Overall:** BOUNDED_CHECKS_PASSED

**Reference model:** bounded pass — 3901 reachable states, 64204 explored edges, 54096 rejected transitions (depth 7).

**Real verifier mutation checks:** 90/90 detected (seed 20261022).

**Deliberately weakened models:** 3/3 caught with a replayable trace.

## Safety properties checked in the bounded model
- NO_AUTHORITY_EXPANSION
- NO_BUDGET_RESET
- CUMULATIVE_LIMIT
- RESERVATION_ACCOUNTING
- UNIQUE_NONCE
- AT_MOST_ONCE_EFFECT
- WITNESS_BEFORE_EFFECT
- COMPLETE_REQUIRES_EFFECT
- RECOVERY_NEVER_INVENTS_EFFECT
- NO_RETRY_AFTER_UNCERTAINTY

## Deliberately introduced faults / shortest counterexamples
### allow-widen
Detected: true; violated: NO_AUTHORITY_EXPANSION
```json
[
  {
    "type": "WIDEN",
    "actor": "scout"
  }
]
```

### skip-witness
Detected: true; violated: WITNESS_BEFORE_EFFECT
```json
[
  {
    "type": "RESERVE",
    "actor": "scout",
    "nonce": "N1",
    "units": 1
  },
  {
    "type": "START",
    "nonce": "N1"
  },
  {
    "type": "EFFECT",
    "nonce": "N1"
  }
]
```

### unsafe-retry
Detected: true; violated: AT_MOST_ONCE_EFFECT, NO_RETRY_AFTER_UNCERTAINTY
```json
[
  {
    "type": "RESERVE",
    "actor": "scout",
    "nonce": "N1",
    "units": 1
  },
  {
    "type": "START",
    "nonce": "N1"
  },
  {
    "type": "WITNESS_START",
    "nonce": "N1"
  },
  {
    "type": "EFFECT",
    "nonce": "N1"
  },
  {
    "type": "RETRY",
    "nonce": "N1"
  }
]
```

## Open finding — F-001 (HIGH)

A local attacker who rolls back **both** a previously valid signed journal and its matching seal can make the local verifier accept the stale head. This is reproduced by the test harness and is **not resolved** in v2.6.

Mitigation: externally operated, durable and monotonic checkpoints; compare heads during startup and reconciliation. The v2.4 witness is a research prototype, not a verified independent production anchor.

## Boundaries

This is a **bounded reference model**, not a mathematical proof that the production implementation always meets these properties.

The mutation campaign exercises the real v2.2 signed-journal verifier; it does not cover arbitrary parser, dependency, network, key custody or remote witness compromise paths.

Untested or out-of-scope items:
- Unbounded system behaviour
- Remote physical host administration
- Real-world truth of signed claims
- Compromised signing keys
- Remote witness equivocation
- OS-level concurrent crash/power-failure atomicity
- Network partitions across actual machines
- Midnight proof generation or Cardano settlement

Source SHA-256 (model): `68105393c8ad982f37c2910c069614c5390c011e37329e432c35e0b6ee6ca2cc`

Source SHA-256 (activation verifier): `076e9bf0d013ddbac0a6c32248c0402fb577dbd8a48f761f9e071c981f3b5f7f`

## Reproduce

```sh
npm run safety:model
npm run safety:attack
npm run safety:report
```

The JSON report contains the full property list, the rejected mutation categories, and replayable counterexample traces.
