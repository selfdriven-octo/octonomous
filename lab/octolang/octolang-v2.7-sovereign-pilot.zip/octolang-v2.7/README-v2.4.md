# OctoLang v2.4 — Remote Witnessed Execution

**22 October 2026 — experimental reference implementation.** Extends v2.3 with a separately running witness service over pinned mutual TLS and Ed25519-signed state attestations. The existing OctoLang language, governance and execution receipts remain compatible.

## Quick start

```bash
node --version   # 22+
openssl version
npm run remote:demo
npm run remote:test
npm run test:isolated
```

The demo creates a dedicated witness identity on a different process and signs the start/completion checkpoints of **one real, bounded local intent-recording action**. The witness private key never enters the controller process. The demo runs both processes on localhost. No network payments, shell tools or blockchain transactions occur.

## Modules

- `language/v2.4/remote.js`: independent witness HTTPS service, scoped signed-request API, pinned client transport and durable verified mirror
- `language/v2.4/service.js`: standalone process, config from a JSON file
- `language/v2.4/provision.js`: standalone witness key provisioning and temporary local test certificate generation
- `language/v2.4/execution.js`: v2.3 execution controller with networked, fresh attestations required before the local effect
- `language/v2.4/inspect.js`: read-only online witness history and optional controller evidence audit
- `language/v2.4/demo.js`: separate-process localhost end-to-end example
- `test/language-v2.4.test.js`: mTLS, witness state and adversarial tests

## Documentation

- [v2.4 security and protocol specification](docs/OCTOLANG-LANGUAGE-v2.4.md)
- [v2.4 two-machine operator guide](docs/REMOTE-WITNESS-v2.4.md)
- [v2.3 witnessed execution specification](docs/OCTOLANG-LANGUAGE-v2.3.md)

## Current limitations

Only the local `intent.record` effect is implemented. The remote witness cryptographically attests to the *controller-reported* journal heads, not physical-world execution. Signed evidence does not establish objective truth. Although components can be configured with a remote URL, **actual separate-machine deployment has not been validated**. The package requires independent operational security review, key management and recovery controls before production use. Prior v2.3 local witness API is preserved.
