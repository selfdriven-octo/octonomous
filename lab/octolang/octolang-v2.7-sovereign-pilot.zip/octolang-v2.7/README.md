# OctoLang v2.7 — Three-Role Sovereign Community Pilot

**Research prototype, not production-ready.** This release adds an independently running governance signer and monotonic governance checkpoint service to the existing OctoLang v2.6 formal-safety, v2.5 recovery, and v2.4 remote-witness implementations.

The architecture is:

```
Execution host A                    Governance host B
  AI score (not authority)             independently signed approval
  Human-reviewed mission  ── mTLS ──> verified revision + high-water checkpoint
  VCC and execution gate             private governance signing key
  Local intent-recording tool
          │
          └── pinned mTLS ──> Witness host C
                                independent signed START and COMPLETE
                                persistent monotonic journal
```

## Download, run and inspect

Requires Node.js 22+ and OpenSSL for local ephemeral test certificates. Use these from the project root:

```bash
npm run sovereign:demo             # Three-process localhost rehearsal, one local file effect
npm run sovereign:test             # v2.7 security and fault-injection tests
npm run test:isolated              # Full inherited regression suite
npm run safety:model               # Existing v2.6 bounded state explorer
npm run safety:report              # Existing v2.6 reproducible safety report
```

The demonstration prints the three process IDs, verifies the signatures and receipts, and checks exactly one local effect. No wallets, payments or live blockchain calls are enabled.

## Release additions

- `language/v2.7/governance.js` — signed, policy-bound remote governance approval and history checkpointing
- `language/v2.7/service.js` — deployable mutual-TLS governance service process
- `language/v2.7/provision.js` — independent Ed25519 governance key creation
- `language/v2.7/pilot.js` — three-process, real signed end-to-end rehearsal
- `language/v2.7/operator.js` — read-only cross-host identity and signed-history verification
- `test/language-v2.7.test.js` — adversarial, restart and network failure checks
- `docs/SOVEREIGN-PILOT-v2.7.md` — deployment runbook and physical-host acceptance checklist
- `docs/SAFETY-SPEC-v2.7.md` — protocol, safety properties and limits

Existing v2.6 safety tests, v2.5 evidence-only reconciliation and v2.4 remote witness remain included.

## Real multi-machine use

Both governance and witness services can bind to explicitly configured HTTPS interfaces, and the read-only operator check accepts separately configured remote endpoints:

```bash
node language/v2.7/service.js /secure/governance-config.json
node language/v2.4/service.js /secure/witness-config.json
node language/v2.7/operator.js /secure/connectivity.json
```

**The release does not claim a successful deployment onto three distinct physical machines.** The harness automatically provisions only loopback services; a real split-host executor must be configured using the exported `GovernanceClient`, `RemoteWitness` and `RemoteExecutionController` APIs and the runbook. Complete that acceptance exercise before deploying into an operational community.

## Security limitations

A separate governor key is kept outside the executor process. This release's synthetic observer/reviewer keys are still generated on the test executor, so real governance signers need independent enrolment. Governance maintains a durable high-water mark and checks prefix extension of signed state, mitigating rollback of an execution host's journal and matching seal **provided** that the independent governance and witness stores cannot also be rolled back. Long-term Ed25519 governance-root rotation is not supported by the v2.2 policy ledger; only deliberate transport certificate rotation is tested.

A remote witness only signs a controller-reported snapshot. It is not direct physical observation. Any interrupted action is held for separate evidence-only reconciliation; there is no blind retry.

License remains `UNLICENSED`, inherited from the OctoLang reference implementation.
