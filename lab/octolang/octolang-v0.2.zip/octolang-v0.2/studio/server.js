'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { Studio } = require('./core');
const { makeOpenAIAdapter } = require('./providers/openai');

const ROOT = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };
const headers = { 'cache-control': 'no-store', 'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer', 'x-frame-options': 'DENY',
  'content-security-policy': "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'" };
const json = (res, code, value) => { res.writeHead(code, { ...headers, 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(value)); };
function parseJson(req) {
  return new Promise((resolve, reject) => {
    if (!(req.headers['content-type'] || '').startsWith('application/json')) {
      const e = new Error('Expected application/json'); e.statusCode = 415; reject(e); return;
    }
    let body = '', length = 0;
    req.on('data', chunk => {
      length += chunk.length;
      if (length > 70000) { req.destroy(); reject(Object.assign(new Error('Payload too large'), { statusCode: 413 })); return; }
      body += chunk.toString('utf8');
    });
    req.on('end', () => { try { const object = JSON.parse(body); if (!object || Array.isArray(object) || typeof object !== 'object') throw new Error('Expected JSON object'); resolve(object); } catch { reject(Object.assign(new Error('Invalid JSON object'), { statusCode: 400 })); } });
    req.on('error', reject);
  });
}
function createServer({ studio = new Studio(), openAIAdapter = makeOpenAIAdapter() } = {}) {
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const host = req.headers.host || '';
      if (!/^(localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/.test(host)) return json(res, 403, { error: 'Localhost-only server' });
      const origin = req.headers.origin;
      if (origin) {
        let source;
        try { source = new URL(origin); } catch { return json(res, 403, { error: 'Invalid origin' }); }
        if (source.host !== host || source.protocol !== 'http:') return json(res, 403, { error: 'Cross-origin requests denied' });
      }
      if (req.method === 'GET' && url.pathname === '/api/status') {
        return json(res, 200, { ...studio.status(), openAIAvailable: !!openAIAdapter, note: 'SIMULATOR ONLY' });
      }
      if (req.method === 'POST' && url.pathname.startsWith('/api/')) {
        if (req.headers['x-octolang-local'] !== 'studio') return json(res, 403, { error: 'Studio request header required' });
        const body = await parseJson(req);
        if (url.pathname === '/api/compose') return json(res, 200, await studio.compose(body.intent, body.mode, openAIAdapter));
        if (url.pathname === '/api/compile') return json(res, 200, studio.setSource(body.source, 'manual'));
        if (url.pathname === '/api/enroll') return json(res, 200, studio.enroll(body.pairingCode, body.publicKeySpki));
        if (url.pathname === '/api/review') return json(res, 200, studio.acceptReview(body.review));
        if (url.pathname === '/api/prepare') return json(res, 200, studio.prepare(body));
        if (url.pathname === '/api/steward-approve') return json(res, 200, studio.approve(body.id));
        if (url.pathname === '/api/simulate') return json(res, 200, await studio.simulate(body.id));
        return json(res, 404, { error: 'Unknown API route' });
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'Method not supported' });
      const filename = { '/': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css' }[url.pathname];
      if (!filename) return json(res, 404, { error: 'Not found' });
      const filepath = path.join(ROOT, filename);
      const data = fs.readFileSync(filepath);
      res.writeHead(200, { ...headers, 'content-type': MIME[path.extname(filename)], 'content-length': data.length });
      res.end(req.method === 'HEAD' ? undefined : data);
    } catch (e) {
      const status = e.statusCode || (/OctoLang compile error|SyntaxError/.test(e.message) || e instanceof SyntaxError ? 400 : 500);
      // Avoid exposing provider secrets and stack traces over HTTP.
      json(res, status, { error: status === 500 ? (e.message.startsWith('AI provider') ? e.message : 'Internal studio error') : e.message });
      if (status === 500) console.error('[OctoLang Studio]', e.message);
    }
  });
  return { server, studio };
}
if (require.main === module) {
  const { server, studio } = createServer();
  const port = Number(process.env.OCTOLANG_PORT || 8787);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Invalid OCTOLANG_PORT');
  server.listen(port, '127.0.0.1', () => {
    console.log(`\nOctoLang Studio v0.2: http://127.0.0.1:${port}`);
    console.log(`PAIRING CODE (local demo reviewer): ${studio.pairingCode}`);
    console.log('Simulator only. Never enter a wallet seed, custody key or sensitive secret.\n');
  });
}
module.exports = { createServer };
