'use strict';
const $ = id => document.getElementById(id);
let current = null;
let actionId = null;
let reviewerKey = null;
const utf8 = new TextEncoder();
const bytesToB64 = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes)));
const canonical = x => {
  if (x === null || ['string', 'boolean', 'number'].includes(typeof x)) return JSON.stringify(x);
  if (Array.isArray(x)) return `[${x.map(canonical).join(',')}]`;
  if (x && typeof x === 'object') return `{${Object.keys(x).sort().map(k => `${JSON.stringify(k)}:${canonical(x[k])}`).join(',')}}`;
  throw new Error('Unserialisable signed data');
};
async function post(route, body) {
  const response = await fetch('/api/' + route, { method:'POST', headers: { 'content-type':'application/json', 'x-octolang-local':'studio' }, body: JSON.stringify(body) });
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || `HTTP ${response.status}`);
  return value;
}
function notify(message, error = false) { $('notice').textContent = message; $('notice').classList.toggle('error', error); }
function showDraft(draft) {
  current = draft;
  actionId = null;
  $('source').value = draft.source;
  $('draftStatus').textContent = draft.approved ? 'Reviewed and signed' : 'Compiled · awaiting human review';
  $('reviewStatus').textContent = draft.approved ? 'Signed policy' : 'Awaiting review';
  const p = draft.policy;
  const ada = x => (Number(x) / 1e6).toString() + ' ADA';
  $('summary').textContent = [
    `Intent: ${p.intent}`,
    `Action / agent: ${p.action} / ${p.agents.map(a => a.name).join(', ')}`,
    `Spending limit: ${p.agents.map(a => ada(a.limitLovelace)).join(', ')}`,
    `Human escalation: > ${ada(p.approval.aboveLovelace)} by ${p.approval.signer}`,
    `Evidence: signed ${p.contexts.map(c => c.claim + ' from ' + c.issuer).join(', ')}`,
    `Context maximum age: ${p.contexts.map(c => (c.maxAgeMs / 86400000) + ' days').join(', ')}`,
    `Before action: require ${p.requiredContext}; after: ${p.expectedReceipt} receipt`,
    'Delegation: disabled | On violation: DENY',
    `SHA-256 policy digest: ${p.digest}`,
    `Origin: ${draft.origin} | Approval: ${draft.approved ? 'SIGNED' : 'NOT SIGNED'}`,
    '',
    'IMPORTANT: the demo claim issuer and approver are temporary MOCK signers.'
  ].join('\n');
  $('decision').textContent = 'No action prepared for this score.';
}
function requireCurrent() {
  if (!current) throw new Error('Generate or compile a score first.');
  if ($('source').value !== current.source) throw new Error('You edited the source. Validate & compile edits before continuing.');
}
function openDb() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open('octolang-review-v0.2', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('keys');
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function loadKey() {
  try {
    const db = await openDb();
    const v = await new Promise((resolve,reject) => {
      const tx = db.transaction('keys', 'readonly');
      const q = tx.objectStore('keys').get('local-reviewer');
      q.onsuccess = () => resolve(q.result || null); q.onerror = () => reject(q.error);
    });
    db.close(); return v;
  } catch { return null; }
}
async function storeKey(value) {
  try {
    const db = await openDb();
    await new Promise((resolve,reject) => {
      const tx = db.transaction('keys','readwrite');
      tx.objectStore('keys').put(value, 'local-reviewer');
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch { notify('Browser key storage unavailable; private key works only until page reload.'); }
}
async function getOrCreateKey() {
  if (reviewerKey) return reviewerKey;
  reviewerKey = await loadKey();
  if (reviewerKey) return reviewerKey;
  const pair = await crypto.subtle.generateKey({ name:'Ed25519' }, false, ['sign', 'verify']);
  reviewerKey = { privateKey: pair.privateKey, spki: bytesToB64(await crypto.subtle.exportKey('spki', pair.publicKey)) };
  await storeKey(reviewerKey);
  return reviewerKey;
}
async function signedReview(policyDigest) {
  const key = await getOrCreateKey();
  const payload = { schema:'octolang.review.v1', reviewer:'local-reviewer', scoreDigest:policyDigest,
    issuedAt:new Date(Date.now()-1000).toISOString(), expiresAt:new Date(Date.now()+3600000).toISOString(), nonce:crypto.randomUUID() };
  const signature = await crypto.subtle.sign('Ed25519', key.privateKey, utf8.encode(canonical(payload)));
  return { payload, signature: bytesToB64(signature) };
}
function bind(id, fn) {
  $(id).addEventListener('click', () => Promise.resolve().then(fn).catch(e => notify(e.message, true)));
}
bind('compose', async () => {
  notify('Composing a new unapproved score…');
  const result = await post('compose', { intent:$('intent').value, mode:$('mode').value });
  showDraft(result); notify('Draft compiled. Read its scope, evidence requirements and limits before signing.');
});
bind('compile', async () => {
  const result = await post('compile', { source:$('source').value });
  showDraft(result); notify('Validated and compiled. Any change to the source requires a fresh signature.');
});
bind('enroll', async () => {
  const key = await getOrCreateKey();
  const result = await post('enroll', { pairingCode:$('pairing').value.trim().toUpperCase(), publicKeySpki:key.spki });
  $('pairing').value = '';
  $('reviewStatus').textContent = 'Reviewer paired · ' + result.keyFingerprint;
  notify('Browser reviewer key is paired to this local server session.');
});
bind('review', async () => {
  requireCurrent();
  if (!confirm('Have you inspected the permissions, spending limit, issuer and approval threshold? Sign exactly this compiled digest?\n\n' + current.policy.digest)) return;
  const result = await post('review', { review:await signedReview(current.policy.digest) });
  current.approved = true;
  $('draftStatus').textContent = 'Reviewed and signed';
  $('reviewStatus').textContent = 'Signed through ' + result.expiresAt;
  notify('Signed review accepted. The runtime now checks this exact policy digest.');
});
bind('prepare', async () => {
  requireCurrent();
  const result = await post('prepare', { amount:$('amount').value.trim(), target:$('target').value.trim() });
  actionId = result.id;
  $('decision').textContent = JSON.stringify({ request:result.request, decision:result.decision, evidence:result.source }, null, 2);
  notify(result.decision.status === 'ESCALATE' ? 'A separate mock steward approval is required.' : 'Pre-execution check complete: ' + result.decision.status);
});
bind('steward', async () => {
  requireCurrent(); if (!actionId) throw new Error('Prepare an action first.');
  if (!confirm('Generate a DEMO-only signed approval from the local mock steward?')) return;
  const result = await post('steward-approve', { id:actionId });
  $('decision').textContent = JSON.stringify(result, null, 2);
  notify('The temporary demo steward signed this exact request digest.');
});
bind('simulate', async () => {
  requireCurrent(); if (!actionId) throw new Error('Prepare an action first.');
  const result = await post('simulate', { id:actionId });
  $('decision').textContent = JSON.stringify(result, null, 2);
  notify(result.decision.status === 'ALLOW' ? 'Simulated only. Signed mock receipt returned; no real-world action.' : `No action: ${result.decision.status}.`);
});
async function init() {
  const status = await fetch('/api/status').then(r => r.json());
  if (status.draft) showDraft({ ...status.draft, approved:status.approved });
  $('mode').querySelector('option[value="openai"]').disabled = !status.openAIAvailable;
  if (!status.openAIAvailable) $('mode').title = 'Set OPENAI_API_KEY on the server for optional AI composing';
  if (status.enrolled) $('reviewStatus').textContent = 'Local reviewer paired; approval ' + (status.approved ? 'active' : 'pending');
  await loadKey().then(k => { reviewerKey = k; });
}
init().catch(e => notify(e.message, true));
