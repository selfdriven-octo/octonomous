'use strict';
const crypto = require('node:crypto');
const { compile, amountToLovelace } = require('../src/compiler');
const { signed, digest } = require('../src/canonical');
const { evaluate, simulate, verifyReview } = require('../src/runtime');
const { propose } = require('../src/authoring');
const template = require('node:fs').readFileSync(require('node:path').join(__dirname, '../examples/community-supplies.octo'), 'utf8');

function iso(minutes = 0) { return new Date(Date.now() + minutes * 60000).toISOString(); }
function bad(message, status = 400) { const err = new Error(message); err.statusCode = status; throw err; }
function makeOfflineDraft(intent) {
  if (typeof intent !== 'string' || !intent.trim() || intent.length > 500) bad('Enter a goal of 1–500 characters.');
  if (!/\b(buy|purchase|purchasing|procure|order|spend)\b/i.test(intent)) {
    bad('The offline composer only demonstrates purchase intents. Describe buying/purchasing supplies, or use the optional AI mode.');
  }
  // Fixed policy template; no free-form LLM interpretation or discovered authority.
  return template.replace('"Purchase materials for a community learning project"', JSON.stringify(intent.trim()));
}
class Studio {
  constructor({ pairingCode = crypto.randomBytes(5).toString('hex').toUpperCase() } = {}) {
    this.pairingCode = pairingCode;
    this.draft = null;
    this.review = null;
    this.pending = new Map();
    this.usedNonces = new Set();
    this.issuer = crypto.generateKeyPairSync('ed25519');
    this.approver = crypto.generateKeyPairSync('ed25519');
    this.executor = crypto.generateKeyPairSync('ed25519');
    this.trusted = {
      reviewers: {}, issuers: { 'community-registry': this.issuer.publicKey },
      approvers: { 'project-steward': this.approver.publicKey },
      executors: { 'mock-payment': this.executor.publicKey }
    };
  }
  setSource(source, origin = 'manual') {
    if (typeof source !== 'string') bad('Source must be a string');
    const policy = compile(source);
    // Any content edit invalidates approval and pending actions, even if the digest is unchanged.
    if (!this.draft || this.draft.source !== source) {
      this.review = null; this.pending.clear();
    }
    this.draft = { source, policy, origin };
    return { source, policy, origin, approved: !!this.review };
  }
  async compose(intent, mode = 'offline', modelAdapter) {
    if (typeof intent !== 'string' || !intent.trim() || intent.length > 500) bad('Enter a goal of 1–500 characters.');
    let source;
    if (mode === 'offline') source = makeOfflineDraft(intent);
    else if (mode === 'openai') {
      if (typeof modelAdapter !== 'function') bad('OpenAI composer is not enabled on this server.', 503);
      source = (await propose({ userIntent: intent, modelAdapter })).draft;
    } else bad('Unsupported composer mode');
    return this.setSource(source, mode);
  }
  enroll(pairingCode, publicKeySpki) {
    if (this.trusted.reviewers['local-reviewer']) bad('Reviewer already paired. Restart the local studio to re-pair.', 409);
    if (typeof pairingCode !== 'string' || pairingCode !== this.pairingCode) bad('Invalid pairing code.', 403);
    if (typeof publicKeySpki !== 'string' || !/^[a-zA-Z0-9+/]+={0,2}$/.test(publicKeySpki) || publicKeySpki.length > 256) bad('Invalid reviewer key.');
    let key;
    try {
      key = crypto.createPublicKey({ key: Buffer.from(publicKeySpki, 'base64'), type: 'spki', format: 'der' });
      if (key.asymmetricKeyType !== 'ed25519') bad('Reviewer key must be Ed25519.');
    } catch { bad('Invalid Ed25519 public key.'); }
    this.trusted.reviewers['local-reviewer'] = key;
    this.pairingCode = null;
    return { reviewer: 'local-reviewer', enrolled: true, keyFingerprint: digest(publicKeySpki).slice(0, 20) };
  }
  acceptReview(review) {
    if (!this.draft) bad('Compile a score before reviewing.');
    if (!this.trusted.reviewers['local-reviewer']) bad('Pair a human reviewer first.', 403);
    if (!verifyReview(this.draft.policy, review, this.trusted, Date.now()) || review.payload.reviewer !== 'local-reviewer') bad('Signature invalid or policy digest mismatch.', 403);
    this.review = review;
    this.pending.clear();
    return { approved: true, policyDigest: this.draft.policy.digest, reviewer: 'local-reviewer', expiresAt: review.payload.expiresAt };
  }
  approved() { return !!this.draft && !!this.review && !!verifyReview(this.draft.policy, this.review, this.trusted, Date.now()); }
  status() { return { draft: this.draft && { ...this.draft }, approved: this.approved(), enrolled: !!this.trusted.reviewers['local-reviewer'], pendingCount: this.pending.size }; }
  requireApproved() { if (!this.approved()) bad('A valid human-signed review is required.', 403); }
  prepare({ amount, target }) {
    this.requireApproved();
    if (typeof amount !== 'string') bad('ADA amount must be a decimal string.');
    amountToLovelace(amount, 'ADA');
    if (typeof target !== 'string' || !/^[a-zA-Z0-9_.:-]{1,80}$/.test(target)) bad('Supplier target must be 1–80 safe characters.');
    const p = this.draft.policy;
    const request = { schema: 'octolang.action-request.v1', scoreDigest: p.digest,
      agent: 'buyer', capability: 'purchase', amount, currency: 'ADA', target,
      nonce: crypto.randomUUID(), issuedAt: iso(-1), expiresAt: iso(4) };
    // MOCK registry: the signature only attests to a locally invented claim.
    const claim = signed({ schema: 'octolang.claim.v1', issuer: 'community-registry',
      claim: 'supplier.accredited', subject: target, status: 'VERIFIED',
      issuedAt: iso(-1), expiresAt: iso(40), nonce: crypto.randomUUID() }, this.issuer.privateKey);
    const id = crypto.randomUUID();
    const entry = { id, request, claims: [claim], approvals: [] };
    this.pending.set(id, entry);
    if (this.pending.size > 100) this.pending.delete(this.pending.keys().next().value);
    return { id, request, decision: this.assess(entry), source: 'SIMULATED_REGISTRY_CLAIM' };
  }
  get(id) {
    if (typeof id !== 'string' || !this.pending.has(id)) bad('Unknown or stale action proposal.', 404);
    const entry = this.pending.get(id);
    if (entry.request.scoreDigest !== this.draft?.policy.digest) bad('Proposal is from an older score.', 409);
    return entry;
  }
  assess(entry) {
    return evaluate({ policy: this.draft.policy, request: entry.request, claims: entry.claims,
      approvals: entry.approvals, review: this.review, trusted: this.trusted, usedNonces: this.usedNonces });
  }
  approve(id) {
    this.requireApproved();
    const entry = this.get(id);
    const decision = this.assess(entry);
    if (decision.status !== 'ESCALATE') bad(`No steward approval possible (${decision.status}: ${decision.reason}).`, 409);
    // Separately clicked MOCK steward: NOT a real independent approval process.
    const approval = signed({ schema: 'octolang.approval.v1', approver: 'project-steward',
      scoreDigest: this.draft.policy.digest, requestDigest: digest(entry.request),
      issuedAt: iso(-1), expiresAt: iso(10), nonce: crypto.randomUUID() }, this.approver.privateKey);
    entry.approvals.push(approval);
    return { id, decision: this.assess(entry), mockStewardApproved: true };
  }
  async simulate(id) {
    this.requireApproved();
    const entry = this.get(id);
    return simulate({ policy: this.draft.policy, request: entry.request, claims: entry.claims,
      approvals: entry.approvals, review: this.review, trusted: this.trusted,
      usedNonces: this.usedNonces,
      executor: async ({ requestDigest, scoreDigest, type }) => signed({
        schema: 'octolang.execution-receipt.v1', executor: 'mock-payment', type,
        requestDigest, scoreDigest, outcome: 'SIMULATED', issuedAt: iso(-1), expiresAt: iso(1), nonce: crypto.randomUUID()
      }, this.executor.privateKey) });
  }
}
module.exports = { Studio, makeOfflineDraft };
