# OctoLang architecture and fit with Octonomous

## Boundary diagram

```mermaid
flowchart TB
  H[Human intent] --> M[AI composer: untrusted draft]
  M --> S[.octo source]
  S --> C[Parser + semantic compiler]
  C --> IR[Canonical IR + SHA256 digest]
  IR --> R[Human reviewer + independent signing service]
  R --> V[Verified Code Controller - deterministic]
  E[Externally verified context claims] --> V
  A[Requested action + evidence of principal mandate] --> V
  G[Signer/governance approvals] --> V
  V -->|ALLOW only| X[Constrained executor / external custody]
  X --> Q[Signed execution receipt + audit]
  Q --> F[Optional OFP / Cardano / Midnight adapter in future]
```

In this **prototype**, the reviewer/issuer/executor keys are generated inside a demo helper, human review is simulated, and the executor *only signs a simulated receipt*. Real VCC, identity, governance, signing services and custody are NOT supplied.

## Relationship to Octonomous

- **Score** — declarative composition: desired goal, context, constraints, participants, outcome evidence.
- **Composer** — may use an LLM to propose a score and candidate action; cannot confer authority.
- **Conductor** — future process coordinator; not present here.
- **VCC** — independent decision point using current signed mandates, fresh VCG evidence and the approved score digest.
- **VCG** — future structured evidence graph with provenance/freshness/conflicts. v0.1 uses a single signed claim fixture, not a VCG implementation.
- **OFP** — independent federation transport, signature, governance, replay and treaty semantics. Future adapter should reuse existing OFP rather than silently invent a parallel protocol.
- **Proof-carrying data** — signed claim/review/approval/receipt objects in the prototype. ZK proof systems including Groth16 are optional later for specific formally defined relations.

## Next development milestones

**0.2:** formal grammar; typed contexts/resources; signed action requests and principal mandates; independent human review UI; hermetic policy bundle verifier; persistent replay / idempotency; mock orchestration.

**0.3:** independently deployed VCC with provisioned trust roots, revocation, audit, bounded capability tokens, external execution gateway and explicit receipts; integrated VCG object proofs and provenance.

**0.4:** OFP envelope and governance-proof adapter with interoperability and adversarial tests, separate proof-plugin API (Groth16 with specified circuit semantics), optional Cardano/Midnight modules.

All deployment milestones are engineering targets, not promises of certified security.
