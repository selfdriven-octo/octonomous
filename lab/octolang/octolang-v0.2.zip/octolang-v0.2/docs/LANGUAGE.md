# OctoLang v0.1 language specification (experimental)

**Goal:** a compact declarative score for machine-authored policies subject to explicit human review, suitable as an input to a future deterministic Octonomous controller.

## Supported declarations

| Syntax | Meaning |
|---|---|
| `score identifier { ... }` | Named score container. |
| `intent "text"` | Human-readable goal; never grants authority on its own. |
| `context name { claim "key" issuer "id" status VERIFIED max_age 30d }` | Required claim from configured issuer, subject bound to exact request target. Freshness bound and signed evidence required. `m`, `h`, `d` accepted for max age. |
| `agent name { capability "purchase" limit 100 ADA delegate false }` | Local simulated capability. This is not cryptographic agent authentication. |
| `before purchase { require name approve "signer" when amount > 50 ADA }` | Local deterministic precondition, with signed action-bound approval strictly above threshold. |
| `after purchase { require receipt "payment" record evidence }` | Require signed simulated receipt from trusted mock executor. |
| `on violation DENY` | Fail closed on unrecognised/unsupported violation. |

## Semantic restrictions

- Exactly one `intent`, `before`, `after`, `on violation`; at least one context and agent.
- `before` and `after` actions must match. The agent capability must match this action.
- `before.require` must reference a declared context.
- `delegate false` is mandatory. The compiler rejects delegation.
- `ADA` only, with at most six decimals converted to lovelace as decimal strings (no JavaScript floating point accounting).
- `VERIFIED` is a **required claim state**, not a fact the compiler establishes. Runtime separately checks Ed25519 evidence against trusted issuer keys.
- `on violation DENY` mandatory; no arbitrary script execution, imports, network calls, loops or unsafe evaluation.
- A compiled policy includes `schema: octolang.policy.v0.1` and a `digest` of its canonical policy structure. Comments and whitespace do not change the digest.
- `approve ... when amount > 50 ADA` means a request of exactly 50 ADA does not need this approval. Higher requests require a signature valid for the exact request and score digest.
- The human reviewer receipt must be signed over the exact policy digest, and within the time window.
- Other operations, multiple actions, logical combinations, proofs, federation and full score composition are future work.

## Wire objects for local demo

- `octolang.review.v1`: `reviewer, scoreDigest, issuedAt, expiresAt, nonce`
- `octolang.claim.v1`: `issuer, claim, subject, status, issuedAt, expiresAt, nonce`
- `octolang.approval.v1`: `approver, scoreDigest, requestDigest, issuedAt, expiresAt, nonce`
- `octolang.action-request.v1`: `scoreDigest, agent, capability, amount, currency, target, nonce, issuedAt, expiresAt`
- `octolang.execution-receipt.v1`: `executor, type, requestDigest, scoreDigest, outcome=SIMULATED, issuedAt, expiresAt, nonce`

Signed objects use `{ payload, signature }` where `signature` is Ed25519 over canonicalized payload bytes, base64 encoded. Keys belong to the external supplied trust map. The action request itself is **not signed** in this demo, which is a major production limitation. No data format here claims OFP interoperability.
