'use strict';
const crypto = require('node:crypto');

// Disallows ambiguous/non-JSON representations; keys are UTF-16 sorted consistently.
function canonical(value) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype) {
    return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  }
  throw new TypeError('Unsupported value in canonical payload');
}
function digest(value) {
  return crypto.createHash('sha256').update(canonical(value), 'utf8').digest('hex');
}
function signed(payload, privateKey) {
  return { payload, signature: crypto.sign(null, Buffer.from(canonical(payload)), privateKey).toString('base64') };
}
function verifiedSigned(object, key) {
  if (!object || !object.payload || typeof object.signature !== 'string' || !key) return false;
  try {
    const signature = Buffer.from(object.signature, 'base64');
    if (signature.length !== 64 || signature.toString('base64') !== object.signature) return false;
    return crypto.verify(null, Buffer.from(canonical(object.payload)), key, signature);
  } catch { return false; }
}
module.exports = { canonical, digest, signed, verifiedSigned };
