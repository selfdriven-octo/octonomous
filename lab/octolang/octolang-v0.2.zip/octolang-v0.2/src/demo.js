'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { compile } = require('./compiler');
const { signed, digest } = require('./canonical');
const { evaluate, simulate } = require('./runtime');

const minutes = n => new Date(Date.now() + n * 60000).toISOString();
const randomNonce = () => crypto.randomUUID();
const kp = () => crypto.generateKeyPairSync('ed25519');
function demoSetup(source = fs.readFileSync(path.join(__dirname, '..', 'examples', 'community-supplies.octo'), 'utf8')) {
  const policy = compile(source);
  // Private keys exist ONLY in this volatile demonstration, never in the policy/runtime.
  const owner = kp(), issuer = kp(), approver = kp(), executorKey = kp();
  const trusted = {
    reviewers: { 'community-owner': owner.publicKey },
    issuers: { 'community-registry': issuer.publicKey },
    approvers: { 'project-steward': approver.publicKey },
    executors: { 'mock-payment': executorKey.publicKey }
  };
  const review = signed({ schema: 'octolang.review.v1', reviewer: 'community-owner', scoreDigest: policy.digest,
    issuedAt: minutes(-1), expiresAt: minutes(60), nonce: randomNonce() }, owner.privateKey);
  function request(amount) {
    return { schema: 'octolang.action-request.v1', scoreDigest: policy.digest, agent: 'buyer', capability: 'purchase',
      amount: String(amount), currency: 'ADA', target: 'supplier-42', nonce: randomNonce(),
      issuedAt: minutes(-1), expiresAt: minutes(4) };
  }
  function claim(subject = 'supplier-42') {
    return signed({ schema: 'octolang.claim.v1', issuer: 'community-registry', claim: 'supplier.accredited',
      subject, status: 'VERIFIED', issuedAt: minutes(-1), expiresAt: minutes(40), nonce: randomNonce() }, issuer.privateKey);
  }
  function approval(req) {
    return signed({ schema: 'octolang.approval.v1', approver: 'project-steward', scoreDigest: policy.digest,
      requestDigest: digest(req), issuedAt: minutes(-1), expiresAt: minutes(10), nonce: randomNonce() }, approver.privateKey);
  }
  async function mockExecutor({ requestDigest, scoreDigest, type }) {
    return signed({ schema: 'octolang.execution-receipt.v1', executor: 'mock-payment', type,
      requestDigest, scoreDigest, outcome: 'SIMULATED', issuedAt: minutes(-1), expiresAt: minutes(1),
      nonce: randomNonce() }, executorKey.privateKey);
  }
  return { policy, trusted, review, request, claim, approval, mockExecutor };
}
async function demo() {
  const d = demoSetup();
  const request = d.request('75');
  const claims = [d.claim()];
  const approvals = [d.approval(request)];
  const outcome = await simulate({ policy: d.policy, request, claims, approvals, review: d.review,
    trusted: d.trusted, usedNonces: new Set(), executor: d.mockExecutor });
  const tooMuch = evaluate({ policy: d.policy, request: d.request('110'), claims, approvals: [],
    review: d.review, trusted: d.trusted });
  const needsApproval = evaluate({ policy: d.policy, request: d.request('75'), claims, approvals: [],
    review: d.review, trusted: d.trusted });
  console.log(JSON.stringify({ score: d.policy.score, scoreDigest: d.policy.digest,
    permitted: { decision: outcome.decision, simulatedReceiptVerified: !!outcome.simulation },
    overLimit: tooMuch, missingApproval: needsApproval,
    note: 'SIMULATED ONLY: no wallet, payment, chain or external service invoked.' }, null, 2));
}
module.exports = { demoSetup, demo };
