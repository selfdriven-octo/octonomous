'use strict';
const { compile } = require('./compiler');

// Model-generated text is always UNTRUSTED; no model output becomes executable authority.
const SYSTEM_INSTRUCTIONS = `You are a DRAFTING assistant for OctoLang v0.1.
Return ONLY syntactically valid .octo text. Never claim the policy is approved.
The human reviewer will independently check intent, every permission, every source,
limits, escalation thresholds, evidence requirements and the compiled digest.
Supported grammar (exactly one of each named block):
score name {
  intent "human-readable goal"
  context source_name { claim "claim.key" issuer "trusted-issuer" status VERIFIED max_age 30d }
  agent actor_name { capability "purchase" limit 100 ADA delegate false }
  before purchase { require source_name approve "trusted-steward" when amount > 50 ADA }
  after purchase { require receipt "payment" record evidence }
  on violation DENY
}
Only ADA supported, delegate must be false. Untrusted claims must never be called verified
without an independent signed evidence verifier configured in the runtime.`;

async function propose({ userIntent, modelAdapter }) {
  if (typeof userIntent !== 'string' || !userIntent.trim() || userIntent.length > 2000) {
    throw new TypeError('userIntent must be a nonempty string up to 2000 chars');
  }
  if (typeof modelAdapter !== 'function') throw new TypeError('modelAdapter(prompt) is required');
  const raw = await modelAdapter({ system: SYSTEM_INSTRUCTIONS, user: userIntent });
  if (typeof raw !== 'string') throw new TypeError('Model must return plain .octo text');
  const compiled = compile(raw); // reject unsafe, unsupported, malformed or incomplete drafts
  return { draft: raw, compiled, status: 'AWAITING_HUMAN_REVIEW', digest: compiled.digest };
}
module.exports = { SYSTEM_INSTRUCTIONS, propose };
