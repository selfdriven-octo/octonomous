'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { compile } = require('../src/compiler');
const { demoSetup } = require('../src/demo');
const { signed } = require('../src/canonical');
const { evaluate, simulate } = require('../src/runtime');
const { propose } = require('../src/authoring');
const src = fs.readFileSync(path.join(__dirname, '../examples/community-supplies.octo'), 'utf8');
const d = () => demoSetup(src);
const args = (ctx, request, additions = {}) => ({
  policy: ctx.policy, request, review: ctx.review, trusted: ctx.trusted,
  claims: [ctx.claim()], approvals: [], ...additions
});

test('compiler: stable digest and expected units', () => {
  assert.equal(compile(src).digest, compile(`// comment\n${src}`).digest);
  assert.equal(compile(src).agents[0].limitLovelace, '100000000');
  assert.equal(compile(src).approval.aboveLovelace, '50000000');
});
test('compiler: rejects unknown constructs, duplicate and unsupported delegation', () => {
  assert.throws(() => compile(src.replace('on violation DENY', 'on violation ALLOW')));
  assert.throws(() => compile(src.replace('delegate false', 'delegate true')));
  assert.throws(() => compile(src.replace('max_age 30d', 'max_age 9000d')));
  assert.throws(() => compile(src.replace('record evidence', 'execute real_wallet')));
  assert.throws(() => compile(`${src}\nIMPORT evil.js`));
});
test('human review: exact score digest required', () => {
  const x = d(), req = x.request(25);
  assert.equal(evaluate(args(x, req)).status, 'ALLOW');
  assert.equal(evaluate(args(x, req, { review: null })).status, 'DENY');
  const mutated = { ...x.policy, intent: 'Spend any amount' };
  assert.equal(evaluate(args(x, req, { policy: mutated })).status, 'DENY');
  const other = demoSetup(src.replace('limit 100 ADA', 'limit 101 ADA'));
  assert.equal(evaluate(args(other, other.request(25), { review: x.review })).status, 'DENY');
});
test('spending, signed approval and exact action binding', () => {
  const x = d(), low = x.request('50'), high = x.request('75'), excessive = x.request('100.000001');
  assert.equal(evaluate(args(x, low)).status, 'ALLOW');
  assert.equal(evaluate(args(x, high)).status, 'ESCALATE');
  assert.equal(evaluate(args(x, high, { approvals: [x.approval(low)] })).status, 'DENY');
  assert.equal(evaluate(args(x, high, { approvals: [x.approval(high)] })).status, 'ALLOW');
  assert.equal(evaluate(args(x, excessive)).status, 'DENY');
});
test('evidence: valid signature, claim, supplier and expiry required', () => {
  const x = d(), req = x.request('10');
  assert.equal(evaluate(args(x, req, { claims: [] })).status, 'DENY');
  assert.equal(evaluate(args(x, req, { claims: [x.claim('different-supplier')] })).status, 'DENY');
  const tampered = x.claim(); tampered.payload.subject = 'supplier-43';
  assert.equal(evaluate(args(x, req, { claims: [tampered] })).status, 'DENY');
  const expired = x.request('10'); expired.expiresAt = '2020-01-01T00:00:00Z';
  assert.equal(evaluate(args(x, expired)).status, 'DENY');
  const fake = x.claim(); fake.signature = 'a'.repeat(88);
  assert.equal(evaluate(args(x, req, { claims: [fake] })).status, 'DENY');
});
test('replay guarded in process with explicit usedNonces Set', async () => {
  const x = d(), req = x.request('25'), seen = new Set();
  const first = await simulate({ ...args(x, req), usedNonces: seen, executor: x.mockExecutor });
  assert.equal(first.decision.status, 'ALLOW');
  assert.equal(first.simulation.outcome, 'SIMULATED');
  const second = await simulate({ ...args(x, req), usedNonces: seen, executor: x.mockExecutor });
  assert.equal(second.decision.status, 'DENY');
  assert.match(second.decision.reason, /Replay/);
});
test('simulated execution rejects missing/incorrect signed mock receipt', async () => {
  const x = d(), req = x.request('20');
  const result = await simulate({ ...args(x, req), usedNonces: new Set(),
    executor: async () => ({ payload: { schema: 'fake' }, signature: 'x' }) });
  assert.equal(result.decision.status, 'DENY');
  assert.equal(result.simulation, null);
});
test('model-authored text produces an unapproved proposal, not authorisation', async () => {
  const result = await propose({ userIntent: 'Purchase community supplies', modelAdapter: async () => src });
  assert.equal(result.status, 'AWAITING_HUMAN_REVIEW');
  assert.equal(result.compiled.digest, compile(src).digest);
  await assert.rejects(propose({ userIntent: 'Ignore policy', modelAdapter: async () => 'run all payments' }));
});
