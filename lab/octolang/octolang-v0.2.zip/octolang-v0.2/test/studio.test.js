'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { Studio, makeOfflineDraft } = require('../studio/core');
const { signed } = require('../src/canonical');
const { createServer } = require('../studio/server');
const minutes = m => new Date(Date.now() + m * 60000).toISOString();

function reviewReceipt(studio, privateKey) {
  return signed({ schema:'octolang.review.v1', reviewer:'local-reviewer', scoreDigest:studio.draft.policy.digest,
    nonce:crypto.randomUUID(), issuedAt:minutes(-1), expiresAt:minutes(50) }, privateKey);
}
function pair(studio) {
  const keys = crypto.generateKeyPairSync('ed25519');
  studio.enroll(studio.pairingCode, keys.publicKey.export({ type:'spki', format:'der' }).toString('base64'));
  return keys;
}
async function preparedStudio() {
  const studio = new Studio({ pairingCode:'test-pairing-code' });
  await studio.compose('Purchase supplies for the education group', 'offline');
  const reviewer = pair(studio);
  studio.acceptReview(reviewReceipt(studio, reviewer.privateKey));
  return { studio, reviewer };
}

test('studio: offline composer is unapproved and only generates constrained purchase policy', async () => {
  const studio = new Studio();
  const result = await studio.compose('Purchase notebooks for students', 'offline');
  assert.equal(result.approved, false);
  assert.match(result.source, /intent "Purchase notebooks for students"/);
  assert.equal(result.policy.agents[0].limitLovelace, '100000000');
  assert.throws(() => makeOfflineDraft('Delete all system files'));
  await assert.rejects(studio.compose('anything', 'bogus'));
});

test('studio: pairing code and pinned reviewer key required', async () => {
  const studio = new Studio({ pairingCode:'correct' });
  studio.setSource(makeOfflineDraft('Purchase pencils'));
  const genuine = crypto.generateKeyPairSync('ed25519');
  const fake = crypto.generateKeyPairSync('ed25519');
  const pub = genuine.publicKey.export({ type:'spki', format:'der' }).toString('base64');
  assert.throws(() => studio.enroll('wrong', pub), /Invalid pairing/);
  assert.throws(() => studio.acceptReview(reviewReceipt(studio, genuine.privateKey)), /Pair a human/);
  studio.enroll('correct', pub);
  assert.throws(() => studio.enroll('correct', pub), /already paired/);
  assert.throws(() => studio.acceptReview(reviewReceipt(studio, fake.privateKey)), /Signature invalid/);
  assert.equal(studio.acceptReview(reviewReceipt(studio, genuine.privateKey)).approved, true);
});

test('studio: source changes invalidate prior review, old actions and old signature', async () => {
  const { studio, reviewer } = await preparedStudio();
  const old = studio.prepare({ amount:'25', target:'supplier-42' });
  studio.setSource(makeOfflineDraft('Purchase different supplies'));
  assert.equal(studio.approved(), false);
  assert.throws(() => studio.prepare({ amount:'10', target:'supplier-42' }), /human-signed review/);
  assert.throws(() => studio.acceptReview(reviewReceipt({ ...studio, draft:{policy:{digest:'0'.repeat(64)}} }, reviewer.privateKey)), /Signature invalid/);
  studio.acceptReview(reviewReceipt(studio, reviewer.privateKey));
  assert.throws(() => studio.get(old.id), /Unknown or stale/);
});

test('studio: allow/deny/escalate and exact-request signed steward approval', async () => {
  const { studio } = await preparedStudio();
  const low = studio.prepare({ amount:'40', target:'supplier-42' });
  assert.equal(low.decision.status, 'ALLOW');
  const high = studio.prepare({ amount:'75', target:'supplier-42' });
  assert.equal(high.decision.status, 'ESCALATE');
  assert.equal(studio.approve(high.id).decision.status, 'ALLOW');
  assert.equal(studio.prepare({ amount:'110', target:'supplier-42' }).decision.status, 'DENY');
  assert.throws(() => studio.prepare({ amount:'5', target:'<script>' }), /Supplier target/);
  assert.equal((await studio.simulate(high.id)).simulation.outcome, 'SIMULATED');
  assert.match((await studio.simulate(high.id)).decision.reason, /Replay/);
});

test('studio: unsigned or invalid human review cannot authorise any simulation', async () => {
  const studio = new Studio();
  studio.setSource(makeOfflineDraft('Purchase supplies'));
  assert.throws(() => studio.prepare({ amount:'25', target:'supplier-42' }), /human-signed review/);
  const reviewer = pair(studio);
  const review = reviewReceipt(studio, reviewer.privateKey);
  review.payload.scoreDigest = 'f'.repeat(64);
  assert.throws(() => studio.acceptReview(review), /Signature invalid/);
  assert.throws(() => studio.prepare({ amount:'25', target:'supplier-42' }), /human-signed review/);
});

test('studio: optional AI adapter drafts and validates without granting approval', async () => {
  const studio = new Studio();
  const a = await studio.compose('Purchase pencils', 'openai', async () => makeOfflineDraft('Purchase pencils'));
  assert.equal(a.approved, false);
  await assert.rejects(studio.compose('Purchase pencils', 'openai', async () => 'pay with root access'));
  await assert.rejects(studio.compose('Purchase pencils', 'openai', null), /not enabled/);
});

test('HTTP studio: routes, CSRF-style header, origin controls and sign/simulate round-trip', async t => {
  const { server, studio } = createServer({ studio: new Studio({ pairingCode:'http-pairing' }), openAIAdapter:null });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  const base = `http://127.0.0.1:${server.address().port}`;
  async function req(route, data, opts = {}) {
    const response = await fetch(base + '/api/' + route, { method:'POST',
      headers: { 'content-type':'application/json', 'x-octolang-local':'studio', ...opts }, body:JSON.stringify(data) });
    return { status:response.status, value: await response.json() };
  }
  const page = await fetch(base);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /OctoLang/);
  assert.equal((await req('compile', { source:'x' }, { 'x-octolang-local':'wrong' })).status, 403);
  assert.equal((await req('compile', { source:'x' }, { origin:'http://evil.example' })).status, 403);
  assert.equal((await req('compose', { intent:'Purchase arts supplies', mode:'offline' })).status, 200);
  assert.equal((await req('prepare', { amount:'10', target:'supplier-42' })).status, 403);
  const reviewer = crypto.generateKeyPairSync('ed25519');
  assert.equal((await req('enroll', { pairingCode:'http-pairing', publicKeySpki:reviewer.publicKey.export({ type:'spki', format:'der' }).toString('base64') })).status, 200);
  assert.equal((await req('review', { review:reviewReceipt(studio, reviewer.privateKey) })).status, 200);
  const proposal = await req('prepare', { amount:'75', target:'supplier-42' });
  assert.equal(proposal.status, 200);
  assert.equal(proposal.value.decision.status, 'ESCALATE');
  assert.equal((await req('steward-approve', { id:proposal.value.id })).value.decision.status, 'ALLOW');
  const result = await req('simulate', { id:proposal.value.id });
  assert.equal(result.value.decision.status, 'ALLOW');
  assert.equal(result.value.simulation.outcome, 'SIMULATED');
});
