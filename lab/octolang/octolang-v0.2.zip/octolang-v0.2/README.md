# OctoLang v0.1 — working reference prototype

A small **dependency-free CommonJS / Node.js 20+** implementation of an AI-*drafted*, human-*reviewed*, deterministic policy language for autonomous agent compositions.

**Status:** experimental **simulator**. Not a production custody, payment, federation, or blockchain system. This prototype does not create Groth16 proofs. Do not connect live wallets or privileged tools.

## Quick start

```bash
node --version                    # v20+
npm test                          # 8 automated tests
npm run check                     # validate the .octo score
npm run compile                   # emit canonical, hashed policy as JSON
npm run demo                      # locally simulate allow/deny/escalate
node bin/octolang.js compile examples/community-supplies.octo policy.json
```

No `npm install` or API key required. Outputs are offline and deterministic except for ephemeral demo identities, request nonces and timestamps. Run `npm run demo` to see an action of **75 ADA** allowed with a signed steward approval, **110 ADA** denied, and **75 ADA** escalated without approval. No funds are moved.

## Design: AI writes the draft; people authorise the exact compiled policy

1. A person describes their goal.
2. An AI model proposes `.octo` text using the rules in `src/authoring.js` / `docs/AI_AUTHORING.md`.
3. `compile()` rejects unsupported syntax and produces a canonical policy plus SHA-256 digest.
4. A human reviews intent, signer trust roots, agent limits, context requirements and escalation thresholds. The human signs a **review receipt binding that exact digest**.
5. When an action is proposed, the VCC-like deterministic evaluator checks the approved digest, target-bound signed context, capability/limits, time windows and exact signed approval where required.
6. The included mock execution adapter returns a **signed SIMULATED receipt**. Live execution is not supported by this project.

**Compiling is not approval.** A signed review receipt represents a reviewer's attestation but does not demonstrate that they understood or agreed with a good policy. The human review process is external to the example CLI.

## Example

```octo
score community_supplies {
  intent "Purchase materials for a community learning project"
  context accredited_provider {
    claim "supplier.accredited"
    issuer "community-registry"
    status VERIFIED
    max_age 30d
  }
  agent buyer {
    capability "purchase"
    limit 100 ADA
    delegate false
  }
  before purchase {
    require accredited_provider
    approve "project-steward" when amount > 50 ADA
  }
  after purchase {
    require receipt "payment"
    record evidence
  }
  on violation DENY
}
```

See `docs/LANGUAGE.md` for the v0.1 syntax/semantics and `docs/ARCHITECTURE.md` for trust boundaries and future plans.

## Repository layout

- `examples/community-supplies.octo` — draft score humans can inspect
- `src/parser.js` — bounded lexer and no-eval parser
- `src/compiler.js` — semantic validation, fixed-point ADA conversion, canonical IR digest
- `src/canonical.js` — canonical encoding / SHA-256 / native Ed25519 utilities
- `src/authoring.js` — optional AI-model callback returning an **unapproved** typed draft
- `src/runtime.js` — pre-execution policy decisions and simulated receipt verification
- `src/demo.js` — ephemeral keys, mock issuer, mock signer and mock payment executor
- `bin/octolang.js` — command-line frontend
- `test/` — automated compiler, signature, policy and replay tests

## Trust and security limitations

- **Only a simulator**. `agent buyer` is an untrusted label, not authenticated actor identity; implement strong principal and delegation bindings before any production operation.
- Keys/trust anchors are generated locally for the demo; they are not registered in KERI/DID or any real governance process. A valid signer can still attest false facts. Revocation not implemented.
- In-process `Set` replay protection is **not atomic or persistent**. Production must use a transactional nonce/idempotency store and safe distributed execution protocols.
- Signed approval is bound to exact policy digest and request digest. A production deployment must also handle signer revocation, governance approval, key isolation, durable audit, external custody, robust time, race conditions, and TOCTOU.
- Canonical JSON here is a private deterministic encoding for this reference only, **not** a standards-certified cross-platform JSON canonicalization protocol.
- Only the example `purchase` action and ADA (six decimal places) are supported. No delegation, federation, nested scores, semantic typing of external evidence, wallet handling or Groth16 circuit compilation is implemented.
- A signed **SIMULATED** receipt is evidence that the local demo signer attested to a simulation — **not** proof that a payment occurred.
- Future production VCC should recheck the current mandate and revocation state immediately before effects and never give the LLM custody keys.

## Compatibility

The architecture is informed by the existing **Octonomous Federation Protocol (OFP) 1.0** and proposed Nightframes integration, but does **not** implement OFP envelopes, quorum consensus, real Groth16, Cardano/Plutus/Midnight integrations, or OFP-HIGH-ASSURANCE-1.

## Next steps

Implement a formal versioned grammar + typed IR, human-review tool and signed policy deployment; a separately deployed VCC that verifies identities and revocation; persistent replay store; external effects through confined capabilities with real signed receipts; OFP adapter; circuit/proof interface for select bounded predicates. Security review and conformance testing required before external deployment.
