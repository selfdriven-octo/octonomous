# OctoLang development history

## v0.1.0 — 2026-10-18

- AI-first source-proposal interface with mandatory separate human-review signature for local simulation.
- Human-readable `.octo` scores, bounded parser, fail-closed semantic compiler, deterministic canonical policy digests.
- Fixed-point ADA constraints, target-bound Ed25519 evidence, exact action-bound approvals.
- Simulated receipt verification and per-process replay detection.
- CLI, reference score, developer documentation and eight node:test test cases.

Security: local developer prototype only. No external effects, ledger transactions, hardware key storage, Groth16 or OFP integration.
