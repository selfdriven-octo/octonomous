const Being = require('./being');

function Runtime(options) {
  options = options || {};

  this.store = options.store;
  this.cognition = options.cognition;
  this.policy = options.policy;
  this.tools = options.tools;
  this.commitments = options.commitments;
}

Runtime.prototype.createBeing = function (definition) {
  return new Being({
    definition: definition,
    store: this.store,
    cognition: this.cognition,
    policy: this.policy,
    tools: this.tools,
    commitments: this.commitments
  });
};

Runtime.prototype.registerBeing = function (definition) {
  const self = this;

  return self.store.loadBeing(definition.id)
    .then(function (existing) {
      if (existing) {
        return existing;
      }

      return self.store.saveBeing(definition);
    });
};

Runtime.prototype.handleEventForBeing = function (beingId, event) {
  const self = this;

  return self.store.loadBeing(beingId)
    .then(function (definition) {
      if (!definition) {
        throw new Error('Unknown being: ' + beingId);
      }

      const subscriptions = definition.subscriptions || [];

      if (!subscriptions.includes(event.type)) {
        return {
          beingId: beingId,
          skipped: true,
          reason: 'Being is not subscribed to event type: ' + event.type
        };
      }

      return self.createBeing(definition).handleEvent(event);
    });
};

module.exports = Runtime;
