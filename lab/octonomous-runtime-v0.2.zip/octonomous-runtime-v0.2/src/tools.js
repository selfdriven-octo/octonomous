function ToolRegistry() {
  this.handlers = new Map();
  this.metadata = new Map();
}

ToolRegistry.prototype.register = function (definition, handler) {
  if (!definition || !definition.name) {
    throw new Error('Tool definition requires a name');
  }

  this.handlers.set(definition.name, handler);
  this.metadata.set(definition.name, {
    name: definition.name,
    description: definition.description || '',
    inputSchema: definition.inputSchema || null,
    source: definition.source || 'local'
  });
};

ToolRegistry.prototype.execute = function (name, input) {
  const handler = this.handlers.get(name);

  if (!handler) {
    return Promise.reject(new Error('Unknown tool: ' + name));
  }

  try {
    return Promise.resolve(handler(input || {}));
  }
  catch (error) {
    return Promise.reject(error);
  }
};

ToolRegistry.prototype.listMetadata = function () {
  return Array.from(this.metadata.values());
};

module.exports = ToolRegistry;
