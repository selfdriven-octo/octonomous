function Being(options) {
  options = options || {};

  this.definition = options.definition;
  this.store = options.store;
  this.cognition = options.cognition;
  this.policy = options.policy;
  this.tools = options.tools;
  this.commitments = options.commitments;
}

Being.prototype.handleEvent = function (event) {
  const self = this;
  const context = {
    event: event
  };

  return self.wake(event, context)
    .then(function () {
      return self.observe(event, context);
    })
    .then(function () {
      return self.consider(event, context);
    })
    .then(function () {
      return self.decide(event, context);
    })
    .then(function () {
      return self.govern(event, context);
    })
    .then(function () {
      return self.commit(event, context);
    })
    .then(function () {
      return self.act(event, context);
    })
    .then(function () {
      return self.reflect(event, context);
    })
    .then(function () {
      return self.remember(event, context);
    })
    .then(function () {
      return self.sleep(event, context);
    })
    .then(function () {
      return {
        beingId: self.definition.id,
        eventId: event.id,
        decision: context.decision,
        governance: context.governance,
        commitment: context.commitment || null,
        actionResult: context.actionResult,
        reflection: context.reflection
      };
    });
};

Being.prototype.wake = function (event, context) {
  context.wokeAt = new Date().toISOString();
  return Promise.resolve();
};

Being.prototype.observe = function (event, context) {
  const memory = this.definition.memory || {};
  const reflections = memory.reflections || [];

  context.observation = {
    event: event,
    being: {
      id: this.definition.id,
      identity: this.definition.identity,
      purpose: this.definition.purpose,
      character: this.definition.character,
      commitments: this.definition.commitments || [],
      recentReflections: reflections.slice(-5)
    }
  };

  return Promise.resolve();
};

Being.prototype.consider = function (event, context) {
  return this.cognition.consider({
    being: this.definition,
    event: event,
    observation: context.observation,
    tools: this.tools.listMetadata()
  })
    .then(function (consideration) {
      context.consideration = consideration;
    });
};

Being.prototype.decide = function (event, context) {
  return this.cognition.decide({
    being: this.definition,
    event: event,
    observation: context.observation,
    consideration: context.consideration,
    tools: this.tools.listMetadata()
  })
    .then(function (decision) {
      context.decision = decision;
    });
};

Being.prototype.govern = function (event, context) {
  context.governance = this.policy.check({
    being: this.definition,
    decision: context.decision,
    availableTools: this.tools.listMetadata()
  });

  return Promise.resolve();
};

Being.prototype.commit = function (event, context) {
  const self = this;
  const proposal = context.decision && context.decision.commitment;

  if (!proposal || !proposal.enabled) {
    return Promise.resolve();
  }

  return self.commitments.create({
    being: self.definition,
    event: event,
    proposal: proposal
  })
    .then(function (commitment) {
      context.commitment = commitment;
    });
};

Being.prototype.act = function (event, context) {
  const decision = context.decision || {};
  const governance = context.governance || {};
  const action = decision.action;

  if (!decision.shouldAct || !action || !action.enabled) {
    context.actionResult = {
      ok: true,
      skipped: true,
      reason: 'No action selected'
    };

    return Promise.resolve();
  }

  if (!governance.allowed) {
    context.actionResult = {
      ok: false,
      blocked: true,
      status: governance.status,
      reason: governance.reason
    };

    return Promise.resolve();
  }

  return this.tools.execute(action.tool, action.input)
    .then(function (result) {
      context.actionResult = result;
    })
    .catch(function (error) {
      context.actionResult = {
        ok: false,
        error: error.message
      };
    });
};

Being.prototype.reflect = function (event, context) {
  return this.cognition.reflect({
    being: this.definition,
    event: event,
    decision: context.decision,
    governance: context.governance,
    commitment: context.commitment,
    actionResult: context.actionResult
  })
    .then(function (reflection) {
      context.reflection = reflection;
    });
};

Being.prototype.remember = function (event, context) {
  const self = this;

  self.definition.memory = self.definition.memory || {};
  self.definition.memory.reflections = self.definition.memory.reflections || [];

  self.definition.memory.reflections.push({
    at: new Date().toISOString(),
    eventId: event.id,
    eventType: event.type,
    decision: context.decision,
    governance: context.governance,
    commitmentId: context.commitment ? context.commitment.id : null,
    result: context.actionResult,
    reflection: context.reflection
  });

  if (self.definition.memory.reflections.length > 100) {
    self.definition.memory.reflections = self.definition.memory.reflections.slice(-100);
  }

  return self.store.saveBeing(self.definition)
    .then(function (saved) {
      self.definition = saved;
    });
};

Being.prototype.sleep = function (event, context) {
  context.sleptAt = new Date().toISOString();
  return Promise.resolve();
};

module.exports = Being;
