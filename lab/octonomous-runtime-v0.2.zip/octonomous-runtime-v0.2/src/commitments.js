const crypto = require('crypto');

function commitmentId(beingId, eventId, title) {
  return crypto.createHash('sha256')
    .update([beingId, eventId || '', title || ''].join('|'))
    .digest('hex')
    .slice(0, 32);
}

function CommitmentService(options) {
  options = options || {};
  this.scheduler = options.scheduler || null;
}

CommitmentService.prototype.create = function (context) {
  const self = this;
  const being = context.being;
  const proposal = context.proposal;
  const id = commitmentId(being.id, context.event.id, proposal.title);

  being.commitments = being.commitments || [];

  const existing = being.commitments.find(function (item) {
    return item.id === id;
  });

  if (existing) {
    return Promise.resolve(existing);
  }

  const commitment = {
    id: id,
    title: proposal.title,
    reason: proposal.reason,
    dueAt: proposal.dueAt,
    status: 'active',
    createdAt: new Date().toISOString(),
    sourceEventId: context.event.id
  };

  being.commitments.push(commitment);

  if (!self.scheduler || !commitment.dueAt) {
    return Promise.resolve(commitment);
  }

  return self.scheduler.scheduleCommitment({
    beingId: being.id,
    commitment: commitment
  })
    .then(function (schedule) {
      commitment.reminder = schedule;
      return commitment;
    });
};

module.exports = CommitmentService;
