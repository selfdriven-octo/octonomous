const path = require('path');
const Runtime = require('./runtime');
const Policy = require('./policy');
const ToolRegistry = require('./tools');
const CommitmentService = require('./commitments');
const FileStore = require('./store/file');
const DynamoDBStore = require('./store/dynamodb');
const OpenAICognition = require('./cognition/openai');
const MockCognition = require('./cognition/mock');
const EventBridgePublisher = require('./events/eventbridge');
const ReminderScheduler = require('./events/scheduler');
const MCPManager = require('./mcp');
const Secrets = require('./secrets');

function bool(value, fallback) {
  if (value === undefined || value === '') {
    return fallback;
  }
  return String(value).toLowerCase() === 'true';
}

function parseMcpServers() {
  if (!process.env.MCP_SERVERS_JSON) {
    return [];
  }

  return JSON.parse(process.env.MCP_SERVERS_JSON);
}

function createStore() {
  if (process.env.STORE_MODE === 'dynamodb') {
    return new DynamoDBStore({
      tableName: process.env.DYNAMODB_TABLE,
      region: process.env.AWS_REGION
    });
  }

  return new FileStore({
    basePath: process.env.DATA_PATH || path.join(process.cwd(), 'data')
  });
}

function resolveOpenAIKey(secrets) {
  if (process.env.OPENAI_API_KEY) {
    return Promise.resolve(process.env.OPENAI_API_KEY);
  }

  if (process.env.OPENAI_API_KEY_SECRET_ARN) {
    return secrets.get(
      process.env.OPENAI_API_KEY_SECRET_ARN,
      process.env.OPENAI_API_KEY_SECRET_JSON_KEY || undefined
    );
  }

  return Promise.resolve(null);
}

function resolveMcpServerSecrets(servers, secrets) {
  return Promise.all(servers.map(function (server) {
    if (!server.tokenSecretArn) {
      return server;
    }

    return secrets.get(server.tokenSecretArn, server.tokenSecretJsonKey)
      .then(function (token) {
        return Object.assign({}, server, {
          token: token
        });
      });
  }));
}

function bootstrap() {
  const region = process.env.AWS_REGION;
  const tools = new ToolRegistry();
  const secrets = new Secrets({ region: region });
  const store = createStore();

  const eventPublisher = process.env.EVENT_BUS_NAME
    ? new EventBridgePublisher({
      busName: process.env.EVENT_BUS_NAME,
      region: region
    })
    : null;

  const scheduler = process.env.WAKE_QUEUE_ARN && process.env.SCHEDULER_TARGET_ROLE_ARN
    ? new ReminderScheduler({
      queueArn: process.env.WAKE_QUEUE_ARN,
      roleArn: process.env.SCHEDULER_TARGET_ROLE_ARN,
      region: region
    })
    : null;

  tools.register({
    name: 'echo',
    description: 'Return the supplied input unchanged.',
    inputSchema: {
      type: 'object'
    },
    source: 'local'
  }, function (input) {
    return Promise.resolve({
      ok: true,
      output: input
    });
  });

  if (eventPublisher) {
    tools.register({
      name: 'event.publish',
      description: 'Publish an event to another Octonomous being through EventBridge.',
      inputSchema: {
        type: 'object',
        properties: {
          targetBeingId: { type: 'string' },
          type: { type: 'string' },
          payload: { type: 'object' }
        }
      },
      source: 'local'
    }, function (input) {
      return eventPublisher.publish({
        targetBeingId: input.targetBeingId,
        type: input.type,
        payload: input.payload || {}
      })
        .then(function (event) {
          return {
            ok: true,
            event: event
          };
        });
    });
  }

  return resolveOpenAIKey(secrets)
    .then(function (apiKey) {
      const cognitionMode = process.env.COGNITION_MODE || (apiKey ? 'openai' : 'mock');
      let cognition;

      if (cognitionMode === 'openai') {
        if (!apiKey) {
          throw new Error('COGNITION_MODE=openai but no OpenAI API key is configured');
        }

        cognition = new OpenAICognition({
          apiKey: apiKey,
          model: process.env.OPENAI_MODEL || 'gpt-5.5',
          reflectWithModel: bool(process.env.REFLECT_WITH_MODEL, true)
        });
      }
      else {
        cognition = new MockCognition();
      }

      const commitments = new CommitmentService({
        scheduler: scheduler
      });

      const runtime = new Runtime({
        store: store,
        cognition: cognition,
        policy: new Policy(),
        tools: tools,
        commitments: commitments
      });

      const mcp = new MCPManager({
        registry: tools
      });

      return resolveMcpServerSecrets(parseMcpServers(), secrets)
        .then(function (servers) {
          return Promise.all(servers.map(function (server) {
            return mcp.connectServer(server);
          }));
        })
        .then(function () {
          return {
            runtime: runtime,
            tools: tools,
            mcp: mcp,
            eventPublisher: eventPublisher
          };
        });
    });
}

module.exports = bootstrap;
