const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const Runtime = require('../src/runtime');
const Policy = require('../src/policy');
const ToolRegistry = require('../src/tools');
const CommitmentService = require('../src/commitments');
const FileStore = require('../src/store/file');
const MockCognition = require('../src/cognition/mock');

test('being completes governed lifecycle and persists reflection', function () {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-'));
  const store = new FileStore({ basePath: dir });
  const tools = new ToolRegistry();

  tools.register({
    name: 'echo',
    description: 'Echo'
  }, function (input) {
    return Promise.resolve({ ok: true, output: input });
  });

  const runtime = new Runtime({
    store: store,
    cognition: new MockCognition(),
    policy: new Policy(),
    tools: tools,
    commitments: new CommitmentService()
  });

  const being = {
    id: 'octo:test:1',
    purpose: ['test'],
    character: {
      curious: true,
      caring: true,
      constructive: true,
      chill: true
    },
    authority: {
      allowedTools: ['echo'],
      requiresApproval: []
    },
    subscriptions: ['intent.created'],
    commitments: [],
    memory: {
      reflections: []
    }
  };

  return runtime.registerBeing(being)
    .then(function () {
      return runtime.handleEventForBeing(being.id, {
        id: 'event-1',
        type: 'intent.created',
        payload: {
          intent: 'test'
        }
      });
    })
    .then(function (result) {
      assert.equal(result.actionResult.ok, true);
      return store.loadBeing(being.id);
    })
    .then(function (saved) {
      assert.equal(saved.memory.reflections.length, 1);
      assert.equal(saved._version >= 2, true);
    });
});

test('policy blocks unauthorised tools without retrying the event', function () {
  const policy = new Policy();

  const result = policy.check({
    being: {
      authority: {
        allowedTools: [],
        requiresApproval: []
      }
    },
    decision: {
      shouldAct: true,
      action: {
        enabled: true,
        tool: 'dangerous.tool'
      }
    },
    availableTools: [{ name: 'dangerous.tool' }]
  });

  assert.equal(result.allowed, false);
  assert.equal(result.status, 'not_authorised');
});
