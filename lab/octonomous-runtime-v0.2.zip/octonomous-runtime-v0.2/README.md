# Octonomous Runtime v0.2

A small Node.js runtime for persistent, event-driven **Octonomous beings**.

The runtime keeps the being separate from the cognition engine:

```text
EventBridge / Scheduler
        |
        v
       SQS
        |
        v
   Lambda worker
        |
        v
      Being
        |
        +--> wake
        +--> observe
        +--> consider
        +--> decide        OpenAI adapter
        +--> govern        runtime policy, not the LLM
        +--> commit        durable commitment + reminder
        +--> act           local or MCP tool
        +--> reflect
        +--> remember      DynamoDB
        +--> sleep
```

A being is durable state. Compute is temporary.

## What changed from v0.1

- Real OpenAI Responses API cognition adapter.
- Strict structured decisions and reflections.
- Tool authority remains outside the model.
- MCP v2 Streamable HTTP client support.
- DynamoDB persistent being state with optimistic concurrency.
- EventBridge event publishing.
- SQS wake queue + Lambda handler.
- Durable commitments.
- EventBridge Scheduler one-time reminders that wake a being through SQS.
- Secrets Manager support for the OpenAI key and MCP bearer tokens.
- Local file-backed mode and mock cognition for tests.

## Requirements

- Node.js 22+ (Node.js 24 recommended for AWS Lambda)
- npm
- For real cognition: an OpenAI API key
- For AWS deployment: AWS credentials + AWS SAM CLI

## Install

```bash
npm install
```

## Run locally with OpenAI

```bash
export COGNITION_MODE=openai
export OPENAI_API_KEY='...'
export OPENAI_MODEL='gpt-5.5'
npm start
```

The local runtime stores being state under `./data`.

For a zero-API test:

```bash
export COGNITION_MODE=mock
npm start
```

Run tests:

```bash
npm test
```

## The governance boundary

The cognition layer only returns a proposal:

```json
{
  "shouldAct": true,
  "rationale": "...",
  "action": {
    "enabled": true,
    "tool": "echo",
    "input": {}
  },
  "commitment": {
    "enabled": false,
    "title": "",
    "dueAt": "",
    "reason": ""
  }
}
```

The runtime independently checks the being's authority:

```json
{
  "authority": {
    "allowedTools": ["echo"],
    "requiresApproval": ["event.publish"]
  }
}
```

The LLM cannot grant itself authority by selecting a tool.

## MCP

Set `MCP_SERVERS_JSON` to remote Streamable HTTP MCP servers:

```bash
export MCP_SERVERS_JSON='[
  {
    "name": "community",
    "url": "https://example.com/mcp"
  }
]'
```

Discovered tools are registered as:

```text
mcp:community:<tool-name>
```

Then explicitly grant a being access by adding the registered tool name to `authority.allowedTools`.

For bearer-token MCP servers on AWS, prefer a secret reference:

```json
[
  {
    "name": "community",
    "url": "https://example.com/mcp",
    "tokenSecretArn": "arn:aws:secretsmanager:ap-southeast-2:123456789012:secret:..."
  }
]
```

Add `secretsmanager:GetSecretValue` permission for those MCP secret ARNs to the Lambda role.

## Commitments

A cognition decision may propose a commitment:

```json
{
  "enabled": true,
  "title": "Review the community response",
  "dueAt": "2026-09-10T00:00:00Z",
  "reason": "A follow-up is required"
}
```

The runtime:

1. Creates a deterministic commitment ID.
2. Stores the commitment on the being.
3. Creates a one-time EventBridge Scheduler schedule.
4. Scheduler sends a `commitment.due` event to the SQS wake queue.
5. The being wakes at the due time.
6. The schedule deletes itself after firing.

That means there is no long-running timer process.

## AWS deployment

Create a Secrets Manager secret, for example:

```json
{
  "OPENAI_API_KEY": "..."
}
```

Then:

```bash
npm install
sam build
sam deploy --guided
```

Use the secret ARN when SAM asks for `OpenAIApiKeySecretArn`.

The template creates:

- DynamoDB being table
- custom EventBridge bus
- SQS wake queue
- SQS dead-letter queue
- EventBridge → SQS rule
- Lambda worker
- EventBridge Scheduler target IAM role

The Lambda runtime is Node.js 24.x.

## Register a being in AWS

After deployment, export the stack outputs:

```bash
export STORE_MODE=dynamodb
export AWS_REGION=ap-southeast-2
export DYNAMODB_TABLE='<table-name>'
npm run register -- ./being.example.json
```

## Wake a being via EventBridge

```bash
export AWS_REGION=ap-southeast-2
export EVENT_BUS_NAME=octonomous

npm run publish -- \
  octo:being:001 \
  intent.created \
  '{"intent":"Investigate the new community request"}'
```

Flow:

```text
publish-event.js
      |
      v
 EventBridge
      |
      v
     SQS
      |
      v
   Lambda
      |
      v
 Octonomous Being
```

## State model

A being is ordinary JSON:

```json
{
  "id": "octo:being:001",
  "identity": {
    "did": "did:example:octo-001"
  },
  "purpose": [],
  "character": {
    "curious": true,
    "caring": true,
    "constructive": true,
    "chill": true
  },
  "authority": {
    "allowedTools": [],
    "requiresApproval": []
  },
  "subscriptions": [],
  "commitments": [],
  "memory": {
    "reflections": []
  }
}
```

DynamoDB adds an internal `_version` on load. Writes use optimistic concurrency so simultaneous stale updates fail rather than silently overwrite each other. SQS then retries the failed event.

## Production hardening I would do next

1. Add a first-class approval queue rather than merely blocking approval-required actions.
2. Add signed event receipts / KERI identity proofs.
3. Split episodic, semantic and relationship memory.
4. Add idempotency records for external side effects.
5. Add per-tool JSON-schema validation before execution.
6. Add contribution records for Octomics.
7. Add OpenTelemetry tracing across event → being → tool → outcome.
8. Add multi-being delegation and signed commitments between beings.

The important invariant should remain:

```text
Intelligence proposes.
Identity persists.
Policy authorises.
Tools act.
Evidence records.
```
