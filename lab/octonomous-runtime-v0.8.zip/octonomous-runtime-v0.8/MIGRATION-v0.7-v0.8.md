# Migration: v0.7 → v0.8

v0.8 is designed to preserve v0.7 behavior while adding opt-in protocol hardening.

## 1. Package

```json
{
  "version": "0.8.0"
}
```

No new npm dependency is required.

## 2. New environment variables

Add if you want to override defaults:

```bash
FEDERATION_PROTOCOL_VERSIONS=1.0,1.1,2.0
FEDERATION_ENVELOPE_MAX_LIFETIME_SECONDS=900
FEDERATION_CLOCK_SKEW_SECONDS=120
FEDERATION_REPLAY_RETENTION_SECONDS=604800
```

## 3. DynamoDB TTL

The SAM template now enables TTL using:

```text
ttlEpochSeconds
```

This is used for replay-protection records. Existing being/community/resource records do not set this field and are unaffected.

## 4. Federation messages

v0.7 federation events remain valid internally.

For cross-community transport, prefer v0.8 signed envelopes:

```text
create envelope → transport → verify → dispatch
```

Do not dispatch the embedded payload before envelope verification and nonce claiming succeeds.

## 5. Federated community votes

Existing proposals default to:

```json
{
  "governanceProofPolicy": "optional"
}
```

For hardened federation decisions, create new proposals with:

```json
{
  "governanceProofPolicy": "required"
}
```

Then each community vote must include a verified `localGovernanceProof` bound to the exact decision.

## 6. Treaty amendments

Do not mutate an active treaty object to change scopes/terms.

Use:

```text
federation.treaty.amend
```

The amendment becomes a new revision and must be independently ratified. The previous revision remains active until the new revision activates.

v0.7 treaties without explicit lineage fields are treated as revision 1 when used as amendment parents.

## 7. BFT certificates

The v0.8 BFT layer is new and optional.

Use it where a federation decision needs a cryptographically inspectable `2f+1` quorum certificate. It does not replace a network consensus protocol; it provides decision/signature/equivocation/finality evidence.

## 8. Store extensions

Both bundled stores now implement:

```js
store.claimResource(kind, resource)
```

This is an atomic create-if-absent primitive used for replay protection.

Custom stores should implement equivalent semantics before being used for hostile cross-community traffic.

## 9. Recommended rollout

1. Deploy v0.8 with old federation behavior unchanged.
2. Enable signed discovery between trusted test communities.
3. Wrap cross-community protocol messages in signed envelopes.
4. Require local-governance proofs for high-impact federated votes.
5. Move treaty changes to amendment/version chains.
6. Add BFT quorum certificates only for decisions that need fault-tolerant federation finality.
