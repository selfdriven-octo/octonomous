# Octonomous Runtime v0.8 — Federation Protocol Hardening

Node.js/CommonJS runtime for durable, governed Octonomous beings and sovereign communities.

v0.8 hardens the v0.7 federation protocol rather than adding another autonomy layer. The runtime now has explicit message authenticity, replay resistance, protocol negotiation, local-governance proofs, immutable treaty version chains, and a signed Byzantine-fault-tolerant quorum-certificate layer.

## Architecture progression

```text
v0.1  Being
v0.2  Durable Being
v0.3  Accountable Being
v0.4  Society of Beings
v0.5  Governed Society
v0.6  Federated Societies
v0.7  Sovereign Federation
v0.8  Hardened Federation Protocol
```

## v0.8 additions

### 1. Signed federation envelopes

Federation messages can be wrapped as short-lived signed envelopes:

```text
Community A
   │
   │ canonical envelope
   │ + protocol/schema version
   │ + nonce
   │ + expiry
   │ + recipient binding
   │ + community signature
   ▼
Transport
HTTP / queue / EventBridge / DIDComm / other
   │
   ▼
Community B
   │
   ├─ protocol/schema supported?
   ├─ recipient correct?
   ├─ timestamps valid?
   ├─ signature bound to exact payload?
   └─ nonce never seen before?
```

The envelope transport is deliberately independent from AWS. EventBridge can carry the envelope, but it is not part of its security model.

### 2. Atomic replay protection

`ReplayProtectionService` creates a one-time `(sender, recipient, nonce)` claim.

- File mode uses exclusive file creation (`wx`).
- DynamoDB mode uses conditional `PutItem` semantics.
- DynamoDB replay records carry `ttlEpochSeconds`; the SAM table enables TTL cleanup.
- Envelopes are short-lived, so a nonce cannot become useful again after replay-state TTL expiry.

### 3. Protocol/schema negotiation

Communities advertise supported:

- protocol versions
- schemas
- protocol capabilities
- federation operations
- scopes
- endpoints/transport hints

Negotiation chooses the highest exact common version and intersection of supported schemas/capabilities.

### 4. Signed capability discovery

A community can publish a signed `octonomous.federation-discovery.v1` descriptor. Another community verifies the descriptor before using it for negotiation.

Discovery says what a community supports. It does **not** itself grant authority or establish trust.

### 5. Local-governance proofs

A community-level federation vote can require proof that the community's own governance process approved that exact external decision.

```text
Local proposal
   │
   │ approves exactly:
   │ { action, externalProposalId, communityId, vote }
   ▼
Signed local resolution
   │
   ▼
Local-governance proof
   │
   ▼
Federated community vote
```

The proof binds to the exact authorisation digest; changing `approve` to `reject`, the community ID, or proposal ID invalidates it.

Federated proposals support:

```json
{
  "governanceProofPolicy": "required"
}
```

`optional` remains available for backward compatibility with v0.7 flows.

### 6. Treaty amendment/version chains

Treaties are no longer amended in place.

```text
Treaty revision 1 (active)
      │
      │ stable parent digest
      ▼
Treaty revision 2 (proposed)
      │
      │ independent participant ratification
      ▼
Treaty revision 2 (active)
      │
      └── revision 1 becomes superseded
```

A failed/unratified amendment leaves the previous treaty active.

`versionChain()` checks:

- shared lineage ID
- monotonic revision number
- previous-treaty linkage
- parent digest integrity

v0.8 keeps treaty participants/ratification structure immutable within an amendment. Membership changes should be represented as a new treaty rather than silently expanding an existing treaty's parties.

### 7. BFT quorum certificates

v0.8 includes a deterministic signed quorum-certificate layer for federation decisions.

It is **not** presented as a complete PBFT networking implementation.

For configured fault tolerance `f`:

```text
n >= 3f + 1
certificate quorum = 2f + 1
```

Every decision is signed by its community. The service:

- accepts one decision slot per community
- detects conflicting decisions from the same community as equivocation
- groups decisions by canonical value digest
- certifies only after `2f+1` matching distinct community decisions
- verifies the certificate against stored signed decisions

This is useful as the finality/evidence layer underneath a separate transport/round protocol.

## Security boundaries

The runtime intentionally maintains these separations:

```text
LLM/cognition proposes
Governance authorises
Community identity signs
Federation protocol transports/verifies
External custody executes assets/resources
Evidence records what occurred
```

Octonomous does not need to hold treasury/payment keys to govern a treasury action.

Likewise, a signed federation message is evidence that a community identity signed it; acceptance can additionally require treaty scope, federation trust, local-governance proof, or a BFT quorum certificate.

## Important production note: KERI/community signatures

The default local signer is Ed25519 and is intended for development/testing.

Production community identity remains an adapter boundary:

```text
COMMUNITY_SIGNER_MODULE
        │
        ▼
KERI / group-AID / multisig provider
```

No private KERI/group signing material needs to live in the autonomous runtime.

## New modules

```text
src/federation/
├── protocol.js
├── replay-protection.js
├── envelopes.js
├── capability-discovery.js
├── governance-proofs.js
├── bft-quorum.js
└── treaties.js              # now includes version chains
```

The existing `federated-proposals.js` now optionally/mandatorily verifies local-governance proofs.

## New tools

```text
federation.protocol.describe

federation.discovery.publish
federation.discovery.verify
federation.discovery.negotiate

federation.envelope.create
federation.envelope.verify

federation.governance-proof.create
federation.governance-proof.verify

federation.treaty.amend
federation.treaty.version-chain

federation.bft.round.create
federation.bft.decision.cast
federation.bft.certificate.verify
```

Existing tools continue to work.

## Run locally

```bash
npm install
cp .env.example .env
npm test
npm start
```

The runtime uses CommonJS and Promise `.then()` chains.

## Federation environment settings

```bash
FEDERATION_PROTOCOL_VERSIONS=1.0,1.1,2.0
FEDERATION_ENVELOPE_MAX_LIFETIME_SECONDS=900
FEDERATION_CLOCK_SKEW_SECONDS=120
FEDERATION_REPLAY_RETENTION_SECONDS=604800
```

## Example envelope

```js
runtime.federationEnvelopes.create({
  being: communityAGovernor,
  input: {
    senderCommunityId: 'community:a',
    recipientCommunityId: 'community:b',
    messageType: 'federation.proposal.notice',
    protocolVersion: '2.0',
    payload: {
      proposalId: 'proposal:123'
    }
  }
})
  .then(function (result) {
    return runtime.federationEnvelopes.verify({
      envelope: result.envelope,
      expectedRecipientCommunityId: 'community:b'
    });
  });
```

A second verification attempt of the same envelope is rejected as a replay.

## Example governance-bound federation vote

The local community proposal should approve an exact authorization:

```js
const authorization = {
  action: 'federation.proposal.vote',
  proposalId: federatedProposal.id,
  communityId: 'community:a',
  vote: 'approve'
};
```

After local governance approves a proposal whose payload contains that `authorization`:

```js
governanceProofs.create({
  communityId: 'community:a',
  proposalId: localProposal.id,
  authorization: authorization
})
  .then(function (proof) {
    return federatedProposals.castCommunityVote({
      being: governorA,
      input: {
        proposalId: federatedProposal.id,
        communityId: 'community:a',
        vote: 'approve',
        localGovernanceProof: proof
      }
    });
  });
```

## Example BFT parameters

Four communities tolerating one Byzantine/faulty participant:

```text
n = 4
f = 1
3f + 1 = 4
2f + 1 = 3 matching decisions required
```

Seven communities tolerating two:

```text
n = 7
f = 2
2f + 1 = 5 matching decisions required
```

## AWS deployment

```bash
sam build
sam deploy --guided
```

The v0.8 SAM template enables DynamoDB TTL for replay records while retaining point-in-time recovery and server-side encryption.

## Tests

v0.8 retains the previous 30 tests and adds protocol-hardening coverage for:

- signed envelope verification
- atomic replay rejection
- envelope payload tampering
- protocol/capability negotiation
- exact local-governance proof binding
- treaty version-chain activation/supersession
- invalid BFT topology rejection
- `2f+1` signed quorum certification
- BFT certificate verification
- equivocation detection

Current suite: **38 tests, 38 passing**.

Run:

```bash
npm test
```

## What v0.8 is not

v0.8 deliberately does not claim to provide:

- a full PBFT/HotStuff/Tendermint networking implementation
- globally authoritative trust
- automatic execution of treasury/resource transfers
- production KERI group signing without a configured provider
- secure network transport by itself

It provides the signed state/evidence primitives those systems can safely integrate with.
