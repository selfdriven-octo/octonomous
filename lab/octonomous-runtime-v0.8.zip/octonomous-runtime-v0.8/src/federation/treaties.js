const crypto = require('crypto');
const canonical = require('../canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function unique(values) {
  return Array.from(new Set(values));
}

function TreatyService(options) {
  options = options || {};
  this.store = options.store;
  this.communities = options.communities;
  this.signing = options.signing || null;
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
}

TreatyService.prototype.load = function (id) {
  return this.store.loadResource('treaty', id);
};

TreatyService.prototype.save = function (treaty) {
  return this.store.saveResource('treaty', treaty);
};

TreatyService.prototype._canRepresent = function (community, beingId) {
  return this.communities.hasRole(community, beingId, ['founder', 'governor', 'federation-admin']);
};

TreatyService.prototype._linkCommunity = function (communityId, treaty) {
  const self = this;
  return self.communities.load(communityId)
    .then(function (community) {
      if (!community) {
        throw new Error('Unknown treaty community: ' + communityId);
      }
      community.federation = community.federation || {};
      community.federation.treaties = community.federation.treaties || [];
      const existing = community.federation.treaties.find(function (item) {
        return item.treatyId === treaty.id;
      });
      const ratifiedCommunityIds = (treaty.ratification && treaty.ratification.ratifications || []).map(function (item) {
        return item.communityId;
      });
      const ref = {
        treatyId: treaty.id,
        status: treaty.status,
        ratified: ratifiedCommunityIds.includes(communityId),
        scopes: clone(treaty.scopes),
        participantCommunityIds: clone(treaty.participantCommunityIds),
        updatedAt: new Date().toISOString()
      };
      if (existing) {
        Object.assign(existing, ref);
      }
      else {
        community.federation.treaties.push(ref);
      }
      return self.communities.save(community);
    });
};

TreatyService.prototype._syncLinks = function (treaty) {
  const self = this;
  return Promise.all((treaty.participantCommunityIds || []).map(function (communityId) {
    return self._linkCommunity(communityId, treaty);
  }));
};

TreatyService.prototype.propose = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let proposerCommunity;
  let treaty;

  if (!input.proposerCommunityId) {
    return Promise.reject(new Error('federation.treaty.propose requires proposerCommunityId'));
  }

  const participants = unique([input.proposerCommunityId].concat(input.participantCommunityIds || []));
  if (participants.length < 2) {
    return Promise.reject(new Error('A treaty requires at least two distinct communities'));
  }

  return Promise.all(participants.map(function (communityId) {
    return self.communities.load(communityId);
  }))
    .then(function (communities) {
      if (communities.some(function (community) { return !community; })) {
        throw new Error('Treaty includes an unknown community');
      }
      proposerCommunity = communities.find(function (community) {
        return community.id === input.proposerCommunityId;
      });
      if (!self._canRepresent(proposerCommunity, being.id)) {
        throw new Error('Being is not authorised to propose treaties for community: ' + proposerCommunity.id);
      }

      const minimum = Number(input.minimumRatifications || participants.length);
      if (!Number.isInteger(minimum) || minimum < 2 || minimum > participants.length) {
        throw new Error('minimumRatifications must be between 2 and the number of treaty participants');
      }

      treaty = {
        id: input.id || ('treaty:' + crypto.randomUUID()),
        version: 'octonomous.federation-treaty.v1',
        lineageId: null,
        revision: 1,
        previousTreatyId: null,
        parentDigest: null,
        supersededByTreatyId: null,
        name: input.name || 'Federation Treaty',
        proposerCommunityId: proposerCommunity.id,
        participantCommunityIds: participants,
        scopes: Array.isArray(input.scopes) && input.scopes.length ? unique(input.scopes) : ['*'],
        terms: clone(input.terms || {}),
        dispute: {
          resolverCommunityId: input.disputeResolverCommunityId || null,
          process: clone(input.disputeProcess || {})
        },
        validity: {
          validFrom: input.validFrom || null,
          validUntil: input.validUntil || null
        },
        ratification: {
          minimum: minimum,
          requiredCommunityIds: participants,
          ratifications: []
        },
        status: 'proposed',
        createdAt: new Date().toISOString(),
        createdByBeingId: being.id,
        proposalReceipt: null,
        activationReceipt: null,
        termination: null
      };

      treaty.lineageId = treaty.id;

      return self.signing
        ? self.signing.sign(proposerCommunity, 'federation.treaty.proposed', treaty, {
          participantCommunityIds: participants,
          sourceEventId: context.event && context.event.id
        })
        : null;
    })
    .then(function (receipt) {
      treaty.proposalReceipt = receipt;
      return self.save(treaty);
    })
    .then(function () {
      return self._syncLinks(treaty);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, treaty: treaty, event: null };
      }
      return self.publisher.publish({
        type: 'federation.treaty.proposed',
        sourceBeingId: being.id,
        payload: { treaty: treaty, sourceBeingId: being.id }
      }).then(function (event) {
        return { ok: true, treaty: treaty, event: event };
      });
    });
};

TreatyService.prototype.ratify = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let treaty;
  let community;
  let ratification;

  if (!input.treatyId || !input.communityId) {
    return Promise.reject(new Error('federation.treaty.ratify requires treatyId and communityId'));
  }

  return Promise.all([
    self.load(input.treatyId),
    self.communities.load(input.communityId)
  ])
    .then(function (loaded) {
      treaty = loaded[0];
      community = loaded[1];
      if (!treaty) {
        throw new Error('Unknown treaty: ' + input.treatyId);
      }
      if (!community) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      if (!['proposed', 'active'].includes(treaty.status)) {
        throw new Error('Treaty is not open for ratification');
      }
      if (!treaty.participantCommunityIds.includes(community.id)) {
        throw new Error('Community is not a treaty participant');
      }
      if (!self._canRepresent(community, being.id)) {
        throw new Error('Being is not authorised to ratify for community: ' + community.id);
      }
      if ((treaty.ratification.ratifications || []).some(function (item) {
        return item.communityId === community.id;
      })) {
        throw new Error('Community has already ratified this treaty');
      }

      ratification = {
        id: crypto.randomUUID(),
        treatyId: treaty.id,
        communityId: community.id,
        ratifiedByBeingId: being.id,
        localGovernanceProposalId: input.localGovernanceProposalId || null,
        statement: input.statement || 'ratified',
        ratifiedAt: new Date().toISOString(),
        receipt: null
      };

      return self.signing
        ? self.signing.sign(community, 'federation.treaty.ratified', ratification, {
          treatyProposalReceiptId: treaty.proposalReceipt && treaty.proposalReceipt.id || null
        })
        : null;
    })
    .then(function (receipt) {
      ratification.receipt = receipt;
      treaty.ratification.ratifications.push(ratification);

      if (treaty.status === 'active' || treaty.ratification.ratifications.length < treaty.ratification.minimum) {
        return null;
      }

      treaty.status = 'active';
      treaty.activatedAt = new Date().toISOString();

      if (!self.receipts) {
        return null;
      }
      return self.receipts.create({
        kind: 'federation.treaty.activated',
        beingId: 'federation:' + treaty.id,
        subject: {
          treatyId: treaty.id,
          participantCommunityIds: treaty.participantCommunityIds,
          scopes: treaty.scopes,
          activatedAt: treaty.activatedAt
        },
        evidence: {
          ratificationReceiptIds: treaty.ratification.ratifications.map(function (item) {
            return item.receipt && item.receipt.id || null;
          }).filter(Boolean)
        }
      });
    })
    .then(function (activationReceipt) {
      if (activationReceipt) {
        treaty.activationReceipt = activationReceipt;
      }
      return self.save(treaty);
    })
    .then(function () {
      if (treaty.status !== 'active' || !treaty.previousTreatyId) {
        return null;
      }
      return self.load(treaty.previousTreatyId)
        .then(function (previous) {
          if (!previous) {
            throw new Error('Treaty amendment parent is missing: ' + treaty.previousTreatyId);
          }
          previous.status = 'superseded';
          previous.supersededByTreatyId = treaty.id;
          previous.supersededAt = new Date().toISOString();
          return self.save(previous)
            .then(function () { return self._syncLinks(previous); });
        });
    })
    .then(function () {
      return self._syncLinks(treaty);
    })
    .then(function () {
      const result = {
        ok: true,
        treaty: treaty,
        ratification: ratification,
        activated: treaty.status === 'active'
      };
      if (!self.publisher) {
        return result;
      }
      return self.publisher.publish({
        type: treaty.status === 'active' ? 'federation.treaty.activated' : 'federation.treaty.ratified',
        sourceBeingId: being.id,
        payload: {
          treatyId: treaty.id,
          communityId: community.id,
          status: treaty.status,
          ratification: ratification,
          sourceBeingId: being.id
        }
      }).then(function (event) {
        result.event = event;
        return result;
      });
    });
};

TreatyService.prototype.terminate = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let treaty;
  let community;

  if (!input.treatyId || !input.communityId) {
    return Promise.reject(new Error('federation.treaty.terminate requires treatyId and communityId'));
  }

  return Promise.all([self.load(input.treatyId), self.communities.load(input.communityId)])
    .then(function (loaded) {
      treaty = loaded[0];
      community = loaded[1];
      if (!treaty || !community) {
        throw new Error('Unknown treaty or community');
      }
      if (!treaty.participantCommunityIds.includes(community.id)) {
        throw new Error('Only a treaty participant may terminate it');
      }
      if (!self._canRepresent(community, being.id)) {
        throw new Error('Being is not authorised to terminate for community');
      }
      if (!['active', 'proposed'].includes(treaty.status)) {
        throw new Error('Treaty cannot be terminated from status: ' + treaty.status);
      }

      treaty.status = 'terminated';
      treaty.termination = {
        communityId: community.id,
        terminatedByBeingId: being.id,
        reason: input.reason || '',
        terminatedAt: new Date().toISOString(),
        receipt: null
      };

      return self.signing
        ? self.signing.sign(community, 'federation.treaty.terminated', treaty.termination, {
          treatyId: treaty.id
        })
        : null;
    })
    .then(function (receipt) {
      treaty.termination.receipt = receipt;
      return self.save(treaty);
    })
    .then(function () { return self._syncLinks(treaty); })
    .then(function () {
      return { ok: true, treaty: treaty };
    });
};

TreatyService.prototype.isActive = function (treaty, communityA, communityB, scope) {
  if (!treaty || treaty.status !== 'active') {
    return false;
  }
  const now = Date.now();
  if (treaty.validity && treaty.validity.validFrom && Date.parse(treaty.validity.validFrom) > now) {
    return false;
  }
  if (treaty.validity && treaty.validity.validUntil && Date.parse(treaty.validity.validUntil) <= now) {
    return false;
  }
  if (!treaty.participantCommunityIds.includes(communityA) || !treaty.participantCommunityIds.includes(communityB)) {
    return false;
  }
  const ratified = new Set((treaty.ratification && treaty.ratification.ratifications || []).map(function (item) {
    return item.communityId;
  }));
  if (!ratified.has(communityA) || !ratified.has(communityB)) {
    return false;
  }
  const scopes = treaty.scopes || ['*'];
  return scopes.includes('*') || scopes.includes(scope || '*');
};


TreatyService.prototype._lineageSubject = function (treaty) {
  return {
    id: treaty.id,
    lineageId: treaty.lineageId || treaty.id,
    revision: Number(treaty.revision || 1),
    previousTreatyId: treaty.previousTreatyId || null,
    participantCommunityIds: clone(treaty.participantCommunityIds || []),
    scopes: clone(treaty.scopes || []),
    terms: clone(treaty.terms || {}),
    dispute: clone(treaty.dispute || {}),
    validity: clone(treaty.validity || {}),
    ratificationMinimum: treaty.ratification && treaty.ratification.minimum || 0,
    proposalReceiptDigest: treaty.proposalReceipt && treaty.proposalReceipt.digest || null,
    activationReceiptDigest: treaty.activationReceipt && treaty.activationReceipt.digest || null
  };
};

TreatyService.prototype.lineageDigest = function (treaty) {
  return canonical.sha256(this._lineageSubject(treaty));
};

TreatyService.prototype.amend = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let previous;
  let proposerCommunity;
  let amended;

  if (!input.treatyId || !input.proposerCommunityId || !input.patch || typeof input.patch !== 'object') {
    return Promise.reject(new Error('federation.treaty.amend requires treatyId, proposerCommunityId, and patch'));
  }

  return Promise.all([self.load(input.treatyId), self.communities.load(input.proposerCommunityId)])
    .then(function (loaded) {
      previous = loaded[0];
      proposerCommunity = loaded[1];
      if (!previous || !proposerCommunity) {
        throw new Error('Unknown treaty or proposer community');
      }
      if (previous.status !== 'active') {
        throw new Error('Only an active treaty may be amended');
      }
      if (!previous.participantCommunityIds.includes(proposerCommunity.id)) {
        throw new Error('Amendment proposer must be a treaty participant');
      }
      if (!self._canRepresent(proposerCommunity, being.id)) {
        throw new Error('Being is not authorised to propose treaty amendments for community');
      }
      if (input.patch.participantCommunityIds || input.patch.proposerCommunityId || input.patch.ratification) {
        throw new Error('v0.8 treaty amendments cannot change participants or ratification structure');
      }

      amended = clone(previous);
      delete amended._version;
      amended.id = input.id || ('treaty:' + crypto.randomUUID());
      amended.lineageId = previous.lineageId || previous.id;
      amended.revision = Number(previous.revision || 1) + 1;
      amended.previousTreatyId = previous.id;
      amended.parentDigest = self.lineageDigest(previous);
      amended.supersededByTreatyId = null;
      amended.status = 'proposed';
      amended.createdAt = new Date().toISOString();
      amended.createdByBeingId = being.id;
      amended.activatedAt = null;
      amended.proposalReceipt = null;
      amended.activationReceipt = null;
      amended.termination = null;
      amended.ratification = {
        minimum: previous.ratification.minimum,
        requiredCommunityIds: clone(previous.ratification.requiredCommunityIds || previous.participantCommunityIds),
        ratifications: []
      };

      if (input.patch.name !== undefined) { amended.name = input.patch.name; }
      if (input.patch.scopes !== undefined) { amended.scopes = unique(input.patch.scopes); }
      if (input.patch.terms !== undefined) { amended.terms = clone(input.patch.terms); }
      if (input.patch.dispute !== undefined) { amended.dispute = clone(input.patch.dispute); }
      if (input.patch.validity !== undefined) { amended.validity = clone(input.patch.validity); }

      return self.signing
        ? self.signing.sign(proposerCommunity, 'federation.treaty.amendment.proposed', amended, {
          previousTreatyId: previous.id,
          parentDigest: amended.parentDigest,
          sourceEventId: context.event && context.event.id
        })
        : null;
    })
    .then(function (receipt) {
      amended.proposalReceipt = receipt;
      return self.save(amended);
    })
    .then(function () { return self._syncLinks(amended); })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, treaty: amended, previousTreaty: previous };
      }
      return self.publisher.publish({
        type: 'federation.treaty.amendment.proposed',
        sourceBeingId: being.id,
        payload: {
          treaty: amended,
          previousTreatyId: previous.id,
          sourceBeingId: being.id
        }
      }).then(function (event) {
        return { ok: true, treaty: amended, previousTreaty: previous, event: event };
      });
    });
};

TreatyService.prototype.versionChain = function (treatyId) {
  const self = this;
  const chain = [];
  const seen = new Set();

  function visit(id) {
    if (!id) {
      return Promise.resolve();
    }
    if (seen.has(id)) {
      return Promise.reject(new Error('Treaty version chain contains a cycle'));
    }
    seen.add(id);
    return self.load(id)
      .then(function (treaty) {
        if (!treaty) {
          throw new Error('Treaty version chain is missing: ' + id);
        }
        chain.unshift(treaty);
        return visit(treaty.previousTreatyId || null);
      });
  }

  return visit(treatyId)
    .then(function () {
      let valid = true;
      let reason = null;
      chain.forEach(function (treaty, index) {
        if (!valid || index === 0) { return; }
        const previous = chain[index - 1];
        if ((treaty.lineageId || treaty.id) !== (previous.lineageId || previous.id) ||
            Number(treaty.revision || 1) !== Number(previous.revision || 1) + 1 ||
            treaty.previousTreatyId !== previous.id ||
            treaty.parentDigest !== self.lineageDigest(previous)) {
          valid = false;
          reason = 'Treaty version-chain integrity check failed at ' + treaty.id;
        }
      });
      return {
        valid: valid,
        reason: reason,
        lineageId: chain[0] && (chain[0].lineageId || chain[0].id) || null,
        versions: chain
      };
    });
};

module.exports = TreatyService;
