const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function FederatedProposalService(options) {
  options = options || {};
  this.store = options.store;
  this.communities = options.communities;
  this.signing = options.signing || null;
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
  this.treaties = options.treaties || null;
  this.governanceProofs = options.governanceProofs || null;
}

FederatedProposalService.prototype.load = function (id) {
  return this.store.loadResource('federated-proposal', id);
};

FederatedProposalService.prototype.save = function (proposal) {
  return this.store.saveResource('federated-proposal', proposal);
};

FederatedProposalService.prototype._canRepresent = function (community, beingId) {
  return this.communities.hasRole(community, beingId, ['founder', 'governor', 'federation-admin']);
};

FederatedProposalService.prototype.create = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let sourceCommunity;
  let proposal;
  let treaty = null;

  if (!input.proposerCommunityId || !Array.isArray(input.participantCommunityIds) || !input.participantCommunityIds.length) {
    return Promise.reject(new Error('federation.proposal.create requires proposerCommunityId and participantCommunityIds'));
  }

  const participants = Array.from(new Set([input.proposerCommunityId].concat(input.participantCommunityIds)));
  const treatyPromise = input.treatyId && self.treaties ? self.treaties.load(input.treatyId) : Promise.resolve(null);

  return Promise.all([
    self.communities.load(input.proposerCommunityId),
    treatyPromise,
    Promise.all(participants.map(function (communityId) { return self.communities.load(communityId); }))
  ])
    .then(function (loaded) {
      sourceCommunity = loaded[0];
      treaty = loaded[1];
      const communities = loaded[2];
      if (!sourceCommunity || communities.some(function (community) { return !community; })) {
        throw new Error('Federated proposal includes an unknown community');
      }
      if (!self._canRepresent(sourceCommunity, being.id)) {
        throw new Error('Being is not authorised to create federated proposals for source community');
      }
      if (input.treatyId) {
        if (!treaty) {
          throw new Error('Unknown treaty: ' + input.treatyId);
        }
        const scope = input.scope || 'federation.proposal';
        const allCovered = participants.every(function (communityId) {
          return treaty.participantCommunityIds.includes(communityId);
        });
        if (!allCovered || !self.treaties.isActive(treaty, participants[0], participants[1], scope)) {
          throw new Error('Treaty does not authorise this federated proposal scope');
        }
      }

      const approvals = Number(input.approvals || participants.length);
      const rejections = Number(input.rejections || 1);
      if (!Number.isInteger(approvals) || approvals < 1 || approvals > participants.length) {
        throw new Error('Federated proposal approval threshold is invalid');
      }
      if (!Number.isInteger(rejections) || rejections < 1 || rejections > participants.length) {
        throw new Error('Federated proposal rejection threshold is invalid');
      }

      proposal = {
        id: input.id || ('federated-proposal:' + crypto.randomUUID()),
        version: 'octonomous.federated-proposal.v1',
        treatyId: input.treatyId || null,
        scope: input.scope || 'federation.proposal',
        kind: input.kind || 'general',
        proposerCommunityId: sourceCommunity.id,
        participantCommunityIds: participants,
        payload: clone(input.payload || {}),
        threshold: { approvals: approvals, rejections: rejections },
        governanceProofPolicy: input.governanceProofPolicy === 'required' ? 'required' : 'optional',
        votes: [],
        status: 'pending',
        createdAt: new Date().toISOString(),
        createdByBeingId: being.id,
        proposalReceipt: null,
        resolution: null,
        resolutionReceipt: null
      };

      return self.signing
        ? self.signing.sign(sourceCommunity, 'federation.proposal.created', proposal, {
          treatyId: proposal.treatyId,
          sourceEventId: context.event && context.event.id
        })
        : null;
    })
    .then(function (receipt) {
      proposal.proposalReceipt = receipt;
      return self.save(proposal);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, proposal: proposal };
      }
      return self.publisher.publish({
        type: 'federation.proposal.created',
        sourceBeingId: being.id,
        payload: { proposal: proposal, sourceBeingId: being.id }
      }).then(function (event) {
        return { ok: true, proposal: proposal, event: event };
      });
    });
};

FederatedProposalService.prototype.castCommunityVote = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const voteValue = String(input.vote || '').toLowerCase();
  let proposal;
  let community;
  let vote;

  if (!input.proposalId || !input.communityId || !['approve', 'reject', 'abstain'].includes(voteValue)) {
    return Promise.reject(new Error('federation.proposal.vote requires proposalId, communityId, and a valid vote'));
  }

  return Promise.all([self.load(input.proposalId), self.communities.load(input.communityId)])
    .then(function (loaded) {
      proposal = loaded[0];
      community = loaded[1];
      if (!proposal || !community) {
        throw new Error('Unknown federated proposal or community');
      }
      if (proposal.status !== 'pending') {
        throw new Error('Federated proposal is not pending');
      }
      if (!proposal.participantCommunityIds.includes(community.id)) {
        throw new Error('Community is not eligible to decide this proposal');
      }
      if (!self._canRepresent(community, being.id)) {
        throw new Error('Being is not authorised to decide for community: ' + community.id);
      }
      if ((proposal.votes || []).some(function (item) { return item.communityId === community.id; })) {
        throw new Error('Community has already decided this federated proposal');
      }

      vote = {
        id: crypto.randomUUID(),
        proposalId: proposal.id,
        communityId: community.id,
        voterBeingId: being.id,
        localGovernanceProposalId: input.localGovernanceProposalId || input.localGovernanceProof && input.localGovernanceProof.proposalId || null,
        localGovernanceProof: input.localGovernanceProof ? clone(input.localGovernanceProof) : null,
        vote: voteValue,
        reason: input.reason || '',
        createdAt: new Date().toISOString(),
        receipt: null
      };

      const expectedAuthorization = {
        action: 'federation.proposal.vote',
        proposalId: proposal.id,
        communityId: community.id,
        vote: voteValue
      };

      if (proposal.governanceProofPolicy === 'required' && !vote.localGovernanceProof) {
        throw new Error('Federated proposal requires a verified local-governance proof for each community vote');
      }

      const proofPromise = vote.localGovernanceProof
        ? (self.governanceProofs
          ? self.governanceProofs.verify(vote.localGovernanceProof, expectedAuthorization)
          : Promise.resolve({ valid: false, reason: 'No local-governance proof verifier configured' }))
        : Promise.resolve({ valid: null });

      return proofPromise
        .then(function (proofVerification) {
          if (vote.localGovernanceProof && (!proofVerification || proofVerification.valid !== true)) {
            throw new Error('Local-governance proof verification failed: ' + (proofVerification && proofVerification.reason || 'unknown reason'));
          }
          vote.localGovernanceVerification = proofVerification;
          return self.signing
            ? self.signing.sign(community, 'federation.proposal.vote.cast', vote, {
              proposalReceiptId: proposal.proposalReceipt && proposal.proposalReceipt.id || null,
              localGovernanceProposalId: vote.localGovernanceProposalId
            })
            : null;
        });
    })
    .then(function (receipt) {
      vote.receipt = receipt;
      proposal.votes.push(vote);
      const approvals = proposal.votes.filter(function (item) { return item.vote === 'approve'; }).length;
      const rejections = proposal.votes.filter(function (item) { return item.vote === 'reject'; }).length;
      let status = null;
      if (rejections >= proposal.threshold.rejections) {
        status = 'rejected';
      }
      else if (approvals >= proposal.threshold.approvals) {
        status = 'approved';
      }

      if (!status) {
        return null;
      }
      proposal.status = status;
      proposal.resolution = {
        status: status,
        approvals: approvals,
        rejections: rejections,
        abstentions: proposal.votes.filter(function (item) { return item.vote === 'abstain'; }).length,
        resolvedAt: new Date().toISOString()
      };
      if (!self.receipts) {
        return null;
      }
      return self.receipts.create({
        kind: 'federation.proposal.' + status,
        beingId: 'federation:' + proposal.id,
        subject: proposal.resolution,
        evidence: {
          proposalId: proposal.id,
          communityVoteReceiptIds: proposal.votes.map(function (item) {
            return item.receipt && item.receipt.id || null;
          }).filter(Boolean)
        }
      });
    })
    .then(function (resolutionReceipt) {
      if (resolutionReceipt) {
        proposal.resolutionReceipt = resolutionReceipt;
      }
      return self.save(proposal);
    })
    .then(function () {
      const result = { ok: true, proposal: proposal, vote: vote, resolution: proposal.resolution };
      if (!self.publisher) {
        return result;
      }
      return self.publisher.publish({
        type: proposal.status === 'pending' ? 'federation.proposal.vote.cast' : 'federation.proposal.' + proposal.status,
        sourceBeingId: being.id,
        payload: {
          proposalId: proposal.id,
          communityId: community.id,
          status: proposal.status,
          vote: vote,
          resolution: proposal.resolution,
          sourceBeingId: being.id
        }
      }).then(function (event) {
        result.event = event;
        return result;
      });
    });
};

module.exports = FederatedProposalService;
