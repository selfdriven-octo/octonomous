const canonical = require('../canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function FederationCapabilityDiscoveryService(options) {
  options = options || {};
  this.communities = options.communities;
  this.signing = options.signing;
  this.protocol = options.protocol;
}

FederationCapabilityDiscoveryService.prototype.publish = function (context) {
  const self = this;
  const input = context.input || {};
  let community;
  let descriptor;

  if (!input.communityId) {
    return Promise.reject(new Error('federation.discovery.publish requires communityId'));
  }

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      community = loaded;
      if (!community) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      if (context.being && !self.communities.hasRole(community, context.being.id, ['founder', 'governor', 'federation-admin'])) {
        throw new Error('Being is not authorised to publish federation discovery for community');
      }

      const protocol = self.protocol.describe({
        capabilities: input.protocolCapabilities || [],
        metadata: input.protocolMetadata || {}
      });

      descriptor = {
        version: 'octonomous.federation-discovery.v1',
        communityId: community.id,
        protocol: protocol,
        operations: Array.from(new Set(input.operations || [
          'federation.treaty',
          'federation.proposal',
          'federation.dispute',
          'federation.exchange',
          'reputation.proof'
        ])),
        scopes: Array.from(new Set(input.scopes || ['*'])),
        endpoints: clone(input.endpoints || {}),
        identity: clone(community.identity || community.groupIdentity || {}),
        validUntil: input.validUntil || null,
        publishedAt: new Date().toISOString(),
        receipt: null
      };

      const unsigned = clone(descriptor);
      delete unsigned.receipt;
      return self.signing.sign(community, 'federation.discovery.published', unsigned, {
        protocolDigest: protocol.digest
      });
    })
    .then(function (receipt) {
      descriptor.receipt = receipt;
      community.federation = community.federation || {};
      community.federation.discovery = descriptor;
      return self.communities.save(community);
    })
    .then(function () {
      return { ok: true, descriptor: descriptor };
    });
};

FederationCapabilityDiscoveryService.prototype.verify = function (descriptor) {
  const self = this;
  let community;
  if (!descriptor || !descriptor.communityId || !descriptor.receipt) {
    return Promise.resolve({ valid: false, reason: 'Invalid discovery descriptor' });
  }
  if (descriptor.validUntil && new Date(descriptor.validUntil).getTime() < Date.now()) {
    return Promise.resolve({ valid: false, reason: 'Discovery descriptor expired' });
  }

  return self.communities.load(descriptor.communityId)
    .then(function (loaded) {
      community = loaded;
      if (!community) {
        return { valid: false, reason: 'Unknown descriptor community' };
      }
      const unsigned = clone(descriptor);
      delete unsigned.receipt;
      const receiptSubject = descriptor.receipt.payload && descriptor.receipt.payload.subject;
      if (canonical.sha256(receiptSubject || {}) !== canonical.sha256(unsigned)) {
        return { valid: false, reason: 'Discovery receipt is not bound to descriptor' };
      }
      return self.signing.verify(community, descriptor.receipt);
    })
    .then(function (verification) {
      if (!verification || verification.valid === false) {
        return { valid: false, reason: 'Discovery signature invalid', cryptographic: verification };
      }
      return { valid: true, communityId: descriptor.communityId, descriptor: descriptor };
    });
};

FederationCapabilityDiscoveryService.prototype.negotiate = function (localDescriptor, remoteDescriptor) {
  const self = this;
  return Promise.all([self.verify(localDescriptor), self.verify(remoteDescriptor)])
    .then(function (results) {
      if (!results[0].valid || !results[1].valid) {
        throw new Error('Cannot negotiate unverified federation discovery descriptors');
      }
      const protocol = self.protocol.negotiate(localDescriptor.protocol, remoteDescriptor.protocol);
      const remoteOperations = new Set(remoteDescriptor.operations || []);
      const remoteScopes = new Set(remoteDescriptor.scopes || []);
      return {
        ok: true,
        protocol: protocol,
        operations: (localDescriptor.operations || []).filter(function (item) { return remoteOperations.has(item); }),
        scopes: (localDescriptor.scopes || []).filter(function (item) { return remoteScopes.has(item) || remoteScopes.has('*'); }),
        localCommunityId: localDescriptor.communityId,
        remoteCommunityId: remoteDescriptor.communityId
      };
    });
};

module.exports = FederationCapabilityDiscoveryService;
