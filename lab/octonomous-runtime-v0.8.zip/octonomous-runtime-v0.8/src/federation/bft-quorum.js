const crypto = require('crypto');
const canonical = require('../canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function BftQuorumService(options) {
  options = options || {};
  this.store = options.store;
  this.communities = options.communities;
  this.signing = options.signing;
  this.receipts = options.receipts || null;
}

BftQuorumService.prototype.createRound = function (input) {
  input = input || {};
  const participants = Array.from(new Set(input.participantCommunityIds || []));
  const f = Number(input.faultTolerance || 0);
  if (!input.subject || participants.length < 1) {
    return Promise.reject(new Error('BFT round requires subject and participantCommunityIds'));
  }
  if (!Number.isInteger(f) || f < 0) {
    return Promise.reject(new Error('faultTolerance must be a non-negative integer'));
  }
  if (participants.length < (3 * f + 1)) {
    return Promise.reject(new Error('BFT round requires n >= 3f + 1 participants'));
  }

  const round = {
    id: input.id || ('bft-round:' + crypto.randomUUID()),
    version: 'octonomous.bft-round.v1',
    subject: clone(input.subject),
    subjectDigest: canonical.sha256(input.subject),
    participantCommunityIds: participants,
    faultTolerance: f,
    quorum: 2 * f + 1,
    decisions: [],
    equivocations: [],
    status: 'pending',
    certificate: null,
    createdAt: new Date().toISOString()
  };

  return this.store.saveResource('federation-bft-round', round)
    .then(function () { return { ok: true, round: round }; });
};

BftQuorumService.prototype.load = function (id) {
  return this.store.loadResource('federation-bft-round', id);
};

BftQuorumService.prototype.cast = function (context) {
  const self = this;
  const input = context.input || {};
  let round;
  let community;
  let decision;

  if (!input.roundId || !input.communityId || !input.value) {
    return Promise.reject(new Error('BFT decision requires roundId, communityId, and value'));
  }

  return Promise.all([self.load(input.roundId), self.communities.load(input.communityId)])
    .then(function (loaded) {
      round = loaded[0];
      community = loaded[1];
      if (!round || !community) {
        throw new Error('Unknown BFT round or community');
      }
      if (round.status !== 'pending') {
        throw new Error('BFT round is already certified');
      }
      if (!round.participantCommunityIds.includes(community.id)) {
        throw new Error('Community is not a BFT round participant');
      }
      if (context.being && !self.communities.hasRole(community, context.being.id, ['founder', 'governor', 'federation-admin'])) {
        throw new Error('Being is not authorised to decide for BFT participant community');
      }

      const existing = round.decisions.find(function (item) { return item.communityId === community.id; });
      if (existing) {
        if (canonical.sha256(existing.value) !== canonical.sha256(input.value)) {
          round.equivocations.push({
            communityId: community.id,
            firstDecisionId: existing.id,
            conflictingValue: clone(input.value),
            detectedAt: new Date().toISOString()
          });
          return self.store.saveResource('federation-bft-round', round)
            .then(function () {
              throw new Error('BFT equivocation detected for community: ' + community.id);
            });
        }
        throw new Error('Community has already cast this BFT decision');
      }

      decision = {
        id: crypto.randomUUID(),
        version: 'octonomous.bft-decision.v1',
        roundId: round.id,
        subjectDigest: round.subjectDigest,
        communityId: community.id,
        value: clone(input.value),
        valueDigest: canonical.sha256(input.value),
        createdAt: new Date().toISOString(),
        receipt: null
      };
      return self.signing.sign(community, 'federation.bft.decision', clone(decision), {
        roundId: round.id,
        subjectDigest: round.subjectDigest
      });
    })
    .then(function (receipt) {
      decision.receipt = receipt;
      round.decisions.push(decision);
      return self._tryCertify(round);
    })
    .then(function () {
      return self.store.saveResource('federation-bft-round', round);
    })
    .then(function () {
      return { ok: true, round: round, decision: decision, certificate: round.certificate };
    });
};

BftQuorumService.prototype._tryCertify = function (round) {
  const self = this;
  const groups = {};
  round.decisions.forEach(function (decision) {
    groups[decision.valueDigest] = groups[decision.valueDigest] || [];
    groups[decision.valueDigest].push(decision);
  });
  const winnerDigest = Object.keys(groups).find(function (digest) {
    return groups[digest].length >= round.quorum;
  });
  if (!winnerDigest) {
    return Promise.resolve(null);
  }

  const winners = groups[winnerDigest].slice(0, round.quorum);
  const certificate = {
    id: 'bft-cert:' + crypto.randomUUID(),
    version: 'octonomous.bft-quorum-certificate.v1',
    roundId: round.id,
    subjectDigest: round.subjectDigest,
    value: clone(winners[0].value),
    valueDigest: winnerDigest,
    participantCount: round.participantCommunityIds.length,
    faultTolerance: round.faultTolerance,
    quorum: round.quorum,
    signerCommunityIds: winners.map(function (item) { return item.communityId; }),
    decisionReceiptIds: winners.map(function (item) { return item.receipt && item.receipt.id || null; }).filter(Boolean),
    certifiedAt: new Date().toISOString(),
    receipt: null
  };

  const receiptPromise = self.receipts ? self.receipts.create({
    kind: 'federation.bft.quorum.certified',
    beingId: 'federation:' + round.id,
    subject: clone(certificate),
    evidence: { decisionReceiptIds: certificate.decisionReceiptIds }
  }) : Promise.resolve(null);

  return receiptPromise.then(function (receipt) {
    certificate.receipt = receipt;
    round.status = 'certified';
    round.certificate = certificate;
    return certificate;
  });
};

BftQuorumService.prototype.verifyCertificate = function (certificate) {
  const self = this;
  if (!certificate || certificate.version !== 'octonomous.bft-quorum-certificate.v1') {
    return Promise.resolve({ valid: false, reason: 'Unsupported BFT certificate' });
  }
  if (certificate.participantCount < 3 * certificate.faultTolerance + 1 || certificate.quorum !== 2 * certificate.faultTolerance + 1) {
    return Promise.resolve({ valid: false, reason: 'Invalid BFT quorum parameters' });
  }
  if ((certificate.signerCommunityIds || []).length < certificate.quorum || new Set(certificate.signerCommunityIds || []).size !== (certificate.signerCommunityIds || []).length) {
    return Promise.resolve({ valid: false, reason: 'BFT certificate does not contain a distinct quorum' });
  }

  return self.load(certificate.roundId)
    .then(function (round) {
      if (!round) {
        return { valid: false, reason: 'Unknown BFT round' };
      }
      if (round.subjectDigest !== certificate.subjectDigest || canonical.sha256(certificate.value) !== certificate.valueDigest) {
        return { valid: false, reason: 'BFT certificate subject/value digest mismatch' };
      }
      const decisions = (round.decisions || []).filter(function (item) {
        return certificate.signerCommunityIds.includes(item.communityId) && item.valueDigest === certificate.valueDigest;
      });
      if (decisions.length < certificate.quorum) {
        return { valid: false, reason: 'BFT certificate is not backed by stored quorum decisions' };
      }

      return Promise.all(decisions.slice(0, certificate.quorum).map(function (decision) {
        const signedSubject = decision.receipt && decision.receipt.payload && decision.receipt.payload.subject || {};
        const expectedSubject = clone(decision);
        expectedSubject.receipt = null;
        if (canonical.sha256(signedSubject) !== canonical.sha256(expectedSubject)) {
          return Promise.resolve({ valid: false, reason: 'BFT decision receipt is not bound to stored decision' });
        }
        return self.communities.load(decision.communityId)
          .then(function (community) {
            if (!community) { return { valid: false }; }
            return self.signing.verify(community, decision.receipt);
          });
      }))
        .then(function (results) {
          const decisionsValid = results.every(function (result) { return result && result.valid !== false; });
          if (!decisionsValid) {
            return { valid: false, reason: 'One or more BFT decision signatures/bindings are invalid' };
          }
          if (!certificate.receipt || !self.receipts) {
            return { valid: true, certificateReceiptValid: null };
          }
          const certificateSubject = clone(certificate);
          certificateSubject.receipt = null;
          const signedCertificateSubject = certificate.receipt.payload && certificate.receipt.payload.subject || {};
          if (canonical.sha256(signedCertificateSubject) !== canonical.sha256(certificateSubject)) {
            return { valid: false, reason: 'BFT certificate receipt is not bound to certificate contents' };
          }
          return self.receipts.verify(certificate.receipt)
            .then(function (receiptVerification) {
              const valid = receiptVerification && receiptVerification.valid !== false;
              return {
                valid: valid,
                reason: valid ? null : 'BFT certificate receipt signature is invalid',
                certificateReceipt: receiptVerification
              };
            });
        });
    });
};

module.exports = BftQuorumService;
