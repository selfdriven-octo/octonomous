const canonical = require('../canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function LocalGovernanceProofService(options) {
  options = options || {};
  this.communities = options.communities;
  this.signing = options.signing;
}

LocalGovernanceProofService.prototype._proposal = function (community, proposalId) {
  return community && community.governance && (community.governance.proposals || []).find(function (item) {
    return item.id === proposalId;
  });
};

LocalGovernanceProofService.prototype.create = function (input) {
  const self = this;
  let community;
  let proposal;
  if (!input || !input.communityId || !input.proposalId || !input.authorization) {
    return Promise.reject(new Error('Local governance proof requires communityId, proposalId, and authorization'));
  }

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      community = loaded;
      if (!community) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      proposal = self._proposal(community, input.proposalId);
      if (!proposal || proposal.status !== 'approved' || !proposal.resolutionReceipt) {
        throw new Error('Local governance proposal is not approved with a signed resolution');
      }
      if (!proposal.payload || canonical.sha256(proposal.payload.authorization || {}) !== canonical.sha256(input.authorization)) {
        throw new Error('Local governance proposal does not authorise this exact external decision');
      }

      return {
        version: 'octonomous.local-governance-proof.v1',
        communityId: community.id,
        proposalId: proposal.id,
        proposalKind: proposal.kind,
        authorization: clone(input.authorization),
        authorizationDigest: canonical.sha256(input.authorization),
        proposalReceipt: clone(proposal.receipt),
        resolutionReceipt: clone(proposal.resolutionReceipt),
        createdAt: new Date().toISOString()
      };
    });
};

LocalGovernanceProofService.prototype.verify = function (proof, expectedAuthorization) {
  const self = this;
  let community;
  let proposal;
  if (!proof || proof.version !== 'octonomous.local-governance-proof.v1') {
    return Promise.resolve({ valid: false, reason: 'Unsupported local governance proof' });
  }
  if (expectedAuthorization && canonical.sha256(proof.authorization || {}) !== canonical.sha256(expectedAuthorization)) {
    return Promise.resolve({ valid: false, reason: 'Governance proof authorization mismatch' });
  }
  if (proof.authorizationDigest !== canonical.sha256(proof.authorization || {})) {
    return Promise.resolve({ valid: false, reason: 'Governance proof authorization digest mismatch' });
  }

  return self.communities.load(proof.communityId)
    .then(function (loaded) {
      community = loaded;
      if (!community) {
        return { valid: false, reason: 'Unknown governance-proof community' };
      }
      proposal = self._proposal(community, proof.proposalId);
      if (!proposal || proposal.status !== 'approved') {
        return { valid: false, reason: 'Referenced local governance proposal is not approved' };
      }
      if (canonical.sha256(proposal.payload && proposal.payload.authorization || {}) !== proof.authorizationDigest) {
        return { valid: false, reason: 'Referenced proposal authorization does not match proof' };
      }
      if (!proposal.resolutionReceipt || canonical.sha256(proposal.resolutionReceipt) !== canonical.sha256(proof.resolutionReceipt)) {
        return { valid: false, reason: 'Resolution receipt differs from current community record' };
      }
      const resolutionSubject = proof.resolutionReceipt && proof.resolutionReceipt.payload && proof.resolutionReceipt.payload.subject || {};
      if (resolutionSubject.proposalId !== proposal.id ||
          resolutionSubject.kind !== proposal.kind ||
          !resolutionSubject.resolution || resolutionSubject.resolution.status !== 'approved' ||
          canonical.sha256(resolutionSubject.payload || {}) !== canonical.sha256(proposal.payload || {})) {
        return { valid: false, reason: 'Signed local governance resolution is not bound to the referenced approved proposal' };
      }
      return self.signing.verify(community, proof.resolutionReceipt);
    })
    .then(function (verification) {
      if (verification && verification.valid !== undefined) {
        if (!verification.valid) {
          return { valid: false, reason: 'Local governance resolution signature invalid', cryptographic: verification };
        }
        return { valid: true, communityId: proof.communityId, proposalId: proof.proposalId, cryptographic: verification };
      }
      return verification;
    });
};

module.exports = LocalGovernanceProofService;
