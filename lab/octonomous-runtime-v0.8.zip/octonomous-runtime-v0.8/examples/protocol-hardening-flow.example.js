const bootstrap = require('../src/bootstrap');

let services;
let communityA;
let communityB;

bootstrap()
  .then(function (result) {
    services = result;
    return services.communities.load('community:protocol-a');
  })
  .then(function (existing) {
    if (existing) {
      communityA = existing;
      return existing;
    }
    return services.communities.create({
      being: { id: 'being:protocol-a' },
      input: { id: 'community:protocol-a', name: 'Protocol A' }
    }).then(function (result) {
      communityA = result.community;
      return communityA;
    });
  })
  .then(function () {
    return services.communities.load('community:protocol-b');
  })
  .then(function (existing) {
    if (existing) {
      communityB = existing;
      return existing;
    }
    return services.communities.create({
      being: { id: 'being:protocol-b' },
      input: { id: 'community:protocol-b', name: 'Protocol B' }
    }).then(function (result) {
      communityB = result.community;
      return communityB;
    });
  })
  .then(function () {
    return services.federationEnvelopes.create({
      being: { id: 'being:protocol-a' },
      input: {
        senderCommunityId: communityA.id,
        recipientCommunityId: communityB.id,
        messageType: 'federation.example.hello',
        payload: { hello: 'Octonomous federation v0.8' }
      }
    });
  })
  .then(function (result) {
    console.log('Signed envelope:', JSON.stringify(result.envelope, null, 2));
    return services.federationEnvelopes.verify({
      envelope: result.envelope,
      expectedRecipientCommunityId: communityB.id
    });
  })
  .then(function (verified) {
    console.log('Verified:', verified.valid);
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
