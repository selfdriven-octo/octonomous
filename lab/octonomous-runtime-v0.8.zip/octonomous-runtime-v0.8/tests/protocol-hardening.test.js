const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const FileStore = require('../src/store/file');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const CommunitySigningService = require('../src/federation/community-signing');
const CommunityService = require('../src/federation/communities');
const CommunityGovernanceService = require('../src/federation/governance');
const FederationProtocolService = require('../src/federation/protocol');
const ReplayProtectionService = require('../src/federation/replay-protection');
const FederationEnvelopeService = require('../src/federation/envelopes');
const FederationCapabilityDiscoveryService = require('../src/federation/capability-discovery');
const LocalGovernanceProofService = require('../src/federation/governance-proofs');
const TreatyService = require('../src/federation/treaties');
const FederatedProposalService = require('../src/federation/federated-proposals');
const BftQuorumService = require('../src/federation/bft-quorum');

function createServices(protocolOptions) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-v08-'));
  const store = new FileStore({ basePath: dir });
  const receipts = new ReceiptService({ signer: new LocalEd25519Signer({ aid: 'did:key:v08-test' }) });
  const signing = new CommunitySigningService({ receipts: receipts });
  const communities = new CommunityService({ store: store, signing: signing });
  const governance = new CommunityGovernanceService({ communities: communities, signing: signing, receipts: receipts });
  const protocol = new FederationProtocolService(protocolOptions || {});
  const replay = new ReplayProtectionService({ store: store, retentionSeconds: 3600 });
  const envelopes = new FederationEnvelopeService({
    communities: communities,
    signing: signing,
    protocol: protocol,
    replay: replay,
    maxLifetimeSeconds: 600,
    clockSkewSeconds: 5
  });
  const discovery = new FederationCapabilityDiscoveryService({ communities: communities, signing: signing, protocol: protocol });
  const governanceProofs = new LocalGovernanceProofService({ communities: communities, signing: signing });
  const treaties = new TreatyService({ store: store, communities: communities, signing: signing, receipts: receipts });
  const proposals = new FederatedProposalService({
    store: store,
    communities: communities,
    signing: signing,
    receipts: receipts,
    treaties: treaties,
    governanceProofs: governanceProofs
  });
  const bft = new BftQuorumService({ store: store, communities: communities, signing: signing, receipts: receipts });

  return {
    dir: dir,
    store: store,
    receipts: receipts,
    signing: signing,
    communities: communities,
    governance: governance,
    protocol: protocol,
    replay: replay,
    envelopes: envelopes,
    discovery: discovery,
    governanceProofs: governanceProofs,
    treaties: treaties,
    proposals: proposals,
    bft: bft
  };
}

function makeCommunity(svc, id, being) {
  return svc.communities.create({ being: being, input: { id: id, name: id } });
}

function activateTreaty(svc, a, beingA, b, beingB) {
  let treaty;
  return svc.treaties.propose({
    being: beingA,
    input: { proposerCommunityId: a, participantCommunityIds: [b], scopes: ['federation.proposal', 'resource.exchange'] }
  })
    .then(function (result) {
      treaty = result.treaty;
      return svc.treaties.ratify({ being: beingA, input: { treatyId: treaty.id, communityId: a } });
    })
    .then(function () {
      return svc.treaties.ratify({ being: beingB, input: { treatyId: treaty.id, communityId: b } });
    })
    .then(function () { return svc.treaties.load(treaty.id); });
}

test('signed federation envelope verifies once and atomic nonce claim rejects replay', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  let envelope;

  return Promise.all([makeCommunity(svc, 'community:a', a), makeCommunity(svc, 'community:b', b)])
    .then(function () {
      return svc.envelopes.create({
        being: a,
        input: {
          senderCommunityId: 'community:a',
          recipientCommunityId: 'community:b',
          messageType: 'federation.test',
          payload: { value: 42 },
          protocolVersion: '2.0'
        }
      });
    })
    .then(function (result) {
      envelope = result.envelope;
      assert.ok(envelope.receipt.signature);
      return svc.envelopes.verify({ envelope: envelope, expectedRecipientCommunityId: 'community:b' });
    })
    .then(function (verified) {
      assert.equal(verified.valid, true);
      return assert.rejects(function () {
        return svc.envelopes.verify({ envelope: envelope, expectedRecipientCommunityId: 'community:b' });
      }, /replay detected/);
    });
});

test('federation envelope signature binds the exact payload and recipient', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };

  return Promise.all([makeCommunity(svc, 'community:a', a), makeCommunity(svc, 'community:b', b)])
    .then(function () {
      return svc.envelopes.create({
        being: a,
        input: { senderCommunityId: 'community:a', recipientCommunityId: 'community:b', messageType: 'federation.test', payload: { amount: 10 } }
      });
    })
    .then(function (result) {
      const tampered = JSON.parse(JSON.stringify(result.envelope));
      tampered.payload.amount = 1000;
      return assert.rejects(function () {
        return svc.envelopes.verify({ envelope: tampered, expectedRecipientCommunityId: 'community:b' });
      }, /not bound to the envelope contents/);
    });
});

test('signed discovery descriptors negotiate the highest common protocol and capability set', function () {
  const svc = createServices({ supportedVersions: ['1.0', '1.1', '2.0'] });
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  const remoteProtocol = new FederationProtocolService({
    supportedVersions: ['1.1', '2.0', '2.1'],
    capabilities: ['signed-envelopes', 'replay-protection', 'version-negotiation']
  });
  const remoteDiscovery = new FederationCapabilityDiscoveryService({
    communities: svc.communities,
    signing: svc.signing,
    protocol: remoteProtocol
  });
  let localDescriptor;
  let remoteDescriptor;

  return Promise.all([makeCommunity(svc, 'community:a', a), makeCommunity(svc, 'community:b', b)])
    .then(function () {
      return svc.discovery.publish({
        being: a,
        input: { communityId: 'community:a', operations: ['federation.proposal', 'federation.exchange'], scopes: ['reputation', 'resource.exchange'] }
      });
    })
    .then(function (result) {
      localDescriptor = result.descriptor;
      return remoteDiscovery.publish({
        being: b,
        input: { communityId: 'community:b', operations: ['federation.proposal'], scopes: ['reputation'] }
      });
    })
    .then(function (result) {
      remoteDescriptor = result.descriptor;
      return svc.discovery.negotiate(localDescriptor, remoteDescriptor);
    })
    .then(function (negotiated) {
      assert.equal(negotiated.protocol.version, '2.0');
      assert.deepEqual(negotiated.operations, ['federation.proposal']);
      assert.deepEqual(negotiated.scopes, ['reputation']);
      assert.ok(negotiated.protocol.capabilities.includes('signed-envelopes'));
    });
});

test('required local-governance proof binds a sovereign community vote to the exact approved decision', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  let federatedProposal;
  let localProposal;
  let proof;
  let authorization;

  return Promise.all([makeCommunity(svc, 'community:a', a), makeCommunity(svc, 'community:b', b)])
    .then(function () {
      return svc.proposals.create({
        being: a,
        input: {
          proposerCommunityId: 'community:a',
          participantCommunityIds: ['community:b'],
          approvals: 2,
          governanceProofPolicy: 'required',
          payload: { standard: 'evidence-v2' }
        }
      });
    })
    .then(function (result) {
      federatedProposal = result.proposal;
      authorization = {
        action: 'federation.proposal.vote',
        proposalId: federatedProposal.id,
        communityId: 'community:a',
        vote: 'approve'
      };
      return svc.governance.propose({
        being: a,
        input: {
          communityId: 'community:a',
          kind: 'federation.vote.authorise',
          payload: { authorization: authorization }
        }
      });
    })
    .then(function (result) {
      localProposal = result.proposal;
      return svc.governance.castVote({
        being: a,
        input: { communityId: 'community:a', proposalId: localProposal.id, vote: 'approve' }
      });
    })
    .then(function () {
      return svc.governanceProofs.create({
        communityId: 'community:a',
        proposalId: localProposal.id,
        authorization: authorization
      });
    })
    .then(function (createdProof) {
      proof = createdProof;
      return assert.rejects(function () {
        return svc.proposals.castCommunityVote({
          being: b,
          input: { proposalId: federatedProposal.id, communityId: 'community:b', vote: 'approve' }
        });
      }, /requires a verified local-governance proof/);
    })
    .then(function () {
      return svc.proposals.castCommunityVote({
        being: a,
        input: { proposalId: federatedProposal.id, communityId: 'community:a', vote: 'approve', localGovernanceProof: proof }
      });
    })
    .then(function (result) {
      assert.equal(result.vote.localGovernanceVerification.valid, true);
      const wrong = Object.assign({}, authorization, { vote: 'reject' });
      return svc.governanceProofs.verify(proof, wrong);
    })
    .then(function (verification) {
      assert.equal(verification.valid, false);
      assert.match(verification.reason, /authorization mismatch/);
    });
});

test('treaty amendment creates a digest-linked version chain and supersedes parent only after re-ratification', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  let original;
  let amended;

  return Promise.all([makeCommunity(svc, 'community:a', a), makeCommunity(svc, 'community:b', b)])
    .then(function () { return activateTreaty(svc, 'community:a', a, 'community:b', b); })
    .then(function (treaty) {
      original = treaty;
      return svc.treaties.amend({
        being: a,
        input: {
          treatyId: original.id,
          proposerCommunityId: 'community:a',
          patch: { scopes: ['federation.proposal', 'resource.exchange', 'reputation'] }
        }
      });
    })
    .then(function (result) {
      amended = result.treaty;
      assert.equal(amended.revision, 2);
      assert.equal(amended.previousTreatyId, original.id);
      assert.equal(amended.status, 'proposed');
      return svc.treaties.load(original.id);
    })
    .then(function (stillActive) {
      assert.equal(stillActive.status, 'active');
      return svc.treaties.ratify({ being: a, input: { treatyId: amended.id, communityId: 'community:a' } });
    })
    .then(function () {
      return svc.treaties.ratify({ being: b, input: { treatyId: amended.id, communityId: 'community:b' } });
    })
    .then(function () {
      return Promise.all([svc.treaties.load(original.id), svc.treaties.versionChain(amended.id)]);
    })
    .then(function (loaded) {
      assert.equal(loaded[0].status, 'superseded');
      assert.equal(loaded[0].supersededByTreatyId, amended.id);
      assert.equal(loaded[1].valid, true);
      assert.deepEqual(loaded[1].versions.map(function (item) { return item.revision; }), [1, 2]);
    });
});

test('BFT quorum configuration rejects n < 3f+1', function () {
  const svc = createServices();
  return assert.rejects(function () {
    return svc.bft.createRound({
      subject: { decision: 'x' },
      participantCommunityIds: ['a', 'b', 'c'],
      faultTolerance: 1
    });
  }, /n >= 3f \+ 1/);
});

test('BFT quorum certificate requires 2f+1 matching signed community decisions and verifies them', function () {
  const svc = createServices();
  const beings = ['a', 'b', 'c', 'd'].map(function (id) { return { id: 'being:' + id }; });
  const communityIds = ['a', 'b', 'c', 'd'].map(function (id) { return 'community:' + id; });
  let round;
  let certificate;

  return Promise.all(communityIds.map(function (id, index) { return makeCommunity(svc, id, beings[index]); }))
    .then(function () {
      return svc.bft.createRound({
        subject: { proposalId: 'federated:123' },
        participantCommunityIds: communityIds,
        faultTolerance: 1
      });
    })
    .then(function (result) {
      round = result.round;
      return svc.bft.cast({ being: beings[0], input: { roundId: round.id, communityId: communityIds[0], value: { decision: 'approve' } } });
    })
    .then(function (first) {
      assert.equal(first.round.status, 'pending');
      return svc.bft.cast({ being: beings[1], input: { roundId: round.id, communityId: communityIds[1], value: { decision: 'approve' } } });
    })
    .then(function (second) {
      assert.equal(second.round.status, 'pending');
      return svc.bft.cast({ being: beings[2], input: { roundId: round.id, communityId: communityIds[2], value: { decision: 'approve' } } });
    })
    .then(function (third) {
      assert.equal(third.round.status, 'certified');
      certificate = third.certificate;
      assert.equal(certificate.quorum, 3);
      assert.equal(certificate.signerCommunityIds.length, 3);
      return svc.bft.verifyCertificate(certificate);
    })
    .then(function (verification) {
      assert.equal(verification.valid, true);
    });
});

test('BFT layer detects community equivocation before quorum certification', function () {
  const svc = createServices();
  const beings = ['a', 'b', 'c', 'd'].map(function (id) { return { id: 'being:' + id }; });
  const communityIds = ['a', 'b', 'c', 'd'].map(function (id) { return 'community:' + id; });
  let round;

  return Promise.all(communityIds.map(function (id, index) { return makeCommunity(svc, id, beings[index]); }))
    .then(function () {
      return svc.bft.createRound({ subject: { decision: 'x' }, participantCommunityIds: communityIds, faultTolerance: 1 });
    })
    .then(function (result) {
      round = result.round;
      return svc.bft.cast({ being: beings[0], input: { roundId: round.id, communityId: communityIds[0], value: 'A' } });
    })
    .then(function () {
      return assert.rejects(function () {
        return svc.bft.cast({ being: beings[0], input: { roundId: round.id, communityId: communityIds[0], value: 'B' } });
      }, /equivocation detected/);
    })
    .then(function () {
      return svc.bft.load(round.id);
    })
    .then(function (loaded) {
      assert.equal(loaded.equivocations.length, 1);
      assert.equal(loaded.status, 'pending');
    });
});
