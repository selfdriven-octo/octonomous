const bootstrap = require('../bootstrap');

let servicesPromise;

function getServices() {
  if (!servicesPromise) {
    servicesPromise = bootstrap();
  }
  return servicesPromise;
}

function response(statusCode, body) {
  return {
    statusCode: statusCode,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body)
  };
}

exports.handler = function (event) {
  let body;
  try {
    body = typeof event.body === 'string' ? JSON.parse(event.body) : (event.body || {});
  }
  catch (error) {
    return Promise.resolve(response(400, { ok: false, error: 'Invalid JSON body' }));
  }

  if (!body.envelope) {
    return Promise.resolve(response(400, { ok: false, error: 'Missing envelope' }));
  }

  return getServices()
    .then(function (services) {
      return services.gatewayInbound.handle({
        envelope: body.envelope,
        expectedRecipientCommunityId: process.env.GATEWAY_COMMUNITY_ID,
        transport: 'http',
        headers: event.headers || {}
      });
    })
    .then(function (result) {
      return response(result.inProgress ? 202 : 200, { ok: true, delivery: result });
    })
    .catch(function (error) {
      console.error(error);
      const status = /recipient mismatch|signature|expired|unsupported|replay|unknown.*sender/i.test(error.message) ? 400 : 500;
      return response(status, { ok: false, error: error.message });
    });
};
