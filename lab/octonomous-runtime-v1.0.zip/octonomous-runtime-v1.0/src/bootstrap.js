const path = require('path');
const Runtime = require('./runtime');
const Policy = require('./policy');
const ToolRegistry = require('./tools');
const CommitmentService = require('./commitments');
const ApprovalService = require('./approvals');
const RelationshipService = require('./relationships');
const ContributionService = require('./contributions');
const DelegationService = require('./delegations');
const CapabilityService = require('./capabilities');
const VerificationService = require('./verifications');
const ConstitutionService = require('./governance/constitutions');
const GovernanceProposalService = require('./governance/proposals');
const ChallengeService = require('./governance/challenges');
const VerificationQuorumService = require('./governance/quorum');
const EvidenceReputationService = require('./reputation/evidence');
const PortableReputationProofService = require('./reputation/portable-proof');
const CommunitySigningService = require('./federation/community-signing');
const CommunityService = require('./federation/communities');
const MembershipService = require('./federation/memberships');
const GovernanceDelegationService = require('./federation/governance-delegations');
const CommunityGovernanceService = require('./federation/governance');
const FederationTrustService = require('./federation/trust');
const TreatyService = require('./federation/treaties');
const FederatedProposalService = require('./federation/federated-proposals');
const FederatedDisputeService = require('./federation/disputes');
const FederationTrustPathService = require('./federation/trust-paths');
const ResourceExchangeService = require('./federation/resource-exchange');
const GroupIdentityService = require('./federation/group-identity');
const FederationProtocolService = require('./federation/protocol');
const ReplayProtectionService = require('./federation/replay-protection');
const FederationEnvelopeService = require('./federation/envelopes');
const FederationCapabilityDiscoveryService = require('./federation/capability-discovery');
const LocalGovernanceProofService = require('./federation/governance-proofs');
const BftQuorumService = require('./federation/bft-quorum');
const PeerRegistryService = require('./gateway/peer-registry');
const GatewayIdempotencyService = require('./gateway/idempotency');
const RetryPolicy = require('./gateway/retry');
const DeadLetterService = require('./gateway/dead-letter');
const GatewayTraceService = require('./gateway/tracing');
const GatewayRouter = require('./gateway/router');
const InboundGateway = require('./gateway/inbound');
const OutboundGateway = require('./gateway/outbound');
const GatewayTransportRegistry = require('./gateway/transports/registry');
const HttpGatewayTransport = require('./gateway/transports/http');
const McpGatewayTransport = require('./gateway/transports/mcp');
const DidCommGatewayTransport = require('./gateway/transports/didcomm');
const AcdcCredentialService = require('./credentials/acdc');
const EvidenceAnchorService = require('./anchors/evidence');
const CardanoProvider = require('./anchors/cardano-provider');
const ReceiptService = require('./receipts/service');
const LocalEd25519Signer = require('./receipts/local-ed25519');
const KeriSigner = require('./receipts/keri');
const FileStore = require('./store/file');
const DynamoDBStore = require('./store/dynamodb');
const OpenAICognition = require('./cognition/openai');
const MockCognition = require('./cognition/mock');
const EventBridgePublisher = require('./events/eventbridge');
const ReminderScheduler = require('./events/scheduler');
const MCPManager = require('./mcp');
const Secrets = require('./secrets');

function bool(value, fallback) {
  if (value === undefined || value === '') {
    return fallback;
  }
  return String(value).toLowerCase() === 'true';
}

function parseMcpServers() {
  if (!process.env.MCP_SERVERS_JSON) {
    return [];
  }
  return JSON.parse(process.env.MCP_SERVERS_JSON);
}

function loadProviderModule(modulePath, options) {
  if (!modulePath) {
    return null;
  }

  const providerPath = path.isAbsolute(modulePath)
    ? modulePath
    : path.resolve(process.cwd(), modulePath);
  const loaded = require(providerPath);

  return typeof loaded.createProvider === 'function'
    ? loaded.createProvider(options || {})
    : loaded;
}

function createStore() {
  if (process.env.STORE_MODE === 'dynamodb') {
    return new DynamoDBStore({
      tableName: process.env.DYNAMODB_TABLE,
      region: process.env.AWS_REGION
    });
  }

  return new FileStore({
    basePath: process.env.DATA_PATH || path.join(process.cwd(), 'data')
  });
}

function resolveOpenAIKey(secrets) {
  if (process.env.OPENAI_API_KEY) {
    return Promise.resolve(process.env.OPENAI_API_KEY);
  }

  if (process.env.OPENAI_API_KEY_SECRET_ARN) {
    return secrets.get(
      process.env.OPENAI_API_KEY_SECRET_ARN,
      process.env.OPENAI_API_KEY_SECRET_JSON_KEY || undefined
    );
  }

  return Promise.resolve(null);
}

function resolveMcpServerSecrets(servers, secrets) {
  return Promise.all(servers.map(function (server) {
    if (!server.tokenSecretArn) {
      return server;
    }

    return secrets.get(server.tokenSecretArn, server.tokenSecretJsonKey)
      .then(function (token) {
        return Object.assign({}, server, { token: token });
      });
  }));
}

function createReceiptSigner() {
  const mode = process.env.RECEIPT_MODE || 'local';

  if (mode === 'none') {
    return null;
  }

  if (mode === 'keri') {
    if (!process.env.KERI_SIGNER_MODULE) {
      throw new Error('RECEIPT_MODE=keri requires KERI_SIGNER_MODULE');
    }

    const provider = loadProviderModule(process.env.KERI_SIGNER_MODULE, {
      aid: process.env.KERI_AID,
      keriaUrl: process.env.KERIA_URL
    });

    return new KeriSigner({
      aid: process.env.KERI_AID,
      provider: provider
    });
  }

  return new LocalEd25519Signer({
    aid: process.env.LOCAL_RECEIPT_AID || 'did:key:local-development',
    privateKeyPem: process.env.RECEIPT_PRIVATE_KEY_PEM,
    publicKeyPem: process.env.RECEIPT_PUBLIC_KEY_PEM
  });
}

function bootstrap() {
  const region = process.env.AWS_REGION;
  const tools = new ToolRegistry();
  const secrets = new Secrets({ region: region });
  const store = createStore();
  const receiptSigner = createReceiptSigner();
  const receipts = new ReceiptService({ signer: receiptSigner });

  const eventPublisher = process.env.EVENT_BUS_NAME
    ? new EventBridgePublisher({
      busName: process.env.EVENT_BUS_NAME,
      region: region
    })
    : null;

  const scheduler = process.env.WAKE_QUEUE_ARN && process.env.SCHEDULER_TARGET_ROLE_ARN
    ? new ReminderScheduler({
      queueArn: process.env.WAKE_QUEUE_ARN,
      roleArn: process.env.SCHEDULER_TARGET_ROLE_ARN,
      region: region
    })
    : null;

  const acdcProvider = loadProviderModule(process.env.ACDC_PROVIDER_MODULE, {
    keriaUrl: process.env.KERIA_URL,
    registryName: process.env.ACDC_REGISTRY_NAME
  });

  const credentials = new AcdcCredentialService({
    provider: acdcProvider,
    receipts: receipts
  });

  const capabilities = new CapabilityService({
    publisher: eventPublisher,
    receipts: receipts,
    credentials: credentials
  });

  const delegations = new DelegationService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const relationships = new RelationshipService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const commitments = new CommitmentService({
    scheduler: scheduler,
    receipts: receipts,
    publisher: eventPublisher
  });

  const verifications = new VerificationService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const constitutions = new ConstitutionService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const governance = new GovernanceProposalService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const challenges = new ChallengeService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const quorum = new VerificationQuorumService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const reputation = new EvidenceReputationService({
    receipts: receipts
  });

  const communitySignerProvider = loadProviderModule(process.env.COMMUNITY_SIGNER_MODULE, {
    keriaUrl: process.env.KERIA_URL,
    aid: process.env.COMMUNITY_KERI_AID
  });

  const communitySigning = new CommunitySigningService({
    provider: communitySignerProvider,
    receipts: receipts
  });

  const communities = new CommunityService({
    store: store,
    signing: communitySigning,
    publisher: eventPublisher
  });

  const memberships = new MembershipService({
    communities: communities,
    credentials: credentials,
    signing: communitySigning,
    publisher: eventPublisher
  });

  const governanceDelegations = new GovernanceDelegationService({
    communities: communities,
    receipts: receipts,
    publisher: eventPublisher
  });

  const communityGovernance = new CommunityGovernanceService({
    communities: communities,
    signing: communitySigning,
    receipts: receipts,
    publisher: eventPublisher,
    delegations: governanceDelegations
  });

  const federationTrust = new FederationTrustService({
    communities: communities,
    signing: communitySigning,
    publisher: eventPublisher
  });

  const federationProtocolVersions = (process.env.FEDERATION_PROTOCOL_VERSIONS || '1.0,1.1,2.0')
    .split(',').map(function (value) { return value.trim(); }).filter(Boolean);
  const federationEnvelopeMaxLifetimeSeconds = Number(process.env.FEDERATION_ENVELOPE_MAX_LIFETIME_SECONDS || 900);
  const federationClockSkewSeconds = Number(process.env.FEDERATION_CLOCK_SKEW_SECONDS || 120);
  const federationReplayRetentionSeconds = Number(process.env.FEDERATION_REPLAY_RETENTION_SECONDS || (7 * 24 * 60 * 60));

  if (!federationProtocolVersions.length) {
    throw new Error('FEDERATION_PROTOCOL_VERSIONS must contain at least one version');
  }
  if (!Number.isFinite(federationEnvelopeMaxLifetimeSeconds) || federationEnvelopeMaxLifetimeSeconds <= 0 ||
      !Number.isFinite(federationClockSkewSeconds) || federationClockSkewSeconds < 0 ||
      !Number.isFinite(federationReplayRetentionSeconds) || federationReplayRetentionSeconds <= 0) {
    throw new Error('Federation protocol timing configuration is invalid');
  }
  if (federationReplayRetentionSeconds < federationEnvelopeMaxLifetimeSeconds + (2 * federationClockSkewSeconds)) {
    throw new Error('FEDERATION_REPLAY_RETENTION_SECONDS must cover envelope lifetime plus clock-skew window');
  }

  const federationProtocol = new FederationProtocolService({
    supportedVersions: federationProtocolVersions
  });

  const gatewayPeers = new PeerRegistryService({
    store: store,
    signing: communitySigning,
    cacheTtlSeconds: Number(process.env.GATEWAY_PEER_CACHE_TTL_SECONDS || 300)
  });

  const replayProtection = new ReplayProtectionService({
    store: store,
    retentionSeconds: federationReplayRetentionSeconds
  });

  const federationEnvelopes = new FederationEnvelopeService({
    communities: communities,
    signing: communitySigning,
    protocol: federationProtocol,
    replay: replayProtection,
    peers: gatewayPeers,
    maxLifetimeSeconds: federationEnvelopeMaxLifetimeSeconds,
    clockSkewSeconds: federationClockSkewSeconds
  });

  const federationDiscovery = new FederationCapabilityDiscoveryService({
    communities: communities,
    signing: communitySigning,
    protocol: federationProtocol
  });

  const governanceProofs = new LocalGovernanceProofService({
    communities: communities,
    signing: communitySigning
  });

  const treaties = new TreatyService({
    store: store,
    communities: communities,
    signing: communitySigning,
    receipts: receipts,
    publisher: eventPublisher
  });

  const federatedProposals = new FederatedProposalService({
    store: store,
    communities: communities,
    signing: communitySigning,
    receipts: receipts,
    publisher: eventPublisher,
    treaties: treaties,
    governanceProofs: governanceProofs
  });

  const federatedDisputes = new FederatedDisputeService({
    store: store,
    communities: communities,
    signing: communitySigning,
    publisher: eventPublisher,
    treaties: treaties
  });

  const trustPaths = new FederationTrustPathService({
    communities: communities,
    trust: federationTrust,
    treaties: treaties
  });

  const resourceExchange = new ResourceExchangeService({
    store: store,
    communities: communities,
    signing: communitySigning,
    publisher: eventPublisher,
    treaties: treaties
  });

  const bftQuorum = new BftQuorumService({
    store: store,
    communities: communities,
    signing: communitySigning,
    receipts: receipts
  });

  const groupIdentityProvider = loadProviderModule(process.env.COMMUNITY_GROUP_IDENTITY_MODULE, {
    keriaUrl: process.env.KERIA_URL,
    aid: process.env.COMMUNITY_KERI_AID
  });

  const groupIdentity = new GroupIdentityService({
    communities: communities,
    signing: communitySigning,
    provider: groupIdentityProvider
  });

  const portableReputation = new PortableReputationProofService({
    reputation: reputation,
    receipts: receipts,
    trust: federationTrust,
    communities: communities
  });

  let cardanoProvider = loadProviderModule(process.env.CARDANO_ANCHOR_MODULE, {
    network: process.env.CARDANO_NETWORK || 'preprod'
  });
  if (cardanoProvider) {
    cardanoProvider = new CardanoProvider({ provider: cardanoProvider });
  }

  const anchors = new EvidenceAnchorService({
    provider: cardanoProvider,
    receipts: receipts,
    metadataLabel: process.env.CARDANO_METADATA_LABEL || '1337',
    network: process.env.CARDANO_NETWORK || 'preprod'
  });


  const gatewayIdempotency = new GatewayIdempotencyService({
    store: store,
    retentionSeconds: Number(process.env.GATEWAY_IDEMPOTENCY_RETENTION_SECONDS || 86400),
    processingTimeoutSeconds: Number(process.env.GATEWAY_PROCESSING_TIMEOUT_SECONDS || 120)
  });

  const gatewayTraceProvider = loadProviderModule(process.env.GATEWAY_TRACE_PROVIDER_MODULE, {});
  const gatewayTraces = new GatewayTraceService({
    store: store,
    provider: gatewayTraceProvider,
    log: bool(process.env.GATEWAY_TRACE_LOG, false),
    retentionSeconds: Number(process.env.GATEWAY_TRACE_RETENTION_SECONDS || 604800)
  });

  const gatewayDeadLetters = new DeadLetterService({
    store: store,
    publisher: eventPublisher,
    retentionSeconds: Number(process.env.GATEWAY_DEAD_LETTER_RETENTION_SECONDS || 1209600)
  });

  const gatewayRetry = new RetryPolicy({
    maxAttempts: Number(process.env.GATEWAY_RETRY_MAX_ATTEMPTS || 3),
    baseDelayMs: Number(process.env.GATEWAY_RETRY_BASE_DELAY_MS || 250),
    maxDelayMs: Number(process.env.GATEWAY_RETRY_MAX_DELAY_MS || 5000)
  });

  const gatewayTransports = new GatewayTransportRegistry();
  gatewayTransports.register('http', new HttpGatewayTransport({
    timeoutMs: Number(process.env.GATEWAY_HTTP_TIMEOUT_MS || 10000)
  }));
  gatewayTransports.register('mcp', new McpGatewayTransport({ tools: tools }));

  const didcommProvider = loadProviderModule(process.env.DIDCOMM_GATEWAY_PROVIDER_MODULE, {});
  if (didcommProvider) {
    gatewayTransports.register('didcomm', new DidCommGatewayTransport({ provider: didcommProvider }));
  }

  const gatewayRouter = new GatewayRouter();
  gatewayRouter.register('*', function (context) {
    const targetBeingId = context.envelope && context.envelope.payload && context.envelope.payload.targetBeingId;
    if (!eventPublisher || !targetBeingId) {
      return Promise.resolve({
        ok: true,
        accepted: true,
        routed: false,
        messageType: context.envelope.messageType
      });
    }
    return eventPublisher.publish({
      type: context.envelope.messageType,
      targetBeingId: targetBeingId,
      payload: context.envelope.payload,
      occurredAt: context.envelope.issuedAt
    }).then(function (published) {
      return { ok: true, accepted: true, routed: true, event: published };
    });
  });

  const gatewayInbound = new InboundGateway({
    communityId: process.env.GATEWAY_COMMUNITY_ID || null,
    envelopes: federationEnvelopes,
    idempotency: gatewayIdempotency,
    router: gatewayRouter,
    traces: gatewayTraces
  });

  const gatewayOutbound = new OutboundGateway({
    envelopes: federationEnvelopes,
    peers: gatewayPeers,
    transports: gatewayTransports,
    retry: gatewayRetry,
    deadLetters: gatewayDeadLetters,
    traces: gatewayTraces,
    store: store,
    transportPreference: (process.env.GATEWAY_TRANSPORT_PREFERENCE || 'http,mcp,didcomm')
      .split(',').map(function (value) { return value.trim(); }).filter(Boolean)
  });

  tools.register({
    name: 'echo',
    description: 'Return the supplied input unchanged.',
    inputSchema: { type: 'object' },
    source: 'local'
  }, function (input) {
    return Promise.resolve({ ok: true, output: input });
  });

  tools.register({
    name: 'commitment.fulfil',
    description: 'Mark one of this being\'s commitments fulfilled with outcome/evidence.',
    inputSchema: {
      type: 'object',
      required: ['commitmentId'],
      properties: {
        commitmentId: { type: 'string' },
        outcome: {},
        evidence: {},
        reason: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return commitments.fulfil({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'commitment.violate',
    description: 'Record that one of this being\'s commitments was violated.',
    inputSchema: {
      type: 'object',
      required: ['commitmentId'],
      properties: {
        commitmentId: { type: 'string' },
        outcome: {},
        evidence: {},
        reason: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return commitments.violate({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'contribution.verify',
    description: 'Create a signed third-party verification record for an Octomics contribution.',
    inputSchema: {
      type: 'object',
      required: ['contribution'],
      properties: {
        contribution: { type: 'object' },
        verdict: { type: 'string' },
        notes: { type: 'string' },
        evidenceChecks: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return verifications.verify({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'evidence.anchor',
    description: 'Batch unanchored signed evidence into a Merkle root and optionally submit it to Cardano.',
    inputSchema: {
      type: 'object',
      properties: {
        limit: { type: 'integer' },
        includeAnchored: { type: 'boolean' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return anchors.anchor({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'constitution.adopt',
    description: 'Adopt or supersede this being\'s signed constitution/policy set.',
    inputSchema: {
      type: 'object',
      required: ['constitution'],
      properties: { constitution: { type: 'object' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return constitutions.adopt({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'reputation.compute',
    description: 'Compute a reputation report from signed evidence without mutating counters.',
    inputSchema: { type: 'object' },
    source: 'octonomous'
  }, function (input, executionContext) {
    return reputation.compute(executionContext.being)
      .then(function (report) { return { ok: true, report: report }; });
  });

  tools.register({
    name: 'community.create',
    description: 'Create a durable Octonomous community with a community-owned constitution and founding membership.',
    inputSchema: {
      type: 'object',
      required: ['name'],
      properties: {
        id: { type: 'string' },
        name: { type: 'string' },
        purpose: { type: 'array' },
        identity: { type: 'object' },
        constitution: { type: 'object' },
        treasury: { type: 'object' },
        resources: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return communities.create({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.membership.issue',
    description: 'Issue credential-backed membership and roles in a community.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'targetBeingId', 'roles'],
      properties: {
        communityId: { type: 'string' },
        targetBeingId: { type: 'string' },
        subjectAid: { type: 'string' },
        roles: { type: 'array', items: { type: 'string' } },
        validUntil: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return memberships.issue({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.membership.revoke',
    description: 'Revoke a community membership and its credential binding.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'membershipId'],
      properties: {
        communityId: { type: 'string' },
        membershipId: { type: 'string' },
        reason: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return memberships.revoke({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.governance.propose',
    description: 'Create a community-owned governance proposal for constitution, treasury, resources, or another governed matter.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'kind'],
      properties: {
        communityId: { type: 'string' },
        kind: { type: 'string' },
        patch: { type: 'object' },
        asset: { type: 'string' },
        amount: { type: 'number' },
        resource: { type: 'string' },
        quantity: { type: 'number' },
        target: { type: 'string' },
        purpose: { type: 'string' },
        reference: {},
        payload: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return communityGovernance.propose({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.constitution.propose',
    description: 'Propose a JSON Merge Patch amendment to a community-owned constitution.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'patch'],
      properties: { communityId: { type: 'string' }, patch: { type: 'object' }, summary: { type: 'string' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return communityGovernance.propose({
      being: executionContext.being,
      event: executionContext.event,
      input: Object.assign({}, input, { kind: 'constitution.amend' })
    });
  });

  tools.register({
    name: 'community.treasury.propose',
    description: 'Propose an authorised treasury allocation. This records governance authority; it does not hold or spend keys.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'asset', 'amount', 'target'],
      properties: {
        communityId: { type: 'string' }, asset: { type: 'string' }, amount: { type: 'number' },
        target: { type: 'string' }, purpose: { type: 'string' }, reference: {}
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return communityGovernance.propose({
      being: executionContext.being,
      event: executionContext.event,
      input: Object.assign({}, input, { kind: 'treasury.allocate' })
    });
  });

  tools.register({
    name: 'community.resource.propose',
    description: 'Propose a governed allocation of a non-financial community resource.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'resource', 'quantity', 'target'],
      properties: {
        communityId: { type: 'string' }, resource: { type: 'string' }, quantity: { type: 'number' },
        target: { type: 'string' }, purpose: { type: 'string' }, reference: {}
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return communityGovernance.propose({
      being: executionContext.being,
      event: executionContext.event,
      input: Object.assign({}, input, { kind: 'resource.allocate' })
    });
  });

  tools.register({
    name: 'community.governance.vote',
    description: 'Cast a signed community vote directly or under a bounded governance delegation.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'proposalId', 'vote'],
      properties: {
        communityId: { type: 'string' }, proposalId: { type: 'string' },
        vote: { type: 'string', enum: ['approve', 'reject', 'abstain'] },
        representingBeingId: { type: 'string' }, reason: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return communityGovernance.castVote({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.governance.delegate',
    description: 'Delegate bounded community governance voting authority without transferring membership.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'delegateeBeingId'],
      properties: {
        communityId: { type: 'string' }, delegateeBeingId: { type: 'string' },
        scopes: { type: 'array', items: { type: 'string' } }, validUntil: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return governanceDelegations.create({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.governance.delegation.revoke',
    description: 'Revoke a governance delegation previously created by this member.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'delegationId'],
      properties: { communityId: { type: 'string' }, delegationId: { type: 'string' }, reason: { type: 'string' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return governanceDelegations.revoke({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.trust.assert',
    description: 'Create a signed cross-community trust assertion with bounded scopes and expiry.',
    inputSchema: {
      type: 'object',
      required: ['sourceCommunityId', 'targetCommunityId'],
      properties: {
        sourceCommunityId: { type: 'string' }, targetCommunityId: { type: 'string' },
        level: { type: 'string' }, scopes: { type: 'array', items: { type: 'string' } },
        claims: { type: 'object' }, validUntil: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federationTrust.assert({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.trust.revoke',
    description: 'Revoke a cross-community trust assertion.',
    inputSchema: {
      type: 'object',
      required: ['sourceCommunityId', 'assertionId'],
      properties: { sourceCommunityId: { type: 'string' }, assertionId: { type: 'string' }, reason: { type: 'string' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federationTrust.revoke({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'reputation.proof.issue',
    description: 'Issue a signed, portable reputation proof derived only from verifiable evidence.',
    inputSchema: {
      type: 'object',
      properties: {
        issuerCommunityId: { type: 'string' }, audienceCommunityId: { type: 'string' },
        scope: { type: 'string' }, validUntil: { type: 'string' }, includeEvidenceRefs: { type: 'boolean' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return portableReputation.issue({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'reputation.proof.verify',
    description: 'Verify a portable reputation proof and optionally apply relying-community federation trust.',
    inputSchema: {
      type: 'object',
      required: ['proof'],
      properties: { proof: { type: 'object' }, relyingCommunityId: { type: 'string' } }
    },
    source: 'octonomous'
  }, function (input) {
    return portableReputation.verify({ proof: input.proof, relyingCommunityId: input.relyingCommunityId || null });
  });


  tools.register({
    name: 'federation.gateway.peer.register',
    description: 'Register or refresh a cryptographically verified remote federation peer discovery record.',
    inputSchema: {
      type: 'object', required: ['descriptor'],
      properties: {
        descriptor: { type: 'object' }, endpoints: { type: 'object' },
        transportPreference: { type: 'array', items: { type: 'string' } }, metadata: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input) {
    return gatewayPeers.register({ input: input });
  });

  tools.register({
    name: 'federation.gateway.peer.get',
    description: 'Load a verified federation gateway peer record.',
    inputSchema: { type: 'object', required: ['communityId'], properties: { communityId: { type: 'string' } } },
    source: 'octonomous'
  }, function (input) {
    return gatewayPeers.load(input.communityId).then(function (peer) { return { ok: Boolean(peer), peer: peer }; });
  });

  tools.register({
    name: 'federation.gateway.send',
    description: 'Create and deliver a signed federation envelope through a verified peer endpoint with retries, idempotency, tracing, and dead-letter handling.',
    inputSchema: {
      type: 'object', required: ['senderCommunityId', 'recipientCommunityId', 'messageType'],
      properties: {
        senderCommunityId: { type: 'string' }, recipientCommunityId: { type: 'string' },
        messageType: { type: 'string' }, payload: { type: 'object' }, protocolVersion: { type: 'string' },
        lifetimeSeconds: { type: 'integer' }, correlationId: { type: 'string' }, causationId: { type: 'string' },
        transport: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return gatewayOutbound.send({ being: executionContext.being, event: executionContext.event, input: input, transport: input.transport });
  });

  tools.register({
    name: 'federation.gateway.dead-letter.get',
    description: 'Load a gateway dead-letter record by id.',
    inputSchema: { type: 'object', required: ['id'], properties: { id: { type: 'string' } } },
    source: 'octonomous'
  }, function (input) {
    return gatewayDeadLetters.load(input.id).then(function (deadLetter) { return { ok: Boolean(deadLetter), deadLetter: deadLetter }; });
  });

  tools.register({
    name: 'federation.gateway.dead-letter.replay',
    description: 'Replay a previously dead-lettered federation envelope through the current verified peer route.',
    inputSchema: { type: 'object', required: ['id'], properties: { id: { type: 'string' } } },
    source: 'octonomous'
  }, function (input) {
    return gatewayOutbound.replayDeadLetter(input.id);
  });

  tools.register({
    name: 'federation.gateway.trace.get',
    description: 'Load a persisted federation gateway protocol trace.',
    inputSchema: { type: 'object', required: ['id'], properties: { id: { type: 'string' } } },
    source: 'octonomous'
  }, function (input) {
    return gatewayTraces.load(input.id).then(function (trace) { return { ok: Boolean(trace), trace: trace }; });
  });

  tools.register({
    name: 'federation.protocol.describe',
    description: 'Describe locally supported federation protocol versions, schemas, and hardening capabilities.',
    inputSchema: { type: 'object', properties: {} },
    source: 'octonomous'
  }, function () {
    return Promise.resolve({ ok: true, descriptor: federationProtocol.describe() });
  });

  tools.register({
    name: 'federation.discovery.publish',
    description: 'Publish a signed community federation-capability descriptor for protocol negotiation and discovery.',
    inputSchema: {
      type: 'object', required: ['communityId'],
      properties: {
        communityId: { type: 'string' }, operations: { type: 'array', items: { type: 'string' } },
        scopes: { type: 'array', items: { type: 'string' } }, endpoints: { type: 'object' }, validUntil: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federationDiscovery.publish({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.discovery.verify',
    description: 'Verify a signed federation-capability descriptor.',
    inputSchema: { type: 'object', required: ['descriptor'], properties: { descriptor: { type: 'object' } } },
    source: 'octonomous'
  }, function (input) {
    return federationDiscovery.verify(input.descriptor);
  });

  tools.register({
    name: 'federation.discovery.negotiate',
    description: 'Negotiate the highest common protocol version, schemas, capabilities, operations, and scopes between two verified descriptors.',
    inputSchema: {
      type: 'object', required: ['localDescriptor', 'remoteDescriptor'],
      properties: { localDescriptor: { type: 'object' }, remoteDescriptor: { type: 'object' } }
    },
    source: 'octonomous'
  }, function (input) {
    return federationDiscovery.negotiate(input.localDescriptor, input.remoteDescriptor);
  });

  tools.register({
    name: 'federation.envelope.create',
    description: 'Create a short-lived signed federation envelope with protocol/schema identifiers and a cryptographic nonce.',
    inputSchema: {
      type: 'object', required: ['senderCommunityId', 'recipientCommunityId', 'messageType'],
      properties: {
        senderCommunityId: { type: 'string' }, recipientCommunityId: { type: 'string' }, messageType: { type: 'string' },
        payload: { type: 'object' }, protocolVersion: { type: 'string' }, lifetimeSeconds: { type: 'integer' },
        correlationId: { type: 'string' }, causationId: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federationEnvelopes.create({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.envelope.verify',
    description: 'Verify envelope protocol, expiry, recipient, signature binding, and atomically claim its nonce to reject replay.',
    inputSchema: {
      type: 'object', required: ['envelope'],
      properties: { envelope: { type: 'object' }, expectedRecipientCommunityId: { type: 'string' } }
    },
    source: 'octonomous'
  }, function (input) {
    return federationEnvelopes.verify({ input: input });
  });

  tools.register({
    name: 'federation.governance-proof.create',
    description: 'Create a proof that a local community governance proposal approved an exact external federation decision.',
    inputSchema: {
      type: 'object', required: ['communityId', 'proposalId', 'authorization'],
      properties: { communityId: { type: 'string' }, proposalId: { type: 'string' }, authorization: { type: 'object' } }
    },
    source: 'octonomous'
  }, function (input) {
    return governanceProofs.create(input).then(function (proof) { return { ok: true, proof: proof }; });
  });

  tools.register({
    name: 'federation.governance-proof.verify',
    description: 'Verify a local-governance proof against an exact expected federation authorization.',
    inputSchema: {
      type: 'object', required: ['proof'],
      properties: { proof: { type: 'object' }, expectedAuthorization: { type: 'object' } }
    },
    source: 'octonomous'
  }, function (input) {
    return governanceProofs.verify(input.proof, input.expectedAuthorization || null);
  });

  tools.register({
    name: 'federation.treaty.propose',
    description: 'Propose a signed community-to-community treaty with bounded scopes, validity, and dispute rules.',
    inputSchema: {
      type: 'object',
      required: ['proposerCommunityId', 'participantCommunityIds'],
      properties: {
        id: { type: 'string' }, proposerCommunityId: { type: 'string' },
        participantCommunityIds: { type: 'array', items: { type: 'string' } },
        name: { type: 'string' }, scopes: { type: 'array', items: { type: 'string' } },
        terms: { type: 'object' }, minimumRatifications: { type: 'integer' },
        disputeResolverCommunityId: { type: 'string' }, disputeProcess: { type: 'object' },
        validFrom: { type: 'string' }, validUntil: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return treaties.propose({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.treaty.ratify',
    description: 'Ratify a treaty on behalf of one participating community. The treaty activates only when its frozen ratification threshold is reached.',
    inputSchema: {
      type: 'object',
      required: ['treatyId', 'communityId'],
      properties: {
        treatyId: { type: 'string' }, communityId: { type: 'string' },
        localGovernanceProposalId: { type: 'string' }, statement: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return treaties.ratify({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.treaty.terminate',
    description: 'Terminate an active or proposed treaty with a signed participant-community record.',
    inputSchema: {
      type: 'object',
      required: ['treatyId', 'communityId'],
      properties: { treatyId: { type: 'string' }, communityId: { type: 'string' }, reason: { type: 'string' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return treaties.terminate({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.treaty.amend',
    description: 'Create a new treaty version linked to an active parent by a stable lineage digest. The parent is superseded only after re-ratification activates the amendment.',
    inputSchema: {
      type: 'object', required: ['treatyId', 'proposerCommunityId', 'patch'],
      properties: { treatyId: { type: 'string' }, proposerCommunityId: { type: 'string' }, patch: { type: 'object' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return treaties.amend({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.treaty.version-chain',
    description: 'Load and integrity-check a treaty amendment/version chain.',
    inputSchema: { type: 'object', required: ['treatyId'], properties: { treatyId: { type: 'string' } } },
    source: 'octonomous'
  }, function (input) {
    return treaties.versionChain(input.treatyId);
  });

  tools.register({
    name: 'federation.proposal.create',
    description: 'Create a proposal whose voters are sovereign communities rather than individual beings.',
    inputSchema: {
      type: 'object',
      required: ['proposerCommunityId', 'participantCommunityIds'],
      properties: {
        id: { type: 'string' }, proposerCommunityId: { type: 'string' },
        participantCommunityIds: { type: 'array', items: { type: 'string' } },
        treatyId: { type: 'string' }, scope: { type: 'string' }, kind: { type: 'string' },
        payload: { type: 'object' }, approvals: { type: 'integer' }, rejections: { type: 'integer' },
        governanceProofPolicy: { type: 'string', enum: ['optional', 'required'] }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federatedProposals.create({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.proposal.vote',
    description: 'Cast one signed decision for one participating community on a federated proposal.',
    inputSchema: {
      type: 'object',
      required: ['proposalId', 'communityId', 'vote'],
      properties: {
        proposalId: { type: 'string' }, communityId: { type: 'string' },
        vote: { type: 'string', enum: ['approve', 'reject', 'abstain'] },
        reason: { type: 'string' }, localGovernanceProposalId: { type: 'string' }, localGovernanceProof: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federatedProposals.castCommunityVote({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.dispute.open',
    description: 'Open a signed cross-community dispute under a treaty.',
    inputSchema: {
      type: 'object',
      required: ['treatyId', 'claimantCommunityId', 'respondentCommunityId'],
      properties: {
        treatyId: { type: 'string' }, claimantCommunityId: { type: 'string' }, respondentCommunityId: { type: 'string' },
        resolverCommunityId: { type: 'string' }, subjectKind: { type: 'string' }, subjectId: { type: 'string' },
        claim: { type: 'string' }, evidence: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federatedDisputes.open({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.dispute.respond',
    description: 'Respond to a treaty dispute on behalf of the respondent community.',
    inputSchema: {
      type: 'object',
      required: ['disputeId'],
      properties: { disputeId: { type: 'string' }, statement: { type: 'string' }, evidence: { type: 'object' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federatedDisputes.respond({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.dispute.resolve',
    description: 'Resolve a cross-community dispute using the treaty-designated resolver community.',
    inputSchema: {
      type: 'object',
      required: ['disputeId', 'verdict'],
      properties: {
        disputeId: { type: 'string' }, verdict: { type: 'string', enum: ['upheld', 'dismissed', 'settled', 'partially_upheld'] },
        reasoning: { type: 'string' }, remedy: { type: 'object' }, evidence: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return federatedDisputes.resolve({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.trust.path',
    description: 'Calculate a bounded trust path across signed trust assertions and active treaties.',
    inputSchema: {
      type: 'object',
      required: ['sourceCommunityId', 'targetCommunityId'],
      properties: {
        sourceCommunityId: { type: 'string' }, targetCommunityId: { type: 'string' },
        scope: { type: 'string' }, maxHops: { type: 'integer' }
      }
    },
    source: 'octonomous'
  }, function (input) {
    return trustPaths.compute(input).then(function (path) { return { ok: true, path: path }; });
  });

  tools.register({
    name: 'federation.exchange.offer',
    description: 'Offer a treaty-scoped resource exchange. This creates signed authorisation intent but does not transfer assets or resources.',
    inputSchema: {
      type: 'object',
      required: ['sourceCommunityId', 'targetCommunityId', 'treatyId'],
      properties: {
        sourceCommunityId: { type: 'string' }, targetCommunityId: { type: 'string' }, treatyId: { type: 'string' },
        give: { type: 'array' }, receive: { type: 'array' }, terms: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return resourceExchange.offer({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.exchange.accept',
    description: 'Accept a treaty-scoped resource exchange and create paired external-execution authorisations.',
    inputSchema: {
      type: 'object',
      required: ['exchangeId'],
      properties: { exchangeId: { type: 'string' }, statement: { type: 'string' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return resourceExchange.accept({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.exchange.settlement.record',
    description: 'Record externally executed settlement evidence for one side of an authorised resource exchange.',
    inputSchema: {
      type: 'object',
      required: ['exchangeId', 'communityId'],
      properties: {
        exchangeId: { type: 'string' }, communityId: { type: 'string' },
        externalReference: {}, evidence: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return resourceExchange.recordSettlement({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.bft.round.create',
    description: 'Create a BFT quorum round. Requires n >= 3f+1 and certifies a value at 2f+1 matching signed community decisions.',
    inputSchema: {
      type: 'object', required: ['subject', 'participantCommunityIds'],
      properties: { subject: { type: 'object' }, participantCommunityIds: { type: 'array', items: { type: 'string' } }, faultTolerance: { type: 'integer' } }
    },
    source: 'octonomous'
  }, function (input) {
    return bftQuorum.createRound(input);
  });

  tools.register({
    name: 'federation.bft.decision.cast',
    description: 'Cast one signed community decision in a BFT quorum round. Equivocation is detected and rejected.',
    inputSchema: {
      type: 'object', required: ['roundId', 'communityId', 'value'],
      properties: { roundId: { type: 'string' }, communityId: { type: 'string' }, value: {} }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return bftQuorum.cast({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'federation.bft.certificate.verify',
    description: 'Verify a BFT quorum certificate against its stored round and signed community decisions.',
    inputSchema: { type: 'object', required: ['certificate'], properties: { certificate: { type: 'object' } } },
    source: 'octonomous'
  }, function (input) {
    return bftQuorum.verifyCertificate(input.certificate);
  });

  tools.register({
    name: 'community.group-identity.bind',
    description: 'Bind a community to a KERI/group AID identity through a provider adapter, with an explicitly marked development fallback.',
    inputSchema: {
      type: 'object',
      required: ['communityId', 'aid'],
      properties: {
        communityId: { type: 'string' }, aid: { type: 'string' },
        memberAids: { type: 'array', items: { type: 'string' } }, threshold: {}, metadata: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return groupIdentity.bind({ being: executionContext.being, event: executionContext.event, input: input });
  });

  tools.register({
    name: 'community.group-identity.describe',
    description: 'Describe the community group identity and provider state without exposing private signing material.',
    inputSchema: { type: 'object', required: ['communityId'], properties: { communityId: { type: 'string' } } },
    source: 'octonomous'
  }, function (input) {
    return groupIdentity.describe(input);
  });

  if (eventPublisher) {
    tools.register({
      name: 'event.publish',
      description: 'Publish a targeted event to another Octonomous being.',
      inputSchema: {
        type: 'object',
        properties: {
          targetBeingId: { type: 'string' },
          type: { type: 'string' },
          payload: { type: 'object' }
        }
      },
      source: 'local'
    }, function (input, executionContext) {
      return eventPublisher.publish({
        sourceBeingId: executionContext.being && executionContext.being.id,
        targetBeingId: input.targetBeingId,
        type: input.type,
        payload: input.payload || {}
      })
        .then(function (event) {
          return { ok: true, event: event };
        });
    });

    tools.register({
      name: 'being.delegate',
      description: 'Delegate an intent or bounded task to another Octonomous being.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'intent'],
        properties: {
          targetBeingId: { type: 'string' },
          intent: { type: 'string' },
          requestedAction: { type: 'object' },
          constraints: { type: 'object' },
          capabilityIds: { type: 'array', items: { type: 'string' } }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.create({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'being.delegate.accept',
      description: 'Accept an incoming delegation.',
      inputSchema: {
        type: 'object',
        required: ['delegationId'],
        properties: { delegationId: { type: 'string' }, reason: { type: 'string' } }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.accept({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'being.delegate.reject',
      description: 'Reject an incoming delegation.',
      inputSchema: {
        type: 'object',
        required: ['delegationId'],
        properties: { delegationId: { type: 'string' }, reason: { type: 'string' } }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.reject({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'being.delegate.complete',
      description: 'Complete an accepted delegation with outcome and evidence.',
      inputSchema: {
        type: 'object',
        required: ['delegationId'],
        properties: {
          delegationId: { type: 'string' }, outcome: {}, evidence: {}, reason: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.complete({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'capability.grant',
      description: 'Grant a bounded, revocable tool capability to another being.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'tool'],
        properties: {
          targetBeingId: { type: 'string' },
          subjectAid: { type: 'string' },
          tool: { type: 'string' },
          constraints: { type: 'object' },
          delegable: { type: 'boolean' },
          expiresAt: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return capabilities.grant({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'capability.revoke',
      description: 'Revoke a capability previously granted by this being.',
      inputSchema: {
        type: 'object',
        required: ['capabilityId'],
        properties: { capabilityId: { type: 'string' }, reason: { type: 'string' } }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return capabilities.revoke({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'relationship.assert',
      description: 'Create a signed assertion about this being\'s relationship to another being.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'relationshipType'],
        properties: {
          targetBeingId: { type: 'string' },
          relationshipType: { type: 'string' },
          claims: { type: 'object' },
          validUntil: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return relationships.assert({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'contribution.verification.request',
      description: 'Ask another being to independently verify an Octomics contribution.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'contribution'],
        properties: {
          targetBeingId: { type: 'string' },
          contribution: { type: 'object' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return verifications.request({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'capability.delegate',
      description: 'Delegate a received capability without broadening its authority.',
      inputSchema: {
        type: 'object',
        required: ['parentCapabilityId', 'targetBeingId'],
        properties: {
          parentCapabilityId: { type: 'string' },
          targetBeingId: { type: 'string' },
          subjectAid: { type: 'string' },
          constraints: { type: 'object' },
          delegable: { type: 'boolean' },
          expiresAt: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return capabilities.delegate({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'governance.vote',
      description: 'Cast a signed approve/reject/abstain vote on an incoming governance proposal.',
      inputSchema: {
        type: 'object',
        required: ['proposal', 'vote'],
        properties: {
          proposal: { type: 'object' },
          vote: { type: 'string', enum: ['approve', 'reject', 'abstain'] },
          reason: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return governance.castVote({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'challenge.open',
      description: 'Open a signed challenge against a contribution, commitment, delegation, verification, or other evidence.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'subjectKind', 'subjectId'],
        properties: {
          targetBeingId: { type: 'string' },
          subjectKind: { type: 'string' },
          subjectId: { type: 'string' },
          claim: { type: 'string' },
          evidence: { type: 'object' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return challenges.open({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'challenge.respond',
      description: 'Respond to an open challenge with signed evidence.',
      inputSchema: {
        type: 'object',
        required: ['challengeId'],
        properties: { challengeId: { type: 'string' }, response: { type: 'string' }, evidence: { type: 'object' } }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return challenges.respond({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'challenge.resolve',
      description: 'Resolve a challenge as upheld, dismissed, or partially_upheld.',
      inputSchema: {
        type: 'object',
        required: ['verdict'],
        properties: {
          challengeId: { type: 'string' },
          challenge: { type: 'object' },
          verdict: { type: 'string', enum: ['upheld', 'dismissed', 'partially_upheld'] },
          resolution: { type: 'string' },
          evidence: { type: 'object' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return challenges.resolve({ being: executionContext.being, event: executionContext.event, input: input });
    });
  }

  return resolveOpenAIKey(secrets)
    .then(function (apiKey) {
      const cognitionMode = process.env.COGNITION_MODE || (apiKey ? 'openai' : 'mock');
      let cognition;

      if (cognitionMode === 'openai') {
        if (!apiKey) {
          throw new Error('COGNITION_MODE=openai but no OpenAI API key is configured');
        }

        cognition = new OpenAICognition({
          apiKey: apiKey,
          model: process.env.OPENAI_MODEL || 'gpt-5.6',
          reflectWithModel: bool(process.env.REFLECT_WITH_MODEL, true)
        });
      }
      else {
        cognition = new MockCognition();
      }

      const runtime = new Runtime({
        store: store,
        cognition: cognition,
        policy: new Policy({ capabilities: capabilities, constitutions: constitutions }),
        tools: tools,
        commitments: commitments,
        approvals: new ApprovalService({
          publisher: eventPublisher,
          receipts: receipts
        }),
        relationships: relationships,
        contributions: new ContributionService({
          receipts: receipts,
          publisher: eventPublisher
        }),
        receipts: receipts,
        delegations: delegations,
        capabilities: capabilities,
        verifications: verifications,
        governance: governance,
        challenges: challenges,
        quorum: quorum,
        reputation: reputation,
        memberships: memberships,
        communityGovernance: communityGovernance,
        governanceDelegations: governanceDelegations,
        federationTrust: federationTrust,
        portableReputation: portableReputation
      });

      const mcp = new MCPManager({ registry: tools });

      return resolveMcpServerSecrets(parseMcpServers(), secrets)
        .then(function (servers) {
          return Promise.all(servers.map(function (server) {
            return mcp.connectServer(server);
          }));
        })
        .then(function () {
          return {
            runtime: runtime,
            tools: tools,
            mcp: mcp,
            eventPublisher: eventPublisher,
            receipts: receipts,
            delegations: delegations,
            capabilities: capabilities,
            relationships: relationships,
            commitments: commitments,
            verifications: verifications,
            anchors: anchors,
            credentials: credentials,
            constitutions: constitutions,
            governance: governance,
            challenges: challenges,
            quorum: quorum,
            reputation: reputation,
            communitySigning: communitySigning,
            communities: communities,
            memberships: memberships,
            communityGovernance: communityGovernance,
            governanceDelegations: governanceDelegations,
            federationTrust: federationTrust,
            federationProtocol: federationProtocol,
            replayProtection: replayProtection,
            federationEnvelopes: federationEnvelopes,
            federationDiscovery: federationDiscovery,
            governanceProofs: governanceProofs,
            treaties: treaties,
            federatedProposals: federatedProposals,
            federatedDisputes: federatedDisputes,
            trustPaths: trustPaths,
            resourceExchange: resourceExchange,
            bftQuorum: bftQuorum,
            groupIdentity: groupIdentity,
            gatewayPeers: gatewayPeers,
            gatewayIdempotency: gatewayIdempotency,
            gatewayTraces: gatewayTraces,
            gatewayDeadLetters: gatewayDeadLetters,
            gatewayRetry: gatewayRetry,
            gatewayTransports: gatewayTransports,
            gatewayRouter: gatewayRouter,
            gatewayInbound: gatewayInbound,
            gatewayOutbound: gatewayOutbound,
            portableReputation: portableReputation
          };
        });
    });
}

module.exports = bootstrap;
