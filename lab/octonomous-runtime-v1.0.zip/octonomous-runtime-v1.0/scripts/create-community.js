const bootstrap = require('../src/bootstrap');

const communityId = process.argv[2];
const founderBeingId = process.argv[3];
const name = process.argv[4] || communityId;

if (!communityId || !founderBeingId) {
  console.error('Usage: node scripts/create-community.js <communityId> <founderBeingId> [name]');
  process.exit(1);
}

bootstrap()
  .then(function (services) {
    return services.communities.create({
      being: { id: founderBeingId },
      input: { id: communityId, name: name }
    });
  })
  .then(function (result) {
    console.log(JSON.stringify(result.community, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
