const fs = require('fs');
const bootstrap = require('../src/bootstrap');

const descriptorFile = process.argv[2];

if (!descriptorFile) {
  console.error('Usage: node scripts/register-peer.js <descriptor-json-file>');
  process.exit(1);
}

let descriptor;
try {
  descriptor = JSON.parse(fs.readFileSync(descriptorFile, 'utf8'));
}
catch (error) {
  console.error('Could not read descriptor JSON:', error.message);
  process.exit(1);
}

bootstrap()
  .then(function (services) {
    return services.gatewayPeers.register({ input: { descriptor: descriptor } });
  })
  .then(function (result) {
    console.log(JSON.stringify(result.peer, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
