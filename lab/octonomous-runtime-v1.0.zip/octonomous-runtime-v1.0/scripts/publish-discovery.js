const bootstrap = require('../src/bootstrap');

const communityId = process.argv[2];
const governorBeingId = process.argv[3];
const endpointsJson = process.argv[4] || '{}';

if (!communityId || !governorBeingId) {
  console.error('Usage: node scripts/publish-discovery.js <communityId> <governorBeingId> [endpoints-json]');
  process.exit(1);
}

let endpoints;
try {
  endpoints = JSON.parse(endpointsJson);
}
catch (error) {
  console.error('endpoints-json must be valid JSON');
  process.exit(1);
}

bootstrap()
  .then(function (services) {
    return services.federationDiscovery.publish({
      being: { id: governorBeingId },
      input: {
        communityId: communityId,
        endpoints: endpoints,
        operations: [
          'federation.gateway',
          'federation.treaty',
          'federation.proposal',
          'federation.dispute',
          'federation.exchange',
          'reputation.proof'
        ],
        scopes: ['*']
      }
    });
  })
  .then(function (result) {
    console.log(JSON.stringify(result.descriptor, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
