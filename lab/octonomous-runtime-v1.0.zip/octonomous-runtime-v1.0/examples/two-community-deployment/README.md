# Two-community AWS deployment

The same `template.yaml` is deployed once per sovereign community. Each stack receives its own DynamoDB table, EventBridge bus, wake queue, and inbound HTTP gateway.

## 1. Deploy Community A

```bash
sam build
sam deploy --guided \
  --stack-name octonomous-community-a \
  --parameter-overrides \
    GatewayCommunityId=community:a \
    OpenAIApiKeySecretArn=<secret-arn>
```

Record the `GatewayUrl` and `BeingTableName` outputs.

## 2. Deploy Community B

```bash
sam deploy --guided \
  --stack-name octonomous-community-b \
  --parameter-overrides \
    GatewayCommunityId=community:b \
    OpenAIApiKeySecretArn=<secret-arn>
```

Record its outputs as well.

## 3. Create the local community state in each stack

Run the helper scripts with credentials/environment pointing at that stack's DynamoDB table. In production also configure a stable `COMMUNITY_SIGNER_MODULE` / KERI group identity rather than the development local signer.

Community A:

```bash
STORE_MODE=dynamodb \
DYNAMODB_TABLE=<community-a-table> \
AWS_REGION=<region> \
COGNITION_MODE=mock \
node scripts/create-community.js community:a being:a "Community A"
```

Community B:

```bash
STORE_MODE=dynamodb \
DYNAMODB_TABLE=<community-b-table> \
AWS_REGION=<region> \
COGNITION_MODE=mock \
node scripts/create-community.js community:b being:b "Community B"
```

## 4. Publish signed discovery descriptors

Community A:

```bash
STORE_MODE=dynamodb \
DYNAMODB_TABLE=<community-a-table> \
AWS_REGION=<region> \
COGNITION_MODE=mock \
node scripts/publish-discovery.js \
  community:a being:a \
  '{"http":{"url":"<community-a-gateway-url>"}}' \
  > community-a.discovery.json
```

Community B:

```bash
STORE_MODE=dynamodb \
DYNAMODB_TABLE=<community-b-table> \
AWS_REGION=<region> \
COGNITION_MODE=mock \
node scripts/publish-discovery.js \
  community:b being:b \
  '{"http":{"url":"<community-b-gateway-url>"}}' \
  > community-b.discovery.json
```

## 5. Exchange peer records

Register B's signed descriptor in A's stack:

```bash
STORE_MODE=dynamodb \
DYNAMODB_TABLE=<community-a-table> \
AWS_REGION=<region> \
COGNITION_MODE=mock \
node scripts/register-peer.js community-b.discovery.json
```

Register A's descriptor in B's stack the same way.

At this point neither stack contains a local mirror of the other community. Each contains only a cryptographically verified peer/discovery snapshot.

## 6. Send

A governed being can invoke `federation.gateway.send`, or application code can call `services.gatewayOutbound.send(...)`.

The receiving HTTP function:

1. verifies protocol/schema and exact envelope signature binding;
2. verifies sender through the peer registry;
3. claims replay state;
4. applies delivery idempotency;
5. dispatches the message once;
6. persists a gateway trace;
7. returns a stable result for exact duplicates.

## Production boundary

The sample HTTP API is intentionally minimal. Put the gateway behind the controls appropriate to the deployment: WAF/rate limits, private networking or mTLS where appropriate, and stable KERI/community signing providers. Signed federation envelopes are the protocol authentication mechanism, but they are not a substitute for volumetric network protection.
