const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const FileStore = require('../src/store/file');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const CommunitySigningService = require('../src/federation/community-signing');
const CommunityService = require('../src/federation/communities');
const FederationProtocolService = require('../src/federation/protocol');
const ReplayProtectionService = require('../src/federation/replay-protection');
const FederationEnvelopeService = require('../src/federation/envelopes');
const FederationCapabilityDiscoveryService = require('../src/federation/capability-discovery');
const PeerRegistryService = require('../src/gateway/peer-registry');
const GatewayIdempotencyService = require('../src/gateway/idempotency');
const RetryPolicy = require('../src/gateway/retry');
const DeadLetterService = require('../src/gateway/dead-letter');
const GatewayTraceService = require('../src/gateway/tracing');
const GatewayRouter = require('../src/gateway/router');
const InboundGateway = require('../src/gateway/inbound');
const OutboundGateway = require('../src/gateway/outbound');
const GatewayTransportRegistry = require('../src/gateway/transports/registry');
const HttpGatewayTransport = require('../src/gateway/transports/http');

function createSide(name) {
  const store = new FileStore({
    basePath: fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-' + name + '-'))
  });
  const receipts = new ReceiptService({
    signer: new LocalEd25519Signer({ aid: 'did:key:' + name })
  });
  const signing = new CommunitySigningService({ receipts: receipts });
  const communities = new CommunityService({ store: store, signing: signing });
  const protocol = new FederationProtocolService({ supportedVersions: ['2.0'] });
  const peers = new PeerRegistryService({ store: store, signing: signing });
  const replay = new ReplayProtectionService({ store: store, retentionSeconds: 3600 });
  const envelopes = new FederationEnvelopeService({
    communities: communities,
    signing: signing,
    protocol: protocol,
    replay: replay,
    peers: peers
  });
  const discovery = new FederationCapabilityDiscoveryService({
    communities: communities,
    signing: signing,
    protocol: protocol
  });
  const idempotency = new GatewayIdempotencyService({ store: store });
  const traces = new GatewayTraceService({ store: store });
  const deadLetters = new DeadLetterService({ store: store });
  const retry = new RetryPolicy({
    maxAttempts: 3,
    baseDelayMs: 50,
    maxDelayMs: 200
  });
  const router = new GatewayRouter();
  const transports = new GatewayTransportRegistry();
  transports.register('http', new HttpGatewayTransport({ timeoutMs: 3000 }));
  const outbound = new OutboundGateway({
    envelopes: envelopes,
    peers: peers,
    transports: transports,
    retry: retry,
    deadLetters: deadLetters,
    traces: traces,
    store: store,
    transportPreference: ['http']
  });

  return {
    store: store,
    signing: signing,
    communities: communities,
    discovery: discovery,
    peers: peers,
    envelopes: envelopes,
    idempotency: idempotency,
    traces: traces,
    router: router,
    outbound: outbound
  };
}

function createCommunity(side, communityId, beingId) {
  return side.communities.create({
    being: { id: beingId },
    input: { id: communityId, name: communityId }
  });
}

function publishDescriptor(side, communityId, beingId, endpoints) {
  return side.discovery.publish({
    being: { id: beingId },
    input: {
      communityId: communityId,
      endpoints: endpoints,
      operations: ['federation.gateway'],
      scopes: ['*']
    }
  }).then(function (result) {
    return result.descriptor;
  });
}

function listen(server) {
  return new Promise(function (resolve, reject) {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', function () {
      resolve(server.address());
    });
  });
}

function close(server) {
  return new Promise(function (resolve) {
    server.close(resolve);
  });
}

const communityA = createSide('community-a');
const communityB = createSide('community-b');
let server;
let inboundB;
let descriptorA;
let descriptorB;

Promise.all([
  createCommunity(communityA, 'community:a', 'being:a'),
  createCommunity(communityB, 'community:b', 'being:b')
])
  .then(function () {
    communityB.router.register('federation.learning.shared', function (context) {
      return {
        ok: true,
        accepted: true,
        receivedFrom: context.envelope.senderCommunityId,
        topic: context.envelope.payload.topic
      };
    });

    inboundB = new InboundGateway({
      communityId: 'community:b',
      envelopes: communityB.envelopes,
      idempotency: communityB.idempotency,
      router: communityB.router,
      traces: communityB.traces
    });

    server = http.createServer(function (request, response) {
      let body = '';

      request.on('data', function (chunk) {
        body += chunk;
      });

      request.on('end', function () {
        const parsed = JSON.parse(body);

        inboundB.handle({
          envelope: parsed.envelope,
          transport: 'http',
          headers: request.headers
        })
          .then(function (delivery) {
            response.writeHead(200, { 'content-type': 'application/json' });
            response.end(JSON.stringify({ ok: true, delivery: delivery }));
          })
          .catch(function (error) {
            response.writeHead(400, { 'content-type': 'application/json' });
            response.end(JSON.stringify({ ok: false, error: error.message }));
          });
      });
    });

    return listen(server);
  })
  .then(function (address) {
    return Promise.all([
      publishDescriptor(communityA, 'community:a', 'being:a', {
        http: { url: 'http://127.0.0.1:1/not-used-in-this-direction' }
      }),
      publishDescriptor(communityB, 'community:b', 'being:b', {
        http: { url: 'http://127.0.0.1:' + address.port + '/federation/envelopes' }
      })
    ]);
  })
  .then(function (descriptors) {
    descriptorA = descriptors[0];
    descriptorB = descriptors[1];

    return Promise.all([
      communityA.peers.register({ input: { descriptor: descriptorB } }),
      communityB.peers.register({ input: { descriptor: descriptorA } })
    ]);
  })
  .then(function () {
    return communityA.outbound.send({
      being: { id: 'being:a' },
      input: {
        senderCommunityId: 'community:a',
        recipientCommunityId: 'community:b',
        messageType: 'federation.learning.shared',
        payload: {
          topic: 'durable autonomous communities'
        },
        transport: 'http'
      },
      transport: 'http'
    });
  })
  .then(function (delivery) {
    console.log(JSON.stringify({
      sentEnvelopeId: delivery.delivery.envelopeId,
      attempts: delivery.delivery.attempts,
      transport: delivery.delivery.transport,
      remoteResponse: delivery.response.body,
      traceId: delivery.traceId
    }, null, 2));
  })
  .then(function () {
    return close(server);
  })
  .catch(function (error) {
    console.error(error);
    if (server) {
      close(server).then(function () { process.exitCode = 1; });
      return;
    }
    process.exitCode = 1;
  });
