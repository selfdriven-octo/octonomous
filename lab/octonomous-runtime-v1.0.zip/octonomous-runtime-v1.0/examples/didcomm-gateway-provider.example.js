// Example adapter boundary for a DIDComm implementation.
// The provider owns DID resolution, packing, transport, authentication, and key management.

exports.createProvider = function (options) {
  options = options || {};

  return {
    send: function (context) {
      // context.endpoint
      // context.envelope
      // context.idempotencyKey
      // context.peerCommunityId
      //
      // Integrate your DIDComm library/agent here and return its delivery result.
      return Promise.reject(new Error('Configure a real DIDComm provider before using this example'));
    }
  };
};
