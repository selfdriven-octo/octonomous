// Optional trace adapter. Connect this to OpenTelemetry, CloudWatch EMF,
// X-Ray, Honeycomb, Datadog, or another observability backend.

exports.createProvider = function () {
  return {
    record: function (context) {
      // context.trace and context.span are already persistence-safe objects.
      return Promise.resolve();
    },

    finish: function (trace) {
      return Promise.resolve(trace);
    }
  };
};
