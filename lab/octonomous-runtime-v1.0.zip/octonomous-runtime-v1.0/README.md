# Octonomous Runtime v1.0

A production-oriented Node.js reference runtime for **durable, accountable, governed autonomous beings and sovereign federations**.

v1.0 freezes the public boundaries created through v0.1-v0.9 rather than adding another autonomy layer.

## Release architecture

```text
@octonomous/runtime
  Being lifecycle
  policy / governance
  capabilities / commitments
  evidence / receipts
  persistence
  optional cognition adapters

@octonomous/federation
  communities / membership
  treaties / trust
  signed envelopes
  replay + idempotency
  governance proofs
  BFT quorum evidence
  HTTP / MCP / DIDComm gateways
```

The central invariant remains:

```text
Intelligence proposes.
Identity persists.
Policy authorises.
Tools act.
Evidence proves.
Governance constrains.
Federation transports assertions, not implicit authority.
```

## Version model

- software: `1.0.0`
- federation protocol: `octonomous-federation`
- preferred wire version: `2.0`
- backward-compatible wire versions: `1.0`, `1.1`, `2.0`
- public conformance profile: `OFP-1.0`

Software and wire versions are intentionally independent.

## Run tests

```bash
npm test
npm run conformance
```

The conformance suite has a dependency-free schema-validation fallback, while `ajv` + `ajv-formats` are included as dev dependencies for full JSON Schema validation in normal CI installs.

## Package imports

```js
const octo = require('@octonomous/runtime');
const federation = require('@octonomous/federation');
```

The monorepo packages live under `packages/`. The original combined `src/` tree remains in v1.0 for backward compatibility and the reference AWS deployment.

## Protocol/security documentation

- `spec/PROTOCOL.md`
- `spec/THREAT-MODEL.md`
- `spec/SECURITY-PROFILES.md`
- `spec/VERSIONING.md`
- `spec/schemas/`
- `docs/API.md`
- `docs/RELEASE-CHECKLIST.md`

## Reference deployment

See `deployment/reference/` and `examples/two-community-deployment/`.

The production boundary intentionally keeps LLM cognition, federation gateway, community signing and treasury/custody as separable trust domains.

## Migration

See `MIGRATION-v0.9-v1.0.md`.
