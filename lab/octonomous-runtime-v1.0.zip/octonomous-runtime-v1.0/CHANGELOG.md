# Changelog

## 1.0.0

Production-release packaging and protocol freeze:

- public OFP 1.0 specification;
- stable package/API boundaries;
- JSON Schemas and conformance suite;
- threat model and security profiles;
- explicit software/wire/schema version separation;
- reference deployment and release checklist;
- all v0.9 runtime/gateway behavior retained for compatibility.
