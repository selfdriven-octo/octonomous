# Migration: v0.8 → v0.9

v0.9 adds a federation gateway around the v0.8 signed-envelope protocol. Existing v0.8 federation services remain compatible.

## What changes

### 1. Remote communities are peers, not local mirrors

v0.8 envelope creation/verification assumed both communities could be loaded through the local `CommunityService`.

v0.9 adds `PeerRegistryService`. `FederationEnvelopeService` now resolves:

```text
local sender/recipient community
        OR
verified remote peer snapshot
```

A remote peer record is created from a signed federation discovery descriptor. The descriptor receipt must be cryptographically valid and bound to the exact descriptor contents.

No remote community governance state is copied into the local community store.

### 2. Exact replay can be idempotent at the gateway

The default `federation.envelope.verify` behavior is unchanged: a second use of the same nonce is rejected.

The inbound gateway uses:

```js
allowExactReplay: true
```

Only an **exact same envelope id + digest + nonce record** is considered an idempotent duplicate. A nonce reused with different envelope contents remains a replay error.

### 3. Gateway delivery idempotency is separate from protocol replay protection

Replay protection answers:

> Has this cryptographic nonce been used before?

Gateway idempotency answers:

> Has this exact delivery already been processed, and can I return the same result without executing it again?

The gateway persists both.

A failed inbound processing attempt may be retried with the exact same signed envelope. A completed delivery is returned from the stored idempotency result without rerunning the handler.

### 4. Transport becomes an adapter registry

New adapters:

```text
HTTP     built-in using Node fetch()
MCP      invokes a configured MCP tool through ToolRegistry
DIDComm  provider adapter boundary
```

The signed federation envelope is unchanged across transports.

### 5. Outbound delivery records

Every outbound envelope gets a stable delivery id derived from:

```text
senderCommunityId
recipientCommunityId
envelopeId
```

Retries reuse the exact same signed envelope. Successful deliveries are cached; terminal failures create a dead-letter record.

### 6. Protocol traces

Gateway traces are persisted independently from being memory. They include delivery attempts and protocol milestones, not private chain-of-thought/model reasoning.

An optional trace provider can export the same records to OpenTelemetry/X-Ray/etc.

### 7. AWS inbound gateway

`template.yaml` now includes:

```text
HTTP API
   ↓
GatewayFunction
   ↓
verify / replay / idempotency / route
   ↓
EventBridge (when targetBeingId is supplied)
```

The gateway Lambda uses deterministic/mock cognition and does not require an OpenAI API key.

## New environment variables

```bash
GATEWAY_COMMUNITY_ID=community:local
GATEWAY_TRANSPORT_PREFERENCE=http,mcp,didcomm
GATEWAY_PEER_CACHE_TTL_SECONDS=300
GATEWAY_IDEMPOTENCY_RETENTION_SECONDS=86400
GATEWAY_PROCESSING_TIMEOUT_SECONDS=120
GATEWAY_RETRY_MAX_ATTEMPTS=3
GATEWAY_RETRY_BASE_DELAY_MS=250
GATEWAY_RETRY_MAX_DELAY_MS=5000
GATEWAY_HTTP_TIMEOUT_MS=10000
GATEWAY_TRACE_RETENTION_SECONDS=604800
GATEWAY_TRACE_LOG=false
GATEWAY_DEAD_LETTER_RETENTION_SECONDS=1209600
# GATEWAY_TRACE_PROVIDER_MODULE=./my-trace-provider.js
# DIDCOMM_GATEWAY_PROVIDER_MODULE=./my-didcomm-provider.js
```

## New tools

```text
federation.gateway.peer.register
federation.gateway.peer.get
federation.gateway.send
federation.gateway.dead-letter.get
federation.gateway.dead-letter.replay
federation.gateway.trace.get
```

## New helper scripts

```text
npm run community:create -- <communityId> <founderBeingId> [name]
npm run discovery:publish -- <communityId> <governorBeingId> '<endpoints-json>'
npm run peer:register -- <descriptor-json-file>
```

## Production notes

- Use a stable community KERI/group-AID signer rather than ephemeral local signing.
- Put the public HTTP gateway behind appropriate WAF/rate-limit/network controls.
- Signed envelopes provide protocol authenticity/integrity; they do not provide volumetric DDoS protection.
- DIDComm remains a provider boundary; v0.9 does not invent a partial DIDComm implementation.
- For highly concurrent inbound processing, prefer the DynamoDB store and keep one stable idempotency key per signed envelope.
