'use strict';
const cp = require('node:child_process');
const path = require('node:path');
const result = cp.spawnSync(process.execPath, ['--test', path.join(__dirname, '*.test.js')], { stdio: 'inherit', shell: true });
process.exitCode = result.status || 0;
