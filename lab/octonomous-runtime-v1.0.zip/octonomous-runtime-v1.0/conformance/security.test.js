'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const canonical = require('../src/canonical');
test('canonical digest is stable across object key order', function () {
  assert.equal(canonical.sha256({a:1,b:2}), canonical.sha256({b:2,a:1}));
});
test('security profile documents exist', function () {
  const fs = require('node:fs');
  ['THREAT-MODEL.md','SECURITY-PROFILES.md','VERSIONING.md','PROTOCOL.md'].forEach(function (f) {
    assert.equal(fs.existsSync(require('node:path').join(__dirname, '../spec', f)), true);
  });
});
