'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const validate = require('./schema-validator');
function json(p) { return JSON.parse(fs.readFileSync(path.join(__dirname, p), 'utf8')); }
test('public JSON Schemas parse and valid envelope vector conforms', function () {
  const schema = json('../spec/schemas/federation-envelope.v1.schema.json');
  const vector = json('vectors/valid-envelope.json');
  const result = validate(schema, vector);
  assert.equal(result.valid, true, JSON.stringify(result.errors));
});
test('invalid envelope vector is rejected', function () {
  const schema = json('../spec/schemas/federation-envelope.v1.schema.json');
  const vector = json('vectors/invalid-envelope.json');
  assert.equal(validate(schema, vector).valid, false);
});
test('all shipped schemas declare draft 2020-12 and parse', function () {
  const dir = path.join(__dirname, '../spec/schemas');
  fs.readdirSync(dir).filter(function (f) { return f.endsWith('.json'); }).forEach(function (f) {
    const schema = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
    assert.equal(schema.$schema, 'https://json-schema.org/draft/2020-12/schema');
    assert.ok(schema.$id);
  });
});
