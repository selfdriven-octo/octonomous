'use strict';
function fallback(schema, value, path) {
  path = path || '$';
  const errors = [];
  function add(message) { errors.push(path + ': ' + message); }
  if (schema.const !== undefined && JSON.stringify(value) !== JSON.stringify(schema.const)) add('const mismatch');
  if (schema.enum && !schema.enum.includes(value)) add('not in enum');
  if (schema.type) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    const actual = value === null ? 'null' : Array.isArray(value) ? 'array' : Number.isInteger(value) ? 'integer' : typeof value;
    if (!types.includes(actual) && !(actual === 'integer' && types.includes('number'))) add('expected type ' + types.join('|') + ', got ' + actual);
  }
  if (typeof value === 'string') {
    if (schema.minLength && value.length < schema.minLength) add('too short');
    if (schema.pattern && !(new RegExp(schema.pattern)).test(value)) add('pattern mismatch');
    if (schema.format === 'date-time' && Number.isNaN(new Date(value).getTime())) add('invalid date-time');
  }
  if (typeof value === 'number' && schema.minimum !== undefined && value < schema.minimum) add('below minimum');
  if (Array.isArray(value)) {
    if (schema.uniqueItems && new Set(value.map(JSON.stringify)).size !== value.length) add('array items not unique');
    if (schema.items) value.forEach(function (item, i) { errors.push.apply(errors, fallback(schema.items, item, path + '[' + i + ']')); });
  }
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    (schema.required || []).forEach(function (key) { if (!Object.prototype.hasOwnProperty.call(value, key)) errors.push(path + ': missing required ' + key); });
    if (schema.additionalProperties === false && schema.properties) {
      Object.keys(value).forEach(function (key) { if (!Object.prototype.hasOwnProperty.call(schema.properties, key)) errors.push(path + ': unexpected property ' + key); });
    }
    Object.keys(schema.properties || {}).forEach(function (key) {
      if (Object.prototype.hasOwnProperty.call(value, key)) errors.push.apply(errors, fallback(schema.properties[key], value[key], path + '.' + key));
    });
  }
  return errors;
}
function createValidator() {
  try {
    const Ajv2020 = require('ajv/dist/2020');
    const addFormats = require('ajv-formats');
    const ajv = new Ajv2020({ allErrors: true, strict: false });
    addFormats(ajv);
    return function (schema, value) {
      const validate = ajv.compile(schema);
      return { valid: Boolean(validate(value)), errors: validate.errors || [] };
    };
  } catch (error) {
    return function (schema, value) {
      const errors = fallback(schema, value, '$');
      return { valid: errors.length === 0, errors: errors };
    };
  }
}
module.exports = createValidator();
