'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const CommunitySigningService = require('../src/federation/community-signing');
const FederationProtocolService = require('../src/federation/protocol');
const FederationEnvelopeService = require('../src/federation/envelopes');
const ReplayProtectionService = require('../src/federation/replay-protection');

function memoryStore() {
  const maps = new Map();
  function map(kind) { if (!maps.has(kind)) maps.set(kind, new Map()); return maps.get(kind); }
  return {
    claimResource: function (kind, value) {
      const m = map(kind);
      if (m.has(value.id)) return Promise.resolve(false);
      m.set(value.id, JSON.parse(JSON.stringify(value)));
      return Promise.resolve(true);
    },
    loadResource: function (kind, id) { return Promise.resolve(map(kind).get(id) || null); },
    saveResource: function (kind, value) { map(kind).set(value.id, JSON.parse(JSON.stringify(value))); return Promise.resolve(value); }
  };
}

function fixture() {
  const communitiesMap = new Map([
    ['community:a', { id: 'community:a' }],
    ['community:b', { id: 'community:b' }]
  ]);
  const communities = {
    load: function (id) { return Promise.resolve(communitiesMap.get(id) || null); },
    hasRole: function () { return true; }
  };
  const receipts = new ReceiptService({ signer: new LocalEd25519Signer({ aid: 'did:key:conformance' }) });
  const signing = new CommunitySigningService({ receipts: receipts });
  const protocol = new FederationProtocolService();
  const replay = new ReplayProtectionService({ store: memoryStore() });
  return new FederationEnvelopeService({ communities: communities, signing: signing, protocol: protocol, replay: replay, maxLifetimeSeconds: 900 });
}

test('signed envelope verifies once and atomic replay is rejected', function () {
  const service = fixture();
  let envelope;
  return service.create({ input: { senderCommunityId: 'community:a', recipientCommunityId: 'community:b', messageType: 'conformance.ping', payload: { value: 1 } } })
    .then(function (created) { envelope = created.envelope; return service.verify({ envelope: envelope, expectedRecipientCommunityId: 'community:b' }); })
    .then(function (verified) {
      assert.equal(verified.valid, true);
      return assert.rejects(function () { return service.verify({ envelope: envelope, expectedRecipientCommunityId: 'community:b' }); }, /replay/i);
    });
});

test('payload tampering and recipient substitution are rejected', function () {
  const service = fixture();
  return service.create({ input: { senderCommunityId: 'community:a', recipientCommunityId: 'community:b', messageType: 'conformance.ping', payload: { value: 1 } } })
    .then(function (created) {
      const altered = JSON.parse(JSON.stringify(created.envelope));
      altered.payload.value = 2;
      return assert.rejects(function () { return service.verify({ envelope: altered, expectedRecipientCommunityId: 'community:b' }); }, /not bound/i)
        .then(function () {
          return assert.rejects(function () { return service.verify({ envelope: created.envelope, expectedRecipientCommunityId: 'community:x' }); }, /recipient mismatch/i);
        });
    });
});
