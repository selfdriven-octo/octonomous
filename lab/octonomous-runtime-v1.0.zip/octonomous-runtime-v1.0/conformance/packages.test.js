'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
test('@octonomous/runtime package boundary loads without federation', function () {
  const runtime = require('../packages/runtime');
  assert.equal(runtime.version.software, '1.0.0');
  assert.equal(typeof runtime.Runtime, 'function');
  assert.equal(typeof runtime.Policy, 'function');
  assert.equal(typeof runtime.evidence.LocalEd25519Signer, 'function');
});
test('@octonomous/federation package boundary loads with no cognition dependency', function () {
  const federation = require('../packages/federation');
  assert.equal(typeof federation.protocol.FederationProtocolService, 'function');
  assert.equal(typeof federation.protocol.FederationEnvelopeService, 'function');
  assert.equal(typeof federation.gateway.InboundGateway, 'function');
  assert.equal(typeof federation.society.TreatyService, 'function');
});
