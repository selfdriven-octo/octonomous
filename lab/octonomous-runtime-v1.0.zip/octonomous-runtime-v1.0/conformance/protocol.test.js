'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const FederationProtocolService = require('../src/federation/protocol');
test('OFP v1 release keeps negotiated backward-compatible wire versions', function () {
  const p = new FederationProtocolService();
  assert.deepEqual(p.supportedVersions, ['1.0', '1.1', '2.0']);
  assert.equal(p.latestVersion(), '2.0');
  const n = p.negotiate(p.describe(), {
    protocol: 'octonomous-federation', versions: ['1.1','2.0'], schemas: p.supportedSchemas.slice(), capabilities: p.capabilities.slice()
  });
  assert.equal(n.version, '2.0');
});
