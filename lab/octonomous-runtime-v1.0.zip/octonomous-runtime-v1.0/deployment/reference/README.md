# Reference deployment

The v1.0 reference topology keeps the federation gateway deterministic and separates cognition from custody.

```text
Internet / peer community
        |
      HTTPS
        |
  Federation Gateway  ---- DynamoDB (peers/replay/idempotency/traces/DLQ)
        |
      SQS/EventBridge
        |
  Autonomous Worker ---- OpenAI/MCP (optional cognition/capabilities)
        |
  Governance/evidence stores

External treasury/custody/signing services remain outside the runtime.
```

## AWS SAM

`template.yaml` is the v0.9 reference SAM deployment carried into the v1.0 conformance release. Deploy each sovereign community independently, with separate state/signing identity, then exchange only signed discovery descriptors.

Recommended production separation:

- gateway role: verification/routing only;
- worker role: cognition and bounded tool invocation;
- signing role/service: community identity, preferably isolated;
- custody role/service: payment/treasury/resource execution, never embedded in gateway or LLM worker.

Before Internet exposure, use at least `OFP-GOVERNED-1` from `../../spec/SECURITY-PROFILES.md`.
