const canonical = require('../canonical');

function ReplayProtectionService(options) {
  options = options || {};
  this.store = options.store;
  this.retentionSeconds = Number(options.retentionSeconds || (7 * 24 * 60 * 60));
}

ReplayProtectionService.prototype._idFor = function (envelope) {
  return canonical.sha256({
    senderCommunityId: envelope.senderCommunityId,
    recipientCommunityId: envelope.recipientCommunityId,
    nonce: envelope.nonce
  });
};

ReplayProtectionService.prototype.claim = function (envelope, options) {
  options = options || {};
  const self = this;
  if (!envelope || !envelope.nonce || !envelope.senderCommunityId || !envelope.recipientCommunityId) {
    return Promise.reject(new Error('Replay protection requires sender, recipient, and nonce'));
  }

  const now = Math.floor(Date.now() / 1000);
  const record = {
    id: self._idFor(envelope),
    version: 'octonomous.federation-replay-record.v1',
    senderCommunityId: envelope.senderCommunityId,
    recipientCommunityId: envelope.recipientCommunityId,
    nonce: envelope.nonce,
    envelopeId: envelope.id,
    envelopeDigest: canonical.sha256(envelope),
    claimedAt: new Date().toISOString(),
    ttlEpochSeconds: now + self.retentionSeconds
  };

  if (typeof self.store.claimResource === 'function') {
    return self.store.claimResource('federation-replay', record)
      .then(function (claimed) {
        if (claimed) {
          return { ok: true, duplicate: false, record: record };
        }
        if (!options.allowExactReplay) {
          throw new Error('Federation envelope replay detected');
        }
        return self.store.loadResource('federation-replay', record.id)
          .then(function (existing) {
            if (!existing || existing.envelopeDigest !== record.envelopeDigest || existing.envelopeId !== record.envelopeId) {
              throw new Error('Federation envelope replay detected');
            }
            return { ok: true, duplicate: true, record: existing };
          });
      });
  }

  return self.store.loadResource('federation-replay', record.id)
    .then(function (existing) {
      if (existing) {
        if (options.allowExactReplay && existing.envelopeDigest === record.envelopeDigest && existing.envelopeId === record.envelopeId) {
          return { ok: true, duplicate: true, record: existing, atomic: false };
        }
        throw new Error('Federation envelope replay detected');
      }
      return self.store.saveResource('federation-replay', record)
        .then(function () { return { ok: true, duplicate: false, record: record, atomic: false }; });
    });
};

module.exports = ReplayProtectionService;
