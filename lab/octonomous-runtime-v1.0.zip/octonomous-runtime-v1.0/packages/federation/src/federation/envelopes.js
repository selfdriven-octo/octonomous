const crypto = require('crypto');
const canonical = require('../canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function FederationEnvelopeService(options) {
  options = options || {};
  this.communities = options.communities;
  this.signing = options.signing;
  this.protocol = options.protocol;
  this.replay = options.replay;
  this.peers = options.peers || null;
  this.maxLifetimeSeconds = Number(options.maxLifetimeSeconds || 900);
  this.clockSkewSeconds = Number(options.clockSkewSeconds || 120);
}

FederationEnvelopeService.prototype._unsigned = function (envelope) {
  const value = clone(envelope);
  delete value.receipt;
  return value;
};

FederationEnvelopeService.prototype.create = function (context) {
  const self = this;
  const input = context.input || {};
  let sender;
  let recipient;
  let envelope;

  if (!input.senderCommunityId || !input.recipientCommunityId || !input.messageType) {
    return Promise.reject(new Error('federation.envelope.create requires senderCommunityId, recipientCommunityId, and messageType'));
  }
  if (input.senderCommunityId === input.recipientCommunityId) {
    return Promise.reject(new Error('Federation envelope sender and recipient must differ'));
  }

  return Promise.all([
    self.communities.load(input.senderCommunityId),
    self.communities.load(input.recipientCommunityId)
      .then(function (localRecipient) {
        if (localRecipient || !self.peers) { return localRecipient; }
        return self.peers.resolveCommunity(input.recipientCommunityId);
      })
  ])
    .then(function (loaded) {
      sender = loaded[0];
      recipient = loaded[1];
      if (!sender) {
        throw new Error('Federation envelope references an unknown sender community');
      }
      if (!recipient) {
        throw new Error('Federation envelope references an unknown recipient community or peer');
      }
      if (context.being && !self.communities.hasRole(sender, context.being.id, ['founder', 'governor', 'federation-admin'])) {
        throw new Error('Being is not authorised to send federation envelopes for community: ' + sender.id);
      }

      const issuedAt = input.issuedAt ? new Date(input.issuedAt) : new Date();
      const lifetime = Math.min(Number(input.lifetimeSeconds || self.maxLifetimeSeconds), self.maxLifetimeSeconds);
      if (!Number.isFinite(lifetime) || lifetime <= 0) {
        throw new Error('Federation envelope lifetime must be positive');
      }
      const expiresAt = input.expiresAt ? new Date(input.expiresAt) : new Date(issuedAt.getTime() + lifetime * 1000);
      if (Number.isNaN(issuedAt.getTime()) || Number.isNaN(expiresAt.getTime()) || expiresAt <= issuedAt) {
        throw new Error('Federation envelope timestamps are invalid');
      }
      if ((expiresAt.getTime() - issuedAt.getTime()) / 1000 > self.maxLifetimeSeconds) {
        throw new Error('Federation envelope lifetime exceeds the configured maximum');
      }

      envelope = {
        id: input.id || ('fenv:' + crypto.randomUUID()),
        schema: input.schema || 'octonomous.federation-envelope.v1',
        protocol: {
          name: input.protocolName || self.protocol.name,
          version: input.protocolVersion || self.protocol.latestVersion()
        },
        messageType: input.messageType,
        senderCommunityId: sender.id,
        recipientCommunityId: recipient.id,
        nonce: input.nonce || crypto.randomBytes(24).toString('base64url'),
        issuedAt: issuedAt.toISOString(),
        expiresAt: expiresAt.toISOString(),
        correlationId: input.correlationId || null,
        causationId: input.causationId || null,
        payload: clone(input.payload || {}),
        receipt: null
      };

      if (!self.protocol.supportsEnvelope(envelope)) {
        throw new Error('Unsupported federation envelope protocol or schema');
      }

      return self.signing.sign(sender, 'federation.envelope.signed', self._unsigned(envelope), {
        recipientCommunityId: recipient.id,
        messageType: envelope.messageType
      });
    })
    .then(function (receipt) {
      envelope.receipt = receipt;
      return { ok: true, envelope: envelope };
    });
};

FederationEnvelopeService.prototype.verify = function (context) {
  const self = this;
  const envelope = context.envelope || context.input && context.input.envelope;
  const expectedRecipientCommunityId = context.expectedRecipientCommunityId || context.input && context.input.expectedRecipientCommunityId || null;
  let sender;

  if (!envelope || !envelope.receipt) {
    return Promise.reject(new Error('Federation envelope is missing its signed receipt'));
  }
  if (!self.protocol.supportsEnvelope(envelope)) {
    return Promise.reject(new Error('Unsupported federation envelope protocol or schema'));
  }
  if (expectedRecipientCommunityId && envelope.recipientCommunityId !== expectedRecipientCommunityId) {
    return Promise.reject(new Error('Federation envelope recipient mismatch'));
  }

  const now = Date.now();
  const issuedAt = new Date(envelope.issuedAt).getTime();
  const expiresAt = new Date(envelope.expiresAt).getTime();
  if (!Number.isFinite(issuedAt) || !Number.isFinite(expiresAt)) {
    return Promise.reject(new Error('Federation envelope timestamps are invalid'));
  }
  if (issuedAt > now + self.clockSkewSeconds * 1000) {
    return Promise.reject(new Error('Federation envelope was issued too far in the future'));
  }
  if (expiresAt < now - self.clockSkewSeconds * 1000) {
    return Promise.reject(new Error('Federation envelope has expired'));
  }
  if ((expiresAt - issuedAt) / 1000 > self.maxLifetimeSeconds) {
    return Promise.reject(new Error('Federation envelope lifetime exceeds the configured maximum'));
  }

  return self.communities.load(envelope.senderCommunityId)
    .then(function (loaded) {
      if (loaded || !self.peers) { return loaded; }
      return self.peers.resolveCommunity(envelope.senderCommunityId);
    })
    .then(function (loaded) {
      sender = loaded;
      if (!sender) {
        throw new Error('Unknown federation envelope sender community or peer');
      }
      const receiptSubject = envelope.receipt && envelope.receipt.payload && envelope.receipt.payload.subject;
      if (canonical.sha256(receiptSubject || {}) !== canonical.sha256(self._unsigned(envelope))) {
        throw new Error('Federation envelope receipt is not bound to the envelope contents');
      }
      return self.signing.verify(sender, envelope.receipt);
    })
    .then(function (verification) {
      if (!verification || verification.valid === false) {
        throw new Error('Federation envelope signature verification failed');
      }
      if (!self.replay) {
        return null;
      }
      return self.replay.claim(envelope, { allowExactReplay: Boolean(context.allowExactReplay) });
    })
    .then(function (replayResult) {
      return {
        ok: true,
        valid: true,
        envelope: envelope,
        replay: replayResult,
        senderCommunityId: envelope.senderCommunityId,
        recipientCommunityId: envelope.recipientCommunityId
      };
    });
};

module.exports = FederationEnvelopeService;
