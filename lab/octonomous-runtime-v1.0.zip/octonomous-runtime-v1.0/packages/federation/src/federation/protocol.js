const canonical = require('../canonical');

function normaliseVersion(value) {
  return String(value || '').trim();
}

function compareVersions(a, b) {
  const ap = normaliseVersion(a).split('.').map(Number);
  const bp = normaliseVersion(b).split('.').map(Number);
  const length = Math.max(ap.length, bp.length);
  let i;

  for (i = 0; i < length; i += 1) {
    const av = Number.isFinite(ap[i]) ? ap[i] : 0;
    const bv = Number.isFinite(bp[i]) ? bp[i] : 0;
    if (av > bv) { return 1; }
    if (av < bv) { return -1; }
  }
  return 0;
}

function intersect(a, b) {
  const right = new Set(b || []);
  return (a || []).filter(function (item) { return right.has(item); });
}

function FederationProtocolService(options) {
  options = options || {};
  this.name = options.name || 'octonomous-federation';
  this.supportedVersions = Array.from(new Set(options.supportedVersions || ['1.0', '1.1', '2.0'])).sort(compareVersions);
  this.supportedSchemas = options.supportedSchemas || [
    'octonomous.federation-envelope.v1',
    'octonomous.federation-discovery.v1',
    'octonomous.local-governance-proof.v1',
    'octonomous.bft-quorum-certificate.v1'
  ];
  this.capabilities = options.capabilities || [
    'signed-envelopes',
    'replay-protection',
    'version-negotiation',
    'capability-discovery',
    'local-governance-proofs',
    'treaty-version-chains',
    'bft-quorum-certificates',
    'federation-gateway',
    'idempotent-delivery',
    'transport-discovery',
    'delivery-tracing'
  ];
}

FederationProtocolService.prototype.describe = function (extra) {
  extra = extra || {};
  return {
    protocol: this.name,
    versions: this.supportedVersions.slice(),
    schemas: this.supportedSchemas.slice(),
    capabilities: Array.from(new Set(this.capabilities.concat(extra.capabilities || []))),
    metadata: extra.metadata || {},
    digest: canonical.sha256({
      protocol: this.name,
      versions: this.supportedVersions,
      schemas: this.supportedSchemas,
      capabilities: Array.from(new Set(this.capabilities.concat(extra.capabilities || [])))
    })
  };
};

FederationProtocolService.prototype.latestVersion = function () {
  return this.supportedVersions[this.supportedVersions.length - 1];
};

FederationProtocolService.prototype.supportsEnvelope = function (envelope) {
  if (!envelope || !envelope.protocol || !envelope.schema) {
    return false;
  }
  return envelope.protocol.name === this.name &&
    this.supportedVersions.includes(envelope.protocol.version) &&
    this.supportedSchemas.includes(envelope.schema);
};

FederationProtocolService.prototype.negotiate = function (localDescriptor, remoteDescriptor) {
  if (!localDescriptor || !remoteDescriptor) {
    throw new Error('Protocol negotiation requires local and remote descriptors');
  }
  if (localDescriptor.protocol !== remoteDescriptor.protocol) {
    throw new Error('No common federation protocol');
  }

  const versions = intersect(localDescriptor.versions, remoteDescriptor.versions)
    .sort(compareVersions)
    .reverse();
  if (!versions.length) {
    throw new Error('No common federation protocol version');
  }

  const schemas = intersect(localDescriptor.schemas, remoteDescriptor.schemas);
  if (!schemas.length) {
    throw new Error('No common federation schema');
  }

  return {
    protocol: localDescriptor.protocol,
    version: versions[0],
    schemas: schemas,
    capabilities: intersect(localDescriptor.capabilities, remoteDescriptor.capabilities),
    localDigest: localDescriptor.digest || canonical.sha256(localDescriptor),
    remoteDigest: remoteDescriptor.digest || canonical.sha256(remoteDescriptor)
  };
};

FederationProtocolService.compareVersions = compareVersions;

module.exports = FederationProtocolService;
