function GatewayTransportRegistry() {
  this.adapters = new Map();
}

GatewayTransportRegistry.prototype.register = function (name, adapter) {
  if (!name || !adapter || typeof adapter.send !== 'function') {
    throw new Error('Gateway transport registration requires a name and send() adapter');
  }
  this.adapters.set(name, adapter);
  return adapter;
};

GatewayTransportRegistry.prototype.has = function (name) {
  return this.adapters.has(name);
};

GatewayTransportRegistry.prototype.list = function () {
  return Array.from(this.adapters.keys());
};

GatewayTransportRegistry.prototype.send = function (name, context) {
  const adapter = this.adapters.get(name);
  if (!adapter) {
    return Promise.reject(new Error('Unknown gateway transport: ' + name));
  }
  return Promise.resolve(adapter.send(context));
};

module.exports = GatewayTransportRegistry;
