function DidCommGatewayTransport(options) {
  options = options || {};
  this.provider = options.provider || null;
}

DidCommGatewayTransport.prototype.send = function (context) {
  if (!this.provider || typeof this.provider.send !== 'function') {
    return Promise.reject(new Error('DIDComm gateway transport requires a DIDComm provider adapter'));
  }
  return Promise.resolve(this.provider.send({
    endpoint: context.endpoint,
    envelope: context.envelope,
    idempotencyKey: context.idempotencyKey || context.envelope.id,
    peerCommunityId: context.peerCommunityId
  }))
    .then(function (result) {
      return { ok: true, transport: 'didcomm', result: result };
    });
};

module.exports = DidCommGatewayTransport;
