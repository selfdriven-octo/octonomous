function McpGatewayTransport(options) {
  options = options || {};
  this.tools = options.tools;
}

McpGatewayTransport.prototype.send = function (context) {
  const endpoint = context.endpoint || {};
  if (!this.tools || typeof this.tools.execute !== 'function') {
    return Promise.reject(new Error('MCP gateway transport requires a tool registry'));
  }
  if (!endpoint.tool) {
    return Promise.reject(new Error('MCP gateway endpoint requires tool'));
  }
  return this.tools.execute(endpoint.tool, {
    envelope: context.envelope,
    idempotencyKey: context.idempotencyKey || context.envelope.id
  }, {
    source: 'federation-gateway',
    peerCommunityId: context.peerCommunityId
  })
    .then(function (result) {
      if (result && (result.ok === false || result.isError)) {
        const error = new Error('MCP federation delivery returned an error');
        error.retryable = Boolean(result.retryable);
        error.result = result;
        throw error;
      }
      return { ok: true, transport: 'mcp', result: result };
    });
};

module.exports = McpGatewayTransport;
