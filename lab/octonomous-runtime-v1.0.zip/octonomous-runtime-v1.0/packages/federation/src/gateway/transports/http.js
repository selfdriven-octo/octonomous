function HttpGatewayTransport(options) {
  options = options || {};
  this.fetch = options.fetch || global.fetch;
  this.timeoutMs = Number(options.timeoutMs || 10000);
  if (typeof this.fetch !== 'function') {
    throw new Error('HTTP gateway transport requires fetch()');
  }
}

HttpGatewayTransport.prototype.send = function (context) {
  const self = this;
  const endpoint = typeof context.endpoint === 'string'
    ? { url: context.endpoint }
    : (context.endpoint || {});
  if (!endpoint.url) {
    return Promise.reject(new Error('HTTP gateway endpoint requires url'));
  }

  const controller = new AbortController();
  const timer = setTimeout(function () { controller.abort(); }, Number(endpoint.timeoutMs || self.timeoutMs));
  const headers = Object.assign({}, endpoint.headers || {}, context.headers || {}, {
    'content-type': 'application/json',
    'x-octonomous-envelope-id': context.envelope.id,
    'x-octonomous-idempotency-key': context.idempotencyKey || context.envelope.id
  });

  return self.fetch(endpoint.url, {
    method: endpoint.method || 'POST',
    headers: headers,
    body: JSON.stringify({ envelope: context.envelope }),
    signal: controller.signal
  })
    .then(function (response) {
      return response.text().then(function (text) {
        let body = text;
        try { body = text ? JSON.parse(text) : null; } catch (error) {}
        if (!response.ok) {
          const failure = new Error('HTTP federation delivery failed with status ' + response.status);
          failure.status = response.status;
          failure.retryable = response.status === 408 || response.status === 425 || response.status === 429 || response.status >= 500;
          failure.responseBody = body;
          throw failure;
        }
        return {
          ok: true,
          transport: 'http',
          status: response.status,
          body: body,
          headers: Object.fromEntries(response.headers.entries())
        };
      });
    })
    .catch(function (error) {
      if (error && error.name === 'AbortError') {
        const timeout = new Error('HTTP federation delivery timed out');
        timeout.retryable = true;
        timeout.cause = error;
        throw timeout;
      }
      throw error;
    })
    .finally(function () { clearTimeout(timer); });
};

module.exports = HttpGatewayTransport;
