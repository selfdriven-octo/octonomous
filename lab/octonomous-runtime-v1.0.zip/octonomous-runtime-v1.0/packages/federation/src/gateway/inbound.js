function InboundGateway(options) {
  options = options || {};
  this.communityId = options.communityId || null;
  this.envelopes = options.envelopes;
  this.idempotency = options.idempotency;
  this.router = options.router;
  this.traces = options.traces || null;
}

InboundGateway.prototype.handle = function (context) {
  const self = this;
  const envelope = context.envelope;
  const expectedRecipientCommunityId = context.expectedRecipientCommunityId || self.communityId;
  let trace;
  let idempotencyRecord;

  if (!envelope) {
    return Promise.reject(new Error('Inbound gateway requires envelope'));
  }
  if (!expectedRecipientCommunityId) {
    return Promise.reject(new Error('Inbound gateway requires expected recipient community id'));
  }

  const startTrace = self.traces
    ? self.traces.start({
      correlationId: envelope.correlationId,
      envelopeId: envelope.id,
      direction: 'inbound',
      peerCommunityId: envelope.senderCommunityId,
      transport: context.transport || null
    })
    : Promise.resolve(null);

  return startTrace
    .then(function (createdTrace) {
      trace = createdTrace;
      return self.traces ? self.traces.record(trace, 'envelope.received', { messageType: envelope.messageType }) : null;
    })
    .then(function () {
      return self.envelopes.verify({
        envelope: envelope,
        expectedRecipientCommunityId: expectedRecipientCommunityId,
        allowExactReplay: true
      });
    })
    .then(function (verification) {
      return self.traces ? self.traces.record(trace, 'envelope.verified', {
        replayDuplicate: Boolean(verification.replay && verification.replay.duplicate)
      }).then(function () { return verification; }) : verification;
    })
    .then(function (verification) {
      return self.idempotency.begin(envelope)
        .then(function (begin) {
          idempotencyRecord = begin.record;
          if (begin.duplicate && !begin.acquired) {
            if (begin.record.status === 'completed') {
              return {
                duplicate: true,
                cached: true,
                result: begin.record.result,
                verification: verification
              };
            }
            return {
              duplicate: true,
              cached: false,
              inProgress: begin.record.status === 'processing',
              status: begin.record.status,
              verification: verification
            };
          }

          return self.router.dispatch({
            envelope: envelope,
            verification: verification,
            transport: context.transport || null,
            headers: context.headers || {},
            traceId: trace && trace.id
          })
            .then(function (result) {
              return self.idempotency.complete(idempotencyRecord, result)
                .then(function () {
                  return { duplicate: false, cached: false, result: result, verification: verification };
                });
            });
        });
    })
    .then(function (result) {
      if (!self.traces) { return result; }
      return self.traces.record(trace, result.duplicate ? 'delivery.duplicate' : 'delivery.processed', {
        cached: Boolean(result.cached)
      })
        .then(function () { return self.traces.finish(trace, 'completed', { duplicate: Boolean(result.duplicate) }); })
        .then(function () {
          result.traceId = trace.id;
          return result;
        });
    })
    .catch(function (error) {
      const failIdempotency = idempotencyRecord && idempotencyRecord.status === 'processing'
        ? self.idempotency.fail(idempotencyRecord, error).catch(function () {})
        : Promise.resolve();
      return failIdempotency
        .then(function () {
          return self.traces && trace
            ? self.traces.record(trace, 'delivery.failed', { message: error.message })
              .then(function () { return self.traces.finish(trace, 'failed', { message: error.message }); })
            : null;
        })
        .then(function () { throw error; });
    });
};

module.exports = InboundGateway;
