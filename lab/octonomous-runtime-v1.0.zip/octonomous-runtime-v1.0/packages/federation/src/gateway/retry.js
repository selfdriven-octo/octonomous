function sleep(ms) {
  return new Promise(function (resolve) { setTimeout(resolve, ms); });
}

function RetryPolicy(options) {
  options = options || {};
  this.maxAttempts = Math.max(1, Number(options.maxAttempts || 3));
  this.baseDelayMs = Math.max(0, Number(options.baseDelayMs || 250));
  this.maxDelayMs = Math.max(this.baseDelayMs, Number(options.maxDelayMs || 5000));
  this.sleep = options.sleep || sleep;
}

RetryPolicy.prototype.delayFor = function (attempt) {
  const delay = this.baseDelayMs * Math.pow(2, Math.max(0, attempt - 1));
  return Math.min(delay, this.maxDelayMs);
};

RetryPolicy.prototype.isRetryable = function (error) {
  if (!error) { return false; }
  if (error.retryable === true) { return true; }
  const status = Number(error.status || error.statusCode || 0);
  return status === 408 || status === 425 || status === 429 || status >= 500;
};

RetryPolicy.prototype.execute = function (operation, onAttempt) {
  const self = this;
  let attempt = 0;

  function run() {
    attempt += 1;
    if (onAttempt) {
      onAttempt({ attempt: attempt, maxAttempts: self.maxAttempts });
    }

    return Promise.resolve()
      .then(function () { return operation(attempt); })
      .catch(function (error) {
        if (attempt >= self.maxAttempts || !self.isRetryable(error)) {
          error.attempts = attempt;
          throw error;
        }
        return self.sleep(self.delayFor(attempt)).then(run);
      });
  }

  return run();
};

module.exports = RetryPolicy;
