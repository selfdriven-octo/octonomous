function GatewayRouter() {
  this.handlers = new Map();
  this.fallback = null;
}

GatewayRouter.prototype.register = function (messageType, handler) {
  if (messageType === '*') {
    this.fallback = handler;
    return;
  }
  this.handlers.set(messageType, handler);
};

GatewayRouter.prototype.dispatch = function (context) {
  const handler = this.handlers.get(context.envelope.messageType) || this.fallback;
  if (!handler) {
    return Promise.resolve({
      ok: true,
      accepted: true,
      routed: false,
      messageType: context.envelope.messageType
    });
  }
  return Promise.resolve(handler(context));
};

module.exports = GatewayRouter;
