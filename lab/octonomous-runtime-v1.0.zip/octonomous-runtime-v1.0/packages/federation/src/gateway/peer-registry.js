const canonical = require('../canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value || {}));
}

function PeerRegistryService(options) {
  options = options || {};
  this.store = options.store;
  this.signing = options.signing;
  this.cacheTtlSeconds = Number(options.cacheTtlSeconds || 300);
  this.cache = new Map();
}

PeerRegistryService.prototype._snapshotFromDescriptor = function (descriptor) {
  return {
    id: descriptor.communityId,
    identity: clone(descriptor.identity || {}),
    groupIdentity: clone(descriptor.groupIdentity || descriptor.identity || {}),
    federationPeer: true
  };
};

PeerRegistryService.prototype._verifyDescriptor = function (descriptor) {
  const self = this;
  if (!descriptor || !descriptor.communityId || !descriptor.receipt) {
    return Promise.reject(new Error('Peer registration requires a signed discovery descriptor'));
  }
  if (descriptor.validUntil && new Date(descriptor.validUntil).getTime() < Date.now()) {
    return Promise.reject(new Error('Peer discovery descriptor has expired'));
  }

  const unsigned = clone(descriptor);
  delete unsigned.receipt;
  const receiptSubject = descriptor.receipt.payload && descriptor.receipt.payload.subject;
  if (canonical.sha256(receiptSubject || {}) !== canonical.sha256(unsigned)) {
    return Promise.reject(new Error('Peer discovery receipt is not bound to descriptor'));
  }

  if (!self.signing || typeof self.signing.verify !== 'function') {
    return Promise.reject(new Error('Peer registry has no community signature verifier'));
  }

  const snapshot = self._snapshotFromDescriptor(descriptor);
  return self.signing.verify(snapshot, descriptor.receipt)
    .then(function (verification) {
      if (!verification || verification.valid === false) {
        throw new Error('Peer discovery signature verification failed');
      }
      return { snapshot: snapshot, verification: verification };
    });
};

PeerRegistryService.prototype.register = function (context) {
  const self = this;
  const input = context && context.input ? context.input : context || {};
  const descriptor = input.descriptor;

  return self._verifyDescriptor(descriptor)
    .then(function (verified) {
      const record = {
        id: descriptor.communityId,
        version: 'octonomous.gateway-peer.v1',
        communityId: descriptor.communityId,
        community: verified.snapshot,
        descriptor: clone(descriptor),
        endpoints: clone(input.endpoints || descriptor.endpoints || {}),
        protocol: clone(descriptor.protocol || {}),
        operations: clone(descriptor.operations || []),
        scopes: clone(descriptor.scopes || []),
        transportPreference: clone(input.transportPreference || []),
        registeredAt: new Date().toISOString(),
        lastVerifiedAt: new Date().toISOString(),
        validUntil: descriptor.validUntil || null,
        metadata: clone(input.metadata || {})
      };

      return self.store.loadResource('gateway-peers', record.id)
        .then(function (existing) {
          if (existing && existing._version !== undefined) {
            record._version = existing._version;
          }
          return self.store.saveResource('gateway-peers', record);
        })
        .then(function () {
          self.cache.set(record.id, {
            expiresAt: Date.now() + self.cacheTtlSeconds * 1000,
            value: record
          });
          return { ok: true, peer: record, verification: verified.verification };
        });
    });
};

PeerRegistryService.prototype.load = function (communityId) {
  const self = this;
  const cached = self.cache.get(communityId);
  if (cached && cached.expiresAt > Date.now()) {
    return Promise.resolve(cached.value);
  }

  return self.store.loadResource('gateway-peers', communityId)
    .then(function (peer) {
      if (!peer) {
        return null;
      }
      if (peer.validUntil && new Date(peer.validUntil).getTime() < Date.now()) {
        return null;
      }
      self.cache.set(communityId, {
        expiresAt: Date.now() + self.cacheTtlSeconds * 1000,
        value: peer
      });
      return peer;
    });
};

PeerRegistryService.prototype.resolveCommunity = function (communityId) {
  return this.load(communityId)
    .then(function (peer) {
      return peer ? peer.community : null;
    });
};

PeerRegistryService.prototype.resolveEndpoint = function (communityId, requestedTransport, defaultPreference) {
  return this.load(communityId)
    .then(function (peer) {
      if (!peer) {
        throw new Error('Unknown federation peer: ' + communityId);
      }

      const endpoints = peer.endpoints || {};
      const preference = [];
      if (requestedTransport) {
        preference.push(requestedTransport);
      }
      (peer.transportPreference || []).forEach(function (item) { preference.push(item); });
      (defaultPreference || []).forEach(function (item) { preference.push(item); });
      Object.keys(endpoints).forEach(function (item) { preference.push(item); });

      const unique = Array.from(new Set(preference));
      let i;
      for (i = 0; i < unique.length; i += 1) {
        if (endpoints[unique[i]]) {
          return {
            peer: peer,
            transport: unique[i],
            endpoint: clone(endpoints[unique[i]])
          };
        }
      }

      throw new Error('Peer has no compatible gateway endpoint: ' + communityId);
    });
};

module.exports = PeerRegistryService;
