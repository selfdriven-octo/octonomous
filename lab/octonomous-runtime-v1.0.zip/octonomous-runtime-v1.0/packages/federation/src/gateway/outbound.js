const canonical = require('../canonical');

function OutboundGateway(options) {
  options = options || {};
  this.envelopes = options.envelopes;
  this.peers = options.peers;
  this.transports = options.transports;
  this.retry = options.retry;
  this.deadLetters = options.deadLetters;
  this.traces = options.traces || null;
  this.store = options.store;
  this.transportPreference = options.transportPreference || ['http', 'mcp', 'didcomm'];
}

OutboundGateway.prototype._deliveryId = function (envelope) {
  return canonical.sha256({
    senderCommunityId: envelope.senderCommunityId,
    recipientCommunityId: envelope.recipientCommunityId,
    envelopeId: envelope.id
  });
};

OutboundGateway.prototype._loadDelivery = function (envelope) {
  return this.store.loadResource('gateway-deliveries', this._deliveryId(envelope));
};

OutboundGateway.prototype._saveDelivery = function (delivery) {
  return this.store.saveResource('gateway-deliveries', delivery);
};

OutboundGateway.prototype.sendEnvelope = function (context) {
  const self = this;
  const envelope = context.envelope;
  let trace;
  let resolved;
  let delivery;
  let attempts = 0;

  return self._loadDelivery(envelope)
    .then(function (existing) {
      if (existing && existing.status === 'completed') {
        return { cached: true, delivery: existing, response: existing.response };
      }
      delivery = existing || {
        id: self._deliveryId(envelope),
        version: 'octonomous.gateway-delivery.v1',
        envelopeId: envelope.id,
        envelopeDigest: canonical.sha256(envelope),
        senderCommunityId: envelope.senderCommunityId,
        recipientCommunityId: envelope.recipientCommunityId,
        status: 'pending',
        attempts: 0,
        createdAt: new Date().toISOString(),
        response: null,
        deadLetterId: null
      };
      if (delivery.envelopeDigest !== canonical.sha256(envelope)) {
        throw new Error('Outbound gateway delivery id collision with different envelope contents');
      }
      return self.peers.resolveEndpoint(envelope.recipientCommunityId, context.transport, self.transportPreference);
    })
    .then(function (endpointResolution) {
      if (endpointResolution && endpointResolution.cached) {
        return endpointResolution;
      }
      resolved = endpointResolution;
      const start = self.traces
        ? self.traces.start({
          correlationId: envelope.correlationId,
          envelopeId: envelope.id,
          direction: 'outbound',
          peerCommunityId: envelope.recipientCommunityId,
          transport: resolved.transport
        })
        : Promise.resolve(null);

      return start.then(function (createdTrace) {
        trace = createdTrace;
        delivery.transport = resolved.transport;
        delivery.endpoint = resolved.endpoint;
        delivery.status = 'sending';
        delivery.updatedAt = new Date().toISOString();
        return self._saveDelivery(delivery);
      })
        .then(function () {
          return self.retry.execute(function (attempt) {
            attempts = attempt;
            delivery.attempts = attempt;
            delivery.lastAttemptAt = new Date().toISOString();
            const span = self.traces
              ? self.traces.record(trace, 'delivery.attempt', { attempt: attempt, transport: resolved.transport })
              : Promise.resolve();
            return span.then(function () {
              return self.transports.send(resolved.transport, {
                endpoint: resolved.endpoint,
                envelope: envelope,
                idempotencyKey: delivery.id,
                peerCommunityId: envelope.recipientCommunityId
              });
            });
          });
        })
        .then(function (response) {
          delivery.status = 'completed';
          delivery.response = response;
          delivery.completedAt = new Date().toISOString();
          delivery.updatedAt = delivery.completedAt;
          return self._saveDelivery(delivery)
            .then(function () {
              return self.traces ? self.traces.finish(trace, 'completed', { attempts: attempts }) : null;
            })
            .then(function () {
              return { ok: true, cached: false, delivery: delivery, response: response, traceId: trace && trace.id };
            });
        })
        .catch(function (error) {
          delivery.status = 'failed';
          delivery.attempts = error.attempts || attempts;
          delivery.error = { name: error.name, message: error.message, status: error.status || null };
          delivery.updatedAt = new Date().toISOString();
          return self._saveDelivery(delivery)
            .then(function () {
              return self.deadLetters.create({
                envelope: envelope,
                peerCommunityId: envelope.recipientCommunityId,
                transport: resolved.transport,
                endpoint: resolved.endpoint,
                attempts: delivery.attempts,
                error: error,
                traceId: trace && trace.id
              });
            })
            .then(function (dead) {
              delivery.status = 'dead-lettered';
              delivery.deadLetterId = dead.deadLetter.id;
              delivery.updatedAt = new Date().toISOString();
              return self._saveDelivery(delivery)
                .then(function () {
                  return self.traces ? self.traces.finish(trace, 'dead-lettered', { deadLetterId: dead.deadLetter.id }) : null;
                })
                .then(function () {
                  error.deadLetterId = dead.deadLetter.id;
                  throw error;
                });
            });
        });
    });
};

OutboundGateway.prototype.send = function (context) {
  const self = this;
  if (context.envelope) {
    return self.sendEnvelope(context);
  }
  return self.envelopes.create({ being: context.being, event: context.event, input: context.input })
    .then(function (created) {
      return self.sendEnvelope({ envelope: created.envelope, transport: context.transport || context.input && context.input.transport });
    });
};

OutboundGateway.prototype.replayDeadLetter = function (id) {
  const self = this;
  return self.deadLetters.load(id)
    .then(function (record) {
      if (!record) {
        throw new Error('Unknown gateway dead-letter: ' + id);
      }
      return self.sendEnvelope({ envelope: record.envelope, transport: record.transport })
        .then(function (delivery) {
          return self.deadLetters.markReplayed(record, delivery)
            .then(function () { return delivery; });
        });
    });
};

module.exports = OutboundGateway;
