const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value || {}));
}

function DeadLetterService(options) {
  options = options || {};
  this.store = options.store;
  this.publisher = options.publisher || null;
  this.retentionSeconds = Number(options.retentionSeconds || (14 * 24 * 60 * 60));
}

DeadLetterService.prototype.create = function (context) {
  const self = this;
  const now = new Date();
  const record = {
    id: context.id || ('gdlq:' + crypto.randomUUID()),
    version: 'octonomous.gateway-dead-letter.v1',
    envelope: clone(context.envelope),
    peerCommunityId: context.peerCommunityId || context.envelope && context.envelope.recipientCommunityId || null,
    transport: context.transport || null,
    endpoint: clone(context.endpoint || {}),
    attempts: Number(context.attempts || 0),
    error: {
      name: context.error && context.error.name || 'Error',
      message: context.error && context.error.message || String(context.error || 'Gateway delivery failed'),
      status: context.error && (context.error.status || context.error.statusCode) || null
    },
    traceId: context.traceId || null,
    createdAt: now.toISOString(),
    status: 'dead-lettered',
    ttlEpochSeconds: Math.floor(now.getTime() / 1000) + self.retentionSeconds
  };

  return self.store.saveResource('gateway-dead-letters', record)
    .then(function () {
      if (!self.publisher) {
        return record;
      }
      return self.publisher.publish({
        type: 'federation.gateway.dead-lettered',
        payload: {
          deadLetterId: record.id,
          peerCommunityId: record.peerCommunityId,
          envelopeId: record.envelope && record.envelope.id,
          traceId: record.traceId
        }
      }).then(function () { return record; });
    })
    .then(function () { return { ok: true, deadLetter: record }; });
};

DeadLetterService.prototype.load = function (id) {
  return this.store.loadResource('gateway-dead-letters', id);
};

DeadLetterService.prototype.markReplayed = function (record, delivery) {
  record.status = 'replayed';
  record.replayedAt = new Date().toISOString();
  record.replayDelivery = clone(delivery || {});
  return this.store.saveResource('gateway-dead-letters', record);
};

module.exports = DeadLetterService;
