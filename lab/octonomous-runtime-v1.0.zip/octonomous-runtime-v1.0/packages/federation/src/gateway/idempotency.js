const canonical = require('../canonical');

function GatewayIdempotencyService(options) {
  options = options || {};
  this.store = options.store;
  this.retentionSeconds = Number(options.retentionSeconds || (24 * 60 * 60));
  this.processingTimeoutSeconds = Number(options.processingTimeoutSeconds || 120);
}

GatewayIdempotencyService.prototype._idFor = function (envelope) {
  return canonical.sha256({
    recipientCommunityId: envelope.recipientCommunityId,
    envelopeId: envelope.id
  });
};

GatewayIdempotencyService.prototype.begin = function (envelope) {
  const self = this;
  if (!envelope || !envelope.id || !envelope.recipientCommunityId) {
    return Promise.reject(new Error('Gateway idempotency requires envelope id and recipient'));
  }

  const now = new Date();
  const record = {
    id: self._idFor(envelope),
    version: 'octonomous.gateway-idempotency.v1',
    envelopeId: envelope.id,
    envelopeDigest: canonical.sha256(envelope),
    senderCommunityId: envelope.senderCommunityId,
    recipientCommunityId: envelope.recipientCommunityId,
    status: 'processing',
    attempts: 1,
    startedAt: now.toISOString(),
    updatedAt: now.toISOString(),
    result: null,
    error: null,
    ttlEpochSeconds: Math.floor(now.getTime() / 1000) + self.retentionSeconds
  };

  if (typeof self.store.claimResource === 'function') {
    return self.store.claimResource('gateway-idempotency', record)
      .then(function (claimed) {
        if (claimed) {
          return { acquired: true, duplicate: false, record: record };
        }
        return self.store.loadResource('gateway-idempotency', record.id)
          .then(function (existing) {
            if (!existing) {
              throw new Error('Gateway idempotency record disappeared after duplicate claim');
            }
            if (existing.envelopeDigest !== record.envelopeDigest) {
              throw new Error('Gateway idempotency key collision with different envelope contents');
            }
            const startedAt = new Date(existing.startedAt || existing.updatedAt || 0).getTime();
            const staleProcessing = existing.status === 'processing' &&
              Number.isFinite(startedAt) && (Date.now() - startedAt) > self.processingTimeoutSeconds * 1000;
            if (existing.status === 'failed' || staleProcessing) {
              existing.status = 'processing';
              existing.attempts = Number(existing.attempts || 1) + 1;
              existing.startedAt = new Date().toISOString();
              existing.updatedAt = existing.startedAt;
              existing.error = null;
              return self.store.saveResource('gateway-idempotency', existing)
                .then(function () { return { acquired: true, duplicate: true, retry: true, record: existing }; });
            }
            return { acquired: false, duplicate: true, record: existing };
          });
      });
  }

  return self.store.loadResource('gateway-idempotency', record.id)
    .then(function (existing) {
      if (existing) {
        if (existing.envelopeDigest !== record.envelopeDigest) {
          throw new Error('Gateway idempotency key collision with different envelope contents');
        }
        const startedAt = new Date(existing.startedAt || existing.updatedAt || 0).getTime();
        const staleProcessing = existing.status === 'processing' &&
          Number.isFinite(startedAt) && (Date.now() - startedAt) > self.processingTimeoutSeconds * 1000;
        if (existing.status === 'failed' || staleProcessing) {
          existing.status = 'processing';
          existing.attempts = Number(existing.attempts || 1) + 1;
          existing.startedAt = new Date().toISOString();
          existing.updatedAt = existing.startedAt;
          existing.error = null;
          return self.store.saveResource('gateway-idempotency', existing)
            .then(function () { return { acquired: true, duplicate: true, retry: true, record: existing }; });
        }
        return { acquired: false, duplicate: true, record: existing };
      }
      return self.store.saveResource('gateway-idempotency', record)
        .then(function () { return { acquired: true, duplicate: false, record: record }; });
    });
};

GatewayIdempotencyService.prototype.complete = function (record, result) {
  record.status = 'completed';
  record.result = result === undefined ? null : JSON.parse(JSON.stringify(result));
  record.error = null;
  record.completedAt = new Date().toISOString();
  record.updatedAt = record.completedAt;
  return this.store.saveResource('gateway-idempotency', record)
    .then(function () { return record; });
};

GatewayIdempotencyService.prototype.fail = function (record, error) {
  record.status = 'failed';
  record.error = {
    name: error && error.name || 'Error',
    message: error && error.message || String(error)
  };
  record.failedAt = new Date().toISOString();
  record.updatedAt = record.failedAt;
  return this.store.saveResource('gateway-idempotency', record)
    .then(function () { return record; });
};

GatewayIdempotencyService.prototype.load = function (envelope) {
  return this.store.loadResource('gateway-idempotency', this._idFor(envelope));
};

module.exports = GatewayIdempotencyService;
