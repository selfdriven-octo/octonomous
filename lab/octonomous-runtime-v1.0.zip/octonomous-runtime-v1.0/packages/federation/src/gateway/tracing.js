const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value || {}));
}

function GatewayTraceService(options) {
  options = options || {};
  this.store = options.store;
  this.provider = options.provider || null;
  this.log = options.log === undefined ? false : Boolean(options.log);
  this.retentionSeconds = Number(options.retentionSeconds || (7 * 24 * 60 * 60));
}

GatewayTraceService.prototype.start = function (context) {
  const self = this;
  const now = new Date();
  const trace = {
    id: context.traceId || ('gtrace:' + crypto.randomUUID()),
    version: 'octonomous.gateway-trace.v1',
    correlationId: context.correlationId || null,
    envelopeId: context.envelopeId || null,
    direction: context.direction || null,
    peerCommunityId: context.peerCommunityId || null,
    transport: context.transport || null,
    status: 'active',
    startedAt: now.toISOString(),
    spans: [],
    ttlEpochSeconds: Math.floor(now.getTime() / 1000) + self.retentionSeconds
  };
  return self.store.saveResource('gateway-traces', trace)
    .then(function () { return trace; });
};

GatewayTraceService.prototype.record = function (trace, name, attributes) {
  const self = this;
  if (!trace) { return Promise.resolve(null); }
  const span = {
    id: crypto.randomUUID(),
    name: name,
    at: new Date().toISOString(),
    attributes: clone(attributes || {})
  };
  trace.spans.push(span);

  if (self.log) {
    console.log(JSON.stringify({ type: 'octonomous.gateway.trace', traceId: trace.id, span: span }));
  }
  if (self.provider && typeof self.provider.record === 'function') {
    Promise.resolve(self.provider.record({ trace: trace, span: span })).catch(function () {});
  }

  return self.store.saveResource('gateway-traces', trace)
    .then(function () { return span; });
};

GatewayTraceService.prototype.finish = function (trace, status, attributes) {
  const self = this;
  if (!trace) { return Promise.resolve(null); }
  trace.status = status || 'completed';
  trace.finishedAt = new Date().toISOString();
  trace.result = clone(attributes || {});
  return self.store.saveResource('gateway-traces', trace)
    .then(function () {
      if (self.provider && typeof self.provider.finish === 'function') {
        return Promise.resolve(self.provider.finish(trace)).catch(function () {});
      }
    })
    .then(function () { return trace; });
};

GatewayTraceService.prototype.load = function (id) {
  return this.store.loadResource('gateway-traces', id);
};

module.exports = GatewayTraceService;
