# @octonomous/federation

Deterministic, dependency-injected federation protocol and gateway services.

The package has no cognition/LLM dependency. A gateway can verify, deduplicate, route and trace signed federation messages even when cognition is unavailable.
