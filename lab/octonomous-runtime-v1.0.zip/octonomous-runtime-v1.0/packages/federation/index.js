'use strict';
module.exports = {
  protocol: {
    FederationProtocolService: require('./src/federation/protocol'),
    FederationEnvelopeService: require('./src/federation/envelopes'),
    ReplayProtectionService: require('./src/federation/replay-protection'),
    CapabilityDiscoveryService: require('./src/federation/capability-discovery'),
    LocalGovernanceProofService: require('./src/federation/governance-proofs'),
    BftQuorumService: require('./src/federation/bft-quorum')
  },
  society: {
    CommunitySigningService: require('./src/federation/community-signing'),
    CommunityService: require('./src/federation/communities'),
    MembershipService: require('./src/federation/memberships'),
    GovernanceDelegationService: require('./src/federation/governance-delegations'),
    CommunityGovernanceService: require('./src/federation/governance'),
    FederationTrustService: require('./src/federation/trust'),
    TreatyService: require('./src/federation/treaties'),
    FederatedProposalService: require('./src/federation/federated-proposals'),
    FederatedDisputeService: require('./src/federation/disputes'),
    FederationTrustPathService: require('./src/federation/trust-paths'),
    ResourceExchangeService: require('./src/federation/resource-exchange'),
    GroupIdentityService: require('./src/federation/group-identity')
  },
  gateway: {
    PeerRegistryService: require('./src/gateway/peer-registry'),
    IdempotencyService: require('./src/gateway/idempotency'),
    RetryPolicy: require('./src/gateway/retry'),
    DeadLetterService: require('./src/gateway/dead-letter'),
    TraceService: require('./src/gateway/tracing'),
    Router: require('./src/gateway/router'),
    InboundGateway: require('./src/gateway/inbound'),
    OutboundGateway: require('./src/gateway/outbound'),
    TransportRegistry: require('./src/gateway/transports/registry'),
    HttpTransport: require('./src/gateway/transports/http'),
    McpTransport: require('./src/gateway/transports/mcp'),
    DidCommTransport: require('./src/gateway/transports/didcomm')
  }
};
