# Migration: v0.9 -> v1.0

v1.0 is primarily a packaging/specification/conformance release. It intentionally does **not** introduce a new autonomy layer.

## Preserved

- Existing v0.9 `src/` API and reference deployment remain available.
- Wire protocol versions `1.0`, `1.1` and `2.0` remain supported; `2.0` remains preferred.
- Existing object schema identifiers are not silently redefined.

## New

- `@octonomous/runtime` package boundary.
- `@octonomous/federation` package boundary.
- Public OFP 1.0 protocol specification.
- Draft 2020-12 JSON Schemas.
- Conformance vectors/tests.
- Threat model and three security profiles.
- Versioning policy and release checklist.
- Reference deployment directory.

## Suggested migration

1. Keep existing v0.9 imports while upgrading and run the full regression suite.
2. Move application imports to `@octonomous/runtime` and federation imports to `@octonomous/federation` incrementally.
3. Run `npm run conformance` in CI.
4. Declare the deployment security profile in operations/security documentation.
5. Do not change wire-version negotiation solely because package version changed to 1.0.0.
