# Octonomous Federation Protocol (OFP) 1.0

**Software release:** Octonomous Runtime 1.0.0  
**Protocol name on wire:** `octonomous-federation`  
**Preferred wire version:** `2.0`  
**Backward-compatible wire versions:** `1.0`, `1.1`, `2.0`  
**Schema family:** `octonomous.*.v1`

## 1. Scope

OFP defines how independently governed Octonomous communities exchange signed protocol messages without sharing a database, wallet, cognition engine, or execution environment.

The protocol separates four concerns:

1. **Identity** — which community signed an assertion.
2. **Authority** — which local governance process authorised it.
3. **Transport** — how the signed envelope moved between peers.
4. **Execution** — what an external capability/custody system actually did.

A transport MUST NOT infer authority merely because an envelope has a valid signature.

## 2. Federation envelope

A conforming envelope contains:

- `id` — globally unique message identifier.
- `schema` — `octonomous.federation-envelope.v1`.
- `protocol.name` — `octonomous-federation`.
- `protocol.version` — negotiated supported version.
- `messageType` — application protocol event name.
- `senderCommunityId` and `recipientCommunityId`.
- `nonce` — unpredictable replay-prevention value.
- `issuedAt` and `expiresAt`.
- optional correlation/causation identifiers.
- `payload` — immutable signed application payload.
- `receipt` — signature receipt cryptographically bound to the unsigned envelope.

The receiver MUST verify protocol/schema compatibility, recipient binding, timestamps, exact signature binding and replay state before dispatch.

## 3. Replay and idempotency

Nonce claims MUST be atomic per sender/recipient protocol domain. Delivery idempotency MUST key on the envelope identifier (or a cryptographically equivalent stable key). Duplicate accepted delivery returns the prior result and MUST NOT execute the handler again.

Failed processing MAY be retried using the same signed envelope. Retries MUST NOT mutate signed fields.

## 4. Local governance proofs

A federated decision that requires local governance SHOULD carry `octonomous.local-governance-proof.v1`. The proof binds the external authorisation to the exact approved local proposal and signed resolution.

A receiving community MUST NOT treat membership or a community signature alone as evidence that a threshold-governed action was locally approved.

## 5. BFT quorum certificates

The reference BFT evidence layer uses `n >= 3f + 1` participants and `2f + 1` matching distinct signed decisions. It detects conflicting signed decisions from the same community within the same round as equivocation.

This is a quorum/finality evidence protocol, not a complete networking consensus algorithm.

## 6. Treaty versioning

Treaties are immutable once activated. Amendments create a new version linked to the previous digest and require a fresh ratification round. A prior version is superseded only after its successor independently activates.

## 7. Transport independence

HTTP, MCP, DIDComm and queue/event transports MAY carry OFP envelopes. The transport is not part of the signed semantic authority model. Transport-specific metadata MUST NOT change signed envelope semantics.

## 8. Security profiles

Implementations declare one of the profiles in `SECURITY-PROFILES.md`. A production Internet-facing deployment SHOULD meet at least `OFP-GOVERNED-1`.

## 9. Compatibility rules

Software package versions and wire versions are independent. A software update MUST NOT change the meaning of an already-supported wire version. Breaking wire changes require a new protocol version and explicit negotiation.

## 10. Conformance

The reference conformance suite checks:

- package API surface;
- schema presence and valid/invalid vectors;
- envelope signature binding and tamper rejection;
- recipient/timestamp/replay rules;
- protocol negotiation;
- governance-proof binding;
- BFT quorum/equivocation invariants.

Run:

```bash
npm run conformance
```
