# Versioning policy

Octonomous uses three independent version axes:

1. **Software SemVer** — e.g. `@octonomous/runtime@1.0.0`.
2. **Wire protocol version** — e.g. `octonomous-federation/2.0`.
3. **Object schema version** — e.g. `octonomous.federation-envelope.v1`.

A patch/minor software release may add functionality without changing existing wire semantics. A breaking wire change requires a new negotiated wire version. A breaking object-shape change requires a new schema identifier. Receivers should reject unsupported versions instead of guessing.
