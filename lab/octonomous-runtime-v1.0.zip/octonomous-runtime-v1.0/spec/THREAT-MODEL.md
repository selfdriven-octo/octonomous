# Octonomous Runtime v1.0 Threat Model

## Assets

Community signing identity, governance decisions, capability grants, commitments, federation envelopes, peer descriptors, replay/idempotency state, contribution evidence, reputation proofs and external-execution authorisations.

## Trust boundaries

1. LLM/cognition ↔ policy engine.
2. Runtime ↔ tool/capability providers.
3. Community ↔ federation gateway.
4. Gateway ↔ public/untrusted transport.
5. Governance ↔ signing service.
6. Runtime ↔ external custody/treasury systems.

## Primary threats and controls

| Threat | Primary control |
|---|---|
| LLM invents unauthorised action | cognition proposes; deterministic policy authorises |
| Prompt injection causes tool abuse | allowlisted/bounded capabilities; approval/governance gates |
| Envelope payload modified in storage/transit | signature bound to canonical unsigned envelope |
| Signed receipt transplanted to another object | exact subject digest comparison before cryptographic verification |
| Network replay | unpredictable nonce + atomic claim + expiry |
| Duplicate transport execution | persisted idempotency record; return prior result |
| Compromised peer discovery cache | signed descriptor, expiry, verification before persistence |
| Community claims local approval it never received | exact local-governance proof and signed resolution |
| Authority grows through delegation | delegated capability must be equal/narrower and no longer-lived than parent |
| One federation voter votes twice | one decision slot per community; equivocation detection |
| One party self-declares exchange completion | bilateral external settlement evidence |
| Runtime compromise steals treasury keys | payment/custody keys are outside runtime/gateway boundary |
| Mutable reputation score manipulation | derive reputation from signed evidence/proofs |
| Old treaty silently edited | immutable version chain + fresh ratification |

## Residual risks

- A legitimately compromised community signing key can produce valid malicious assertions until revoked/rotated.
- Governance rules can be poorly designed even when correctly executed.
- External tool/custody systems can act incorrectly after receiving valid authorisation.
- Availability attacks can prevent quorum, discovery or message delivery.
- A BFT quorum certificate does not by itself provide a full consensus network or data-availability layer.

## Operational assumptions

System clocks are sufficiently synchronised for envelope expiry checks; persistent stores provide atomic conditional writes where required; production signing keys are not stored as plaintext environment variables; and operators monitor dead letters, replay violations, failed governance proofs and equivocation events.
