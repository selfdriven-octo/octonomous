# OFP 1.0 Security Profiles

## OFP-BASELINE-1

For controlled/private federation links.

- Signed federation envelopes.
- Exact receipt-to-subject binding.
- Recipient and expiry verification.
- Atomic replay protection.
- Idempotent inbound delivery.
- TLS for HTTP transport.
- Secrets excluded from envelope payloads and logs.

## OFP-GOVERNED-1

Recommended minimum for production Internet-facing communities. Includes BASELINE plus:

- Verified peer discovery records with expiry.
- Local-governance proof for constitutionally governed external decisions.
- Persistent audit traces and dead-letter records.
- Key/credential rotation procedure.
- Capability grants bounded by scope, target and expiry.
- Explicit human or threshold approval for high-impact tools.
- External custody: gateway/runtime does not hold treasury/payment keys.

## OFP-HIGH-ASSURANCE-1

For cross-organisational high-consequence federation. Includes GOVERNED plus:

- KERI/group-AID or equivalently managed community signing identity.
- Hardware-backed or isolated signing service.
- BFT quorum certificates for designated federation decisions.
- Independent evidence verification/quorum for material contributions.
- Short-lived envelopes (recommended <= 5 minutes where operationally possible).
- Separate trust domains/accounts for gateway, cognition and custody.
- Immutable/append-only evidence retention and periodic external anchoring.
- Tested recovery, revocation and equivocation response procedures.
