const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const FileStore = require('../src/store/file');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const CommunitySigningService = require('../src/federation/community-signing');
const CommunityService = require('../src/federation/communities');
const FederationProtocolService = require('../src/federation/protocol');
const ReplayProtectionService = require('../src/federation/replay-protection');
const FederationEnvelopeService = require('../src/federation/envelopes');
const FederationCapabilityDiscoveryService = require('../src/federation/capability-discovery');
const PeerRegistryService = require('../src/gateway/peer-registry');
const GatewayIdempotencyService = require('../src/gateway/idempotency');
const RetryPolicy = require('../src/gateway/retry');
const DeadLetterService = require('../src/gateway/dead-letter');
const GatewayTraceService = require('../src/gateway/tracing');
const GatewayRouter = require('../src/gateway/router');
const InboundGateway = require('../src/gateway/inbound');
const OutboundGateway = require('../src/gateway/outbound');
const GatewayTransportRegistry = require('../src/gateway/transports/registry');
const HttpGatewayTransport = require('../src/gateway/transports/http');
const McpGatewayTransport = require('../src/gateway/transports/mcp');
const DidCommGatewayTransport = require('../src/gateway/transports/didcomm');
const ToolRegistry = require('../src/tools');

function createSide(name) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-v09-' + name + '-'));
  const store = new FileStore({ basePath: dir });
  const receipts = new ReceiptService({ signer: new LocalEd25519Signer({ aid: 'did:key:' + name }) });
  const signing = new CommunitySigningService({ receipts: receipts });
  const communities = new CommunityService({ store: store, signing: signing });
  const protocol = new FederationProtocolService({ supportedVersions: ['1.0', '2.0'] });
  const peers = new PeerRegistryService({ store: store, signing: signing, cacheTtlSeconds: 60 });
  const replay = new ReplayProtectionService({ store: store, retentionSeconds: 3600 });
  const envelopes = new FederationEnvelopeService({
    communities: communities,
    signing: signing,
    protocol: protocol,
    replay: replay,
    peers: peers,
    maxLifetimeSeconds: 600,
    clockSkewSeconds: 5
  });
  const discovery = new FederationCapabilityDiscoveryService({ communities: communities, signing: signing, protocol: protocol });
  const idempotency = new GatewayIdempotencyService({ store: store, retentionSeconds: 3600 });
  const traces = new GatewayTraceService({ store: store, log: false });
  const deadLetters = new DeadLetterService({ store: store, retentionSeconds: 3600 });
  const retry = new RetryPolicy({ maxAttempts: 3, baseDelayMs: 0, maxDelayMs: 0, sleep: function () { return Promise.resolve(); } });
  const router = new GatewayRouter();
  const transports = new GatewayTransportRegistry();
  transports.register('http', new HttpGatewayTransport({ timeoutMs: 2000 }));
  const outbound = new OutboundGateway({
    envelopes: envelopes,
    peers: peers,
    transports: transports,
    retry: retry,
    deadLetters: deadLetters,
    traces: traces,
    store: store,
    transportPreference: ['http']
  });

  return {
    name: name,
    dir: dir,
    store: store,
    receipts: receipts,
    signing: signing,
    communities: communities,
    protocol: protocol,
    peers: peers,
    replay: replay,
    envelopes: envelopes,
    discovery: discovery,
    idempotency: idempotency,
    traces: traces,
    deadLetters: deadLetters,
    retry: retry,
    router: router,
    transports: transports,
    outbound: outbound
  };
}

function createCommunity(side, communityId, beingId) {
  return side.communities.create({ being: { id: beingId }, input: { id: communityId, name: communityId } });
}

function publishDescriptor(side, communityId, beingId, endpoints) {
  return side.discovery.publish({
    being: { id: beingId },
    input: {
      communityId: communityId,
      operations: ['federation.gateway', 'federation.proposal'],
      scopes: ['*'],
      endpoints: endpoints || {}
    }
  }).then(function (result) { return result.descriptor; });
}

function registerPeer(side, descriptor) {
  return side.peers.register({ input: { descriptor: descriptor } });
}

function listen(server) {
  return new Promise(function (resolve, reject) {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', function () {
      resolve(server.address());
    });
  });
}

function close(server) {
  return new Promise(function (resolve) { server.close(resolve); });
}

test('peer registry accepts a bound signed discovery descriptor and resolves its transport endpoint', function () {
  const a = createSide('peer-a');
  const b = createSide('peer-b');
  let descriptor;

  return Promise.all([
    createCommunity(a, 'community:a', 'being:a'),
    createCommunity(b, 'community:b', 'being:b')
  ])
    .then(function () {
      return publishDescriptor(b, 'community:b', 'being:b', { http: { url: 'https://b.example/federation' } });
    })
    .then(function (value) {
      descriptor = value;
      return registerPeer(a, descriptor);
    })
    .then(function (registered) {
      assert.equal(registered.peer.communityId, 'community:b');
      return a.peers.resolveEndpoint('community:b', 'http', ['http']);
    })
    .then(function (resolved) {
      assert.equal(resolved.transport, 'http');
      assert.equal(resolved.endpoint.url, 'https://b.example/federation');
      assert.equal(resolved.peer.descriptor.receipt.digest, descriptor.receipt.digest);
    });
});

test('federation envelope can target a verified remote peer without a local community mirror', function () {
  const a = createSide('remote-a');
  const b = createSide('remote-b');

  return Promise.all([
    createCommunity(a, 'community:a', 'being:a'),
    createCommunity(b, 'community:b', 'being:b')
  ])
    .then(function () { return publishDescriptor(b, 'community:b', 'being:b', { http: { url: 'https://b.example/federation' } }); })
    .then(function (descriptor) { return registerPeer(a, descriptor); })
    .then(function () {
      return a.communities.load('community:b');
    })
    .then(function (localMirror) {
      assert.equal(localMirror, null);
      return a.envelopes.create({
        being: { id: 'being:a' },
        input: {
          senderCommunityId: 'community:a',
          recipientCommunityId: 'community:b',
          messageType: 'federation.test',
          payload: { hello: 'world' }
        }
      });
    })
    .then(function (created) {
      assert.equal(created.envelope.recipientCommunityId, 'community:b');
      assert.ok(created.envelope.receipt.signature);
    });
});

test('inbound exact duplicate is verified but routed exactly once and returns cached result', function () {
  const a = createSide('inbound-a');
  const b = createSide('inbound-b');
  let routed = 0;
  let inbound;
  let envelope;

  return Promise.all([
    createCommunity(a, 'community:a', 'being:a'),
    createCommunity(b, 'community:b', 'being:b')
  ])
    .then(function () { return Promise.all([
      publishDescriptor(a, 'community:a', 'being:a', {}),
      publishDescriptor(b, 'community:b', 'being:b', {})
    ]); })
    .then(function (descriptors) {
      return Promise.all([registerPeer(a, descriptors[1]), registerPeer(b, descriptors[0])]);
    })
    .then(function () {
      b.router.register('federation.test', function (context) {
        routed += 1;
        return { ok: true, value: context.envelope.payload.value };
      });
      inbound = new InboundGateway({
        communityId: 'community:b',
        envelopes: b.envelopes,
        idempotency: b.idempotency,
        router: b.router,
        traces: b.traces
      });
      return a.envelopes.create({
        being: { id: 'being:a' },
        input: { senderCommunityId: 'community:a', recipientCommunityId: 'community:b', messageType: 'federation.test', payload: { value: 7 } }
      });
    })
    .then(function (created) {
      envelope = created.envelope;
      return inbound.handle({ envelope: envelope, transport: 'http' });
    })
    .then(function (first) {
      assert.equal(first.duplicate, false);
      assert.equal(first.result.value, 7);
      return inbound.handle({ envelope: envelope, transport: 'http' });
    })
    .then(function (second) {
      assert.equal(second.duplicate, true);
      assert.equal(second.cached, true);
      assert.equal(second.result.value, 7);
      assert.equal(routed, 1);
    });
});

test('inbound processing failure can be retried with the exact same signed envelope', function () {
  const a = createSide('inbound-retry-a');
  const b = createSide('inbound-retry-b');
  let attempts = 0;
  let inbound;
  let envelope;

  return Promise.all([
    createCommunity(a, 'community:a', 'being:a'),
    createCommunity(b, 'community:b', 'being:b')
  ])
    .then(function () { return Promise.all([
      publishDescriptor(a, 'community:a', 'being:a', {}),
      publishDescriptor(b, 'community:b', 'being:b', {})
    ]); })
    .then(function (descriptors) {
      return Promise.all([registerPeer(a, descriptors[1]), registerPeer(b, descriptors[0])]);
    })
    .then(function () {
      b.router.register('federation.retryable', function () {
        attempts += 1;
        if (attempts === 1) {
          throw new Error('temporary processing failure');
        }
        return { ok: true, attempts: attempts };
      });
      inbound = new InboundGateway({
        communityId: 'community:b', envelopes: b.envelopes, idempotency: b.idempotency, router: b.router, traces: b.traces
      });
      return a.envelopes.create({
        being: { id: 'being:a' },
        input: { senderCommunityId: 'community:a', recipientCommunityId: 'community:b', messageType: 'federation.retryable', payload: {} }
      });
    })
    .then(function (created) {
      envelope = created.envelope;
      return assert.rejects(function () { return inbound.handle({ envelope: envelope, transport: 'http' }); }, /temporary processing failure/);
    })
    .then(function () { return inbound.handle({ envelope: envelope, transport: 'http' }); })
    .then(function (retried) {
      assert.equal(retried.result.ok, true);
      assert.equal(retried.result.attempts, 2);
      assert.equal(attempts, 2);
    });
});

test('HTTP transport sends envelope and stable idempotency headers', function () {
  let received;
  const server = http.createServer(function (req, res) {
    let body = '';
    req.on('data', function (chunk) { body += chunk; });
    req.on('end', function () {
      received = { headers: req.headers, body: JSON.parse(body) };
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ accepted: true }));
    });
  });
  const transport = new HttpGatewayTransport({ timeoutMs: 1000 });

  return listen(server)
    .then(function (address) {
      return transport.send({
        endpoint: { url: 'http://127.0.0.1:' + address.port + '/federation' },
        envelope: { id: 'fenv:http-test', payload: {} },
        idempotencyKey: 'delivery:123'
      });
    })
    .then(function (result) {
      assert.equal(result.status, 200);
      assert.equal(received.headers['x-octonomous-idempotency-key'], 'delivery:123');
      assert.equal(received.body.envelope.id, 'fenv:http-test');
    })
    .finally(function () { return close(server); });
});

test('MCP and DIDComm transport adapters preserve the signed envelope boundary', function () {
  const tools = new ToolRegistry();
  let mcpInput;
  let didcommInput;
  tools.register({ name: 'mcp:peer:federation.receive' }, function (input) {
    mcpInput = input;
    return { ok: true, accepted: true };
  });
  const mcp = new McpGatewayTransport({ tools: tools });
  const didcomm = new DidCommGatewayTransport({
    provider: {
      send: function (input) {
        didcommInput = input;
        return { messageId: 'didcomm:1' };
      }
    }
  });
  const envelope = { id: 'fenv:transport', receipt: { signature: { signature: 'x' } } };

  return mcp.send({
    endpoint: { tool: 'mcp:peer:federation.receive' },
    envelope: envelope,
    idempotencyKey: 'idem:1',
    peerCommunityId: 'community:b'
  })
    .then(function (mcpResult) {
      assert.equal(mcpResult.ok, true);
      assert.equal(mcpInput.envelope.id, envelope.id);
      return didcomm.send({
        endpoint: { serviceEndpoint: 'didcomm://peer-b' },
        envelope: envelope,
        idempotencyKey: 'idem:2',
        peerCommunityId: 'community:b'
      });
    })
    .then(function (didcommResult) {
      assert.equal(didcommResult.ok, true);
      assert.equal(didcommInput.envelope.id, envelope.id);
      assert.equal(didcommInput.idempotencyKey, 'idem:2');
    });
});

test('outbound gateway retries retryable failure and completes without duplicating envelope identity', function () {
  const a = createSide('retry-a');
  const b = createSide('retry-b');
  let attempts = 0;
  let envelopeId;
  const fake = {
    send: function (context) {
      attempts += 1;
      envelopeId = envelopeId || context.envelope.id;
      assert.equal(context.envelope.id, envelopeId);
      if (attempts < 3) {
        const error = new Error('temporary');
        error.retryable = true;
        error.status = 503;
        return Promise.reject(error);
      }
      return Promise.resolve({ ok: true, transport: 'fake', accepted: true });
    }
  };
  a.transports.register('fake', fake);
  a.outbound.transportPreference = ['fake'];

  return Promise.all([
    createCommunity(a, 'community:a', 'being:a'),
    createCommunity(b, 'community:b', 'being:b')
  ])
    .then(function () { return publishDescriptor(b, 'community:b', 'being:b', { fake: { name: 'peer-b' } }); })
    .then(function (descriptor) { return registerPeer(a, descriptor); })
    .then(function () {
      return a.outbound.send({
        being: { id: 'being:a' },
        input: { senderCommunityId: 'community:a', recipientCommunityId: 'community:b', messageType: 'federation.test', payload: { x: 1 }, transport: 'fake' },
        transport: 'fake'
      });
    })
    .then(function (result) {
      assert.equal(result.ok, true);
      assert.equal(result.delivery.attempts, 3);
      assert.equal(attempts, 3);
      assert.equal(result.delivery.envelopeId, envelopeId);
    });
});

test('terminal outbound failure persists a dead-letter and trace for later replay/inspection', function () {
  const a = createSide('dlq-a');
  const b = createSide('dlq-b');
  a.transports.register('fail', {
    send: function () {
      const error = new Error('peer unavailable');
      error.retryable = true;
      error.status = 503;
      return Promise.reject(error);
    }
  });
  a.outbound.transportPreference = ['fail'];

  return Promise.all([
    createCommunity(a, 'community:a', 'being:a'),
    createCommunity(b, 'community:b', 'being:b')
  ])
    .then(function () { return publishDescriptor(b, 'community:b', 'being:b', { fail: { name: 'peer-b' } }); })
    .then(function (descriptor) { return registerPeer(a, descriptor); })
    .then(function () {
      return a.outbound.send({
        being: { id: 'being:a' },
        input: { senderCommunityId: 'community:a', recipientCommunityId: 'community:b', messageType: 'federation.test', payload: {}, transport: 'fail' },
        transport: 'fail'
      }).then(function () {
        throw new Error('Expected outbound delivery to fail');
      }, function (error) {
        assert.ok(error.deadLetterId);
        return a.deadLetters.load(error.deadLetterId)
          .then(function (dead) {
            assert.equal(dead.status, 'dead-lettered');
            assert.equal(dead.attempts, 3);
            assert.ok(dead.traceId);
            return a.traces.load(dead.traceId);
          })
          .then(function (trace) {
            assert.equal(trace.status, 'dead-lettered');
            assert.equal(trace.spans.filter(function (span) { return span.name === 'delivery.attempt'; }).length, 3);
          });
      });
    });
});

test('two independent community gateways complete an end-to-end HTTP federation delivery', function () {
  const a = createSide('e2e-a');
  const b = createSide('e2e-b');
  let inbound;
  let server;
  let handled = 0;
  let descriptorA;
  let descriptorB;

  return Promise.all([
    createCommunity(a, 'community:a', 'being:a'),
    createCommunity(b, 'community:b', 'being:b')
  ])
    .then(function () {
      b.router.register('federation.learning.shared', function (context) {
        handled += 1;
        return {
          ok: true,
          accepted: true,
          receivedFrom: context.envelope.senderCommunityId,
          topic: context.envelope.payload.topic
        };
      });
      inbound = new InboundGateway({
        communityId: 'community:b',
        envelopes: b.envelopes,
        idempotency: b.idempotency,
        router: b.router,
        traces: b.traces
      });

      server = http.createServer(function (req, res) {
        let body = '';
        req.on('data', function (chunk) { body += chunk; });
        req.on('end', function () {
          let parsed;
          try { parsed = JSON.parse(body); } catch (error) { parsed = {}; }
          inbound.handle({ envelope: parsed.envelope, transport: 'http', headers: req.headers })
            .then(function (result) {
              res.writeHead(200, { 'content-type': 'application/json' });
              res.end(JSON.stringify({ ok: true, delivery: result }));
            })
            .catch(function (error) {
              res.writeHead(400, { 'content-type': 'application/json' });
              res.end(JSON.stringify({ ok: false, error: error.message }));
            });
        });
      });
      return listen(server);
    })
    .then(function (address) {
      return Promise.all([
        publishDescriptor(a, 'community:a', 'being:a', { http: { url: 'http://127.0.0.1:1/not-used' } }),
        publishDescriptor(b, 'community:b', 'being:b', { http: { url: 'http://127.0.0.1:' + address.port + '/federation' } })
      ]);
    })
    .then(function (descriptors) {
      descriptorA = descriptors[0];
      descriptorB = descriptors[1];
      return Promise.all([registerPeer(a, descriptorB), registerPeer(b, descriptorA)]);
    })
    .then(function () {
      return a.outbound.send({
        being: { id: 'being:a' },
        input: {
          senderCommunityId: 'community:a',
          recipientCommunityId: 'community:b',
          messageType: 'federation.learning.shared',
          payload: { topic: 'durable autonomous beings' },
          transport: 'http'
        },
        transport: 'http'
      });
    })
    .then(function (result) {
      assert.equal(result.ok, true);
      assert.equal(result.response.status, 200);
      assert.equal(result.response.body.delivery.result.topic, 'durable autonomous beings');
      assert.equal(result.response.body.delivery.result.receivedFrom, 'community:a');
      assert.equal(handled, 1);
      assert.ok(result.traceId);
    })
    .finally(function () { return server ? close(server) : null; });
});
