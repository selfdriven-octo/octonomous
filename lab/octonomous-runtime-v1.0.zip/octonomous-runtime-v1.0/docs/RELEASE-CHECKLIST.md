# v1.x release checklist

- [ ] Full legacy test suite passes.
- [ ] OFP conformance suite passes.
- [ ] Package-boundary smoke tests pass on the minimum supported Node version.
- [ ] JSON Schemas remain backward compatible or receive new schema IDs.
- [ ] Existing wire-version semantics are unchanged.
- [ ] Threat model reviewed for changed trust boundaries.
- [ ] Dependency/security audit completed in the release environment.
- [ ] Gateway replay/idempotency tests executed against the production persistence backend.
- [ ] Signing key rotation and revocation procedure tested.
- [ ] Reference deployment exercised between two independent community stores/accounts.
