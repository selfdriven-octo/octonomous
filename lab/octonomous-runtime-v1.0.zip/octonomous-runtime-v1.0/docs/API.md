# v1.0 Public API boundaries

## `@octonomous/runtime`

Stable entry points cover the Being lifecycle, deterministic policy/governance, capabilities, commitments, evidence/receipts, stores and optional cognition adapters.

The runtime package MUST NOT require federation to run a local being.

## `@octonomous/federation`

Stable entry points cover communities, memberships, treaties, federation governance, trust, signed envelopes, replay protection, BFT evidence and gateways/transports.

The federation package MUST NOT require an LLM/cognition engine. All external state/signing/transport concerns are injected.

## Compatibility

Anything under a package's top-level `index.js` is public for the 1.x line. Internal file paths are implementation detail unless explicitly exposed through `exports`.
