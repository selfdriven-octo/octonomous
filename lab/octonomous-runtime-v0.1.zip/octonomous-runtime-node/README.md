# octonomous-runtime

Minimal Node.js implementation of an Octonomous Being runtime.

## Lifecycle

```text
wake
  ↓
observe
  ↓
consider
  ↓
decide
  ↓
govern
  ↓
act
  ↓
reflect
  ↓
remember
  ↓
sleep
```

## Run

```bash
npm start
```

No dependencies are required.

## Design

The runtime deliberately separates:

- Being identity/state
- Cognition
- Governance
- Tools
- Persistence
- Events

The current implementation uses:

- CommonJS
- Promise `.then()`
- JSON file persistence
- A mock cognition adapter
- A simple policy engine
- A simple tool registry

## Next adapters

Recommended next steps:

1. Replace `FileStore` with Dapr actor state or DynamoDB.
2. Replace `MockCognition` with an OpenAI/Claude/local model adapter.
3. Add MCP-backed tools.
4. Add signed event records using KERI/DID credentials.
5. Add durable commitments/reminders.
6. Add EventBridge/SQS event ingestion.
