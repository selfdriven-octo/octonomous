const path = require('path');

const Runtime = require('./src/runtime');
const FileStore = require('./src/file-store');
const Policy = require('./src/policy');
const Tools = require('./src/tools');
const MockCognition = require('./src/cognition/mock');

const store = new FileStore({
  basePath: path.join(__dirname, 'data')
});

const tools = new Tools();

tools.register('log', function (input) {
  console.log('[tool:log]', input);
  return Promise.resolve({
    ok: true,
    output: input
  });
});

tools.register('echo', function (input) {
  return Promise.resolve({
    ok: true,
    output: input
  });
});

const runtime = new Runtime({
  store: store,
  cognition: new MockCognition(),
  policy: new Policy(),
  tools: tools
});

const being = {
  id: 'octo:being:001',

  identity: {
    did: 'did:example:octo-001'
  },

  purpose: [
    'Help the community learn',
    'Create useful, verifiable contributions'
  ],

  character: {
    curious: true,
    caring: true,
    constructive: true,
    chill: true
  },

  authority: {
    allowedTools: ['log', 'echo'],
    requiresApproval: []
  },

  subscriptions: [
    'intent.created',
    'message.received'
  ],

  commitments: [],

  memory: {
    reflections: []
  }
};

runtime.registerBeing(being)
  .then(function () {
    return runtime.emitEvent({
      type: 'intent.created',
      payload: {
        intent: 'Create a short learning summary about durable autonomous agents'
      }
    });
  })
  .then(function (result) {
    console.log('\nResult:\n', JSON.stringify(result, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
