const Being = require('./being');

function Runtime(options) {
  options = options || {};

  this.store = options.store;
  this.cognition = options.cognition;
  this.policy = options.policy;
  this.tools = options.tools;

  this.beings = new Map();
}

Runtime.prototype.registerBeing = function (definition) {
  const self = this;

  const being = new Being({
    definition: definition,
    store: self.store,
    cognition: self.cognition,
    policy: self.policy,
    tools: self.tools
  });

  self.beings.set(definition.id, being);

  return self.store.loadBeing(definition.id)
    .then(function (existing) {
      if (existing) {
        being.definition = existing;
        return existing;
      }

      return self.store.saveBeing(definition)
        .then(function () {
          return definition;
        });
    });
};

Runtime.prototype.emitEvent = function (event) {
  const matches = [];

  this.beings.forEach(function (being) {
    const subscriptions = being.definition.subscriptions || [];

    if (subscriptions.includes(event.type)) {
      matches.push(being.handleEvent(event));
    }
  });

  return Promise.all(matches)
    .then(function (results) {
      return {
        event: event,
        handledBy: results
      };
    });
};

module.exports = Runtime;
