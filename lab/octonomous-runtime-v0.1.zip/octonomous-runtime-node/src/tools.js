function Tools() {
  this.handlers = new Map();
}

Tools.prototype.register = function (name, handler) {
  this.handlers.set(name, handler);
};

Tools.prototype.execute = function (name, input) {
  const handler = this.handlers.get(name);

  if (!handler) {
    return Promise.reject(
      new Error('Unknown tool: ' + name)
    );
  }

  try {
    return Promise.resolve(handler(input));
  }
  catch (error) {
    return Promise.reject(error);
  }
};

module.exports = Tools;
