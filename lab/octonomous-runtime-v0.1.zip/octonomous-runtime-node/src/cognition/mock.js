function MockCognition() {}

MockCognition.prototype.consider = function (context) {
  return Promise.resolve({
    relevant: true,
    reason:
      'The event aligns with the being purpose and can be handled safely.'
  });
};

MockCognition.prototype.decide = function (context) {
  const event = context.event;

  return Promise.resolve({
    rationale:
      'Produce a useful contribution in response to the intent.',
    action: {
      tool: 'log',
      input: {
        message:
          'Handling intent: ' +
          (event.payload.intent || JSON.stringify(event.payload))
      }
    }
  });
};

MockCognition.prototype.reflect = function (context) {
  return Promise.resolve({
    whatHappened:
      'The being received an event, considered it, acted, and recorded the result.',
    whatWasLearned:
      'The wake-observe-consider-decide-govern-act-reflect-sleep loop completed successfully.',
    confidence: 0.95
  });
};

module.exports = MockCognition;
