const fs = require('fs');
const path = require('path');

function FileStore(options) {
  options = options || {};

  this.basePath = options.basePath || path.join(process.cwd(), 'data');

  fs.mkdirSync(this.basePath, {
    recursive: true
  });
}

FileStore.prototype._fileFor = function (id) {
  const safeId = id.replace(/[^a-zA-Z0-9-_]/g, '_');

  return path.join(this.basePath, safeId + '.json');
};

FileStore.prototype.loadBeing = function (id) {
  const filename = this._fileFor(id);

  return fs.promises.readFile(filename, 'utf8')
    .then(function (content) {
      return JSON.parse(content);
    })
    .catch(function (error) {
      if (error.code === 'ENOENT') {
        return null;
      }

      throw error;
    });
};

FileStore.prototype.saveBeing = function (being) {
  const filename = this._fileFor(being.id);
  const content = JSON.stringify(being, null, 2);

  return fs.promises.writeFile(filename, content, 'utf8')
    .then(function () {
      return being;
    });
};

module.exports = FileStore;
