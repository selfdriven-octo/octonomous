function Policy() {}

Policy.prototype.check = function (context) {
  const being = context.being;
  const decision = context.decision || {};
  const action = decision.action;

  if (!action) {
    return {
      allowed: true
    };
  }

  const authority = being.authority || {};
  const allowedTools = authority.allowedTools || [];

  if (!allowedTools.includes(action.tool)) {
    return {
      allowed: false,
      reason: 'Tool not authorised: ' + action.tool
    };
  }

  const requiresApproval = authority.requiresApproval || [];

  if (requiresApproval.includes(action.tool)) {
    return {
      allowed: false,
      reason: 'Human approval required for tool: ' + action.tool
    };
  }

  return {
    allowed: true
  };
};

module.exports = Policy;
