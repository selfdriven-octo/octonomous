function Being(options) {
  options = options || {};

  this.definition = options.definition;
  this.store = options.store;
  this.cognition = options.cognition;
  this.policy = options.policy;
  this.tools = options.tools;
}

Being.prototype.handleEvent = function (event) {
  const self = this;
  const context = {};

  return self.wake(event, context)
    .then(function () {
      return self.observe(event, context);
    })
    .then(function () {
      return self.consider(event, context);
    })
    .then(function () {
      return self.decide(event, context);
    })
    .then(function () {
      return self.govern(event, context);
    })
    .then(function () {
      return self.act(event, context);
    })
    .then(function () {
      return self.reflect(event, context);
    })
    .then(function () {
      return self.remember(event, context);
    })
    .then(function () {
      return self.sleep(event, context);
    })
    .then(function () {
      return {
        beingId: self.definition.id,
        decision: context.decision,
        actionResult: context.actionResult,
        reflection: context.reflection
      };
    });
};

Being.prototype.wake = function (event, context) {
  context.wokeAt = new Date().toISOString();

  return Promise.resolve();
};

Being.prototype.observe = function (event, context) {
  context.observation = {
    event: event,
    being: {
      id: this.definition.id,
      purpose: this.definition.purpose,
      character: this.definition.character,
      commitments: this.definition.commitments || []
    }
  };

  return Promise.resolve();
};

Being.prototype.consider = function (event, context) {
  return this.cognition.consider({
    being: this.definition,
    event: event,
    observation: context.observation
  })
    .then(function (consideration) {
      context.consideration = consideration;
    });
};

Being.prototype.decide = function (event, context) {
  return this.cognition.decide({
    being: this.definition,
    event: event,
    observation: context.observation,
    consideration: context.consideration
  })
    .then(function (decision) {
      context.decision = decision;
    });
};

Being.prototype.govern = function (event, context) {
  const result = this.policy.check({
    being: this.definition,
    decision: context.decision
  });

  context.governance = result;

  if (!result.allowed) {
    throw new Error('Action blocked by policy: ' + result.reason);
  }

  return Promise.resolve();
};

Being.prototype.act = function (event, context) {
  const decision = context.decision || {};

  if (!decision.action) {
    context.actionResult = {
      ok: true,
      skipped: true
    };

    return Promise.resolve();
  }

  return this.tools.execute(
    decision.action.tool,
    decision.action.input
  )
    .then(function (result) {
      context.actionResult = result;
    });
};

Being.prototype.reflect = function (event, context) {
  return this.cognition.reflect({
    being: this.definition,
    event: event,
    decision: context.decision,
    actionResult: context.actionResult
  })
    .then(function (reflection) {
      context.reflection = reflection;
    });
};

Being.prototype.remember = function (event, context) {
  const self = this;

  self.definition.memory = self.definition.memory || {};
  self.definition.memory.reflections =
    self.definition.memory.reflections || [];

  self.definition.memory.reflections.push({
    at: new Date().toISOString(),
    event: event,
    decision: context.decision,
    result: context.actionResult,
    reflection: context.reflection
  });

  return self.store.saveBeing(self.definition);
};

Being.prototype.sleep = function (event, context) {
  context.sleptAt = new Date().toISOString();

  return Promise.resolve();
};

module.exports = Being;
