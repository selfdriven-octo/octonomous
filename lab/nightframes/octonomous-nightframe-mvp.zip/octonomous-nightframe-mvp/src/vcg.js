'use strict';
const { digest, verify } = require('./crypto');

const REQUIRED = ['project.active', 'supplier.approved', 'quote.current', 'budget.available'];
const isoTime = v => typeof v === 'string' && !Number.isNaN(Date.parse(v)) && new Date(v).toISOString() === v;

function verifyContext(claims, trustedSources, now) {
  if (!Array.isArray(claims) || claims.length > 32) return { ok: false, reasons: ['CONTEXT_MALFORMED'] };
  const verified = [];
  const reasons = [];
  for (const claim of claims) {
    if (!claim || claim.schema !== 'octonomous.vcg-claim.v0.1' || typeof claim.topic !== 'string' ||
        !isoTime(claim.issuedAt) || !isoTime(claim.expiresAt) || claim.issuedAt > now || claim.expiresAt <= now ||
        !verify('vcg-claim', claim, trustedSources[claim.issuer])) {
      reasons.push('CLAIM_INVALID');
    } else verified.push(claim);
  }
  for (const topic of REQUIRED) {
    if (verified.filter(c => c.topic === topic).length !== 1) reasons.push(`REQUIRED_CLAIM_NOT_UNIQUE:${topic}`);
  }
  const ok = reasons.length === 0;
  // The root is over the exact signed verified claims (including signers, expiry, and signatures).
  const ordered = verified.slice().sort((a, b) => a.topic < b.topic ? -1 : a.topic > b.topic ? 1 : 0);
  return { ok, reasons, root: digest('vcg-snapshot', ordered), byTopic: Object.fromEntries(verified.map(c => [c.topic, c.value])), verifiedCount: verified.length };
}
module.exports = { verifyContext, REQUIRED };
