'use strict';
const { sign, digest, verify } = require('./crypto');

// Separate, deliberately non-financial actor: it records a simulated order only.
// Production: replace with an independently authenticated, idempotent custody service.
class SimulatedExecutor {
  constructor(privateKey, authorisedControllerKey, clock = () => new Date().toISOString()) {
    this.privateKey = privateKey; this.authorisedControllerKey = authorisedControllerKey;
    this.clock = clock; this.invocations = 0; this.executed = new Map();
  }
  execute(action, signedDecision) {
    if (signedDecision?.outcome !== 'ALLOW' || !verify('vcc-decision',signedDecision,this.authorisedControllerKey) ||
        signedDecision.requestDigest !== digest('action-request',action) || signedDecision.actionId !== action.actionId)
      throw Error('EXECUTION_NOT_AUTHORISED');
    const prior=this.executed.get(action.actionId);
    if(prior) {
      if(prior.requestDigest!==digest('action-request',action)) throw Error('EXECUTOR_ID_COLLISION');
      return prior;
    }
    this.invocations++;
    const receipt = sign('execution-receipt', {
      schema: 'octonomous.execution-receipt.v0.1',
      actionId: action.actionId,
      requestDigest: digest('action-request', action),
      decisionDigest: digest('vcc-decision', signedDecision),
      amountMinor: action.amountMinor,
      currency: action.currency,
      supplierId: action.supplierId,
      status: 'SIMULATED_ONLY',
      remoteOrderReference: `DEMO-${this.invocations}`,
      executedAt: this.clock()
    }, this.privateKey);
    this.executed.set(action.actionId,receipt);
    return receipt;
  }
}
module.exports = { SimulatedExecutor };
