'use strict';
const crypto = require('node:crypto');
const {digest} = require('./crypto');

// Local salted commitment, NOT a Midnight or zero-knowledge proof.
// Keep salt + private fields OFF public ledgers and outside published evidence.
function prepareLocalCommitment({ action, decision }) {
  const salt = crypto.randomBytes(32).toString('hex');
  const privateWitness = { amountMinor: action.amountMinor, supplierId: action.supplierId, salt };
  const publicStatement = {
    schema: 'octonomous.midnight-claim.v0.1',
    commitment: digest('private-purchase', privateWitness),
    decisionDigest: digest('vcc-decision', decision),
    circuitId: null,
    proofStatus: 'NOT_PROVEN',
    txId: null
  };
  return { publicStatement, privateWitness };
}
function verifyLocalCommitment(publicStatement, privateWitness) {
  return publicStatement?.commitment === digest('private-purchase', privateWitness);
}
class MidnightAdapter {
  prove() { throw Error('MIDNIGHT_NOT_CONFIGURED: no Compact circuit, proving key, provider, or wallet is installed'); }
  anchor() { throw Error('MIDNIGHT_NOT_CONFIGURED: no contract deployed or transaction submitted'); }
}
module.exports = { MidnightAdapter, prepareLocalCommitment, verifyLocalCommitment };
