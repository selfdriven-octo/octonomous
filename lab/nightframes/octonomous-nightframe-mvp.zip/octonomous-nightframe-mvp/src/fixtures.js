'use strict';
const crypto = require('node:crypto');
const {keyPair,sign,digest} = require('./crypto');
const {verifyContext} = require('./vcg');
const {CONTROLLER_DIGEST} = require('./engine');
const NOW='2026-10-13T00:00:00.000Z';
const START='2026-10-12T00:00:00.000Z';
const END='2026-10-20T00:00:00.000Z';
function setup() {
  const principal=keyPair(), source=keyPair(), approver=keyPair(), controller=keyPair(), executor=keyPair();
  const principalId='community.example'; const agentId='agent.procurement'; const projectId='education-101';
  const sourceId='community.verified-records';
  const mandate=sign('mandate',{
    schema:'octonomous.mandate.v0.1', mandateId:'mandate-edu-2026', principalId, agentId, projectId,
    currency:'AUD', supplierAllowlist:['supplier.approved'],budgetMinor:80000,perActionLimitMinor:50000,
    approvalThresholdMinor:30000, issuedAt:START,expiresAt:END,controllerDigest:CONTROLLER_DIGEST
  },principal.privateKey);
  function makeClaim(topic,value) {
    return sign('vcg-claim', {schema:'octonomous.vcg-claim.v0.1',topic,value,issuer:sourceId,issuedAt:START,expiresAt:END},source.privateKey);
  }
  function claimsFor({supplierId='supplier.approved',amountMinor=42000,quoteRef='QUOTE-42',availableMinor=80000}={}) {
    return [
      makeClaim('project.active',{projectId,active:true}),
      makeClaim('supplier.approved',{supplierId,approved:true}),
      makeClaim('quote.current',{projectId,supplierId,quoteRef,amountMinor,currency:'AUD'}),
      makeClaim('budget.available',{projectId,availableMinor})
    ];
  }
  function actionFor(claims,overrides={}) {
    return {schema:'octonomous.action.v0.1', actionId:'act-'+crypto.randomUUID(),nonce:crypto.randomBytes(24).toString('hex'),
      principalId,agentId,projectId,capability:'purchase.request',supplierId:'supplier.approved',quoteRef:'QUOTE-42',
      amountMinor:42000,currency:'AUD',contextRoot:verifyContext(claims,{[sourceId]:source.publicKey},NOW).root,
      controllerDigest:CONTROLLER_DIGEST,createdAt:START,expiresAt:END,...overrides};
  }
  function approve(action) {
    return sign('approval',{schema:'octonomous.approval.v0.1',actionDigest:digest('action-request',action),
      mandateId:mandate.mandateId,approverId:'human.approver',approvedAt:START,expiresAt:END},approver.privateKey);
  }
  return {NOW,END,mandate,principal,source,approver,controller,executor,claimsFor,actionFor,approve,
    principalKeys:{[principalId]:principal.publicKey},sourceKeys:{[sourceId]:source.publicKey},
    approverKeys:{'human.approver':approver.publicKey}};
}
module.exports={setup};
