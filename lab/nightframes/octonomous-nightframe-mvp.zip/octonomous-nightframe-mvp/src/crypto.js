'use strict';
const crypto = require('node:crypto');

// Domain-separated deterministic encoding within this small JSON application schema.
// Production wire compatibility would need a formally versioned canonicalisation standard.
function stableJson(value) {
  function convert(x) {
    if (x === null || typeof x === 'boolean' || typeof x === 'string') return x;
    if (typeof x === 'number') {
      if (!Number.isSafeInteger(x)) throw Error('Only safe integer numeric fields are supported');
      return x;
    }
    if (Array.isArray(x)) return x.map(convert);
    if (x && typeof x === 'object' && Object.getPrototypeOf(x) === Object.prototype) {
      return Object.fromEntries(Object.keys(x).sort().map(k => {
        if (x[k] === undefined) throw Error('Undefined values are forbidden in signed objects');
        return [k, convert(x[k])];
      }));
    }
    throw Error('Unsupported value in signed object');
  }
  return JSON.stringify(convert(value));
}
function digest(domain, value) {
  return 'sha256:' + crypto.createHash('sha256').update(`ONI-0.1\0${domain}\0`).update(stableJson(value)).digest('hex');
}
function keyPair() { return crypto.generateKeyPairSync('ed25519', { publicKeyEncoding: {format:'pem', type:'spki'}, privateKeyEncoding: {format:'pem', type:'pkcs8'} }); }
function sign(domain, unsigned, privateKey) {
  const data = Buffer.from(`ONI-0.1\0${domain}\0${stableJson(unsigned)}`);
  return { ...unsigned, signature: crypto.sign(null, data, privateKey).toString('base64') };
}
function verify(domain, signed, publicKey) {
  if (!publicKey || !signed || typeof signed !== 'object' || typeof signed.signature !== 'string') return false;
  const { signature, ...body } = signed;
  try {
    const sig = Buffer.from(signature, 'base64');
    if (sig.length !== 64 || sig.toString('base64') !== signature) return false;
    return crypto.verify(null, Buffer.from(`ONI-0.1\0${domain}\0${stableJson(body)}`), publicKey, sig);
  } catch { return false; }
}
module.exports = { stableJson, digest, keyPair, sign, verify };
