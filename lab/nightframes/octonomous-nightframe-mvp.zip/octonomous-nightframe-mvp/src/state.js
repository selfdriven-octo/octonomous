'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

// Single-host durable demo store. Lock fails CLOSED if the process crashes; operator must
// investigate in-flight records before clearing the lock. NOT a distributed datastore.
class JsonState {
  constructor(dir) { this.dir = dir; fs.mkdirSync(dir, {recursive:true, mode:0o700}); }
  read() {
    try { return JSON.parse(fs.readFileSync(path.join(this.dir, 'state.json'), 'utf8')); }
    catch(e) { if (e.code === 'ENOENT') return {actions:{}, committedMinor:{}, nonces:{}}; throw e; }
  }
  write(s) {
    const filename = path.join(this.dir, 'state.json');
    const temporary = `${filename}.${crypto.randomUUID()}.tmp`;
    try {
      fs.writeFileSync(temporary, JSON.stringify(s, null, 2), {flag:'wx',mode:0o600});
      const fd = fs.openSync(temporary, 'r');
      try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      fs.renameSync(temporary, filename);
      // Directory fsync is available on Unix; not portable on every filesystem.
      try { const dirfd = fs.openSync(this.dir, 'r'); try {fs.fsyncSync(dirfd);}finally{fs.closeSync(dirfd);} } catch {}
    } finally { try { fs.unlinkSync(temporary); } catch {} }
  }
  withLock(fn) {
    const lock = path.join(this.dir, '.lock');
    try { fs.mkdirSync(lock); } catch(e) { if (e.code === 'EEXIST') throw Error('STATE_LOCKED_REQUIRES_RECONCILIATION'); throw e; }
    try { return fn(this.read(), state => this.write(state)); }
    finally { fs.rmdirSync(lock); }
  }
}
module.exports = { JsonState };
