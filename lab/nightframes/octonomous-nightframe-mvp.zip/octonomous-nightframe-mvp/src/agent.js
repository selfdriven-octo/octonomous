'use strict';
const crypto=require('node:crypto');
const {verifyContext}=require('./vcg');
const {CONTROLLER_DIGEST}=require('./engine');

// Composer/musician boundary. This proposal builder deliberately has NO signing keys
// and does not grant authority. Replace with LLM planning only behind the same VCC.
function proposePurchase({ mandate, claims, sourceKeys, now, supplierId, quoteRef }) {
  const context=verifyContext(claims,sourceKeys,now);
  if(!context.ok) throw Error('UNTRUSTED_CONTEXT_FOR_PLANNING');
  const quote=context.byTopic['quote.current'];
  if(!quote || quote.supplierId!==supplierId || quote.quoteRef!==quoteRef) throw Error('QUOTE_NOT_IN_CONTEXT');
  return {
    schema:'octonomous.action.v0.1',actionId:'act-'+crypto.randomUUID(),nonce:crypto.randomBytes(24).toString('hex'),
    principalId:mandate.principalId,agentId:mandate.agentId,projectId:mandate.projectId,
    capability:'purchase.request',supplierId,quoteRef,amountMinor:quote.amountMinor,currency:quote.currency,
    contextRoot:context.root,controllerDigest:CONTROLLER_DIGEST,createdAt:now,expiresAt:mandate.expiresAt
  };
}
module.exports={proposePurchase};
