'use strict';
const fs = require('node:fs');
const crypto = require('node:crypto');
const { digest, sign, verify } = require('./crypto');
const { verifyContext } = require('./vcg');
const { prepareLocalCommitment } = require('./midnight');

const CONTROLLER_DIGEST = 'sha256:' + crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex');
const isMoney = n => Number.isSafeInteger(n) && n >= 0;
const isIso = s => typeof s === 'string' && !Number.isNaN(Date.parse(s)) && new Date(s).toISOString() === s;
function allowedFields(obj, fields) { return !!obj && typeof obj === 'object' && !Array.isArray(obj) && Object.keys(obj).every(k=>fields.includes(k)); }
const MANDATE_FIELDS = ['schema','mandateId','principalId','agentId','projectId','currency','supplierAllowlist','budgetMinor','perActionLimitMinor','approvalThresholdMinor','issuedAt','expiresAt','controllerDigest','signature'];
const ACTION_FIELDS = ['schema','actionId','nonce','principalId','agentId','projectId','capability','supplierId','quoteRef','amountMinor','currency','contextRoot','controllerDigest','createdAt','expiresAt'];
const APPROVAL_FIELDS = ['schema','actionDigest','mandateId','approverId','approvedAt','expiresAt','signature'];

function checkShape(action, mandate, now) {
  if (!allowedFields(action,ACTION_FIELDS) || action.schema !== 'octonomous.action.v0.1' ||
     !/^[A-Za-z0-9_-]{8,80}$/.test(action.actionId || '') ||
     !/^[a-f0-9]{32,}$/.test(action.nonce || '') ||
     !['purchase.request'].includes(action.capability) ||
     !isMoney(action.amountMinor) || action.amountMinor === 0 || action.currency !== 'AUD' ||
     !isIso(action.createdAt) || !isIso(action.expiresAt) || action.createdAt > now || action.expiresAt <= now ||
     ![action.principalId,action.agentId,action.projectId,action.supplierId,action.quoteRef,action.contextRoot].every(x=>typeof x==='string' && x.length>0)) return 'ACTION_MALFORMED_OR_EXPIRED';
  if (!allowedFields(mandate,MANDATE_FIELDS) || mandate.schema !== 'octonomous.mandate.v0.1' ||
     !isIso(mandate.issuedAt) || !isIso(mandate.expiresAt) || mandate.issuedAt > now || mandate.expiresAt <= now ||
     !['budgetMinor','perActionLimitMinor','approvalThresholdMinor'].every(k=>isMoney(mandate[k])) ||
     !Array.isArray(mandate.supplierAllowlist) || mandate.supplierAllowlist.length === 0 || mandate.supplierAllowlist.length > 50 ||
     !mandate.supplierAllowlist.every(s=>typeof s==='string' && s.length>0)) return 'MANDATE_MALFORMED_OR_EXPIRED';
  return null;
}
class PurchaseController {
  constructor({ principalKeys, sourceKeys, approverKeys, controllerKey, state, executor, clock=()=>new Date().toISOString() }) {
    this.principalKeys=principalKeys; this.sourceKeys=sourceKeys; this.approverKeys=approverKeys;
    this.controllerKey=controllerKey; this.state=state; this.executor=executor; this.clock=clock;
  }
  decision(action, outcome, reasons, mandate, context) {
    return sign('vcc-decision', {
      schema: 'octonomous.vcc-decision.v0.1', actionId: action?.actionId || 'unknown',
      requestDigest: digest('action-request', action),
      mandateDigest: digest('mandate-record', mandate), contextRoot: context?.root || null,
      controllerDigest: CONTROLLER_DIGEST, outcome, reasons, decidedAt:this.clock()
    }, this.controllerKey);
  }
  evaluate(action, mandate, claims, approvals=[], state={committedMinor:{}}) {
    const now=this.clock();
    const fail=(outcome,reason,ctx)=>({ outcome, decision:this.decision(action,outcome,[reason],mandate,ctx), context:ctx });
    let shape;
    try { shape=checkShape(action,mandate,now); } catch { shape='MALFORMED_OBJECT'; }
    if (shape) return fail('DENY',shape);
    if (!verify('mandate',mandate,this.principalKeys[mandate.principalId])) return fail('DENY','MANDATE_SIGNATURE_INVALID');
    if (mandate.principalId !== action.principalId || mandate.agentId !== action.agentId || mandate.projectId !== action.projectId ||
        mandate.currency !== action.currency || mandate.controllerDigest !== CONTROLLER_DIGEST ||
        action.controllerDigest !== CONTROLLER_DIGEST || action.expiresAt > mandate.expiresAt) return fail('DENY','MANDATE_SCOPE_MISMATCH');
    if (!mandate.supplierAllowlist.includes(action.supplierId)) return fail('DENY','SUPPLIER_NOT_AUTHORISED');
    if (action.amountMinor > mandate.perActionLimitMinor) return fail('DENY','PER_ACTION_LIMIT_EXCEEDED');
    const context=verifyContext(claims,this.sourceKeys,now);
    if (!context.ok) return fail('DENY','CONTEXT_UNVERIFIED',context);
    if (action.contextRoot !== context.root) return fail('DENY','CONTEXT_ROOT_MISMATCH',context);
    const project=context.byTopic['project.active'];
    const supplier=context.byTopic['supplier.approved'];
    const quote=context.byTopic['quote.current'];
    const budget=context.byTopic['budget.available'];
    if (!project || project.projectId!==action.projectId || project.active!==true ||
        !supplier || supplier.supplierId!==action.supplierId || supplier.approved!==true ||
        !quote || quote.projectId!==action.projectId || quote.supplierId!==action.supplierId ||
           quote.quoteRef!==action.quoteRef || quote.currency!==action.currency || quote.amountMinor!==action.amountMinor ||
        !budget || budget.projectId!==action.projectId || !isMoney(budget.availableMinor)) return fail('DENY','CONTEXT_CONTRADICTS_ACTION',context);
    const spent=state.committedMinor?.[mandate.mandateId] || 0;
    if (!isMoney(spent) || !Number.isSafeInteger(spent+action.amountMinor)) return fail('DENY','BUDGET_ACCOUNTING_INVALID',context);
    if (spent+action.amountMinor>mandate.budgetMinor || action.amountMinor>budget.availableMinor) return fail('DENY','BUDGET_EXCEEDED',context);
    if (action.amountMinor>mandate.approvalThresholdMinor) {
      const actionDigest=digest('action-request',action);
      const valid=(Array.isArray(approvals)?approvals:[]).filter(a=>
        allowedFields(a,APPROVAL_FIELDS) && a.schema==='octonomous.approval.v0.1' &&
        a.actionDigest===actionDigest && a.mandateId===mandate.mandateId &&
        isIso(a.approvedAt) && isIso(a.expiresAt) && a.approvedAt<=now && a.expiresAt>now &&
        verify('approval',a,this.approverKeys[a.approverId]));
      if (valid.length<1) return fail('ESCALATE','HUMAN_APPROVAL_REQUIRED',context);
    }
    return fail('ALLOW','POLICY_SATISFIED',context);
  }
  submit(action,mandate,claims,approvals=[]) {
    return this.state.withLock((state,save) => {
      const actionDigest=digest('action-request',action);
      const prior=state.actions[action?.actionId];
      if(prior) {
        if(prior.actionDigest!==actionDigest) return {outcome:'DENY', reason:'ACTION_ID_COLLISION'};
        return {outcome:prior.status==='EXECUTED'?'ALLOW':'ESCALATE', reason:'IDEMPOTENT_REPLAY', record:prior};
      }
      const nonceKey=digest('nonce-namespace',{principalId:action.principalId,agentId:action.agentId,nonce:action.nonce});
      if(state.nonces?.[nonceKey]) return {outcome:'DENY',reason:'NONCE_REUSED'};
      const evaluated=this.evaluate(action,mandate,claims,approvals,state);
      if(evaluated.outcome!=='ALLOW') return {outcome:evaluated.outcome, decision:evaluated.decision};
      const record={actionDigest, mandateId:mandate.mandateId, status:'PENDING', amountMinor:action.amountMinor,
        decision:evaluated.decision, reservedAt:this.clock(), execution:null, commitment:null};
      // Durable reservation before any external side effect. Unknown outcomes remain reserved.
      state.actions[action.actionId]=record;
      state.nonces = state.nonces || {};
      state.nonces[nonceKey]=action.actionId;
      state.committedMinor[mandate.mandateId]=(state.committedMinor[mandate.mandateId]||0)+action.amountMinor;
      save(state);
      try {
        const receipt=this.executor.execute(action,evaluated.decision);
        if (receipt?.status!=='SIMULATED_ONLY') throw Error('UNRECOGNISED_EXECUTOR_RECEIPT');
        record.execution=receipt;
        record.status='EXECUTED';
        const proof=prepareLocalCommitment({action,decision:evaluated.decision});
        record.commitment=proof.publicStatement;
        // The private witness is deliberately not placed in the result or the state file.
        save(state);
        return {outcome:'ALLOW', decision:evaluated.decision, execution:receipt, commitment:record.commitment};
      } catch(error) {
        record.status='RECONCILIATION_REQUIRED';
        record.failureReason=String(error?.message||error).slice(0,140);
        save(state);
        return {outcome:'ESCALATE',reason:'EXECUTION_OUTCOME_UNKNOWN',record};
      }
    });
  }
}
module.exports={PurchaseController,CONTROLLER_DIGEST};
