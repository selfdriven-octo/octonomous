'use strict';
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
const { setup } = require('./src/fixtures');
const { PurchaseController } = require('./src/engine');
const { SimulatedExecutor } = require('./src/executor');
const { JsonState } = require('./src/state');
const { verify } = require('./src/crypto');
const { proposePurchase } = require('./src/agent');

const f=setup();
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'oni-mvp-'));
const executor=new SimulatedExecutor(f.executor.privateKey,f.controller.publicKey,()=>f.NOW);
const engine=new PurchaseController({principalKeys:f.principalKeys,sourceKeys:f.sourceKeys,
  approverKeys:f.approverKeys,controllerKey:f.controller.privateKey,state:new JsonState(dir),
  executor,clock:()=>f.NOW});
const claims=f.claimsFor();
const action=proposePurchase({mandate:f.mandate,claims,sourceKeys:f.sourceKeys,now:f.NOW,supplierId:'supplier.approved',quoteRef:'QUOTE-42'});
const escalated=engine.submit(action,f.mandate,claims);
const allowed=engine.submit(action,f.mandate,claims,[f.approve(action)]);
const replay=engine.submit(action,f.mandate,claims,[f.approve(action)]);
const maliciousAction=f.actionFor(claims,{amountMinor:60000});
const denied=engine.submit(maliciousAction,f.mandate,claims);
const output={
  demonstration:'SIMULATION; NO FUNDS, NO MIDNIGHT TRANSACTION',
  scenario:'community education materials purchase of AUD 420',
  firstRequest:escalated.outcome+' ('+escalated.decision.reasons.join(',')+')',
  withHumanApproval:allowed.outcome+' ('+allowed.execution.status+')',
  authorisedDecisionSignatureValid:verify('vcc-decision',allowed.decision,f.controller.publicKey),
  executionReceiptSignatureValid:verify('execution-receipt',allowed.execution,f.executor.publicKey),
  replay:replay.reason,executorCalls:executor.invocations,
  overLimit:denied.outcome+' ('+denied.decision.reasons.join(',')+')',
  privacyStatement:allowed.commitment.proofStatus,
  publicCommitment:allowed.commitment.commitment,
  localStateDirectory:dir
};
console.log(JSON.stringify(output,null,2));
