'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {setup}=require('../src/fixtures');
const {PurchaseController,CONTROLLER_DIGEST}=require('../src/engine');
const {SimulatedExecutor}=require('../src/executor');
const {JsonState}=require('../src/state');
const {verify,sign,digest}=require('../src/crypto');
const {verifyContext}=require('../src/vcg');
const {MidnightAdapter,prepareLocalCommitment,verifyLocalCommitment}=require('../src/midnight');

function harness() {
  const f=setup();
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'oni-test-'));
  const executor=new SimulatedExecutor(f.executor.privateKey,f.controller.publicKey,()=>f.NOW);
  const state=new JsonState(dir);
  const controller=new PurchaseController({principalKeys:f.principalKeys,sourceKeys:f.sourceKeys,
    approverKeys:f.approverKeys,controllerKey:f.controller.privateKey,state,executor,clock:()=>f.NOW});
  return {...f,controllerSigner:f.controller,executorSigner:f.executor,dir,executor,state,controller};
}
function signedQuote(f,claim,patch) {
  const {signature,...unsigned}=claim;
  return sign('vcg-claim',{...unsigned,value:{...unsigned.value,...patch}},f.source.privateKey);
}
function expectDecision(out,kind,reason) {
  assert.equal(out.outcome,kind); assert.ok(out.decision?.reasons.includes(reason),JSON.stringify(out));
}

test('needs human approval above threshold then executes once with verifiable receipts',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  expectDecision(f.controller.submit(action,f.mandate,claims),'ESCALATE','HUMAN_APPROVAL_REQUIRED');
  const out=f.controller.submit(action,f.mandate,claims,[f.approve(action)]);
  assert.equal(out.outcome,'ALLOW'); assert.equal(out.execution.status,'SIMULATED_ONLY');
  assert.ok(verify('vcc-decision',out.decision,f.controllerSigner.publicKey));
  assert.ok(verify('execution-receipt',out.execution,f.executorSigner.publicKey));
  assert.equal(out.commitment.proofStatus,'NOT_PROVEN');
  assert.equal(f.controller.submit(action,f.mandate,claims,[f.approve(action)]).reason,'IDEMPOTENT_REPLAY');
  assert.equal(f.executor.invocations,1);
  assert.equal(f.state.read().committedMinor[f.mandate.mandateId],42000);
});
test('amount above per-action limit denied even with approval',()=>{
  const f=harness(), claims=f.claimsFor({amountMinor:60000}), action=f.actionFor(claims,{amountMinor:60000});
  expectDecision(f.controller.submit(action,f.mandate,claims,[f.approve(action)]),'DENY','PER_ACTION_LIMIT_EXCEEDED');
});
test('unauthorised supplier denied',()=>{
  const f=harness(),claims=f.claimsFor({supplierId:'supplier.bad'}), action=f.actionFor(claims,{supplierId:'supplier.bad'});
  expectDecision(f.controller.submit(action,f.mandate,claims),'DENY','SUPPLIER_NOT_AUTHORISED');
});
test('quote amount does not match action',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims,{amountMinor:29000});
  expectDecision(f.controller.submit(action,f.mandate,claims),'DENY','CONTEXT_CONTRADICTS_ACTION');
});
test('tampered signed quote fails context validation',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  claims[2].value.amountMinor=39000;
  expectDecision(f.controller.submit(action,f.mandate,claims),'DENY','CONTEXT_UNVERIFIED');
});
test('expired context claim is not silently accepted',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  const {signature,...unsigned}=claims[2];
  claims[2]=sign('vcg-claim',{...unsigned,expiresAt:'2026-10-12T12:00:00.000Z'},f.source.privateKey);
  expectDecision(f.controller.submit(action,f.mandate,claims),'DENY','CONTEXT_UNVERIFIED');
});
test('root mismatch rejects alternate valid context',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  claims[2]=signedQuote(f,claims[2],{amountMinor:39000});
  expectDecision(f.controller.submit(action,f.mandate,claims),'DENY','CONTEXT_ROOT_MISMATCH');
});
test('duplicate critical evidence fails closed',()=>{
  const f=harness(),claims=f.claimsFor();
  const action=f.actionFor(claims);claims.push(claims[2]);
  expectDecision(f.controller.submit(action,f.mandate,claims),'DENY','CONTEXT_UNVERIFIED');
});
test('tampered mandate signature denied',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  const bad={...f.mandate,budgetMinor:9000000};
  expectDecision(f.controller.submit(action,bad,claims),'DENY','MANDATE_SIGNATURE_INVALID');
});
test('controller/source version mismatch denied',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims,{controllerDigest:'sha256:wrong'});
  expectDecision(f.controller.submit(action,f.mandate,claims),'DENY','MANDATE_SCOPE_MISMATCH');
});
test('human approval must match exact signed action digest',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  const approval=f.approve({...action,amountMinor:1000});
  expectDecision(f.controller.submit(action,f.mandate,claims,[approval]),'ESCALATE','HUMAN_APPROVAL_REQUIRED');
});
test('budget is reserved durably and cannot be double spent across action IDs',()=>{
  const f=harness(),claims=f.claimsFor(),a1=f.actionFor(claims),a2=f.actionFor(claims);
  assert.equal(f.controller.submit(a1,f.mandate,claims,[f.approve(a1)]).outcome,'ALLOW');
  expectDecision(f.controller.submit(a2,f.mandate,claims,[f.approve(a2)]),'DENY','BUDGET_EXCEEDED');
  assert.equal(f.executor.invocations,1);
});
test('id collision rejected without second effect',()=>{
  const f=harness(),claims=f.claimsFor(),a1=f.actionFor(claims),a2={...a1,amountMinor:200};
  f.controller.submit(a1,f.mandate,claims,[f.approve(a1)]);
  const out=f.controller.submit(a2,f.mandate,claims,[f.approve(a2)]);
  assert.equal(out.reason,'ACTION_ID_COLLISION'); assert.equal(f.executor.invocations,1);
});
test('nonce reuse under a distinct action ID denied',()=>{
  const f=harness(),claims=f.claimsFor(),a1=f.actionFor(claims),a2=f.actionFor(claims,{nonce:a1.nonce});
  assert.equal(f.controller.submit(a1,f.mandate,claims,[f.approve(a1)]).outcome,'ALLOW');
  assert.equal(f.controller.submit(a2,f.mandate,claims,[f.approve(a2)]).reason,'NONCE_REUSED');
  assert.equal(f.executor.invocations,1);
});
test('executor rejects direct untrusted/model instruction',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  assert.throws(()=>f.executor.execute(action,{outcome:'ALLOW',requestDigest:digest('action-request',action)}),/EXECUTION_NOT_AUTHORISED/);
  assert.equal(f.executor.invocations,0);
});
test('executor verifies action digest even with a legitimate signed allow',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  const decision=f.controller.decision(action,'ALLOW',['POLICY_SATISFIED'],f.mandate,{root:action.contextRoot});
  assert.throws(()=>f.executor.execute({...action,amountMinor:1},decision),/EXECUTION_NOT_AUTHORISED/);
});
test('a simulated executor failure reserves spend and demands reconciliation',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  f.controller.executor={execute(){throw Error('NETWORK_TIMEOUT');}};
  const out=f.controller.submit(action,f.mandate,claims,[f.approve(action)]);
  assert.equal(out.reason,'EXECUTION_OUTCOME_UNKNOWN');
  assert.equal(f.state.read().actions[action.actionId].status,'RECONCILIATION_REQUIRED');
  assert.equal(f.state.read().committedMinor[f.mandate.mandateId],42000);
  assert.equal(f.controller.submit(action,f.mandate,claims,[f.approve(action)]).reason,'IDEMPOTENT_REPLAY');
});
test('salted commitment is NOT a ZK proof and does not publish private witness',()=>{
  const f=harness(),claims=f.claimsFor(),action=f.actionFor(claims);
  const decision=f.controller.decision(action,'ALLOW',['POLICY_SATISFIED'],f.mandate,{root:action.contextRoot});
  const p=prepareLocalCommitment({action,decision});
  assert.ok(verifyLocalCommitment(p.publicStatement,p.privateWitness));
  assert.equal(p.publicStatement.proofStatus,'NOT_PROVEN');
  assert.ok(!JSON.stringify(p.publicStatement).includes(p.privateWitness.salt));
  assert.throws(()=>new MidnightAdapter().prove(),/MIDNIGHT_NOT_CONFIGURED/);
});
test('well-formed lower-risk authorised action skips approval',()=>{
  const f=harness(),claims=f.claimsFor({amountMinor:25000}),action=f.actionFor(claims,{amountMinor:25000});
  const out=f.controller.submit(action,f.mandate,claims);
  assert.equal(out.outcome,'ALLOW'); assert.equal(out.execution.amountMinor,25000);
});
test('trusted source signature can be verified independently',()=>{
  const f=harness(),claims=f.claimsFor();
  assert.equal(verifyContext(claims,f.sourceKeys,f.NOW).verifiedCount,4);
  assert.match(CONTROLLER_DIGEST,/^sha256:[a-f0-9]{64}$/);
});
