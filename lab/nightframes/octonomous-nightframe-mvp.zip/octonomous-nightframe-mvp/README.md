# Octonomous × Midnight/Nightframes — Purchasing Agent MVP

**v0.1 · 13 October 2026 · Reference prototype — NOT FOR FINANCIAL USE**

This is a runnable **Node.js/CommonJS**, zero-dependency proof of concept for **Octonomous Nightframe Integration (ONI)**. It implements the first proposed phase of the *Nightframes × Octonomous* architecture paper: **verified context → deterministic control → separately authenticated simulated execution → signed evidence → optional Midnight adapter boundary**.

**What it does:** A community education agent wants to purchase AUD 420 of materials. Its governing community has issued a signed mandate with an AUD 800 total budget, AUD 500 per-action maximum, an approved supplier list, and a human-approval threshold above AUD 300. Evidence comes from signed, expiry-bounded VCG claims. The agent can propose actions but **cannot authorise them**. The controller enforces exact signed policy and the executor checks the controller's signature.

**What it explicitly does NOT do:** Move money; run an LLM; host a confidential enclave; deploy a smart contract; generate a zero-knowledge proof; connect to Midnight; run a Nightframe; or demonstrate production security. The local commitment is **not a ZK proof**. Nightframe is treated as a potential future execution host, not an existing stable API.

## Run it

Requires Node.js 20+; validated against Node.js 22.16.0. No `npm install` necessary.

```sh
unzip octonomous-nightframe-mvp.zip
cd octonomous-nightframe-mvp
npm run demo
npm test
```

The test suite covers allowed, denied and escalated transactions, signed mandates and claims, approval bindings, budget reservations, replay and nonce reuse, context conflicts, executor bypass attempts, failed execution reconciliation and the non-ZK Midnight adapter.

Example output (commitment and temp path vary each time):

```json
{
  "firstRequest": "ESCALATE (HUMAN_APPROVAL_REQUIRED)",
  "withHumanApproval": "ALLOW (SIMULATED_ONLY)",
  "authorisedDecisionSignatureValid": true,
  "executionReceiptSignatureValid": true,
  "replay": "IDEMPOTENT_REPLAY",
  "executorCalls": 1,
  "overLimit": "DENY (PER_ACTION_LIMIT_EXCEEDED)",
  "privacyStatement": "NOT_PROVEN"
}
```

## Architecture

```mermaid
flowchart TD
  P[Principal / governed community] -->|Ed25519 signed mandate| V[VCC: verified code controller]
  E[Signed evidence / context claims] --> C[VCG snapshot verification]
  C -->|snapshot digest + claims| V
  A[Untrusted planner or LLM] -->|action proposal| V
  H[Independent human approver] -->|action-bound approval| V
  V -->|signed ALLOW only| X[Simulated Executor: no money]
  X -->|signed receipt| R[Local reservation & evidence]
  R --> M[Midnight adapter: NOT CONFIGURED]
  M -.-> N[Future Compact circuit / proof server]
```

**Authority boundary:** The model/planner never holds principal, controller or payment/custody signing keys. In this small teaching repo, demo keys are generated in the same process and **are not isolated**; the diagram represents the intended production trust separation, not current process isolation.

### Main files

| File | Responsibility |
|---|---|
| `src/agent.js` | Untrusted Composer/proposal builder without issuer or payment keys |
| `src/crypto.js` | Ed25519 signing, strict JSON encoding, domain-separated SHA-256 digests |
| `src/vcg.js` | Evidence signature, expiry, required-claim uniqueness and snapshot root |
| `src/engine.js` | Deterministic VCC with signed decisions, approvals, target and spend limits |
| `src/state.js` | Local lock, durable budget/nonce reservation, idempotency journal |
| `src/executor.js` | Separately authenticated **simulated** execution, signed receipt |
| `src/midnight.js` | Salted **local** commitment and explicit unconfigured proof/anchor methods |
| `src/fixtures.js` | Ephemeral demonstration identities and signed fixtures |
| `demo.js` | Worked example |
| `test/purchasing.test.js` | Adversarial regression suite |
| `docs/ORIGINAL-ARCHITECTURE-PAPER.md` | Earlier ONI architecture paper for reference |
| `docs/MIDNIGHT-INTEGRATION.md` | Narrow ZK contract specification and real integration requirements |
| `docs/THREAT-MODEL.md` | Trust assumptions, residual risk and production gaps |

### Exact demo sequence

1. Community issues an Ed25519-signed mandate binding agent, project, supplier allowlist, limits, currency, times and controller-source digest.
2. Trusted source signs four claims: project active, supplier approved, quote current, budget available.
3. Context validator rejects tampering, expiry, missing or duplicate critical claims, and returns a snapshot digest.
4. An untrusted Composer agent proposes an AUD 420 request that binds the exact context snapshot.
5. Controller checks all invariants; price above AUD 300 requires exact-action human approval → **ESCALATE**.
6. Approver signs the action digest; the same proposed action is reevaluated → **ALLOW**.
7. State manager atomically reserves amount and nonce before invoking a simulated executor.
8. Executor checks the controller's Ed25519 signature and action digest, then issues a signed `SIMULATED_ONLY` receipt.
9. Result contains a salted SHA-256 local commitment with `proofStatus=NOT_PROVEN`; it does **not** claim a ZK proof or on-chain transaction.
10. Replay of the same action returns the prior record and does not execute again.

## Design constraints and known limitations

- **Single-host only.** The JSON store uses a directory lock for one machine and is not a distributed, transactional database. After power loss, an orphan lock and `PENDING`/`RECONCILIATION_REQUIRED` record require operator investigation; **never blindly delete and replay**.
- **No real custody.** Executor is deliberately non-financial and only checks a decision signature/action digest. A production executor needs separate identity, a durable provider-side idempotency key, action expiry and revocation checks, settlement confirmation, and reconciled custody.
- **No independently trusted signing service.** Fixture keys exist in the same Node.js process. A compromised process can control those demonstration keys. Production requires separate signers and a real authorisation policy.
- **No live source trust.** The fixture generates all four VCG topics from one ephemeral source. Production must define topic-specific issuers, object schemas, conflict resolution, independent quote/price verification and data freshness SLAs.
- **Budget scope.** Demo budget is keyed to a single mandate ID. It does not prevent overlapping mandates from spending the same underlying external account/project balance.
- **No revocation feed.** Expiry is checked, but real-time grant revocation and global kill switches are still unimplemented.
- **Canonicalisation.** Signature encoding is a small project-specific JSON format, **not** RFC 8785 JCS or OFP's wire encoding. Interoperability needs a reviewed canonical schema.
- **Privacy.** Commitment uses a fresh random 256-bit salt but that salt is not persisted by this MVP, so its commitment cannot later be opened once memory is lost. Design an encrypted private witness store before using commitments in a real proof flow. Signed decision receipts and local state also contain data that should be selectively disclosed, never blindly published.
- **Not OFP-compatible yet.** This is an ONI application-level prototype inspired by OFP 1.0, not its signed federation envelope implementation.
- **No Midnight integration.** `MidnightAdapter.prove()` and `.anchor()` explicitly throw `MIDNIGHT_NOT_CONFIGURED`. Do not mistake `proofStatus: NOT_PROVEN` for on-chain validity.

## What to build next

Phase 1 should integrate a version-pinned Compact contract and local proof server; Phase 2 should isolate the executor and signing services behind authenticated service boundaries; Phase 3 should use real OFP federation envelopes and governance proofs; Phase 4 should add operational assurance, revocation and independent security testing.

See `docs/MIDNIGHT-INTEGRATION.md` for the proof statement and component contract.

## External technical basis

- Midnight private smart contract guide: https://docs.midnight.network/guides/build-a-private-smart-contract
- Midnight Compact toolchain: https://docs.midnight.network/getting-started/installation
- Midnight witnesses: https://docs.midnight.network/guides/private-state-witnesses
- Midnight provider architecture: https://docs.midnight.network/guides/deploy-and-operate
- Midnight API reference: https://docs.midnight.network/api-reference

Octonomous design basis: `PROTOCOL.md` (OFP 1.0), `THREAT-MODEL.md`, `SECURITY-PROFILES.md`, and *Nightframes × Octonomous* v0.1 (12 Oct 2026).
