# Midnight Proof Adapter — Implementation Specification (Proposed)

**Status:** Design contract only. This repository **does not** generate a Midnight proof, compile Compact, hold a Midnight wallet, transact on-chain or execute a Nightframe.

## Why keep Midnight optional?

The essential purchase policy must be secure even when blockchain tooling is unavailable. Midnight brings selective disclosure for specific, encoded predicates. It cannot establish that an AI made an optimal purchase or that an external supplier actually delivered goods.

## Candidate Phase 1 proof

Prove: **“This purchase's private amount is positive, at most the private per-action authorised limit, and committed under the same controller action binding and policy version.”**

Proposed inputs, **not official Midnight types**:

| Inputs | Public / private | Reason |
|---|---|---|
| Circuit ID / verifying key digest | Public | Prevent circuit substitution |
| Controller version hash | Public | Bind to governance policy |
| Public mandate commitment | Public | Bind authorisation semantics |
| Action commitment | Public | Bind exact proposed action |
| Nullifier/action nonce commitment | Public | Prevent duplicate proof acceptance |
| Amount (integer minor units AUD) | Private witness | Hide purchase amount |
| Per-action spending limit | Private witness | Hide mandate-specific limit |
| Random commitment openings | Private witness | Prevent brute-force amount inference |
| Mandate authorisation evidence | Private witness / verified outside circuit | Exact issuer/approval must be verified, not assumed |

**Crucial:** Proving `amount <= limit` is meaningless if the prover can invent the limit. The circuit must verify a signature/commitment or reference an on-chain trusted mandate record; do not make the limit a free, unauthenticated private witness. The circuit should reject zero amounts, enforce range and prevent arithmetic overflow. Amount units, canonical action encoding, commitment algebra, nullifier semantics and policy version must be formalised and independently reviewed.

### Suggested integration seam

```ts
interface ProofAdapter {
  prepare(action: PrivateAction, mandate: SignedMandate): Promise<PublicClaim>;
  prove(privateWitness: PrivateWitness, claim: PublicClaim): Promise<ProofEnvelope>;
  verify(proof: ProofEnvelope, expectedClaim: PublicClaim): Promise<boolean>;
  anchor(proof: ProofEnvelope, publicClaim: PublicClaim): Promise<{ txId: string }>;
}
```

The generated Compact circuits and wallet/provider-specific wrappers go behind the adapter. The VCC does not need to be rewritten to adopt a different host or chain.

## Implementation gates

1. Write the complete contract and verification relation in Compact, with compiler/runtime SDK versions pinned to the current Midnight compatibility matrix.
2. Generate TypeScript bindings, prover and verifier keys. Confirm proof system and parameter security.
3. Run local prover and test network via the documented Midnight toolchain. **Proof server sees private inputs during proving**, so it is inside the trusted boundary.
4. Test negative vectors: forged mandate, amount over limit, commitment mismatch, replay, changing policy version, wrong circuit, malformed witness and public metadata leaks.
5. Verify the on-chain statement/commitment matches the VCC-signed action **without publishing raw VCG claims or sensitive personal/commercial data**.
6. Reconcile confirmed chain state and external executor receipts; a proof of bounds is not evidence of delivery or payment settlement.

### Useful documentation

- https://docs.midnight.network/guides/build-a-private-smart-contract
- https://docs.midnight.network/guides/private-state-witnesses
- https://docs.midnight.network/guides/deploy-and-operate
- https://docs.midnight.network/api-reference

## Future Nightframe host adapter

Expose `start`, `attest?`, `executeOnce`, `checkpoint`, `recover`, `revoke`, and `stop` as host-specific functionality. Publish actual attestation roots, supported algorithms, isolation constraints and custody boundaries if/when an official runtime API is available. This MVP **does not** claim Nightframe deployment support or confidentiality of its Node.js process.
