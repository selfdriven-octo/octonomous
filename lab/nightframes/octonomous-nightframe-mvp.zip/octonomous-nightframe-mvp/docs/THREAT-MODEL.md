# ONI Purchasing Agent MVP — Threat Model

## Assets / boundaries

Assets: community spending authority, purchase approvals, VCG evidence, signing keys, committed budget, replay state, private supplier and amount data. Boundaries: untrusted planner → VCC; signed claims → VCG verifier; VCC → simulated executor; local evidence → optional Midnight integration.

## Protections actually implemented

| Attack | MVP protection |
|---|---|
| LLM suggests purchase over limit | Deterministic VCC `DENY` outside the planner |
| LLM bypasses human approval | Action-digest-bound signed approval required above threshold |
| Supplier substituted | Signed mandate allowlist + exact supplier claim binding |
| Fake/tampered context | Trusted issuer signatures, expiry, uniqueness, signed snapshot binding |
| Replay same action | Action ID digest map returns prior record, no repeated execution |
| Reuse nonce with new action ID | Persisted nonce reservation returns `NONCE_REUSED` |
| Spend over local mandate budget | Durable reservation under a local single-host lock |
| Tool bypass using forged ALLOW | Executor verifies Ed25519 controller decision and action digest |
| Unknown external outcome | Keep reserved budget, mark reconciliation required, do not resend automatically |
| False claim of cryptographic proof | Midnight adapter refuses prove/anchor; output says `NOT_PROVEN` |

## Remaining risks / do NOT use for real purchases

- **Demo key co-location:** issuer, approver, controller and executor keys exist in one process. Separation of duties is logical, not cryptographic isolation from a compromised host.
- **Local state tampering / crash:** JSON store is not protected by a hardware root, encrypted, centrally audited, distributed, or backup-reconciled. File locks may remain after crashes.
- **Authority issuer:** production needs authenticating real people, role assignments, threshold governance and revocation. A valid demo signature means little outside the generated fixture.
- **Policy flaws:** signing a permissive policy faithfully still permits bad actions; independent review required.
- **Endpoint identity and finality:** simulated executor does not call suppliers or payment systems and cannot prove fulfilment or settlement.
- **Freshness and mutable realities:** a signed quote can become stale or stock can run out between approval and execution; production needs short-validity proofs plus just-in-time reservation.
- **Overlapping mandates / accounts:** separate mandates may spend one project account if there is no globally coordinated reservation service.
- **Privacy:** signed evidence can leak metadata; salted hash is not a ZK proof and losing its opening prevents later verification.
- **Proof trust:** a future local proof server handles private witnesses; incorrect constraints, compromised proving host or public metadata disclosures remain possible.
- **Federation:** OFP 1.0 signed wire envelopes, local-governance proofs and BFT quorum evidence are not implemented in this toy repo.

## Exit requirements for a real pilot

Separate protected signing and custody services; centrally enforce revocation and authoritative spend limits; choose a transactional external idempotency design; implement authenticated API transport; verify third-party claims against issuer policies; perform independent penetration testing; adopt RFC 8785-like canonicalisation; implement secure evidence retention and reconciliation; and validate every ZK predicate against official chain state.
