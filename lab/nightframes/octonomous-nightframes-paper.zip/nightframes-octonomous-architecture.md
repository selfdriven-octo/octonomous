# Nightframes × Octonomous
## Confidential Execution, Verified Context, and Sovereign Autonomous Agency

**Technical architecture paper — v0.1**  
**12 October 2026**  
**Status:** Proposed integration architecture; not an announcement of an implemented integration  
**Keywords:** Nightframes, Midnight, Octonomous, verified context graphs, verified code controllers, autonomous agents, selective disclosure, governance, zero-knowledge proofs

> **Core thesis:** Midnight can supply a privacy-preserving verification and settlement substrate, and a future Nightframe-style confidential execution environment may host agents; Octonomous can supply the independently governed, verifiable control plane that decides *whether* those agents may act. The integration succeeds only when identity, authority, reasoning, execution and evidence remain distinct.

---

## Abstract

Autonomous agents are moving from generating text to exercising capabilities: querying records, making recommendations, purchasing resources, coordinating communities and conducting transactions. Their central architectural problem is not merely intelligence. It is **controlled authority in the presence of private context, imperfect reasoning and heterogeneous systems**.

On 10 October 2026 Charles Hoskinson presented *Nightframes* as a proposed successor to smart contracts: private, persistent, personal computers that operate on behalf of their owners. The vision was presented using **Identity, Intention, Intelligence and Personal** (the “three Is and a P”). In parallel, Midnight provides privacy-preserving smart contracts and selective disclosure using Compact and zero-knowledge proofs. These are different maturity levels: the latter has published developer tooling; the former remains an evolving system vision. [1–4]

This paper proposes **Octonomous Nightframe Integration (ONI)**, a layered architecture in which verified/validated context graphs (VCGs) establish evidence and provenance, deterministic verified/validated code controllers (VCCs) enforce authority, Octonomous composers and conductors organise agent work, confidential runtimes protect sensitive processing, and Midnight contracts verify narrowly specified claims and anchor commitments where needed.

The design does **not** claim that a zero-knowledge proof validates the semantic correctness of a language model's reasoning. It instead makes a more useful and defensible promise: an agent may propose actions freely, but important effects occur only after independently verifiable policy checks, appropriately scoped delegation and auditable execution receipts.

## 1. Design question

**Can Nightframes provide the confidential computing environment while Octonomous provides verifiable agent governance, without introducing a new central authority or treating AI output as proof?**

The proposed answer is **yes in principle**, subject to several engineering and product dependencies. Midnight's present ZK stack can be used independently of any future Nightframe runtime. Future TEEs, MPC or distributed execution are optional modules, not assumptions that must be trusted today.

### 1.1 Objectives

1. **Sovereignty:** a human or community principal retains control over identity, mandate, capability grants and revocation.
2. **Confidentiality:** private context, prompts, policies and commercially sensitive execution details need not be broadcast publicly.
3. **Verifiable authorisation:** consequential operations require deterministic policy decisions and evidence of the required approvals.
4. **Composability:** multiple agents and multiple communities can collaborate without a shared database, model provider or wallet.
5. **Auditability with minimal disclosure:** third parties can verify specified claims using signed attestations, commitments, and where appropriate ZK proofs.
6. **Graceful degradation:** local / private deployments remain useful even without a Nightframe product, a TEE or a functioning blockchain connection.

### 1.2 Non-goals

The proposed system does not prove that a model is truthful or aligned, guarantee that a remote API fulfils its promises, make all metadata private, eliminate TEE hardware trust, or establish that Midnight already ships a general-purpose always-on agent runtime. The architecture must not turn speculative capabilities into security dependencies.

## 2. What exists and what remains proposed

| Element | Position as of 12 Oct 2026 | Architecture implication |
|---|---|---|
| Midnight Compact, public ledger and local witnesses | Documented developer functionality | Implement a bounded policy/commitment prototype now. |
| Midnight.js providers and proof tooling | Documented API surface | Use adapters rather than hard-code SDK versions. |
| Midnight mainnet permissionless smart contracts | Reported live from 2 Oct 2026 | Assess deployment maturity separately from agent-runtime maturity. |
| Nightframe: persistent, personal agent computer | Publicly presented vision | Define an execution interface; do not assume production availability. |
| Midnight Passport / agent identity extension | Announced / planned | Make identity provider pluggable; retain current Octonomous signers. |
| Nightframe-level per-agent TEE hosting and decentralised continuity | Proposed / partially demonstrated in Midnight City context | Optional assurance profile, not MVP critical path. |
| Octonomous Federation Protocol v1.0 and security profiles | Existing Octonomous design material | Reuse signed envelopes, authority separation and bounded delegation. |

This distinction matters. **Midnight zero-knowledge contracts are not the same thing as confidential LLM inference.** In the documented contract flow, private inputs remain with the application/prover and proofs plus deliberately disclosed values reach the network; the proof service still has access to sensitive inputs during proving and belongs within the trusted boundary. [2–3]

## 3. Foundational architecture

```mermaid
flowchart TB
    A[Human or community principal] --> B[Identity, intent and governance mandate]
    B --> C[Verified Context Graph: provenance and freshness]
    C --> D[Composer: goals, plans and candidate actions]
    D --> E[Conductor: orchestration and cadence]
    E --> F[Agents and tools: musicians]
    F --> G[Verified Code Controller: capability gates]
    B --> G
    C --> G
    G -->|authorised action only| H[Confidential execution host: local / isolated / future Nightframe]
    H --> I[External tools, systems and custody]
    H --> J[Evidence receipts and commitments]
    J --> K[Midnight proof and ledger adapters]
    J --> L[Octonomous Federation Protocol]
    K --> M[Selective verification / settlement]
    L --> N[Other governed communities]
```

### 3.1 Layer A — Principal, identity and mandate

The principal can be an individual, an organisation or a governed community. A principal defines an **intent** (“obtain materials for a learning project”), a **mandate** (what an agent may attempt), a **policy version**, and a **revocation path**. Identity authenticates who issued the mandate; it does not imply unlimited authority. A signing key must not be treated as a universal permission slip.

An Octonomous community may require a threshold decision, a delegated officer, or a human approval at a specific stage. Reuse an OFP local-governance proof that cryptographically binds the authorisation to the exact proposal and resolution. Do not conflate identity, governance consent and executable authority.

### 3.2 Layer B — Verified Context Graph (VCG)

A VCG stores the *claims on which action depends*, not just documents for retrieval. Nodes identify principals, facts, resources, contracts, policies, observations and decisions. Edges express provenance, dependency, delegation, applicability and contradiction. Evidence may be signed, timestamped, scoped and assigned a freshness rule.

Each decision should bind to a **context snapshot root**. At minimum, an action-critical claim should carry `source`, `digest`, `observedAt`, `validUntil`, `subject`, `issuer`, `verificationMethod` and an explicit `status` such as `VERIFIED`, `UNVERIFIED`, `CONFLICTED` or `EXPIRED`. A model-generated claim is not upgraded to verified merely because it appears in a VCG.

VCG validation checks provenance, signature validity, schema, expiry, conflicts and required completeness. It cannot guarantee that an honest signed source supplied objectively correct real-world information.

### 3.3 Layer C — Composer, conductor and musicians

The **composer** translates a goal into an inspectable score: a plan, constraints, required evidence, expected outcomes and quality conditions. The **conductor** coordinates the execution cadence, assigns bounded work and listens for feedback. **Musicians** are human or machine agents, tool runners, and service providers that perform the work.

Reasoning is generative, adaptable and fallible. The score is a proposal, not executable permission. An agent can discover options, but the conductor must route consequential actions through deterministic controls before anything is signed, paid, published or changed.

### 3.4 Layer D — Verified Code Controller (VCC)

The VCC is the narrow, testable **reference monitor**. It evaluates a requested capability against the currently valid mandate, context snapshot, governance approvals, target identity, budget, expiry, risk class, and replay/idempotency state.

A VCC decision yields `ALLOW`, `DENY` or `ESCALATE`, along with a signed decision receipt. The authoritative checks must be independent of the LLM and must re-evaluate action-critical facts **immediately before execution**, not just when the plan was created. Delegation may only narrow authority: a child grant cannot acquire more scope or time than its parent.

VCC bundles should be versioned, reviewed, reproducibly built and signed. The exact controller digest used for a decision is included in the evidence receipt. No amount of model confidence substitutes for a valid grant or approval.

### 3.5 Layer E — Confidential host / Nightframe adapter

The execution host is an interface with selectable implementations:

- **Local-isolated:** user or community machine, with encrypted storage and protected signing keys.
- **Managed-isolated:** segregated cloud runtime under the customer's operating and access controls.
- **Attested-TEE:** a measured enclave with verified remote attestation, key release policies and narrowly defined trust assumptions.
- **Future Nightframe:** an adapter to a published Nightframe runtime, if it offers suitable APIs and independent assurance.

An adapter should expose lifecycle, state import/export, attestation where supported, capability invocation, encrypted checkpointing, recovery and termination. A running container is not automatically a trusted enclave. A TEE measurement is evidence of what was launched under a hardware trust model, not proof of an agent's wisdom.

### 3.6 Layer F — Evidence, selective disclosure and settlement

Proof objects and receipts describe distinct propositions. A VCC receipt proves *which policy decision was signed*. A signed tool receipt proves *what a tool claims to have executed*. A TEE attestation can support *which measured code ran in an enclave*. A Midnight ZK proof can establish *a formally encoded relation over private and public inputs*. On-chain confirmation records *that a particular transaction or state transition was accepted*.

These propositions are not interchangeable. They are linked by digests, nonces, sequence numbers and actor identities, with minimal data disclosed on-chain. Each verifier must understand exactly what is and is not being proven.

## 4. Formal trust and authority model

Define a proposed action `a` for principal `p` at time `t`, context snapshot `C`, mandate `M`, controller version `V`, and approvals `R`.

**Authorise(a) =** `IdentityValid(p) ∧ MandateValid(M,t) ∧ ContextAcceptable(C,t) ∧ ControllerAllows(V,a,M,C) ∧ ApprovalsSatisfied(R,a) ∧ NonceUnused(a) ∧ RiskWithinLimits(a)`.

Every predicate must be evaluated by deterministic code or an explicit external verifier. An unavailable, expired, contradictory or unknown critical input should make the result **DENY** or **ESCALATE**, never a silent allow.

The statement *“the action satisfied Authorise(a)”* may be encoded into a circuit **only if** the specific predicates, commitment scheme, public/private inputs and witness semantics are all implemented. Arbitrary language-model reasoning remains outside that proof. Some checks are better kept as signatures or off-chain reviews rather than forced into zero-knowledge circuits.

### 4.1 Capability grant invariants

A grant must bind principal, grantee, action set, resource scope, target allowlist, financial/time budgets, approved controller digest, nonce namespace and expiry. It must be signed by an authorised issuer. For each delegation, the child grant must be a strict subset of the parent. High-impact capabilities should require independent approval and external custody; inference infrastructure never receives raw treasury signing keys.

### 4.2 Revocation and concurrency

Revocation is meaningful only where the execution boundary re-checks it. An agent that has already received unrestricted credentials cannot be reliably recalled. Grants should therefore be short-lived, action-specific and issued just in time. The controller atomically reserves budget/nonce state before dispatch, returns the prior result for duplicate requests, and enforces a compare-and-set or equivalent concurrency rule. Off-chain revocation state and on-chain contract state must be reconciled before valuable actions.

## 5. Evidence objects and integration contracts

The following JSON is a **proposed ONI application schema**, not an existing Midnight or OFP wire standard:

```json
{
  "schema": "octonomous.action-evidence.v0.1",
  "actionId": "urn:uuid:...",
  "principalId": "did:example:community-a",
  "actorId": "did:example:agent-7",
  "intentDigest": "sha256:...",
  "contextRoot": "sha256:...",
  "controllerDigest": "sha256:...",
  "mandateDigest": "sha256:...",
  "governanceProofDigest": "sha256:...",
  "capability": "purchase.request",
  "resourceDigest": "sha256:...",
  "amountMinor": 42000,
  "currency": "AUD",
  "decision": "ALLOW",
  "issuedAt": "2026-10-12T00:00:00Z",
  "expiresAt": "2026-10-12T00:05:00Z",
  "nonce": "random-unique-value",
  "executionReceiptDigest": "sha256:...",
  "proofRef": null,
  "signature": "detached-signature-placeholder"
}
```

Sensitive attributes should not necessarily appear as plaintext in a signed public envelope. Use a **private authoritative record**, a **public commitment/statement**, and separately encrypted disclosure packages for authorised reviewers. Canonical encoding must be fixed before signing or hashing; domain-separate hashes by schema and purpose. The example currency amount is illustrative only.

### 5.1 What gets verified where

| Claim | Preferred mechanism | Limits |
|---|---|---|
| Issuer and recipient of a mandate | Signatures and credential verification | A valid key may still be compromised or unauthorised. |
| Grant scope and time bounds | Deterministic VCC | It proves policy compliance, not good policy design. |
| Approval threshold met | Signed governance resolution / quorum evidence | Threshold metadata must correspond to the real governing body. |
| Context snapshot unchanged | Commitment / Merkle root | Integrity does not imply factual correctness. |
| Private amount below authorised budget | Optional Compact ZK circuit | Correct only relative to exact encoded amount/budget binding. |
| Enclave ran a particular build | TEE remote attestation | Depends on vendor roots, runtime integrity and side-channel assumptions. |
| Tool performed a real-world action | Tool receipt plus independent reconciliation | External providers may be faulty, dishonest or unavailable. |
| Payment finally settled | Custodian/blockchain confirmation | Must track chain finality, reversals and failure modes. |

## 6. End-to-end transaction workflow

**Illustrative case: a community education agent proposes an AUD 420 purchase of equipment from an approved supplier.** This is a design example, not an executed transaction.

1. **Mandate:** community governance authorises materials procurement up to AUD 500 for a named project until a specified date, with approvals defined for amounts above a smaller threshold.
2. **Context:** VCG validates the project, supplier registration, product quote, funding balance and previous commitments; records a freshness-bounded snapshot root.
3. **Compose:** a planning agent compares purchase options and proposes a specific supplier, amount and expected educational outcome.
4. **Conduct:** the conductor obtains a bounded `purchase.request` capability with an exact supplier, amount and expiry; never a general-purpose payment key.
5. **Control:** VCC checks issuer, project budget, supplier policy, current quote, required approvals and nonce. It returns a signed `ALLOW` or `ESCALATE` decision.
6. **Execute:** the confidential host submits the signed, single-use request to an external purchasing service. Custody/payment keys remain outside the inference and federation gateway boundaries.
7. **Reconcile:** the purchasing service returns an execution receipt; an independent observer verifies the supplier transaction or delivered order reference.
8. **Prove selectively:** if required, a Midnight Compact contract verifies a narrowly defined private threshold condition and records a commitment. Do not publish the supplier's personal data or internal reasoning.
9. **Federate:** an OFP signed envelope transports the evidence digest and appropriate governance proof to another community; the receiving side verifies authority separately from transport identity.
10. **Review:** the composer/conductor receives delivery and outcome feedback, while the principal can inspect, revoke or amend future mandates.

### 6.1 Runtime sequence (proposal)

```text
Principal -> Mandate service       sign intent, constraints, revocation rules
Agent -> VCG                       request bounded evidence snapshot
VCG -> Agent                       contextRoot + verified claims
Agent -> Conductor                 candidate action (not authority)
Conductor -> VCC                   action + mandate + context + proofs
VCC -> Capability service          atomic nonce/budget reservation
VCC -> Conductor                  ALLOW / DENY / ESCALATE + signed receipt
Conductor -> Confidential host     single-use authorised invocation
Host -> External executor          act using separated service identity
Executor -> Evidence store         execution / settlement receipt
Evidence store -> Midnight adapter optional threshold ZK proof / commitment
Evidence store -> OFP gateway      signed federation envelope + minimal claim
```

## 7. Implementation interfaces

The following is **non-executable interface pseudocode**. It intentionally makes no unverified claims about published Nightframe APIs or current Compact bindings.

```typescript
type ActionRequest = {
  actionId: string;
  principalId: string;
  capability: string;
  target: string;
  contextRoot: string;
  mandateDigest: string;
  controllerDigest: string;
  nonce: string;
  expiresAt: string;
  parametersDigest: string;
};

type ControllerDecision = {
  outcome: 'ALLOW' | 'DENY' | 'ESCALATE';
  reasonCodes: string[];
  approvedRequestDigest?: string;
  receiptSignature: string;
};

interface ContextGraph {
  snapshot(requiredClaims: string[]): Promise<{
    root: string; claimEvidence: unknown[]; unresolved: string[];
  }>;
}

interface VerifiedController {
  evaluate(
    action: ActionRequest,
    evidence: unknown[],
    mandate: unknown,
    approvals: unknown[]
  ): Promise<ControllerDecision>;
}

interface ConfidentialHost {
  attest?(): Promise<unknown>; // available only in capable host profiles
  invokeOnce(action: ActionRequest, signedDecision: ControllerDecision):
    Promise<{ executionReceiptDigest: string; status: string }>;
}

interface ProofAdapter {
  proveConstraint(privateInputs: unknown, publicStatement: unknown):
    Promise<{ proof: Uint8Array; statementDigest: string }>;
  anchorCommitment(root: string): Promise<{ txId: string }>;
}
```

Implement each module behind independently testable interfaces. For a Node.js pilot, keep the deterministic controller and its signing service isolated from any model API. Use explicit promise chains or async boundaries, but never allow a model to call privileged `execute` endpoints without a controller-issued one-use token.

## 8. Confidential computation and proof boundaries

There are at least four distinct computational regimes:

1. **Conventional local computation:** easiest to deploy; owner controls the host but remote collaborators must trust signed claims or independent audits.
2. **TEE computation:** potentially protects code and secrets from some host operators; requires attestation and careful key provisioning. It does not intrinsically prevent logical errors or prompt injection.
3. **Zero-knowledge computation:** a prover can show that a *specific circuit relation* holds without revealing private witness inputs. It is well-suited to limited eligibility, threshold, commitment and authorisation predicates, not arbitrary reasoning transcripts.
4. **MPC / collaborative proof:** may enable cross-party private calculations, subject to protocol, participant, network and collusion assumptions. Do not imply MPC is part of the current Midnight DApp contract path.

The best near-term ONI design is **hybrid**: model cognition and sensitive local records remain off-chain; simple, stable invariants are verified deterministically and optionally encoded as ZK circuits; only indispensable commitments or claims are anchored on-chain.

### 8.1 Privacy leakage analysis

Even a valid ZK proof may expose the existence of an action, the verifier identity, a timestamp, network metadata, a public amount bound, or correlations between repeated commitments. Use fresh salts, purpose-specific identifiers, unlinkable presentation techniques where practical, batching where justified, encrypted off-chain evidence, and careful retention policies. Don't publish raw VCG identifiers or deterministic low-entropy hashes of sensitive values.

## 9. Federation: community-to-community agency

An Octonomous federation already distinguishes **identity, authority, transport and execution**. OFP v1.0 uses signed envelopes, recipient binding, unpredictable nonces, expiry, atomic replay protection, idempotent dispatch, governance evidence and immutable treaty versioning. A Nightframe integration should reuse these guarantees, rather than inventing a parallel agent-to-agent transport.

Federated actions carry *claims plus proofs*, not a blanket assertion that a partner has been “trusted.” Community B independently checks a received OFP envelope, verifies the applicable treaty and signer, verifies governance proof binding to the exact action, and then runs its own VCC against locally defined resource policy. Trust remains local and can be narrower than the sender's permission.

For designated high-consequence federation decisions, an existing OFP high-assurance profile calls for isolated signers, independent evidence checking, and appropriate BFT quorum certificates. Such certificates provide evidence of a quorum, **not** a complete consensus or availability network.

## 10. Threat model and failure handling

| Threat / failure | Design control | Residual risk |
|---|---|---|
| Prompt injection asks agent to spend funds | VCC checks action-specific, scoped grant outside LLM | Approved policy itself may be flawed. |
| Model fabricates VCG evidence | Provenance, independent verification and UNKNOWN state | Verified sources may still be wrong. |
| Plan changes after approval | Bind approval to exact action digest; re-check immediately before effect | Real-world state may change between check and execution. |
| Replay / duplicate actions | Unique nonce, atomic claims, idempotent executor | External executor must honour idempotency. |
| Key compromise | Hardware-backed/isolated signer, rotation and immediate revocation | Previously valid malicious acts may be irreversible. |
| TEE side channels or vendor compromise | Optional attestation, reduce secret exposure, separate custody | Hardware root remains trusted and imperfect. |
| Proof over incorrect semantics | Independent circuit review, versioning, test vectors | A formally proven bad rule is still bad. |
| Chain / proof-server outage | Retry, local event log, later anchoring, fail closed for protected actions | Liveness and deadlines may suffer. |
| Privacy metadata correlation | Minimise on-chain surface and rotate identifiers | Public-network traffic analysis remains possible. |
| Cross-community authority confusion | Verify OFP envelope *and* local mandate proof and treaty | Partner governance can make poor decisions. |

Three immediate **kill-switches** are recommended: revoke a principal's grants; disable a capability globally per governed community; and suspend the executor/custodian while preserving evidence for later audit. A failed blockchain confirmation must not be reported as completed settlement. In outage mode, controllers should explicitly classify actions as safe-to-queue, read-only or blocked.

## 11. An achievable prototype

### Phase 0 — Verifiable control without Midnight dependency

Build a Node.js reference implementation with deterministic VCC decisions, signed VCG snapshots, action digests, one-use grants, replay/idempotency tests and tamper-evident evidence logs. Demonstrate that a deliberately malicious or hallucinating agent cannot bypass authorisation. No real payment keys.

**Exit criteria:** 100% of enumerated denied-action test vectors remain denied; expiry, nonce, delegation and controller-version mismatch are rejected; every accepted action has a reproducible decision transcript.

### Phase 1 — Midnight proof / commitment adapter

Choose one narrow private claim: e.g. *amount <= privately committed authorisation limit* with publicly known policy version. Define the circuit semantics and disclosure boundary, use the documented Compact toolchain and Midnight.js provider abstraction, run locally and against the documented test network, and verify both acceptance and adversarial failures.

**Exit criteria:** valid proof verifies against the correct statement; false proof fails; witness data does not enter public ledger fields; on-chain commitment matches the private decision record; SDK compatibility is pinned and recorded.

### Phase 2 — Confidential-host profiles

Deploy the same agent behind local-isolated and optionally attested-TEE adapters. Test attestation failure, key-release refusal, encrypted checkpoint recovery, revocation and network partitions. Do not use a future Nightframe-specific API until published and independently testable.

**Exit criteria:** replacing the host does not change VCC semantics, receipt verification or custody isolation. Claims about confidentiality are traceable to the host profile and trust assumptions.

### Phase 3 — Governed federation pilot

Connect two community instances through OFP with separate policy engines and signing keys. Exchange an authorisation/evidence claim, not sensitive plaintext. Demonstrate local veto, treaty-version binding and deduplicated delivery.

**Exit criteria:** the recipient can independently reconstruct all mandatory checks without sharing the origin community's database, inference model or payment credentials.

### Phase 4 — Production readiness assessment

Commission a threat-model review, independent audit of controller and circuits, operations playbooks, privacy-impact assessment and reliability tests. Check Nightframe product readiness, published integration APIs and threat model before adopting any platform-specific feature.

## 12. Measures of success

The prototype should report: authorisation bypasses (target zero in defined threat tests), unverified-context action attempts rejected, approval latency, policy-evaluation latency, proof-generation/verification cost, on-chain cost per anchored claim, metadata disclosed, replay duplicates prevented, signing-key exposure (target zero in cognition/runtime), recoverability after host loss, and time to effective revocation.

Do not rely on a single “agent trust score.” Publish the exact conformance tests and signed evidence for each measured claim.

## 13. Open research questions

1. **Portable sovereign identity:** can Midnight Passport credentials and Octonomous community/AID identity bind to the same principal without creating a universal identifier that destroys unlinkability?
2. **Proof granularity:** what is the smallest economically useful ZK predicate that adds assurance beyond a signed VCC receipt?
3. **Attested agent lifecycle:** can a confidential host preserve continuity, revocation and recovery across devices and hosts without becoming a custodial service?
4. **Authority under change:** how are just-in-time approvals bound to fresh prices, inventory, budget and policy when conditions shift?
5. **Federated evidence semantics:** what minimum claim schema allows recipient communities to independently verify outcomes while preserving context privacy?
6. **Human governance and recourse:** who is accountable for an agent's action, how is it contested, and which systems can reverse or compensate a mistaken action?
7. **Cost and liveness:** when should ZK proof generation or on-chain anchoring be used rather than simpler signatures, audit logs or bilateral settlement?

## 14. Conclusion and recommendation

**Recommended architecture: Octonomous as the agent governance and evidence plane; Midnight as an optional privacy/proof and settlement plane; Nightframes as a potential future execution plane.** These are related but separable concerns. This division protects the project against vendor lock-in and against premature claims about AI verifiability.

A useful first demonstration is a community purchasing agent that can reason freely, yet cannot spend outside its signed mandate. The proof target is *not* “the AI made the right decision.” It is *“this exact action passed this exact published policy, using this bounded context and this authorised governance resolution, and the external effect has a separately verifiable receipt.”*

That is a practical bridge from autonomous intelligence toward **sovereign, accountable agency**.

---

## Appendix A — Proposed minimal artefact set

| Artefact | Owner / issuer | Core properties |
|---|---|---|
| Intent declaration | Principal | Purpose, validity, revocation, permitted goal types |
| Governance mandate | Community / authorised principal | Scope, approvals, budget, delegation limits, signature |
| VCG snapshot | Evidence service | Claim provenance, timestamp, status, Merkle/digest root |
| Controller bundle | Governance / policy maintainer | Reproducible build, digest, tests, approved policy version |
| Action request | Conductor | Exact target, parameters digest, nonce, expiry |
| Control receipt | VCC signer | Decision, reasons, request digest, signature |
| Execution receipt | Tool/custodian | Independent action result and status evidence |
| Proof package | Prover | Statement, circuit/version, proof, public commitment |
| Federation envelope | OFP gateway | Origin, recipient, nonce, expiry, immutable signed payload |

## Appendix B — Security assurance profiles

- **ONI-L1 / Locally Governed:** local or isolated execution, signed VCG/VCC records, controlled secrets, no chain required.
- **ONI-L2 / Selective Proof:** ONI-L1 plus defined ZK statements and optional Midnight anchoring; privacy of witnesses established within declared prover boundary.
- **ONI-L3 / Attested Execution:** ONI-L2 plus attested hardware/runtime, verified measurements, isolated key release and tested continuity.
- **ONI-L4 / Federated High Assurance:** ONI-L3 plus OFP-HIGH-ASSURANCE-1 where justified, independent counterpart verification, and suitable governance/quorum mechanisms.

These are **proposed ONI labels**, not official Midnight or existing Octonomous standards. They must be mapped to formal conformance tests before any certification-like usage.

## References and basis

**External public sources (accessed 12 October 2026):**

1. Charles Hoskinson, *What comes after the smart contract? Welcome to Nightframes*, Midnight City Tokyo presentation, 10 October 2026. https://www.youtube.com/watch?v=Iyrt2fNAWQ4
2. Midnight Network, *What is Midnight?* https://docs.midnight.network/what-is-midnight
3. Midnight Network, *How to build a private smart contract*. https://docs.midnight.network/guides/build-a-private-smart-contract
4. Midnight Network, *Midnight.js API Reference*. https://docs.midnight.network/api-reference/midnight-js
5. Intersect, *Weekly update #132*, 9 October 2026 (mainnet contracts, Passport and Nightframes announcements). https://intersectmbo.org/news/intersect-weekly-update-132-oct-9-2026
6. SIPO.TOKYO, *Hoskinson presents Nightframe as successor to smart contracts*, 11 October 2026. Japanese-language secondary analysis; used to cross-check presentation scope and component maturity. https://sipo.tokyo/deep-dive-20261011-17063e75/

**Octonomous design basis (internal reference files):**

- *PROTOCOL.md*, Octonomous Federation Protocol 1.0, especially identity/authority/transport/execution separation, local governance proofs, replay/idempotency and treaty versioning.
- *THREAT-MODEL.md*, Octonomous Runtime v1.0, especially cognition/policy separation, custody outside runtime, scope-restricted delegation and residual risks.
- *SECURITY-PROFILES.md*, OFP-BASELINE-1, OFP-GOVERNED-1 and OFP-HIGH-ASSURANCE-1 profiles.

**Qualification:** No published, production-ready Octonomous ↔ Nightframes integration specification was identified. All ONI names, interfaces, code snippets, phases and example contracts in this paper are original proposals, not representations of an official Midnight release.
