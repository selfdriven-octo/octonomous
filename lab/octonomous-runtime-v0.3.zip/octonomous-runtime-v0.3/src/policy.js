function Policy() {}

Policy.prototype.check = function (context) {
  const being = context.being;
  const decision = context.decision || {};
  const action = decision.action;

  if (!decision.shouldAct || !action || !action.enabled) {
    return {
      allowed: true,
      status: 'no_action'
    };
  }

  const availableNames = (context.availableTools || []).map(function (tool) {
    return tool.name;
  });

  if (!availableNames.includes(action.tool)) {
    return {
      allowed: false,
      status: 'unknown_tool',
      reason: 'Tool is not registered: ' + action.tool
    };
  }

  const authority = being.authority || {};
  const allowedTools = authority.allowedTools || [];
  const requiresApproval = authority.requiresApproval || [];
  const approval = decision.approvalResolution;

  if (!allowedTools.includes(action.tool) && !requiresApproval.includes(action.tool)) {
    return {
      allowed: false,
      status: 'not_authorised',
      reason: 'Being is not authorised to use tool: ' + action.tool
    };
  }

  if (requiresApproval.includes(action.tool)) {
    if (approval && approval.status === 'granted') {
      return {
        allowed: true,
        status: 'approved',
        approvalId: approval.id,
        resolvedBy: approval.resolvedBy
      };
    }

    return {
      allowed: false,
      status: 'approval_required',
      reason: 'Human approval required for tool: ' + action.tool
    };
  }

  return {
    allowed: true,
    status: 'authorised'
  };
};

module.exports = Policy;
