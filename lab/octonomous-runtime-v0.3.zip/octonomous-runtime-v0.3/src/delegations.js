const crypto = require('crypto');

function DelegationService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
}

DelegationService.prototype.create = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};

  if (!input.targetBeingId) {
    return Promise.reject(new Error('being.delegate requires targetBeingId'));
  }

  if (!self.publisher) {
    return Promise.reject(new Error('No event publisher configured for delegation'));
  }

  being.delegations = being.delegations || [];

  const delegation = {
    id: crypto.randomUUID(),
    fromBeingId: being.id,
    toBeingId: input.targetBeingId,
    intent: input.intent || '',
    requestedAction: input.requestedAction || null,
    constraints: input.constraints || {},
    status: 'requested',
    createdAt: new Date().toISOString(),
    sourceEventId: context.event && context.event.id
  };

  being.delegations.push(delegation);

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'delegation.requested',
      beingId: being.id,
      subject: delegation,
      evidence: { sourceEventId: delegation.sourceEventId }
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      delegation.receipt = receipt;

      return self.publisher.publish({
        type: 'delegation.requested',
        sourceBeingId: being.id,
        targetBeingId: input.targetBeingId,
        payload: {
          delegation: delegation,
          sourceBeingId: being.id
        }
      });
    })
    .then(function (event) {
      delegation.deliveryEventId = event.id;
      return {
        ok: true,
        delegation: delegation,
        event: event
      };
    });
};

module.exports = DelegationService;
