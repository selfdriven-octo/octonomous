const crypto = require('crypto');

function commitmentId(beingId, eventId, title) {
  return crypto.createHash('sha256')
    .update([beingId, eventId || '', title || ''].join('|'))
    .digest('hex')
    .slice(0, 32);
}

function CommitmentService(options) {
  options = options || {};
  this.scheduler = options.scheduler || null;
  this.receipts = options.receipts || null;
}

CommitmentService.prototype.create = function (context) {
  const self = this;
  const being = context.being;
  const proposal = context.proposal;
  const id = commitmentId(being.id, context.event.id, proposal.title);

  being.commitments = being.commitments || [];

  const existing = being.commitments.find(function (item) {
    return item.id === id;
  });

  if (existing) {
    return Promise.resolve(existing);
  }

  const commitment = {
    id: id,
    version: 'octonomous.commitment.v1',
    beingId: being.id,
    title: proposal.title,
    reason: proposal.reason,
    dueAt: proposal.dueAt,
    status: 'active',
    createdAt: new Date().toISOString(),
    sourceEventId: context.event.id,
    receipt: null
  };

  being.commitments.push(commitment);

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'commitment.created',
      beingId: being.id,
      subject: commitment,
      evidence: {
        sourceEventId: context.event.id
      }
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      commitment.receipt = receipt;

      if (!self.scheduler || !commitment.dueAt) {
        return commitment;
      }

      return self.scheduler.scheduleCommitment({
        beingId: being.id,
        commitment: commitment
      })
        .then(function (schedule) {
          commitment.reminder = schedule;
          return commitment;
        });
    });
};

CommitmentService.prototype.markDue = function (being, commitmentId) {
  const commitment = (being.commitments || []).find(function (item) {
    return item.id === commitmentId;
  });

  if (!commitment) {
    return null;
  }

  if (commitment.status === 'active') {
    commitment.status = 'due';
    commitment.dueObservedAt = new Date().toISOString();
  }

  return commitment;
};

module.exports = CommitmentService;
