const canonical = require('../canonical');

/*
 * KERI receipt adapter.
 *
 * The runtime deliberately does not own KERI keys. Supply a provider backed by
 * Signify/KERIA (or another KERI implementation) with:
 *
 *   provider.signReceipt({ aid, digest, payload })
 *     .then(({ signature, ...metadata }) => ...)
 *
 * This keeps AID/key lifecycle outside the autonomous runtime.
 */
function KeriSigner(options) {
  options = options || {};

  if (!options.provider || typeof options.provider.signReceipt !== 'function') {
    throw new Error('KeriSigner requires provider.signReceipt()');
  }

  this.provider = options.provider;
  this.aid = options.aid;
}

KeriSigner.prototype.sign = function (payload) {
  const digest = canonical.sha256(payload);
  const self = this;

  return self.provider.signReceipt({
    aid: self.aid,
    digest: digest,
    payload: payload
  })
    .then(function (signed) {
      return Object.assign({
        mode: 'keri',
        aid: self.aid,
        digest: digest
      }, signed || {});
    });
};

module.exports = KeriSigner;
