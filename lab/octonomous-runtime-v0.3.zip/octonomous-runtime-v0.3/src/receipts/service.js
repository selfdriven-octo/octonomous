const crypto = require('crypto');
const canonical = require('../canonical');

function snapshot(value) {
  return JSON.parse(JSON.stringify(value || {}));
}

function ReceiptService(options) {
  options = options || {};
  this.signer = options.signer || null;
}

ReceiptService.prototype.create = function (context) {
  const self = this;
  const payload = {
    version: 'octonomous.receipt.v1',
    id: context.id || crypto.randomUUID(),
    kind: context.kind,
    beingId: context.beingId,
    occurredAt: context.occurredAt || new Date().toISOString(),
    subject: snapshot(context.subject),
    evidence: snapshot(context.evidence)
  };

  const receipt = {
    id: payload.id,
    kind: payload.kind,
    beingId: payload.beingId,
    occurredAt: payload.occurredAt,
    digest: canonical.sha256(payload),
    payload: payload,
    signature: null
  };

  if (!self.signer) {
    return Promise.resolve(receipt);
  }

  return self.signer.sign(payload)
    .then(function (signature) {
      receipt.signature = signature;
      return receipt;
    });
};

module.exports = ReceiptService;
