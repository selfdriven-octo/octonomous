const path = require('path');
const Runtime = require('./runtime');
const Policy = require('./policy');
const ToolRegistry = require('./tools');
const CommitmentService = require('./commitments');
const ApprovalService = require('./approvals');
const RelationshipService = require('./relationships');
const ContributionService = require('./contributions');
const DelegationService = require('./delegations');
const ReceiptService = require('./receipts/service');
const LocalEd25519Signer = require('./receipts/local-ed25519');
const KeriSigner = require('./receipts/keri');
const FileStore = require('./store/file');
const DynamoDBStore = require('./store/dynamodb');
const OpenAICognition = require('./cognition/openai');
const MockCognition = require('./cognition/mock');
const EventBridgePublisher = require('./events/eventbridge');
const ReminderScheduler = require('./events/scheduler');
const MCPManager = require('./mcp');
const Secrets = require('./secrets');

function bool(value, fallback) {
  if (value === undefined || value === '') {
    return fallback;
  }
  return String(value).toLowerCase() === 'true';
}

function parseMcpServers() {
  if (!process.env.MCP_SERVERS_JSON) {
    return [];
  }

  return JSON.parse(process.env.MCP_SERVERS_JSON);
}

function createStore() {
  if (process.env.STORE_MODE === 'dynamodb') {
    return new DynamoDBStore({
      tableName: process.env.DYNAMODB_TABLE,
      region: process.env.AWS_REGION
    });
  }

  return new FileStore({
    basePath: process.env.DATA_PATH || path.join(process.cwd(), 'data')
  });
}

function resolveOpenAIKey(secrets) {
  if (process.env.OPENAI_API_KEY) {
    return Promise.resolve(process.env.OPENAI_API_KEY);
  }

  if (process.env.OPENAI_API_KEY_SECRET_ARN) {
    return secrets.get(
      process.env.OPENAI_API_KEY_SECRET_ARN,
      process.env.OPENAI_API_KEY_SECRET_JSON_KEY || undefined
    );
  }

  return Promise.resolve(null);
}

function resolveMcpServerSecrets(servers, secrets) {
  return Promise.all(servers.map(function (server) {
    if (!server.tokenSecretArn) {
      return server;
    }

    return secrets.get(server.tokenSecretArn, server.tokenSecretJsonKey)
      .then(function (token) {
        return Object.assign({}, server, { token: token });
      });
  }));
}

function createReceiptSigner() {
  const mode = process.env.RECEIPT_MODE || 'local';

  if (mode === 'none') {
    return null;
  }

  if (mode === 'keri') {
    if (!process.env.KERI_SIGNER_MODULE) {
      throw new Error('RECEIPT_MODE=keri requires KERI_SIGNER_MODULE');
    }

    const providerPath = path.isAbsolute(process.env.KERI_SIGNER_MODULE)
      ? process.env.KERI_SIGNER_MODULE
      : path.resolve(process.cwd(), process.env.KERI_SIGNER_MODULE);
    const loaded = require(providerPath);
    const provider = typeof loaded.createProvider === 'function'
      ? loaded.createProvider({
        aid: process.env.KERI_AID,
        keriaUrl: process.env.KERIA_URL
      })
      : loaded;

    return new KeriSigner({
      aid: process.env.KERI_AID,
      provider: provider
    });
  }

  return new LocalEd25519Signer({
    aid: process.env.LOCAL_RECEIPT_AID || 'did:key:local-development',
    privateKeyPem: process.env.RECEIPT_PRIVATE_KEY_PEM,
    publicKeyPem: process.env.RECEIPT_PUBLIC_KEY_PEM
  });
}

function bootstrap() {
  const region = process.env.AWS_REGION;
  const tools = new ToolRegistry();
  const secrets = new Secrets({ region: region });
  const store = createStore();
  const receiptSigner = createReceiptSigner();
  const receipts = new ReceiptService({ signer: receiptSigner });

  const eventPublisher = process.env.EVENT_BUS_NAME
    ? new EventBridgePublisher({
      busName: process.env.EVENT_BUS_NAME,
      region: region
    })
    : null;

  const scheduler = process.env.WAKE_QUEUE_ARN && process.env.SCHEDULER_TARGET_ROLE_ARN
    ? new ReminderScheduler({
      queueArn: process.env.WAKE_QUEUE_ARN,
      roleArn: process.env.SCHEDULER_TARGET_ROLE_ARN,
      region: region
    })
    : null;

  const delegations = new DelegationService({
    publisher: eventPublisher,
    receipts: receipts
  });

  tools.register({
    name: 'echo',
    description: 'Return the supplied input unchanged.',
    inputSchema: { type: 'object' },
    source: 'local'
  }, function (input) {
    return Promise.resolve({ ok: true, output: input });
  });

  if (eventPublisher) {
    tools.register({
      name: 'event.publish',
      description: 'Publish a targeted event to another Octonomous being.',
      inputSchema: {
        type: 'object',
        properties: {
          targetBeingId: { type: 'string' },
          type: { type: 'string' },
          payload: { type: 'object' }
        }
      },
      source: 'local'
    }, function (input, executionContext) {
      return eventPublisher.publish({
        sourceBeingId: executionContext.being && executionContext.being.id,
        targetBeingId: input.targetBeingId,
        type: input.type,
        payload: input.payload || {}
      })
        .then(function (event) {
          return { ok: true, event: event };
        });
    });

    tools.register({
      name: 'being.delegate',
      description: 'Delegate an intent or bounded task to another Octonomous being.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'intent'],
        properties: {
          targetBeingId: { type: 'string' },
          intent: { type: 'string' },
          requestedAction: { type: 'object' },
          constraints: { type: 'object' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.create({
        being: executionContext.being,
        event: executionContext.event,
        input: input
      });
    });
  }

  return resolveOpenAIKey(secrets)
    .then(function (apiKey) {
      const cognitionMode = process.env.COGNITION_MODE || (apiKey ? 'openai' : 'mock');
      let cognition;

      if (cognitionMode === 'openai') {
        if (!apiKey) {
          throw new Error('COGNITION_MODE=openai but no OpenAI API key is configured');
        }

        cognition = new OpenAICognition({
          apiKey: apiKey,
          model: process.env.OPENAI_MODEL || 'gpt-5.6',
          reflectWithModel: bool(process.env.REFLECT_WITH_MODEL, true)
        });
      }
      else {
        cognition = new MockCognition();
      }

      const commitments = new CommitmentService({
        scheduler: scheduler,
        receipts: receipts
      });

      const runtime = new Runtime({
        store: store,
        cognition: cognition,
        policy: new Policy(),
        tools: tools,
        commitments: commitments,
        approvals: new ApprovalService({
          publisher: eventPublisher,
          receipts: receipts
        }),
        relationships: new RelationshipService(),
        contributions: new ContributionService({
          receipts: receipts,
          publisher: eventPublisher
        }),
        receipts: receipts
      });

      const mcp = new MCPManager({ registry: tools });

      return resolveMcpServerSecrets(parseMcpServers(), secrets)
        .then(function (servers) {
          return Promise.all(servers.map(function (server) {
            return mcp.connectServer(server);
          }));
        })
        .then(function () {
          return {
            runtime: runtime,
            tools: tools,
            mcp: mcp,
            eventPublisher: eventPublisher,
            receipts: receipts,
            delegations: delegations
          };
        });
    });
}

module.exports = bootstrap;
