function ensureRelationship(being, otherBeingId) {
  being.relationships = being.relationships || {};

  if (!being.relationships[otherBeingId]) {
    being.relationships[otherBeingId] = {
      beingId: otherBeingId,
      interactions: 0,
      successfulInteractions: 0,
      blockedInteractions: 0,
      delegationsOut: 0,
      delegationsIn: 0,
      lastInteractionAt: null,
      trustScore: 0.5
    };
  }

  return being.relationships[otherBeingId];
}

function clamp(value) {
  return Math.max(0, Math.min(1, value));
}

function RelationshipService() {}

RelationshipService.prototype.recordEvent = function (being, event) {
  const sourceBeingId = event.sourceBeingId || (event.payload && event.payload.sourceBeingId);

  if (!sourceBeingId || sourceBeingId === being.id) {
    return;
  }

  const rel = ensureRelationship(being, sourceBeingId);
  rel.interactions += 1;
  rel.lastInteractionAt = new Date().toISOString();

  if (event.type === 'delegation.requested') {
    rel.delegationsIn += 1;
  }
};

RelationshipService.prototype.recordOutcome = function (being, context) {
  const action = context.decision && context.decision.action;
  const input = action && action.input;
  const targetBeingId = input && input.targetBeingId;

  if (!targetBeingId || targetBeingId === being.id) {
    return;
  }

  const rel = ensureRelationship(being, targetBeingId);
  rel.interactions += 1;
  rel.lastInteractionAt = new Date().toISOString();

  if (action.tool === 'being.delegate') {
    rel.delegationsOut += 1;
  }

  if (context.actionResult && context.actionResult.ok) {
    rel.successfulInteractions += 1;
    rel.trustScore = clamp(rel.trustScore + 0.02);
  }
  else if (context.actionResult && (context.actionResult.blocked || context.actionResult.error)) {
    rel.blockedInteractions += 1;
    rel.trustScore = clamp(rel.trustScore - 0.02);
  }
};

RelationshipService.prototype.recordReputation = function (being, context) {
  being.reputation = being.reputation || {
    actionsAttempted: 0,
    actionsSucceeded: 0,
    actionsBlocked: 0,
    approvalsRequested: 0,
    approvalsGranted: 0,
    commitmentsCreated: 0,
    contributionsCreated: 0
  };

  const action = context.decision && context.decision.action;
  if (context.decision && context.decision.shouldAct && action && action.enabled) {
    being.reputation.actionsAttempted += 1;
  }

  if (context.actionResult && context.actionResult.ok && !context.actionResult.skipped) {
    being.reputation.actionsSucceeded += 1;
  }

  if (context.actionResult && context.actionResult.blocked) {
    being.reputation.actionsBlocked += 1;
  }

  if (context.approvalRequest) {
    being.reputation.approvalsRequested += 1;
  }

  if (context.decision && context.decision.approvalResolution && context.decision.approvalResolution.status === 'granted') {
    being.reputation.approvalsGranted += 1;
  }

  if (context.commitment) {
    being.reputation.commitmentsCreated += 1;
  }

  if (context.contribution) {
    being.reputation.contributionsCreated += 1;
  }
};

module.exports = RelationshipService;
