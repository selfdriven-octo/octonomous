# Octonomous Runtime v0.4

A Node.js runtime for durable, event-driven **Octonomous beings that can form an accountable society**.

v0.4 extends the v0.3 accountable-being model with:

- delegation request / accept / reject / complete lifecycle
- bounded capability grants and revocation
- pluggable ACDC/KERIA capability credentials
- signed relationship assertions
- commitment fulfilment / violation
- third-party Octomics contribution verification
- deterministic evidence batching
- optional Cardano evidence-root anchoring
- expanded relationship/reputation signals

The runtime remains CommonJS and Promise `.then()` based.

## Core rule

```text
Intelligence proposes.
Identity persists.
Policy authorises.
Capabilities can be granted and revoked.
Humans can approve.
Beings can delegate.
Tools act.
Evidence is signed.
Peers can verify.
Contribution is recorded.
Evidence can be anchored.
```

## Runtime lifecycle

```text
Event
  ↓
wake()
  ↓
observe()
  │   ├─ delegation state
  │   ├─ capabilities
  │   ├─ relationship assertions
  │   └─ verification records
  ↓
consider()
  ↓
decide()
  ↓
govern()
  │   ├─ local authority
  │   ├─ human approval
  │   └─ received capability
  ↓
commit()
  ↓
act()
  ↓
reflect()
  ↓
contribute()
  ↓
remember()
  ↓
sleep()
```

## Society model

```text
Being A
  │
  ├── delegation.requested ──────────> Being B
  │                                     │
  │                              accept / reject
  │                                     │
  │<──────── delegation.accepted ────────┘
  │                                     │
  │                              perform bounded work
  │                                     │
  │<──────── delegation.completed ───────┘
  │
  ├── capability.granted ────────────> Being B
  │           │                         │
  │           └─ signed / credentialed  └─ policy may authorise tool
  │
  ├── relationship.asserted ─────────> Being B
  │
  └── contribution.verification.requested ─> Verifier
                                                │
                                                └─ contribution.verified
```

## Local run

```bash
npm install
export COGNITION_MODE=mock
export STORE_MODE=file
export RECEIPT_MODE=local
npm start
```

Run tests:

```bash
npm test
```

The v0.4 package contains 9 tests covering the original lifecycle plus society features.

## OpenAI cognition

```bash
export COGNITION_MODE=openai
export OPENAI_API_KEY='...'
export OPENAI_MODEL='gpt-5.6'
npm start
```

The model proposes structured actions. It does not execute tools directly.

## Authority + capabilities

A being may have explicit local authority:

```json
{
  "authority": {
    "allowedTools": ["echo"],
    "requiresApproval": ["evidence.anchor"]
  }
}
```

v0.4 also supports received capabilities:

```json
{
  "id": "...",
  "issuerBeingId": "octo:community:001",
  "subjectBeingId": "octo:research:001",
  "tool": "event.publish",
  "constraints": {
    "targetBeingIds": ["octo:community:001"]
  },
  "expiresAt": "2026-12-01T00:00:00Z",
  "status": "active"
}
```

Policy evaluation is:

```text
requires human approval?
        │
       yes ──> only a matching granted approval authorises
        │
        no
        ↓
explicit local authority?
        │
       yes ──> authorise
        │
        no
        ↓
active matching capability?
        │
       yes ──> check expiry + constraints ──> authorise
        │
        no
        ↓
       deny
```

### Capability tools

```text
capability.grant
capability.revoke
```

A capability may be restricted by:

- expiry
- target being IDs
- exact input field values

The structure is intentionally small so stronger policy languages can later be plugged in without changing the being model.

## ACDC / KERI capability credentials

`src/credentials/acdc.js` is a production adapter boundary.

Without a provider, capability issuance creates a signed **development receipt credential** that is explicitly marked as not being an ACDC/TEL credential.

For production:

```bash
export RECEIPT_MODE=keri
export KERI_SIGNER_MODULE=./my-keri-signer.js
export KERI_AID=E...
export KERIA_URL=https://...

export ACDC_PROVIDER_MODULE=./my-acdc-provider.js
export ACDC_REGISTRY_NAME=octonomous-capabilities
```

The ACDC provider owns credential registry/TEL behaviour and exposes:

```js
issueCapability(context)
  .then(function (credential) {
    return credential;
  });

revokeCredential(context)
  .then(function (result) {
    return result;
  });

verifyCredential(context)
  .then(function (result) {
    return result;
  });
```

See `examples/acdc-provider.example.js`.

The runtime deliberately does **not** own KERI keys, KELs, registries or TELs.

## Delegation lifecycle

Create:

```text
being.delegate
```

Then the target may use:

```text
being.delegate.accept
being.delegate.reject
being.delegate.complete
```

State machine:

```text
requested
  ├──> rejected
  └──> accepted
          └──> completed
```

Every transition can carry a signed receipt.

A delegation can include:

```json
{
  "targetBeingId": "octo:research:001",
  "intent": "Verify the project evidence",
  "constraints": {
    "deadline": "2026-09-10T00:00:00Z"
  },
  "capabilityIds": ["..."]
}
```

Delegation does not automatically transfer authority. Capabilities are separate objects.

## Commitments

A cognition decision can still create a durable scheduled commitment.

v0.4 adds terminal transitions:

```text
commitment.fulfil
commitment.violate
```

```text
active ──> due ──┬──> fulfilled
                 └──> violated
```

A final commitment cannot subsequently be changed to another terminal state.

## Signed relationship assertions

Use:

```text
relationship.assert
```

Example input:

```json
{
  "targetBeingId": "octo:research:001",
  "relationshipType": "trusted-collaborator",
  "claims": {
    "scope": "evidence verification"
  },
  "validUntil": "2027-01-01T00:00:00Z"
}
```

The assertion is locally persisted, signed, and delivered to the target being when EventBridge is configured.

An assertion is a claim by one being, not universal truth.

## Octomics contribution verification

A producer can ask another being to verify a contribution:

```text
contribution.verification.request
```

The verifier uses:

```text
contribution.verify
```

The verification logic:

```text
contribution
    ↓
receipt digest integrity
    ↓
receipt signature verification (when provider supports it)
    ↓
optional evidence checks
    ↓
verifier verdict
    ↓
signed verification receipt
    ↓
contribution.verified → producer
```

The verifier's statement is independently attributable; it does not mutate the original contribution evidence.

## Evidence anchoring

Use:

```text
evidence.anchor
```

The runtime collects unanchored signed receipts from:

- processed events
- contributions
- commitments and terminal transitions
- delegations and lifecycle transitions
- capability grants/revocations
- relationship assertions
- contribution verifications

It then creates:

```text
receipt digests
      ↓
sorted evidence set
      ↓
Blake2b-256 leaves
      ↓
Merkle tree
      ↓
64-character root
```

The compact anchor metadata looks like:

```json
{
  "v": "octo-anchor-v1",
  "root": "...",
  "count": 42,
  "being": "...",
  "created": "..."
}
```

### Cardano mode

Without a provider, `evidence.anchor` creates and signs the anchor bundle but submits no blockchain transaction.

For production:

```bash
export CARDANO_ANCHOR_MODULE=./my-cardano-provider.js
export CARDANO_NETWORK=preprod
export CARDANO_METADATA_LABEL=1337
```

The adapter exposes:

```js
anchor(context)
  .then(function (result) {
    return {
      txId: result.txId,
      network: result.network
    };
  });
```

The Cardano provider owns:

- UTXO selection
- payment key / wallet access
- transaction construction
- signing
- submission
- confirmation

Private Cardano payment keys should not be stored in a being document.

`1337` is only a development/default custom metadata label. Choose an appropriate application label before production deployment.

See `examples/cardano-anchor-provider.example.js`.

## Targeted system events

These explicit targeted events wake a being even if they are not in its normal subscription list:

```text
approval.granted
approval.denied
commitment.due

delegation.requested
delegation.accepted
delegation.rejected
delegation.completed

capability.granted
capability.revoked

relationship.asserted

contribution.verification.requested
contribution.verified
```

This lets society protocol messages reach their intended being without requiring every being definition to repeat internal protocol subscriptions.

## AWS deployment

The v0.3 AWS shape remains valid:

```text
EventBridge
    ↓
   SQS ──> DLQ
    ↓
 Lambda worker
    ↓
Octonomous runtime
    ├── DynamoDB state
    ├── OpenAI cognition
    ├── MCP tools
    ├── EventBridge society events
    ├── EventBridge Scheduler commitments
    ├── KERI/ACDC adapters
    └── Cardano anchor adapter
```

Deploy:

```bash
sam build
sam deploy --guided
```

Production provider modules must be included in the Lambda package and selected with environment variables.

## Files added in v0.4

```text
src/
├── capabilities.js
├── verifications.js
├── credentials/
│   └── acdc.js
└── anchors/
    ├── evidence.js
    └── cardano-provider.js

examples/
├── acdc-provider.example.js
└── cardano-anchor-provider.example.js

tests/
└── society.test.js
```

## Security boundaries

Keep these separations:

```text
LLM                    proposes
Policy                 authorises
Capability service     grants / revokes bounded authority
Approval service       captures human consent
Tool registry          executes
KERI adapter           controls attributable identity proof
ACDC provider          controls credential/TEL lifecycle
Cardano provider       controls blockchain signing
Runtime state          remembers
Octomics               records contribution
Verifier beings        add independent attestations
```

Do not give the cognition adapter direct access to private signing keys.

## Migration

See:

```text
MIGRATION-v0.3-v0.4.md
```

v0.3 state remains compatible. New collections are initialised lazily where possible.

## Suggested v0.5 direction

The next useful layer would be collective governance rather than more agent features:

- multi-party capability issuance
- threshold approvals
- capability delegation chains
- relationship assertion revocation
- explicit dispute/challenge events
- verification quorum rules
- reputation derived from signed evidence rather than local counters
- shared society policies / constitutions
- deterministic governance evaluation before cognition
