const crypto = require('crypto');
const canonical = require('../canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function blake2b256(value) {
  const input = typeof value === 'string' ? value : canonical.canonicalJson(value);
  return crypto.createHash('blake2b512')
    .update(input)
    .digest()
    .subarray(0, 32)
    .toString('hex');
}

function merkleRoot(values) {
  if (!values.length) {
    return null;
  }

  let level = values.map(function (value) {
    return Buffer.from(blake2b256(value), 'hex');
  });

  while (level.length > 1) {
    const next = [];
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = level[i + 1] || left;
      const joined = Buffer.concat([left, right]);
      next.push(crypto.createHash('blake2b512').update(joined).digest().subarray(0, 32));
    }
    level = next;
  }

  return level[0].toString('hex');
}

function collectReceipts(being) {
  const items = [];
  const seen = new Set();

  function add(receipt, source) {
    if (!receipt || !receipt.id || seen.has(receipt.id)) {
      return;
    }
    seen.add(receipt.id);
    items.push({
      id: receipt.id,
      digest: receipt.digest,
      kind: receipt.kind,
      occurredAt: receipt.occurredAt,
      source: source
    });
  }

  (being.memory && being.memory.receipts || []).forEach(function (r) { add(r, 'memory'); });
  (being.contributions || []).forEach(function (c) { add(c.receipt, 'contribution:' + c.id); });
  (being.commitments || []).forEach(function (c) {
    add(c.receipt, 'commitment:' + c.id);
    add(c.fulfilledReceipt, 'commitment:' + c.id);
    add(c.violatedReceipt, 'commitment:' + c.id);
  });
  (being.delegations || []).forEach(function (d) {
    add(d.receipt, 'delegation:' + d.id);
    add(d.acceptedReceipt, 'delegation:' + d.id);
    add(d.rejectedReceipt, 'delegation:' + d.id);
    add(d.completedReceipt, 'delegation:' + d.id);
  });
  (being.relationshipAssertions || []).forEach(function (a) { add(a.receipt, 'relationship:' + a.id); });
  const caps = being.capabilities || {};
  (caps.granted || []).forEach(function (c) {
    add(c.receipt, 'capability:' + c.id);
    add(c.revocationReceipt, 'capability:' + c.id);
  });
  (being.verifications || []).forEach(function (v) { add(v.receipt, 'verification:' + v.id); });
  (being.anchors || []).forEach(function (a) { add(a.receipt, 'anchor:' + (a.root || 'unknown')); });

  return items.sort(function (a, b) {
    return a.id.localeCompare(b.id);
  });
}

function EvidenceAnchorService(options) {
  options = options || {};
  this.provider = options.provider || null;
  this.receipts = options.receipts || null;
  this.metadataLabel = String(options.metadataLabel || '1337');
  this.network = options.network || null;
}

EvidenceAnchorService.prototype.prepare = function (being, input) {
  input = input || {};
  const all = collectReceipts(being);
  const previouslyAnchored = new Set();

  (being.anchors || []).forEach(function (anchor) {
    (anchor.evidence || []).forEach(function (item) {
      previouslyAnchored.add(item.id);
    });
  });

  let selected = input.includeAnchored
    ? all
    : all.filter(function (item) { return !previouslyAnchored.has(item.id); });

  if (input.limit) {
    selected = selected.slice(0, Number(input.limit));
  }

  const leaves = selected.map(function (item) {
    return item.digest || canonical.sha256(item);
  });

  return {
    version: 'octonomous.evidence-anchor.v1',
    beingId: being.id,
    createdAt: new Date().toISOString(),
    hashAlgorithm: 'blake2b-256',
    root: merkleRoot(leaves),
    count: selected.length,
    evidence: clone(selected),
    metadataLabel: this.metadataLabel,
    network: this.network,
    metadata: {
      v: 'octo-anchor-v1',
      root: merkleRoot(leaves),
      count: selected.length,
      being: blake2b256(being.id),
      created: new Date().toISOString()
    }
  };
};

EvidenceAnchorService.prototype.anchor = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const anchor = self.prepare(being, input);

  if (!anchor.count) {
    return Promise.resolve({ ok: true, skipped: true, reason: 'No unanchored evidence', anchor: anchor });
  }

  being.anchors = being.anchors || [];

  const submitPromise = self.provider && typeof self.provider.anchor === 'function'
    ? Promise.resolve(self.provider.anchor({
      root: anchor.root,
      metadataLabel: self.metadataLabel,
      metadata: anchor.metadata,
      evidence: anchor.evidence,
      network: self.network
    }))
    : Promise.resolve({
      status: 'prepared',
      note: 'No Cardano anchor provider configured; no transaction was submitted.'
    });

  return submitPromise
    .then(function (chainResult) {
      anchor.chain = chainResult;
      anchor.status = chainResult && chainResult.txId ? 'submitted' : (chainResult.status || 'prepared');

      if (!self.receipts) {
        return anchor;
      }

      return self.receipts.create({
        kind: 'evidence.anchor.' + anchor.status,
        beingId: being.id,
        subject: anchor,
        evidence: {
          root: anchor.root,
          count: anchor.count,
          txId: chainResult && chainResult.txId || null
        }
      })
        .then(function (receipt) {
          anchor.receipt = receipt;
          return anchor;
        });
    })
    .then(function (result) {
      being.anchors.push(result);
      return { ok: true, anchor: result };
    });
};

EvidenceAnchorService.collectReceipts = collectReceipts;
EvidenceAnchorService.merkleRoot = merkleRoot;
EvidenceAnchorService.blake2b256 = blake2b256;

module.exports = EvidenceAnchorService;
