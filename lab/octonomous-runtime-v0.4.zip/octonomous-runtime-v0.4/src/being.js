function Being(options) {
  options = options || {};

  this.definition = options.definition;
  this.store = options.store;
  this.cognition = options.cognition;
  this.policy = options.policy;
  this.tools = options.tools;
  this.commitments = options.commitments;
  this.approvals = options.approvals;
  this.relationships = options.relationships;
  this.contributions = options.contributions;
  this.receipts = options.receipts;
  this.delegations = options.delegations;
  this.capabilities = options.capabilities;
  this.verifications = options.verifications;
}

Being.prototype.handleEvent = function (event) {
  const self = this;
  const context = { event: event };

  return self.wake(event, context)
    .then(function () { return self.observe(event, context); })
    .then(function () { return self.consider(event, context); })
    .then(function () { return self.decide(event, context); })
    .then(function () { return self.govern(event, context); })
    .then(function () { return self.commit(event, context); })
    .then(function () { return self.act(event, context); })
    .then(function () { return self.reflect(event, context); })
    .then(function () { return self.contribute(event, context); })
    .then(function () { return self.remember(event, context); })
    .then(function () { return self.sleep(event, context); })
    .then(function () {
      return {
        beingId: self.definition.id,
        eventId: event.id,
        decision: context.decision,
        governance: context.governance,
        approvalRequest: context.approvalRequest || null,
        commitment: context.commitment || null,
        societyObservation: context.societyObservation || null,
        actionResult: context.actionResult,
        reflection: context.reflection,
        contribution: context.contribution || null,
        receipt: context.receipt || null
      };
    });
};

Being.prototype.wake = function (event, context) {
  context.wokeAt = new Date().toISOString();
  return Promise.resolve();
};

Being.prototype.observe = function (event, context) {
  const memory = this.definition.memory || {};
  const reflections = memory.reflections || [];
  const society = {};

  if (this.relationships) {
    this.relationships.recordEvent(this.definition, event);
    const assertion = this.relationships.observeAssertion(this.definition, event);
    if (assertion) {
      society.relationshipAssertion = assertion;
    }
  }

  if (this.delegations) {
    const delegation = this.delegations.observeEvent(this.definition, event);
    if (delegation) {
      society.delegation = delegation;
    }
  }

  if (this.capabilities) {
    const capability = this.capabilities.observeEvent(this.definition, event);
    if (capability) {
      society.capability = capability;
    }
  }

  if (this.verifications) {
    const verification = this.verifications.observeEvent(this.definition, event);
    if (verification) {
      society.verification = verification;
    }
  }

  if (event.type === 'commitment.due' && this.commitments) {
    context.dueCommitment = this.commitments.markDue(
      this.definition,
      event.payload && event.payload.commitmentId
    );
  }

  context.societyObservation = Object.keys(society).length ? society : null;

  context.observation = {
    event: event,
    society: context.societyObservation,
    dueCommitment: context.dueCommitment || null,
    being: {
      id: this.definition.id,
      identity: this.definition.identity,
      purpose: this.definition.purpose,
      character: this.definition.character,
      commitments: this.definition.commitments || [],
      delegations: (this.definition.delegations || []).slice(-20),
      capabilities: this.definition.capabilities || { granted: [], received: [] },
      relationships: this.definition.relationships || {},
      relationshipAssertions: (this.definition.relationshipAssertions || []).slice(-20),
      reputation: this.definition.reputation || {},
      recentReflections: reflections.slice(-5)
    }
  };

  return Promise.resolve();
};

Being.prototype.consider = function (event, context) {
  if (event.type === 'approval.granted' || event.type === 'approval.denied') {
    context.consideration = {
      relevant: true,
      approvalResolution: true
    };
    return Promise.resolve();
  }

  return this.cognition.consider({
    being: this.definition,
    event: event,
    observation: context.observation,
    tools: this.tools.listMetadata()
  })
    .then(function (consideration) {
      context.consideration = consideration;
    });
};

Being.prototype.decide = function (event, context) {
  const self = this;

  if ((event.type === 'approval.granted' || event.type === 'approval.denied') && self.approvals) {
    return self.approvals.resolve(self.definition, event)
      .then(function (resolution) {
        context.approvalResolution = resolution;
        context.decision = self.approvals.decisionFromResolution(resolution);
      });
  }

  return self.cognition.decide({
    being: self.definition,
    event: event,
    observation: context.observation,
    consideration: context.consideration,
    tools: self.tools.listMetadata()
  })
    .then(function (decision) {
      context.decision = decision;
    });
};

Being.prototype.govern = function (event, context) {
  context.governance = this.policy.check({
    being: this.definition,
    decision: context.decision,
    availableTools: this.tools.listMetadata()
  });

  return Promise.resolve();
};

Being.prototype.commit = function (event, context) {
  const self = this;
  const proposal = context.decision && context.decision.commitment;

  if (!proposal || !proposal.enabled || !self.commitments) {
    return Promise.resolve();
  }

  return self.commitments.create({
    being: self.definition,
    event: event,
    proposal: proposal
  })
    .then(function (commitment) {
      context.commitment = commitment;
    });
};

Being.prototype.act = function (event, context) {
  const self = this;
  const decision = context.decision || {};
  const governance = context.governance || {};
  const action = decision.action;

  if (!decision.shouldAct || !action || !action.enabled) {
    context.actionResult = {
      ok: true,
      skipped: true,
      reason: decision.approvalResolution && decision.approvalResolution.status === 'denied'
        ? 'Approval denied'
        : 'No action selected'
    };
    return Promise.resolve();
  }

  if (!governance.allowed && governance.status === 'approval_required' && self.approvals) {
    return self.approvals.request({
      being: self.definition,
      event: event,
      decision: decision
    })
      .then(function (approval) {
        context.approvalRequest = approval;
        context.actionResult = {
          ok: true,
          pendingApproval: true,
          approvalId: approval.id,
          tool: approval.tool
        };
      });
  }

  if (!governance.allowed) {
    context.actionResult = {
      ok: false,
      blocked: true,
      status: governance.status,
      reason: governance.reason
    };
    return Promise.resolve();
  }

  return self.tools.execute(action.tool, action.input, {
    being: self.definition,
    event: event,
    decision: decision,
    governance: governance
  })
    .then(function (result) {
      context.actionResult = result;
    })
    .catch(function (error) {
      context.actionResult = {
        ok: false,
        error: error.message
      };
    });
};

Being.prototype.reflect = function (event, context) {
  return this.cognition.reflect({
    being: this.definition,
    event: event,
    decision: context.decision,
    governance: context.governance,
    societyObservation: context.societyObservation,
    approvalRequest: context.approvalRequest,
    commitment: context.commitment,
    actionResult: context.actionResult
  })
    .then(function (reflection) {
      context.reflection = reflection;
    });
};

Being.prototype.contribute = function (event, context) {
  if (!this.contributions) {
    return Promise.resolve();
  }

  return this.contributions.create({
    being: this.definition,
    event: event,
    decision: context.decision,
    commitment: context.commitment,
    actionResult: context.actionResult,
    reflection: context.reflection
  })
    .then(function (contribution) {
      context.contribution = contribution;
    });
};

Being.prototype.remember = function (event, context) {
  const self = this;

  if (self.relationships) {
    self.relationships.recordOutcome(self.definition, context);
    self.relationships.recordReputation(self.definition, context);
  }

  self.definition.memory = self.definition.memory || {};
  self.definition.memory.reflections = self.definition.memory.reflections || [];
  self.definition.memory.receipts = self.definition.memory.receipts || [];

  self.definition.memory.reflections.push({
    at: new Date().toISOString(),
    eventId: event.id,
    eventType: event.type,
    societyObservation: context.societyObservation || null,
    decision: context.decision,
    governance: context.governance,
    approvalId: context.approvalRequest ? context.approvalRequest.id : null,
    commitmentId: context.commitment ? context.commitment.id : null,
    contributionId: context.contribution ? context.contribution.id : null,
    result: context.actionResult,
    reflection: context.reflection
  });

  if (self.definition.memory.reflections.length > 100) {
    self.definition.memory.reflections = self.definition.memory.reflections.slice(-100);
  }

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'event.processed',
      beingId: self.definition.id,
      occurredAt: new Date().toISOString(),
      subject: {
        eventId: event.id,
        eventType: event.type,
        governance: context.governance,
        actionResult: context.actionResult,
        contributionId: context.contribution ? context.contribution.id : null
      },
      evidence: {
        sourceBeingId: event.sourceBeingId || null
      }
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      context.receipt = receipt;
      if (receipt) {
        self.definition.memory.receipts.push(receipt);
        if (self.definition.memory.receipts.length > 100) {
          self.definition.memory.receipts = self.definition.memory.receipts.slice(-100);
        }
      }

      return self.store.saveBeing(self.definition);
    })
    .then(function (saved) {
      self.definition = saved;
    });
};

Being.prototype.sleep = function (event, context) {
  context.sleptAt = new Date().toISOString();
  return Promise.resolve();
};

module.exports = Being;
