const crypto = require('crypto');

function CapabilityService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
  this.credentials = options.credentials || null;
}

CapabilityService.prototype._sign = function (kind, beingId, subject, evidence) {
  if (!this.receipts) {
    return Promise.resolve(null);
  }

  return this.receipts.create({
    kind: kind,
    beingId: beingId,
    subject: subject,
    evidence: evidence || {}
  });
};

CapabilityService.prototype.grant = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};

  if (!input.targetBeingId) {
    return Promise.reject(new Error('capability.grant requires targetBeingId'));
  }

  if (!input.tool) {
    return Promise.reject(new Error('capability.grant requires tool'));
  }

  being.capabilities = being.capabilities || { granted: [], received: [] };
  being.capabilities.granted = being.capabilities.granted || [];

  const capability = {
    id: crypto.randomUUID(),
    version: 'octonomous.capability.v1',
    issuerBeingId: being.id,
    subjectBeingId: input.targetBeingId,
    subjectAid: input.subjectAid || null,
    tool: input.tool,
    constraints: input.constraints || {},
    delegable: Boolean(input.delegable),
    expiresAt: input.expiresAt || null,
    status: 'active',
    createdAt: new Date().toISOString(),
    sourceEventId: context.event && context.event.id,
    credential: null,
    receipt: null
  };

  being.capabilities.granted.push(capability);

  const credentialPromise = self.credentials
    ? self.credentials.issueCapability({
      issuerBeing: being,
      capability: capability
    })
    : Promise.resolve(null);

  return credentialPromise
    .then(function (credential) {
      capability.credential = credential;
      return self._sign('capability.granted', being.id, capability, {
        sourceEventId: capability.sourceEventId
      });
    })
    .then(function (receipt) {
      capability.receipt = receipt;

      if (!self.publisher) {
        return {
          ok: true,
          capability: capability,
          event: null
        };
      }

      return self.publisher.publish({
        type: 'capability.granted',
        sourceBeingId: being.id,
        targetBeingId: input.targetBeingId,
        payload: {
          capability: capability,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          capability.deliveryEventId = event.id;
          return {
            ok: true,
            capability: capability,
            event: event
          };
        });
    });
};

CapabilityService.prototype.revoke = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const granted = being.capabilities && being.capabilities.granted || [];
  const capability = granted.find(function (item) {
    return item.id === input.capabilityId;
  });

  if (!capability) {
    return Promise.reject(new Error('Unknown granted capability: ' + input.capabilityId));
  }

  if (capability.status === 'revoked') {
    return Promise.resolve({ ok: true, capability: capability, alreadyRevoked: true });
  }

  capability.status = 'revoked';
  capability.revokedAt = new Date().toISOString();
  capability.revokedByBeingId = being.id;
  capability.revocationReason = input.reason || '';

  const credentialPromise = self.credentials && capability.credential
    ? self.credentials.revokeCapability({
      issuerBeing: being,
      capability: capability,
      credential: capability.credential,
      reason: input.reason || ''
    })
    : Promise.resolve(null);

  return credentialPromise
    .then(function (credentialRevocation) {
      capability.credentialRevocation = credentialRevocation;
      return self._sign('capability.revoked', being.id, capability, {
        reason: input.reason || ''
      });
    })
    .then(function (receipt) {
      capability.revocationReceipt = receipt;

      if (!self.publisher) {
        return { ok: true, capability: capability, event: null };
      }

      return self.publisher.publish({
        type: 'capability.revoked',
        sourceBeingId: being.id,
        targetBeingId: capability.subjectBeingId,
        payload: {
          capabilityId: capability.id,
          capability: capability,
          reason: input.reason || '',
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          capability.revocationEventId = event.id;
          return { ok: true, capability: capability, event: event };
        });
    });
};

CapabilityService.prototype.observeEvent = function (being, event) {
  if (!event || !event.payload) {
    return null;
  }

  being.capabilities = being.capabilities || { granted: [], received: [] };
  being.capabilities.received = being.capabilities.received || [];

  if (event.type === 'capability.granted' && event.payload.capability) {
    const incoming = JSON.parse(JSON.stringify(event.payload.capability));
    const existing = being.capabilities.received.find(function (item) {
      return item.id === incoming.id;
    });

    if (!existing) {
      incoming.receivedAt = new Date().toISOString();
      being.capabilities.received.push(incoming);
      return incoming;
    }

    return existing;
  }

  if (event.type === 'capability.revoked') {
    const id = event.payload.capabilityId || (event.payload.capability && event.payload.capability.id);
    const received = being.capabilities.received.find(function (item) {
      return item.id === id;
    });

    if (received) {
      received.status = 'revoked';
      received.revokedAt = event.payload.capability && event.payload.capability.revokedAt
        ? event.payload.capability.revokedAt
        : new Date().toISOString();
      received.revocationReason = event.payload.reason || '';
    }

    return received || null;
  }

  return null;
};

CapabilityService.prototype.activeForAction = function (being, action, now) {
  const capabilities = being.capabilities && being.capabilities.received || [];
  const when = now ? new Date(now) : new Date();

  return capabilities.filter(function (capability) {
    if (!capability || capability.status !== 'active') {
      return false;
    }

    if (capability.subjectBeingId && capability.subjectBeingId !== being.id) {
      return false;
    }

    if (capability.tool !== action.tool) {
      return false;
    }

    if (capability.expiresAt && new Date(capability.expiresAt) <= when) {
      return false;
    }

    const constraints = capability.constraints || {};
    const input = action.input || {};

    if (Array.isArray(constraints.targetBeingIds) && input.targetBeingId) {
      if (!constraints.targetBeingIds.includes(input.targetBeingId)) {
        return false;
      }
    }

    if (constraints.inputEquals && typeof constraints.inputEquals === 'object') {
      const keys = Object.keys(constraints.inputEquals);
      for (let i = 0; i < keys.length; i += 1) {
        const key = keys[i];
        if (input[key] !== constraints.inputEquals[key]) {
          return false;
        }
      }
    }

    return true;
  });
};

module.exports = CapabilityService;
