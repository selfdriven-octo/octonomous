# Migration: v0.4 → v0.5

v0.5 adds governance-of-society semantics without changing the core wake/observe/consider/decide/govern/act lifecycle.

## 1. Add governance state

A being may now contain:

```json
{
  "governance": {
    "constitution": { "id": "...", "policies": [] },
    "constitutions": [],
    "proposals": [],
    "incomingProposals": [],
    "votes": []
  }
}
```

Existing beings with no constitution continue to use v0.4 authority/capability policy behavior.

## 2. Replace mutable reputation counters

v0.4 maintained counters such as:

```text
reputation.actionsSucceeded
reputation.commitmentsFulfilled
...
```

v0.5 no longer updates those counters. Reputation is derived from signed evidence and cached as:

```json
{
  "reputationEvidence": {
    "version": "octonomous.evidence-reputation.v1",
    "score": 5,
    "evidence": []
  }
}
```

The cached report can always be recomputed with `reputation.compute`.

## 3. Constitutional policy

Policies may be `allow`, `deny`, or `threshold`.

```json
{
  "id": "capability-grants-2of3",
  "match": { "tool": "capability.grant" },
  "effect": "threshold",
  "threshold": {
    "approvals": 2,
    "rejections": 2,
    "eligibleBeingIds": ["octo:g1", "octo:g2", "octo:g3"]
  }
}
```

If a threshold policy matches, the runtime persists the exact proposed action and emits `governance.proposal.created`. The action does not execute until `governance.proposal.approved` is observed.

## 4. Capability delegation

New tool:

```text
capability.delegate
```

A delegated capability:

- must originate from an active received capability
- requires the parent to be `delegable`
- must use the same tool
- may only narrow constraints
- may not expire later than its parent
- records the full delegation chain

`capability.revoked` can invalidate a descendant when the revoked ancestor appears in its chain.

## 5. Challenges and disputes

New tools/events:

```text
challenge.open       → challenge.opened
challenge.respond    → challenge.responded
challenge.resolve    → challenge.resolved
```

Resolutions are signed and can feed evidence-derived reputation.

## 6. Verification quorum

A constitution can define:

```json
{
  "verificationQuorum": {
    "required": 2,
    "eligibleBeingIds": ["octo:v1", "octo:v2", "octo:v3"]
  }
}
```

Distinct eligible verifiers are counted. Reaching quorum creates a signed `contribution.quorum.reached` record.

## 7. Evidence anchoring

The v0.4 evidence anchor collector now also includes:

- constitutions
- governance proposals and resolutions
- governance votes
- challenge lifecycle receipts
- verification quorum receipts

No Cardano provider changes are required.

## 8. New system events

The runtime now treats these as targeted protocol events:

```text
governance.proposal.created
governance.vote.cast
governance.proposal.approved
governance.proposal.rejected
constitution.adopted
challenge.opened
challenge.responded
challenge.resolved
contribution.quorum.reached
```

## 9. Recommended migration sequence

1. Deploy v0.5 code with no constitution. Behavior remains close to v0.4.
2. Stop relying on `being.reputation` counters.
3. Add governors/verifiers as explicit being IDs.
4. Adopt a small constitution covering only the most sensitive actions.
5. Add verification quorum rules.
6. Expand governance policy only after observing real event/audit behavior.
