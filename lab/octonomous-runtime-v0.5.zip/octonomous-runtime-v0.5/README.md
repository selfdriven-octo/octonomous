# Octonomous Runtime v0.5

A CommonJS Node.js runtime for durable, event-driven **Octonomous societies with explicit governance and evidence-backed reputation**.

v0.5 builds on the v0.4 society layer and adds:

- signed constitutions and policy sets
- deterministic threshold / multi-party governance
- exact-action suspension and resumption after approval
- capability delegation chains with no authority amplification
- challenge / response / resolution events
- verification quorum for Octomics contributions
- reputation derived from signed evidence instead of mutable counters
- governance/challenge/quorum evidence included in Cardano anchor batches

## Core rule

```text
Intelligence proposes.
Constitution constrains.
Governors attest.
Policy authorises.
Capabilities bound authority.
Tools act.
Peers verify.
Challenges remain attributable.
Reputation is derived from evidence.
Evidence can be anchored.
```

## Lifecycle

```text
Event
  ↓
wake()
  ↓
observe()
  │   ├─ relationships
  │   ├─ delegations
  │   ├─ capability chain
  │   ├─ governance votes / resolutions
  │   ├─ challenges
  │   └─ verification quorum
  ↓
consider()
  ↓
decide()
  ↓
govern()
  │   ├─ constitution deny/threshold/allow
  │   ├─ human approval
  │   ├─ local authority
  │   └─ received/delegated capability
  ↓
commit()
  ↓
act()
  ↓
reflect()
  ↓
contribute()
  ↓
remember()
  │   └─ recompute evidence reputation
  ↓
sleep()
```

## Threshold governance

A constitution can require a multi-party threshold for a tool:

```json
{
  "id": "capability-grants-2of3",
  "match": { "tool": "capability.grant" },
  "effect": "threshold",
  "threshold": {
    "approvals": 2,
    "rejections": 2,
    "eligibleBeingIds": ["octo:g1", "octo:g2", "octo:g3"]
  }
}
```

The runtime then behaves as:

```text
LLM proposes capability.grant
          ↓
constitution requires 2-of-3
          ↓
freeze exact action into signed proposal
          ↓
governance.proposal.created
       ↙       ↓       ↘
     g1       g2       g3
      │        │
 approve    approve
      └────┬───┘
           ↓
 signed threshold resolution
           ↓
governance.proposal.approved
           ↓
 reload exact stored action
           ↓
 policy verifies matching resolution
           ↓
 execute exactly once
```

The model is not asked to reconstruct the action after approval.

### Policy effects

```text
allow       explicit constitutional allow

deny        hard constitutional denial

threshold   signed N-of-M governance resolution required
```

`vetoBeingIds` may also be supplied on a threshold rule; a rejection by a listed veto being resolves the proposal as rejected.

## Capability delegation chains

v0.5 adds:

```text
capability.delegate
```

Authority is monotonic:

```text
Root grant
   │
   └─ tool: event.publish
      targets: [A, B, C]
      expires: Dec 31
      delegable: true
             │
             ▼
      delegated capability
      targets: [A]
      expires: Dec 1
      delegable: false
```

A child may never:

- change the tool
- add targets excluded by the parent
- remove inherited `inputEquals` constraints
- outlive the parent
- delegate if the parent is not delegable

Every child records `rootIssuerBeingId`, `delegatedFromCapabilityId`, `delegationDepth`, and `delegationChain`.

## Challenges / disputes

```text
challenge.open
challenge.respond
challenge.resolve
```

State flow:

```text
open → responded → resolved
                     ├─ upheld
                     ├─ dismissed
                     └─ partially_upheld
```

Every transition can have a signed receipt. A resolution can be made by a separate resolver/arbiter being.

The runtime deliberately records the resolution; it does not claim that every resolver is universally authoritative. Resolver eligibility can itself be protected with constitutional threshold policy.

## Verification quorum

A constitution may define:

```json
{
  "verificationQuorum": {
    "required": 2,
    "eligibleBeingIds": ["octo:v1", "octo:v2", "octo:v3"]
  }
}
```

Distinct eligible `contribution.verified` records are aggregated. Reaching the same verdict threshold creates:

```text
contribution.quorum.reached
```

with a signed consensus receipt referencing the verification IDs.

## Evidence-derived reputation

v0.5 stops incrementing local reputation counters.

Instead:

```text
signed commitments
signed delegation completion
signed quorum verdicts
signed challenge resolutions
signed governance votes
        ↓
verify receipts
        ↓
apply local weighting policy
        ↓
reputationEvidence report
```

Default weights are intentionally transparent and replaceable:

```text
commitment.fulfilled            +5
commitment.violated             -8
delegation.completed            +2
contribution quorum verified    +5
contribution quorum rejected    -3
challenge upheld against        -5
challenge dismissed against     +1
governance vote                 +1
```

This score is **not universal truth**. It is a reproducible interpretation of attributable evidence. A community can replace the weights without rewriting history.

Use:

```text
reputation.compute
```

to recompute the report.

## Tools added in v0.5

```text
constitution.adopt

governance.vote

capability.delegate

challenge.open
challenge.respond
challenge.resolve

reputation.compute
```

Existing v0.4 tools remain available.

## Evidence anchoring

The existing evidence Merkle batch now also includes:

```text
constitution receipts
governance proposal receipts
governance vote receipts
governance resolution receipts
challenge receipts
verification quorum receipts
```

Only the compact Blake2b-256 Merkle root needs to go to the Cardano adapter; private keys stay outside the Octonomous runtime.

## Local run

```bash
npm install
export COGNITION_MODE=mock
export STORE_MODE=file
export RECEIPT_MODE=local
npm start
```

Run tests:

```bash
npm test
```

The v0.5 package currently contains **14 passing tests**, including an end-to-end threshold-governed runtime action.

## OpenAI cognition

```bash
export COGNITION_MODE=openai
export OPENAI_API_KEY='...'
export OPENAI_MODEL='gpt-5.6'
npm start
```

The current OpenAI Node SDK uses the Responses API as its primary model interface, and `gpt-5.6` is the current GPT-5.6 Sol alias. The cognition adapter remains replaceable; governance never depends on the model vendor.

## AWS shape

```text
EventBridge
    ↓
   SQS ──> DLQ
    ↓
 Lambda worker
    ↓
Octonomous runtime
    ├── DynamoDB durable state
    ├── OpenAI / local cognition
    ├── MCP tools
    ├── constitution + threshold governance
    ├── capability chains
    ├── challenge protocol
    ├── verification quorum
    ├── evidence reputation
    ├── EventBridge Scheduler commitments
    ├── KERI / ACDC adapters
    └── Cardano evidence anchor adapter
```

Deploy as before:

```bash
sam build
sam deploy --guided
```

## New protocol events

```text
governance.proposal.created
governance.vote.cast
governance.proposal.approved
governance.proposal.rejected

constitution.adopted

challenge.opened
challenge.responded
challenge.resolved

contribution.quorum.reached
```

## Files added in v0.5

```text
src/governance/
├── constitutions.js
├── proposals.js
├── challenges.js
└── quorum.js

src/reputation/
└── evidence.js

examples/
└── constitution.example.json

tests/
└── governance.test.js
```

## Design boundary

The important progression is now:

```text
v0.1  Being
v0.2  Durable Being
v0.3  Accountable Being
v0.4  Society of Beings
v0.5  Governed Society
```

v0.5 still does not try to define one universal governance system. It supplies primitives that make governance explicit, attributable, testable, replaceable, and cryptographically evidentiary.

See `MIGRATION-v0.4-v0.5.md` for migration notes.
