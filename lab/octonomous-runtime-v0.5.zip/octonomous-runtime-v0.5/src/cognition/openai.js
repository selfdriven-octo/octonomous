const OpenAIModule = require('openai');
const OpenAI = OpenAIModule.default || OpenAIModule.OpenAI || OpenAIModule;

const decisionSchema = {
  type: 'object',
  properties: {
    shouldAct: { type: 'boolean' },
    rationale: { type: 'string' },
    action: {
      type: 'object',
      properties: {
        enabled: { type: 'boolean' },
        tool: { type: 'string' },
        inputJson: { type: 'string' }
      },
      required: ['enabled', 'tool', 'inputJson'],
      additionalProperties: false
    },
    commitment: {
      type: 'object',
      properties: {
        enabled: { type: 'boolean' },
        title: { type: 'string' },
        dueAt: { type: 'string' },
        reason: { type: 'string' }
      },
      required: ['enabled', 'title', 'dueAt', 'reason'],
      additionalProperties: false
    }
  },
  required: ['shouldAct', 'rationale', 'action', 'commitment'],
  additionalProperties: false
};

const reflectionSchema = {
  type: 'object',
  properties: {
    whatHappened: { type: 'string' },
    whatWasLearned: { type: 'string' },
    whoWasAffected: { type: 'string' },
    whatShouldChange: { type: 'string' },
    confidence: { type: 'number', minimum: 0, maximum: 1 }
  },
  required: [
    'whatHappened',
    'whatWasLearned',
    'whoWasAffected',
    'whatShouldChange',
    'confidence'
  ],
  additionalProperties: false
};

function safeParseObject(text) {
  if (!text) {
    return {};
  }

  try {
    return JSON.parse(text);
  }
  catch (error) {
    return {};
  }
}

function OpenAICognition(options) {
  options = options || {};

  this.client = options.client || new OpenAI({
    apiKey: options.apiKey
  });

  this.model = options.model || 'gpt-5.6';
  this.reflectWithModel = options.reflectWithModel !== false;
}

OpenAICognition.prototype.consider = function (context) {
  return Promise.resolve({
    purpose: context.being.purpose || [],
    character: context.being.character || {},
    activeCommitments: (context.being.commitments || []).filter(function (item) {
      return item.status === 'active';
    }),
    availableTools: context.tools || []
  });
};

OpenAICognition.prototype.decide = function (context) {
  const self = this;

  const instructions = [
    'You are the cognition component inside an Octonomous being.',
    'You may propose actions, but you do not have authority to execute them.',
    'The runtime will independently govern every proposed action.',
    'Act only when the event materially relates to the being purpose.',
    'Use the being character as behavioural constraints: Curious, Caring, Constructive, Chill.',
    'Only select a tool from availableTools.',
    'If no action is useful, set shouldAct=false and action.enabled=false.',
    'If a future obligation is genuinely created, propose a commitment with an ISO-8601 dueAt.',
    'Otherwise set commitment.enabled=false and leave its string fields empty.',
    'For action.inputJson return a JSON object encoded as a string.'
  ].join('\n');

  const input = JSON.stringify({
    being: {
      id: context.being.id,
      identity: context.being.identity,
      purpose: context.being.purpose,
      character: context.being.character,
      activeCommitments: context.consideration.activeCommitments
    },
    event: context.event,
    recentReflections: context.observation.being.recentReflections,
    availableTools: context.tools
  }, null, 2);

  return self.client.responses.create({
    model: self.model,
    instructions: instructions,
    input: input,
    text: {
      format: {
        type: 'json_schema',
        name: 'octonomous_decision',
        strict: true,
        schema: decisionSchema
      }
    }
  })
    .then(function (response) {
      const decision = JSON.parse(response.output_text);

      decision.action.input = safeParseObject(decision.action.inputJson);
      delete decision.action.inputJson;

      return decision;
    });
};

OpenAICognition.prototype.reflect = function (context) {
  const self = this;

  if (!self.reflectWithModel) {
    return Promise.resolve({
      whatHappened: 'The being processed event ' + context.event.type + '.',
      whatWasLearned: 'The event lifecycle completed and was persisted.',
      whoWasAffected: 'See the event and action result.',
      whatShouldChange: 'No automatic change proposed.',
      confidence: 0.7
    });
  }

  return self.client.responses.create({
    model: self.model,
    instructions: [
      'Reflect on the completed action for a persistent autonomous being.',
      'Be concise and factual.',
      'Do not invent effects that are not present in the action result.',
      'The reflection becomes durable memory and can influence future decisions.'
    ].join('\n'),
    input: JSON.stringify({
      purpose: context.being.purpose,
      event: context.event,
      decision: context.decision,
      governance: context.governance,
      commitment: context.commitment || null,
      actionResult: context.actionResult
    }, null, 2),
    text: {
      format: {
        type: 'json_schema',
        name: 'octonomous_reflection',
        strict: true,
        schema: reflectionSchema
      }
    }
  })
    .then(function (response) {
      return JSON.parse(response.output_text);
    });
};

module.exports = OpenAICognition;
