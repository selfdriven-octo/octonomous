function MockCognition() {}

MockCognition.prototype.consider = function (context) {
  return Promise.resolve({
    relevant: true,
    availableTools: context.tools || []
  });
};

MockCognition.prototype.decide = function (context) {
  const echoAvailable = (context.tools || []).some(function (tool) {
    return tool.name === 'echo';
  });

  return Promise.resolve({
    shouldAct: echoAvailable,
    rationale: 'Mock cognition selected a safe demonstration action.',
    action: {
      enabled: echoAvailable,
      tool: echoAvailable ? 'echo' : '',
      input: {
        eventType: context.event.type,
        payload: context.event.payload
      }
    },
    commitment: {
      enabled: false,
      title: '',
      dueAt: '',
      reason: ''
    }
  });
};

MockCognition.prototype.reflect = function () {
  return Promise.resolve({
    whatHappened: 'Mock cognition completed the lifecycle.',
    whatWasLearned: 'The runtime is functioning.',
    whoWasAffected: 'No external party.',
    whatShouldChange: 'Nothing.',
    confidence: 1
  });
};

module.exports = MockCognition;
