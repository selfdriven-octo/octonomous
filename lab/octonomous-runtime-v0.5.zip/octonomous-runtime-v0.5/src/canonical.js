const crypto = require('crypto');

function sortValue(value) {
  if (Array.isArray(value)) {
    return value.map(sortValue);
  }

  if (value && typeof value === 'object') {
    return Object.keys(value).sort().reduce(function (out, key) {
      if (value[key] !== undefined) {
        out[key] = sortValue(value[key]);
      }
      return out;
    }, {});
  }

  return value;
}

function canonicalJson(value) {
  return JSON.stringify(sortValue(value));
}

function sha256(value) {
  return crypto.createHash('sha256')
    .update(typeof value === 'string' ? value : canonicalJson(value))
    .digest('base64url');
}

module.exports = {
  canonicalJson: canonicalJson,
  sha256: sha256
};
