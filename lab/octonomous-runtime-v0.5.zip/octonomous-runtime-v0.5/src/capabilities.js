const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function isSubsetArray(child, parent) {
  if (!Array.isArray(parent)) {
    return true;
  }
  if (!Array.isArray(child)) {
    return false;
  }
  return child.every(function (value) { return parent.includes(value); });
}

function constraintsNarrowerOrEqual(child, parent) {
  child = child || {};
  parent = parent || {};

  if (Array.isArray(parent.targetBeingIds)) {
    if (!isSubsetArray(child.targetBeingIds, parent.targetBeingIds)) {
      return false;
    }
  }

  if (parent.inputEquals && typeof parent.inputEquals === 'object') {
    const childInputEquals = child.inputEquals || {};
    const keys = Object.keys(parent.inputEquals);
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      if (childInputEquals[key] !== parent.inputEquals[key]) {
        return false;
      }
    }
  }

  return true;
}

function CapabilityService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
  this.credentials = options.credentials || null;
}

CapabilityService.prototype._sign = function (kind, beingId, subject, evidence) {
  if (!this.receipts) {
    return Promise.resolve(null);
  }

  return this.receipts.create({
    kind: kind,
    beingId: beingId,
    subject: subject,
    evidence: evidence || {}
  });
};

CapabilityService.prototype._issue = function (being, capability) {
  if (!this.credentials) {
    return Promise.resolve(null);
  }
  return this.credentials.issueCapability({
    issuerBeing: being,
    capability: capability
  });
};

CapabilityService.prototype._publishGrant = function (being, capability) {
  if (!this.publisher) {
    return Promise.resolve({ ok: true, capability: capability, event: null });
  }

  return this.publisher.publish({
    type: 'capability.granted',
    sourceBeingId: being.id,
    targetBeingId: capability.subjectBeingId,
    payload: {
      capability: capability,
      sourceBeingId: being.id
    }
  })
    .then(function (event) {
      capability.deliveryEventId = event.id;
      return { ok: true, capability: capability, event: event };
    });
};

CapabilityService.prototype.grant = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};

  if (!input.targetBeingId) {
    return Promise.reject(new Error('capability.grant requires targetBeingId'));
  }

  if (!input.tool) {
    return Promise.reject(new Error('capability.grant requires tool'));
  }

  being.capabilities = being.capabilities || { granted: [], received: [] };
  being.capabilities.granted = being.capabilities.granted || [];

  const capability = {
    id: crypto.randomUUID(),
    version: 'octonomous.capability.v2',
    issuerBeingId: being.id,
    rootIssuerBeingId: being.id,
    subjectBeingId: input.targetBeingId,
    subjectAid: input.subjectAid || null,
    tool: input.tool,
    constraints: clone(input.constraints || {}),
    delegable: Boolean(input.delegable),
    expiresAt: input.expiresAt || null,
    status: 'active',
    delegationDepth: 0,
    delegationChain: [],
    createdAt: new Date().toISOString(),
    sourceEventId: context.event && context.event.id,
    credential: null,
    receipt: null
  };

  being.capabilities.granted.push(capability);

  return self._issue(being, capability)
    .then(function (credential) {
      capability.credential = credential;
      return self._sign('capability.granted', being.id, capability, {
        sourceEventId: capability.sourceEventId
      });
    })
    .then(function (receipt) {
      capability.receipt = receipt;
      return self._publishGrant(being, capability);
    });
};

CapabilityService.prototype.delegate = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const received = being.capabilities && being.capabilities.received || [];
  const parent = received.find(function (item) { return item.id === input.parentCapabilityId; });

  if (!input.targetBeingId || !input.parentCapabilityId) {
    return Promise.reject(new Error('capability.delegate requires targetBeingId and parentCapabilityId'));
  }
  if (!parent) {
    return Promise.reject(new Error('Unknown received parent capability: ' + input.parentCapabilityId));
  }
  if (parent.status !== 'active') {
    return Promise.reject(new Error('Parent capability is not active'));
  }
  if (!parent.delegable) {
    return Promise.reject(new Error('Parent capability is not delegable'));
  }
  if (parent.expiresAt && new Date(parent.expiresAt) <= new Date()) {
    return Promise.reject(new Error('Parent capability is expired'));
  }

  const requestedConstraints = input.constraints === undefined
    ? clone(parent.constraints || {})
    : clone(input.constraints || {});

  if (!constraintsNarrowerOrEqual(requestedConstraints, parent.constraints || {})) {
    return Promise.reject(new Error('Delegated capability constraints may not broaden parent authority'));
  }

  const childExpiresAt = input.expiresAt || parent.expiresAt || null;
  if (parent.expiresAt && childExpiresAt && new Date(childExpiresAt) > new Date(parent.expiresAt)) {
    return Promise.reject(new Error('Delegated capability may not outlive parent capability'));
  }

  being.capabilities = being.capabilities || { granted: [], received: [] };
  being.capabilities.granted = being.capabilities.granted || [];

  const link = {
    capabilityId: parent.id,
    issuerBeingId: parent.issuerBeingId,
    subjectBeingId: parent.subjectBeingId,
    receiptId: parent.receipt && parent.receipt.id || null,
    status: parent.status,
    expiresAt: parent.expiresAt || null
  };

  const capability = {
    id: crypto.randomUUID(),
    version: 'octonomous.capability.v2',
    issuerBeingId: being.id,
    rootIssuerBeingId: parent.rootIssuerBeingId || parent.issuerBeingId,
    subjectBeingId: input.targetBeingId,
    subjectAid: input.subjectAid || null,
    tool: parent.tool,
    constraints: requestedConstraints,
    delegable: Boolean(input.delegable) && Boolean(parent.delegable),
    expiresAt: childExpiresAt,
    status: 'active',
    delegatedFromCapabilityId: parent.id,
    delegationDepth: Number(parent.delegationDepth || 0) + 1,
    delegationChain: (parent.delegationChain || []).concat([link]),
    createdAt: new Date().toISOString(),
    sourceEventId: context.event && context.event.id,
    credential: null,
    receipt: null
  };

  being.capabilities.granted.push(capability);

  return self._issue(being, capability)
    .then(function (credential) {
      capability.credential = credential;
      return self._sign('capability.delegated', being.id, capability, {
        parentCapabilityId: parent.id,
        parentReceiptId: parent.receipt && parent.receipt.id || null
      });
    })
    .then(function (receipt) {
      capability.receipt = receipt;
      return self._publishGrant(being, capability);
    });
};

CapabilityService.prototype.revoke = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const granted = being.capabilities && being.capabilities.granted || [];
  const capability = granted.find(function (item) {
    return item.id === input.capabilityId;
  });

  if (!capability) {
    return Promise.reject(new Error('Unknown granted capability: ' + input.capabilityId));
  }

  if (capability.status === 'revoked') {
    return Promise.resolve({ ok: true, capability: capability, alreadyRevoked: true });
  }

  capability.status = 'revoked';
  capability.revokedAt = new Date().toISOString();
  capability.revokedByBeingId = being.id;
  capability.revocationReason = input.reason || '';

  const credentialPromise = self.credentials && capability.credential
    ? self.credentials.revokeCapability({
      issuerBeing: being,
      capability: capability,
      credential: capability.credential,
      reason: input.reason || ''
    })
    : Promise.resolve(null);

  return credentialPromise
    .then(function (credentialRevocation) {
      capability.credentialRevocation = credentialRevocation;
      return self._sign('capability.revoked', being.id, capability, {
        reason: input.reason || ''
      });
    })
    .then(function (receipt) {
      capability.revocationReceipt = receipt;

      if (!self.publisher) {
        return { ok: true, capability: capability, event: null };
      }

      return self.publisher.publish({
        type: 'capability.revoked',
        sourceBeingId: being.id,
        targetBeingId: capability.subjectBeingId,
        payload: {
          capabilityId: capability.id,
          capability: capability,
          reason: input.reason || '',
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          capability.revocationEventId = event.id;
          return { ok: true, capability: capability, event: event };
        });
    });
};

CapabilityService.prototype.observeEvent = function (being, event) {
  if (!event || !event.payload) {
    return null;
  }

  being.capabilities = being.capabilities || { granted: [], received: [] };
  being.capabilities.received = being.capabilities.received || [];

  if (event.type === 'capability.granted' && event.payload.capability) {
    const incoming = clone(event.payload.capability);
    const existing = being.capabilities.received.find(function (item) {
      return item.id === incoming.id;
    });

    if (!existing) {
      incoming.receivedAt = new Date().toISOString();
      being.capabilities.received.push(incoming);
      return incoming;
    }

    return existing;
  }

  if (event.type === 'capability.revoked') {
    const id = event.payload.capabilityId || (event.payload.capability && event.payload.capability.id);
    let affected = null;

    being.capabilities.received.forEach(function (item) {
      if (item.id === id) {
        item.status = 'revoked';
        item.revokedAt = event.payload.capability && event.payload.capability.revokedAt
          ? event.payload.capability.revokedAt
          : new Date().toISOString();
        item.revocationReason = event.payload.reason || '';
        affected = item;
      }

      const chain = item.delegationChain || [];
      if (chain.some(function (link) { return link.capabilityId === id; })) {
        item.status = 'revoked_by_ancestor';
        item.revokedByAncestorCapabilityId = id;
        item.revokedAt = new Date().toISOString();
        affected = item;
      }
    });

    return affected;
  }

  return null;
};

CapabilityService.prototype.activeForAction = function (being, action, now) {
  const capabilities = being.capabilities && being.capabilities.received || [];
  const when = now ? new Date(now) : new Date();

  return capabilities.filter(function (capability) {
    if (!capability || capability.status !== 'active') {
      return false;
    }

    if (capability.subjectBeingId && capability.subjectBeingId !== being.id) {
      return false;
    }

    if (capability.tool !== action.tool) {
      return false;
    }

    if (capability.expiresAt && new Date(capability.expiresAt) <= when) {
      return false;
    }

    const chain = capability.delegationChain || [];
    if (chain.some(function (link) {
      return link.status === 'revoked' || (link.expiresAt && new Date(link.expiresAt) <= when);
    })) {
      return false;
    }

    const constraints = capability.constraints || {};
    const input = action.input || {};

    if (Array.isArray(constraints.targetBeingIds) && input.targetBeingId) {
      if (!constraints.targetBeingIds.includes(input.targetBeingId)) {
        return false;
      }
    }

    if (constraints.inputEquals && typeof constraints.inputEquals === 'object') {
      const keys = Object.keys(constraints.inputEquals);
      for (let i = 0; i < keys.length; i += 1) {
        const key = keys[i];
        if (input[key] !== constraints.inputEquals[key]) {
          return false;
        }
      }
    }

    return true;
  });
};

CapabilityService.constraintsNarrowerOrEqual = constraintsNarrowerOrEqual;

module.exports = CapabilityService;
