const {
  Client,
  StreamableHTTPClientTransport
} = require('@modelcontextprotocol/client');

function MCPManager(options) {
  options = options || {};

  this.registry = options.registry;
  this.connections = [];
}

MCPManager.prototype.connectServer = function (config) {
  const self = this;
  const client = new Client({
    name: 'octonomous-runtime-' + config.name,
    version: '0.2.0'
  });

  const transportOptions = {};

  if (config.token) {
    transportOptions.authProvider = {
      token: function () {
        return Promise.resolve(config.token);
      }
    };
  }

  const transport = new StreamableHTTPClientTransport(
    new URL(config.url),
    transportOptions
  );

  return client.connect(transport)
    .then(function () {
      return client.listTools();
    })
    .then(function (result) {
      (result.tools || []).forEach(function (tool) {
        const registeredName = 'mcp:' + config.name + ':' + tool.name;

        self.registry.register({
          name: registeredName,
          description: tool.description || '',
          inputSchema: tool.inputSchema || null,
          source: 'mcp:' + config.name
        }, function (input) {
          return client.callTool({
            name: tool.name,
            arguments: input || {}
          })
            .then(function (toolResult) {
              return {
                ok: !toolResult.isError,
                isError: Boolean(toolResult.isError),
                content: toolResult.content || []
              };
            });
        });
      });

      self.connections.push({
        name: config.name,
        client: client,
        transport: transport
      });

      return {
        name: config.name,
        tools: (result.tools || []).map(function (tool) {
          return tool.name;
        })
      };
    });
};

MCPManager.prototype.close = function () {
  const closes = this.connections.map(function (connection) {
    if (connection.client && typeof connection.client.close === 'function') {
      return Promise.resolve(connection.client.close());
    }
    return Promise.resolve();
  });

  return Promise.all(closes);
};

module.exports = MCPManager;
