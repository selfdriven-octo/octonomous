const path = require('path');
const Runtime = require('./runtime');
const Policy = require('./policy');
const ToolRegistry = require('./tools');
const CommitmentService = require('./commitments');
const ApprovalService = require('./approvals');
const RelationshipService = require('./relationships');
const ContributionService = require('./contributions');
const DelegationService = require('./delegations');
const CapabilityService = require('./capabilities');
const VerificationService = require('./verifications');
const ConstitutionService = require('./governance/constitutions');
const GovernanceProposalService = require('./governance/proposals');
const ChallengeService = require('./governance/challenges');
const VerificationQuorumService = require('./governance/quorum');
const EvidenceReputationService = require('./reputation/evidence');
const AcdcCredentialService = require('./credentials/acdc');
const EvidenceAnchorService = require('./anchors/evidence');
const CardanoProvider = require('./anchors/cardano-provider');
const ReceiptService = require('./receipts/service');
const LocalEd25519Signer = require('./receipts/local-ed25519');
const KeriSigner = require('./receipts/keri');
const FileStore = require('./store/file');
const DynamoDBStore = require('./store/dynamodb');
const OpenAICognition = require('./cognition/openai');
const MockCognition = require('./cognition/mock');
const EventBridgePublisher = require('./events/eventbridge');
const ReminderScheduler = require('./events/scheduler');
const MCPManager = require('./mcp');
const Secrets = require('./secrets');

function bool(value, fallback) {
  if (value === undefined || value === '') {
    return fallback;
  }
  return String(value).toLowerCase() === 'true';
}

function parseMcpServers() {
  if (!process.env.MCP_SERVERS_JSON) {
    return [];
  }
  return JSON.parse(process.env.MCP_SERVERS_JSON);
}

function loadProviderModule(modulePath, options) {
  if (!modulePath) {
    return null;
  }

  const providerPath = path.isAbsolute(modulePath)
    ? modulePath
    : path.resolve(process.cwd(), modulePath);
  const loaded = require(providerPath);

  return typeof loaded.createProvider === 'function'
    ? loaded.createProvider(options || {})
    : loaded;
}

function createStore() {
  if (process.env.STORE_MODE === 'dynamodb') {
    return new DynamoDBStore({
      tableName: process.env.DYNAMODB_TABLE,
      region: process.env.AWS_REGION
    });
  }

  return new FileStore({
    basePath: process.env.DATA_PATH || path.join(process.cwd(), 'data')
  });
}

function resolveOpenAIKey(secrets) {
  if (process.env.OPENAI_API_KEY) {
    return Promise.resolve(process.env.OPENAI_API_KEY);
  }

  if (process.env.OPENAI_API_KEY_SECRET_ARN) {
    return secrets.get(
      process.env.OPENAI_API_KEY_SECRET_ARN,
      process.env.OPENAI_API_KEY_SECRET_JSON_KEY || undefined
    );
  }

  return Promise.resolve(null);
}

function resolveMcpServerSecrets(servers, secrets) {
  return Promise.all(servers.map(function (server) {
    if (!server.tokenSecretArn) {
      return server;
    }

    return secrets.get(server.tokenSecretArn, server.tokenSecretJsonKey)
      .then(function (token) {
        return Object.assign({}, server, { token: token });
      });
  }));
}

function createReceiptSigner() {
  const mode = process.env.RECEIPT_MODE || 'local';

  if (mode === 'none') {
    return null;
  }

  if (mode === 'keri') {
    if (!process.env.KERI_SIGNER_MODULE) {
      throw new Error('RECEIPT_MODE=keri requires KERI_SIGNER_MODULE');
    }

    const provider = loadProviderModule(process.env.KERI_SIGNER_MODULE, {
      aid: process.env.KERI_AID,
      keriaUrl: process.env.KERIA_URL
    });

    return new KeriSigner({
      aid: process.env.KERI_AID,
      provider: provider
    });
  }

  return new LocalEd25519Signer({
    aid: process.env.LOCAL_RECEIPT_AID || 'did:key:local-development',
    privateKeyPem: process.env.RECEIPT_PRIVATE_KEY_PEM,
    publicKeyPem: process.env.RECEIPT_PUBLIC_KEY_PEM
  });
}

function bootstrap() {
  const region = process.env.AWS_REGION;
  const tools = new ToolRegistry();
  const secrets = new Secrets({ region: region });
  const store = createStore();
  const receiptSigner = createReceiptSigner();
  const receipts = new ReceiptService({ signer: receiptSigner });

  const eventPublisher = process.env.EVENT_BUS_NAME
    ? new EventBridgePublisher({
      busName: process.env.EVENT_BUS_NAME,
      region: region
    })
    : null;

  const scheduler = process.env.WAKE_QUEUE_ARN && process.env.SCHEDULER_TARGET_ROLE_ARN
    ? new ReminderScheduler({
      queueArn: process.env.WAKE_QUEUE_ARN,
      roleArn: process.env.SCHEDULER_TARGET_ROLE_ARN,
      region: region
    })
    : null;

  const acdcProvider = loadProviderModule(process.env.ACDC_PROVIDER_MODULE, {
    keriaUrl: process.env.KERIA_URL,
    registryName: process.env.ACDC_REGISTRY_NAME
  });

  const credentials = new AcdcCredentialService({
    provider: acdcProvider,
    receipts: receipts
  });

  const capabilities = new CapabilityService({
    publisher: eventPublisher,
    receipts: receipts,
    credentials: credentials
  });

  const delegations = new DelegationService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const relationships = new RelationshipService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const commitments = new CommitmentService({
    scheduler: scheduler,
    receipts: receipts,
    publisher: eventPublisher
  });

  const verifications = new VerificationService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const constitutions = new ConstitutionService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const governance = new GovernanceProposalService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const challenges = new ChallengeService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const quorum = new VerificationQuorumService({
    publisher: eventPublisher,
    receipts: receipts
  });

  const reputation = new EvidenceReputationService({
    receipts: receipts
  });

  let cardanoProvider = loadProviderModule(process.env.CARDANO_ANCHOR_MODULE, {
    network: process.env.CARDANO_NETWORK || 'preprod'
  });
  if (cardanoProvider) {
    cardanoProvider = new CardanoProvider({ provider: cardanoProvider });
  }

  const anchors = new EvidenceAnchorService({
    provider: cardanoProvider,
    receipts: receipts,
    metadataLabel: process.env.CARDANO_METADATA_LABEL || '1337',
    network: process.env.CARDANO_NETWORK || 'preprod'
  });

  tools.register({
    name: 'echo',
    description: 'Return the supplied input unchanged.',
    inputSchema: { type: 'object' },
    source: 'local'
  }, function (input) {
    return Promise.resolve({ ok: true, output: input });
  });

  tools.register({
    name: 'commitment.fulfil',
    description: 'Mark one of this being\'s commitments fulfilled with outcome/evidence.',
    inputSchema: {
      type: 'object',
      required: ['commitmentId'],
      properties: {
        commitmentId: { type: 'string' },
        outcome: {},
        evidence: {},
        reason: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return commitments.fulfil({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'commitment.violate',
    description: 'Record that one of this being\'s commitments was violated.',
    inputSchema: {
      type: 'object',
      required: ['commitmentId'],
      properties: {
        commitmentId: { type: 'string' },
        outcome: {},
        evidence: {},
        reason: { type: 'string' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return commitments.violate({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'contribution.verify',
    description: 'Create a signed third-party verification record for an Octomics contribution.',
    inputSchema: {
      type: 'object',
      required: ['contribution'],
      properties: {
        contribution: { type: 'object' },
        verdict: { type: 'string' },
        notes: { type: 'string' },
        evidenceChecks: { type: 'object' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return verifications.verify({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'evidence.anchor',
    description: 'Batch unanchored signed evidence into a Merkle root and optionally submit it to Cardano.',
    inputSchema: {
      type: 'object',
      properties: {
        limit: { type: 'integer' },
        includeAnchored: { type: 'boolean' }
      }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return anchors.anchor({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'constitution.adopt',
    description: 'Adopt or supersede this being\'s signed constitution/policy set.',
    inputSchema: {
      type: 'object',
      required: ['constitution'],
      properties: { constitution: { type: 'object' } }
    },
    source: 'octonomous'
  }, function (input, executionContext) {
    return constitutions.adopt({
      being: executionContext.being,
      event: executionContext.event,
      input: input
    });
  });

  tools.register({
    name: 'reputation.compute',
    description: 'Compute a reputation report from signed evidence without mutating counters.',
    inputSchema: { type: 'object' },
    source: 'octonomous'
  }, function (input, executionContext) {
    return reputation.compute(executionContext.being)
      .then(function (report) { return { ok: true, report: report }; });
  });

  if (eventPublisher) {
    tools.register({
      name: 'event.publish',
      description: 'Publish a targeted event to another Octonomous being.',
      inputSchema: {
        type: 'object',
        properties: {
          targetBeingId: { type: 'string' },
          type: { type: 'string' },
          payload: { type: 'object' }
        }
      },
      source: 'local'
    }, function (input, executionContext) {
      return eventPublisher.publish({
        sourceBeingId: executionContext.being && executionContext.being.id,
        targetBeingId: input.targetBeingId,
        type: input.type,
        payload: input.payload || {}
      })
        .then(function (event) {
          return { ok: true, event: event };
        });
    });

    tools.register({
      name: 'being.delegate',
      description: 'Delegate an intent or bounded task to another Octonomous being.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'intent'],
        properties: {
          targetBeingId: { type: 'string' },
          intent: { type: 'string' },
          requestedAction: { type: 'object' },
          constraints: { type: 'object' },
          capabilityIds: { type: 'array', items: { type: 'string' } }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.create({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'being.delegate.accept',
      description: 'Accept an incoming delegation.',
      inputSchema: {
        type: 'object',
        required: ['delegationId'],
        properties: { delegationId: { type: 'string' }, reason: { type: 'string' } }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.accept({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'being.delegate.reject',
      description: 'Reject an incoming delegation.',
      inputSchema: {
        type: 'object',
        required: ['delegationId'],
        properties: { delegationId: { type: 'string' }, reason: { type: 'string' } }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.reject({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'being.delegate.complete',
      description: 'Complete an accepted delegation with outcome and evidence.',
      inputSchema: {
        type: 'object',
        required: ['delegationId'],
        properties: {
          delegationId: { type: 'string' }, outcome: {}, evidence: {}, reason: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return delegations.complete({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'capability.grant',
      description: 'Grant a bounded, revocable tool capability to another being.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'tool'],
        properties: {
          targetBeingId: { type: 'string' },
          subjectAid: { type: 'string' },
          tool: { type: 'string' },
          constraints: { type: 'object' },
          delegable: { type: 'boolean' },
          expiresAt: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return capabilities.grant({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'capability.revoke',
      description: 'Revoke a capability previously granted by this being.',
      inputSchema: {
        type: 'object',
        required: ['capabilityId'],
        properties: { capabilityId: { type: 'string' }, reason: { type: 'string' } }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return capabilities.revoke({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'relationship.assert',
      description: 'Create a signed assertion about this being\'s relationship to another being.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'relationshipType'],
        properties: {
          targetBeingId: { type: 'string' },
          relationshipType: { type: 'string' },
          claims: { type: 'object' },
          validUntil: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return relationships.assert({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'contribution.verification.request',
      description: 'Ask another being to independently verify an Octomics contribution.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'contribution'],
        properties: {
          targetBeingId: { type: 'string' },
          contribution: { type: 'object' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return verifications.request({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'capability.delegate',
      description: 'Delegate a received capability without broadening its authority.',
      inputSchema: {
        type: 'object',
        required: ['parentCapabilityId', 'targetBeingId'],
        properties: {
          parentCapabilityId: { type: 'string' },
          targetBeingId: { type: 'string' },
          subjectAid: { type: 'string' },
          constraints: { type: 'object' },
          delegable: { type: 'boolean' },
          expiresAt: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return capabilities.delegate({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'governance.vote',
      description: 'Cast a signed approve/reject/abstain vote on an incoming governance proposal.',
      inputSchema: {
        type: 'object',
        required: ['proposal', 'vote'],
        properties: {
          proposal: { type: 'object' },
          vote: { type: 'string', enum: ['approve', 'reject', 'abstain'] },
          reason: { type: 'string' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return governance.castVote({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'challenge.open',
      description: 'Open a signed challenge against a contribution, commitment, delegation, verification, or other evidence.',
      inputSchema: {
        type: 'object',
        required: ['targetBeingId', 'subjectKind', 'subjectId'],
        properties: {
          targetBeingId: { type: 'string' },
          subjectKind: { type: 'string' },
          subjectId: { type: 'string' },
          claim: { type: 'string' },
          evidence: { type: 'object' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return challenges.open({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'challenge.respond',
      description: 'Respond to an open challenge with signed evidence.',
      inputSchema: {
        type: 'object',
        required: ['challengeId'],
        properties: { challengeId: { type: 'string' }, response: { type: 'string' }, evidence: { type: 'object' } }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return challenges.respond({ being: executionContext.being, event: executionContext.event, input: input });
    });

    tools.register({
      name: 'challenge.resolve',
      description: 'Resolve a challenge as upheld, dismissed, or partially_upheld.',
      inputSchema: {
        type: 'object',
        required: ['verdict'],
        properties: {
          challengeId: { type: 'string' },
          challenge: { type: 'object' },
          verdict: { type: 'string', enum: ['upheld', 'dismissed', 'partially_upheld'] },
          resolution: { type: 'string' },
          evidence: { type: 'object' }
        }
      },
      source: 'octonomous'
    }, function (input, executionContext) {
      return challenges.resolve({ being: executionContext.being, event: executionContext.event, input: input });
    });
  }

  return resolveOpenAIKey(secrets)
    .then(function (apiKey) {
      const cognitionMode = process.env.COGNITION_MODE || (apiKey ? 'openai' : 'mock');
      let cognition;

      if (cognitionMode === 'openai') {
        if (!apiKey) {
          throw new Error('COGNITION_MODE=openai but no OpenAI API key is configured');
        }

        cognition = new OpenAICognition({
          apiKey: apiKey,
          model: process.env.OPENAI_MODEL || 'gpt-5.6',
          reflectWithModel: bool(process.env.REFLECT_WITH_MODEL, true)
        });
      }
      else {
        cognition = new MockCognition();
      }

      const runtime = new Runtime({
        store: store,
        cognition: cognition,
        policy: new Policy({ capabilities: capabilities, constitutions: constitutions }),
        tools: tools,
        commitments: commitments,
        approvals: new ApprovalService({
          publisher: eventPublisher,
          receipts: receipts
        }),
        relationships: relationships,
        contributions: new ContributionService({
          receipts: receipts,
          publisher: eventPublisher
        }),
        receipts: receipts,
        delegations: delegations,
        capabilities: capabilities,
        verifications: verifications,
        governance: governance,
        challenges: challenges,
        quorum: quorum,
        reputation: reputation
      });

      const mcp = new MCPManager({ registry: tools });

      return resolveMcpServerSecrets(parseMcpServers(), secrets)
        .then(function (servers) {
          return Promise.all(servers.map(function (server) {
            return mcp.connectServer(server);
          }));
        })
        .then(function () {
          return {
            runtime: runtime,
            tools: tools,
            mcp: mcp,
            eventPublisher: eventPublisher,
            receipts: receipts,
            delegations: delegations,
            capabilities: capabilities,
            relationships: relationships,
            commitments: commitments,
            verifications: verifications,
            anchors: anchors,
            credentials: credentials,
            constitutions: constitutions,
            governance: governance,
            challenges: challenges,
            quorum: quorum,
            reputation: reputation
          };
        });
    });
}

module.exports = bootstrap;
