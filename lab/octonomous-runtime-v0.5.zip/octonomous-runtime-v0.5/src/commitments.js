const crypto = require('crypto');

function commitmentId(beingId, eventId, title) {
  return crypto.createHash('sha256')
    .update([beingId, eventId || '', title || ''].join('|'))
    .digest('hex')
    .slice(0, 32);
}

function CommitmentService(options) {
  options = options || {};
  this.scheduler = options.scheduler || null;
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
}

CommitmentService.prototype._receipt = function (kind, beingId, subject, evidence) {
  if (!this.receipts) {
    return Promise.resolve(null);
  }

  return this.receipts.create({
    kind: kind,
    beingId: beingId,
    subject: subject,
    evidence: evidence || {}
  });
};

CommitmentService.prototype.create = function (context) {
  const self = this;
  const being = context.being;
  const proposal = context.proposal;
  const id = commitmentId(being.id, context.event.id, proposal.title);

  being.commitments = being.commitments || [];

  const existing = being.commitments.find(function (item) {
    return item.id === id;
  });

  if (existing) {
    return Promise.resolve(existing);
  }

  const commitment = {
    id: id,
    version: 'octonomous.commitment.v2',
    beingId: being.id,
    title: proposal.title,
    reason: proposal.reason,
    dueAt: proposal.dueAt,
    status: 'active',
    createdAt: new Date().toISOString(),
    sourceEventId: context.event.id,
    receipt: null
  };

  being.commitments.push(commitment);

  return self._receipt('commitment.created', being.id, commitment, {
    sourceEventId: context.event.id
  })
    .then(function (receipt) {
      commitment.receipt = receipt;

      if (!self.scheduler || !commitment.dueAt) {
        return commitment;
      }

      return self.scheduler.scheduleCommitment({
        beingId: being.id,
        commitment: commitment
      })
        .then(function (schedule) {
          commitment.reminder = schedule;
          return commitment;
        });
    });
};

CommitmentService.prototype.markDue = function (being, id) {
  const commitment = (being.commitments || []).find(function (item) {
    return item.id === id;
  });

  if (!commitment) {
    return null;
  }

  if (commitment.status === 'active') {
    commitment.status = 'due';
    commitment.dueObservedAt = new Date().toISOString();
  }

  return commitment;
};

CommitmentService.prototype._transition = function (status, context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const commitment = (being.commitments || []).find(function (item) {
    return item.id === input.commitmentId;
  });

  if (!commitment) {
    return Promise.reject(new Error('Unknown commitment: ' + input.commitmentId));
  }

  if (['fulfilled', 'violated', 'cancelled'].includes(commitment.status)) {
    if (commitment.status === status) {
      return Promise.resolve({ ok: true, commitment: commitment, alreadyFinal: true });
    }
    return Promise.reject(new Error('Commitment is already final: ' + commitment.status));
  }

  commitment.status = status;
  commitment[status + 'At'] = new Date().toISOString();
  commitment.outcome = input.outcome || null;
  commitment.evidence = input.evidence || null;
  commitment.reason = input.reason || commitment.reason;

  return self._receipt('commitment.' + status, being.id, commitment, {
    sourceEventId: context.event && context.event.id
  })
    .then(function (receipt) {
      commitment[status + 'Receipt'] = receipt;

      if (!self.publisher) {
        return { ok: true, commitment: commitment, event: null };
      }

      return self.publisher.publish({
        type: 'commitment.' + status,
        sourceBeingId: being.id,
        payload: {
          commitment: commitment,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          commitment[status + 'EventId'] = event.id;
          return { ok: true, commitment: commitment, event: event };
        });
    });
};

CommitmentService.prototype.fulfil = function (context) {
  return this._transition('fulfilled', context);
};

CommitmentService.prototype.violate = function (context) {
  return this._transition('violated', context);
};

module.exports = CommitmentService;
