/*
 * Cardano anchoring adapter boundary.
 *
 * Supply a module that exports createProvider() or an object exposing:
 *
 *   anchor({ root, metadataLabel, metadata, evidence, network })
 *      -> Promise<{ txId, network, submittedAt, ... }>
 *
 * The provider owns wallet/key selection, transaction construction, signing,
 * submission and confirmation. The runtime only supplies the compact hash root
 * and metadata. This keeps private Cardano payment keys out of Octonomous core.
 */
function CardanoProvider(options) {
  options = options || {};
  if (!options.provider || typeof options.provider.anchor !== 'function') {
    throw new Error('CardanoProvider requires provider.anchor()');
  }
  this.provider = options.provider;
}

CardanoProvider.prototype.anchor = function (context) {
  return Promise.resolve(this.provider.anchor(context));
};

module.exports = CardanoProvider;
