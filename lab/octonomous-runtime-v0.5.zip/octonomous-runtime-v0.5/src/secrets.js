const {
  SecretsManagerClient,
  GetSecretValueCommand
} = require('@aws-sdk/client-secrets-manager');

function Secrets(options) {
  options = options || {};
  this.client = options.client || new SecretsManagerClient({
    region: options.region
  });
  this.cache = new Map();
}

Secrets.prototype.get = function (arn, jsonKey) {
  const self = this;
  const cacheKey = arn + '|' + (jsonKey || '');

  if (self.cache.has(cacheKey)) {
    return Promise.resolve(self.cache.get(cacheKey));
  }

  return self.client.send(new GetSecretValueCommand({
    SecretId: arn
  }))
    .then(function (result) {
      let value = result.SecretString;

      if (jsonKey) {
        const parsed = JSON.parse(value);
        value = parsed[jsonKey];
      }

      self.cache.set(cacheKey, value);
      return value;
    });
};

module.exports = Secrets;
