const bootstrap = require('../bootstrap');

let runtimePromise;

function getRuntime() {
  if (!runtimePromise) {
    runtimePromise = bootstrap().then(function (result) {
      return result.runtime;
    });
  }

  return runtimePromise;
}

function normaliseRecord(record) {
  const body = JSON.parse(record.body);

  if (body.source && body.detail) {
    return {
      beingId: body.detail.targetBeingId,
      event: {
        id: body.detail.id || body.id,
        type: body.detail.type || body['detail-type'],
        sourceBeingId: body.detail.sourceBeingId,
        payload: body.detail.payload || {},
        occurredAt: body.detail.occurredAt || body.time
      }
    };
  }

  return {
    beingId: body.targetBeingId,
    event: {
      id: body.id,
      type: body.type,
      sourceBeingId: body.sourceBeingId,
      payload: body.payload || {},
      occurredAt: body.occurredAt
    }
  };
}

exports.handler = function (event) {
  const failures = [];

  return getRuntime()
    .then(function (runtime) {
      return (event.Records || []).reduce(function (chain, record) {
        return chain.then(function () {
          let normalised;

          try {
            normalised = normaliseRecord(record);
          }
          catch (error) {
            failures.push({ itemIdentifier: record.messageId });
            return;
          }

          if (!normalised.beingId || !normalised.event.type) {
            failures.push({ itemIdentifier: record.messageId });
            return;
          }

          return runtime.handleEventForBeing(normalised.beingId, normalised.event)
            .then(function (result) {
              console.log(JSON.stringify({
                messageId: record.messageId,
                result: result
              }));
            })
            .catch(function (error) {
              console.error(error);
              failures.push({ itemIdentifier: record.messageId });
            });
        });
      }, Promise.resolve());
    })
    .then(function () {
      return { batchItemFailures: failures };
    });
};
