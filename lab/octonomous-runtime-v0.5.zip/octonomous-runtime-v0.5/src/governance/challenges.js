const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function ChallengeService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
}

ChallengeService.prototype._sign = function (kind, beingId, subject, evidence) {
  if (!this.receipts) {
    return Promise.resolve(null);
  }
  return this.receipts.create({ kind: kind, beingId: beingId, subject: subject, evidence: evidence || {} });
};

ChallengeService.prototype.open = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};

  if (!input.targetBeingId || !input.subjectId || !input.subjectKind) {
    return Promise.reject(new Error('challenge.open requires targetBeingId, subjectKind, and subjectId'));
  }

  being.challenges = being.challenges || [];
  const challenge = {
    id: crypto.randomUUID(),
    version: 'octonomous.challenge.v1',
    openedByBeingId: being.id,
    targetBeingId: input.targetBeingId,
    subjectKind: input.subjectKind,
    subjectId: input.subjectId,
    claim: input.claim || '',
    evidence: input.evidence || {},
    status: 'open',
    openedAt: new Date().toISOString(),
    receipt: null
  };
  being.challenges.push(challenge);

  return self._sign('challenge.opened', being.id, challenge, { sourceEventId: context.event && context.event.id })
    .then(function (receipt) {
      challenge.receipt = receipt;
      if (!self.publisher) {
        return { ok: true, challenge: challenge, event: null };
      }
      return self.publisher.publish({
        type: 'challenge.opened',
        sourceBeingId: being.id,
        targetBeingId: challenge.targetBeingId,
        payload: { challenge: challenge, sourceBeingId: being.id }
      })
        .then(function (event) {
          challenge.deliveryEventId = event.id;
          return { ok: true, challenge: challenge, event: event };
        });
    });
};

ChallengeService.prototype.respond = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const challenge = (being.challenges || []).find(function (item) { return item.id === input.challengeId; });

  if (!challenge) {
    return Promise.reject(new Error('Unknown challenge: ' + input.challengeId));
  }
  if (challenge.status !== 'open') {
    return Promise.reject(new Error('Challenge is not open'));
  }

  challenge.status = 'responded';
  challenge.response = input.response || '';
  challenge.responseEvidence = input.evidence || {};
  challenge.respondedAt = new Date().toISOString();
  challenge.respondedByBeingId = being.id;

  return self._sign('challenge.responded', being.id, challenge, { challengeId: challenge.id })
    .then(function (receipt) {
      challenge.responseReceipt = receipt;
      if (!self.publisher) {
        return { ok: true, challenge: challenge, event: null };
      }
      return self.publisher.publish({
        type: 'challenge.responded',
        sourceBeingId: being.id,
        targetBeingId: challenge.openedByBeingId,
        payload: { challenge: challenge, sourceBeingId: being.id }
      })
        .then(function (event) {
          challenge.responseEventId = event.id;
          return { ok: true, challenge: challenge, event: event };
        });
    });
};

ChallengeService.prototype.resolve = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const challenge = input.challenge || (being.challenges || []).find(function (item) { return item.id === input.challengeId; });
  const verdict = input.verdict;

  if (!challenge) {
    return Promise.reject(new Error('challenge.resolve requires challenge or challengeId'));
  }
  if (!['upheld', 'dismissed', 'partially_upheld'].includes(verdict)) {
    return Promise.reject(new Error('challenge.resolve verdict must be upheld, dismissed, or partially_upheld'));
  }

  challenge.status = 'resolved';
  challenge.verdict = verdict;
  challenge.resolution = input.resolution || '';
  challenge.resolutionEvidence = input.evidence || {};
  challenge.resolvedAt = new Date().toISOString();
  challenge.resolvedByBeingId = being.id;

  return self._sign('challenge.resolved', being.id, challenge, { challengeId: challenge.id })
    .then(function (receipt) {
      challenge.resolutionReceipt = receipt;

      if (!self.publisher) {
        return { ok: true, challenge: challenge, events: [] };
      }

      const targets = [challenge.openedByBeingId, challenge.targetBeingId]
        .filter(function (value, index, array) { return value && array.indexOf(value) === index; });

      return Promise.all(targets.map(function (targetBeingId) {
        return self.publisher.publish({
          type: 'challenge.resolved',
          sourceBeingId: being.id,
          targetBeingId: targetBeingId,
          payload: { challenge: challenge, sourceBeingId: being.id }
        });
      }))
        .then(function (events) {
          challenge.resolutionEventIds = events.map(function (event) { return event.id; });
          return { ok: true, challenge: challenge, events: events };
        });
    });
};

ChallengeService.prototype.observeEvent = function (being, event) {
  if (!event || !event.payload || !event.payload.challenge) {
    return null;
  }

  if (!['challenge.opened', 'challenge.responded', 'challenge.resolved'].includes(event.type)) {
    return null;
  }

  being.challenges = being.challenges || [];
  const incoming = clone(event.payload.challenge);
  const existing = being.challenges.find(function (item) { return item.id === incoming.id; });

  if (!existing) {
    incoming.receivedAt = new Date().toISOString();
    being.challenges.push(incoming);
    return incoming;
  }

  Object.assign(existing, incoming);
  existing.lastObservedAt = new Date().toISOString();
  return existing;
};

module.exports = ChallengeService;
