const crypto = require('crypto');

function VerificationQuorumService(options) {
  options = options || {};
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
}

VerificationQuorumService.prototype._policyFor = function (being, contribution) {
  if (contribution && contribution.verificationQuorum) {
    return contribution.verificationQuorum;
  }

  const constitution = being && being.governance && being.governance.constitution;
  return constitution && constitution.verificationQuorum || null;
};

VerificationQuorumService.prototype.evaluate = function (context) {
  const self = this;
  const being = context.being;
  const contribution = context.contribution;

  if (!contribution) {
    return Promise.resolve(null);
  }

  const policy = self._policyFor(being, contribution);
  if (!policy) {
    return Promise.resolve(null);
  }

  const required = Number(policy.required || 1);
  const eligible = Array.isArray(policy.eligibleBeingIds) ? policy.eligibleBeingIds : [];
  const verifications = contribution.verifications || [];
  const unique = new Map();

  verifications.forEach(function (verification) {
    if (eligible.length && !eligible.includes(verification.verifierBeingId)) {
      return;
    }
    if (!unique.has(verification.verifierBeingId)) {
      unique.set(verification.verifierBeingId, verification);
    }
  });

  const votes = Array.from(unique.values());
  const verified = votes.filter(function (item) { return item.verdict === 'verified'; });
  const notVerified = votes.filter(function (item) { return item.verdict === 'not_verified'; });

  let verdict = null;
  if (verified.length >= required) {
    verdict = 'verified';
  }
  else if (notVerified.length >= required) {
    verdict = 'not_verified';
  }

  if (!verdict) {
    return Promise.resolve({
      reached: false,
      required: required,
      verified: verified.length,
      notVerified: notVerified.length
    });
  }

  if (contribution.quorum && contribution.quorum.verdict === verdict) {
    return Promise.resolve(contribution.quorum);
  }

  const quorum = {
    id: crypto.randomUUID(),
    version: 'octomics.verification-quorum.v1',
    contributionId: contribution.id,
    contributorBeingId: contribution.beingId || being.id,
    verdict: verdict,
    required: required,
    verifierBeingIds: (verdict === 'verified' ? verified : notVerified).map(function (item) {
      return item.verifierBeingId;
    }),
    verificationIds: (verdict === 'verified' ? verified : notVerified).map(function (item) {
      return item.id;
    }),
    reachedAt: new Date().toISOString(),
    receipt: null
  };

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'contribution.quorum.reached',
      beingId: being.id,
      subject: quorum,
      evidence: { verificationIds: quorum.verificationIds }
    })
    : Promise.resolve(null);

  return receiptPromise.then(function (receipt) {
    quorum.receipt = receipt;
    contribution.quorum = quorum;

    if (!self.publisher) {
      return quorum;
    }

    return self.publisher.publish({
      type: 'contribution.quorum.reached',
      sourceBeingId: being.id,
      payload: {
        contributionId: contribution.id,
        quorum: quorum,
        sourceBeingId: being.id
      }
    })
      .then(function (event) {
        quorum.eventId = event.id;
        return quorum;
      });
  });
};

VerificationQuorumService.prototype.observeVerificationEvent = function (being, event) {
  if (!event || event.type !== 'contribution.verified' || !event.payload || !event.payload.verification) {
    return Promise.resolve(null);
  }

  const verification = event.payload.verification;
  const contribution = (being.contributions || []).find(function (item) {
    return item.id === verification.contributionId;
  });

  if (!contribution) {
    return Promise.resolve(null);
  }

  return this.evaluate({ being: being, contribution: contribution });
};

module.exports = VerificationQuorumService;
