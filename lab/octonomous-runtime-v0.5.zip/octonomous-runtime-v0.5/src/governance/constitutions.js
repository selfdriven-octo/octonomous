const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function matchesTool(match, action) {
  match = match || {};
  action = action || {};

  if (match.tool && match.tool !== '*' && match.tool !== action.tool) {
    return false;
  }

  if (Array.isArray(match.tools) && match.tools.length && !match.tools.includes(action.tool)) {
    return false;
  }

  if (match.inputEquals && typeof match.inputEquals === 'object') {
    const input = action.input || {};
    const keys = Object.keys(match.inputEquals);
    for (let i = 0; i < keys.length; i += 1) {
      if (input[keys[i]] !== match.inputEquals[keys[i]]) {
        return false;
      }
    }
  }

  return true;
}

function ConstitutionService(options) {
  options = options || {};
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
}

ConstitutionService.prototype.adopt = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const constitution = clone(input.constitution || input);

  if (!constitution || !Array.isArray(constitution.policies)) {
    return Promise.reject(new Error('constitution.adopt requires constitution.policies[]'));
  }

  being.governance = being.governance || {};
  being.governance.constitutions = being.governance.constitutions || [];

  const adopted = Object.assign({
    id: constitution.id || crypto.randomUUID(),
    version: constitution.version || '1.0.0',
    name: constitution.name || 'Octonomous Constitution',
    policies: constitution.policies,
    verificationQuorum: constitution.verificationQuorum || null,
    adoptedAt: new Date().toISOString(),
    adoptedByBeingId: being.id,
    status: 'active'
  }, constitution);

  being.governance.constitutions.forEach(function (item) {
    if (item.status === 'active') {
      item.status = 'superseded';
      item.supersededAt = adopted.adoptedAt;
    }
  });

  being.governance.constitutions.push(adopted);
  being.governance.constitution = adopted;

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'constitution.adopted',
      beingId: being.id,
      subject: adopted,
      evidence: { sourceEventId: context.event && context.event.id }
    })
    : Promise.resolve(null);

  return receiptPromise.then(function (receipt) {
    adopted.receipt = receipt;

    if (!self.publisher) {
      return { ok: true, constitution: adopted, event: null };
    }

    return self.publisher.publish({
      type: 'constitution.adopted',
      sourceBeingId: being.id,
      payload: {
        constitution: adopted,
        sourceBeingId: being.id
      }
    })
      .then(function (event) {
        adopted.eventId = event.id;
        return { ok: true, constitution: adopted, event: event };
      });
  });
};

ConstitutionService.prototype.active = function (being) {
  return being && being.governance && being.governance.constitution || null;
};

ConstitutionService.prototype.evaluateAction = function (being, action) {
  const constitution = this.active(being);

  if (!constitution) {
    return null;
  }

  const policies = constitution.policies || [];
  for (let i = 0; i < policies.length; i += 1) {
    const policy = policies[i];
    if (!matchesTool(policy.match || {}, action)) {
      continue;
    }

    if (policy.effect === 'deny') {
      return {
        policyId: policy.id || ('policy-' + i),
        effect: 'deny',
        reason: policy.reason || 'Denied by constitution'
      };
    }

    if (policy.effect === 'threshold') {
      const threshold = policy.threshold || {};
      return {
        policyId: policy.id || ('policy-' + i),
        effect: 'threshold',
        reason: policy.reason || 'Threshold governance approval required',
        threshold: {
          approvals: Number(threshold.approvals || 1),
          rejections: Number(threshold.rejections || 1),
          eligibleBeingIds: Array.isArray(threshold.eligibleBeingIds)
            ? threshold.eligibleBeingIds.slice()
            : [],
          vetoBeingIds: Array.isArray(threshold.vetoBeingIds)
            ? threshold.vetoBeingIds.slice()
            : []
        }
      };
    }

    if (policy.effect === 'allow') {
      return {
        policyId: policy.id || ('policy-' + i),
        effect: 'allow',
        reason: policy.reason || 'Allowed by constitution'
      };
    }
  }

  return null;
};

ConstitutionService.matchesTool = matchesTool;

module.exports = ConstitutionService;
