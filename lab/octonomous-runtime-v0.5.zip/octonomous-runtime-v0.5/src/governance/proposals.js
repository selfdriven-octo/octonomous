const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function GovernanceProposalService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
}

GovernanceProposalService.prototype._sign = function (kind, beingId, subject, evidence) {
  if (!this.receipts) {
    return Promise.resolve(null);
  }

  return this.receipts.create({
    kind: kind,
    beingId: beingId,
    subject: subject,
    evidence: evidence || {}
  });
};

GovernanceProposalService.prototype.request = function (context) {
  const self = this;
  const being = context.being;
  const decision = context.decision || {};
  const rule = context.rule || {};
  const action = decision.action;

  if (!action || !action.tool) {
    return Promise.reject(new Error('governance proposal requires an action'));
  }

  being.governance = being.governance || {};
  being.governance.proposals = being.governance.proposals || [];

  const existing = being.governance.proposals.find(function (item) {
    return item.sourceEventId === (context.event && context.event.id) &&
      item.status === 'pending' &&
      item.action && item.action.tool === action.tool;
  });

  if (existing) {
    return Promise.resolve(existing);
  }

  const threshold = rule.threshold || {};
  const proposal = {
    id: crypto.randomUUID(),
    version: 'octonomous.governance-proposal.v1',
    requestedByBeingId: being.id,
    sourceEventId: context.event && context.event.id,
    constitutionId: rule.constitutionId || null,
    policyId: rule.policyId || null,
    reason: rule.reason || '',
    action: clone(action),
    rationale: decision.rationale || '',
    threshold: {
      approvals: Number(threshold.approvals || 1),
      rejections: Number(threshold.rejections || 1),
      eligibleBeingIds: Array.isArray(threshold.eligibleBeingIds)
        ? threshold.eligibleBeingIds.slice()
        : [],
      vetoBeingIds: Array.isArray(threshold.vetoBeingIds)
        ? threshold.vetoBeingIds.slice()
        : []
    },
    votes: [],
    status: 'pending',
    createdAt: new Date().toISOString(),
    receipt: null,
    resolutionReceipt: null
  };

  being.governance.proposals.push(proposal);

  return self._sign('governance.proposal.created', being.id, proposal, {
    sourceEventId: proposal.sourceEventId,
    policyId: proposal.policyId
  })
    .then(function (receipt) {
      proposal.receipt = receipt;

      if (!self.publisher) {
        return proposal;
      }

      const targets = proposal.threshold.eligibleBeingIds;
      if (!targets.length) {
        return proposal;
      }

      return Promise.all(targets.map(function (targetBeingId) {
        return self.publisher.publish({
          type: 'governance.proposal.created',
          sourceBeingId: being.id,
          targetBeingId: targetBeingId,
          payload: {
            proposal: proposal,
            sourceBeingId: being.id
          }
        });
      }))
        .then(function (events) {
          proposal.deliveryEventIds = events.map(function (event) { return event.id; });
          return proposal;
        });
    });
};

GovernanceProposalService.prototype.castVote = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const proposal = input.proposal;
  const voteValue = String(input.vote || '').toLowerCase();

  if (!proposal || !proposal.id) {
    return Promise.reject(new Error('governance.vote requires proposal'));
  }

  if (!['approve', 'reject', 'abstain'].includes(voteValue)) {
    return Promise.reject(new Error('governance.vote vote must be approve, reject, or abstain'));
  }

  const eligible = proposal.threshold && proposal.threshold.eligibleBeingIds || [];
  if (eligible.length && !eligible.includes(being.id)) {
    return Promise.reject(new Error('Being is not eligible to vote on this proposal'));
  }

  being.governance = being.governance || {};
  being.governance.votes = being.governance.votes || [];

  const vote = {
    id: crypto.randomUUID(),
    version: 'octonomous.governance-vote.v1',
    proposalId: proposal.id,
    proposalRequesterBeingId: proposal.requestedByBeingId,
    voterBeingId: being.id,
    vote: voteValue,
    reason: input.reason || '',
    createdAt: new Date().toISOString(),
    receipt: null
  };

  being.governance.votes.push(vote);

  return self._sign('governance.vote.cast', being.id, vote, {
    proposalId: proposal.id
  })
    .then(function (receipt) {
      vote.receipt = receipt;

      if (!self.publisher) {
        return { ok: true, vote: vote, event: null };
      }

      return self.publisher.publish({
        type: 'governance.vote.cast',
        sourceBeingId: being.id,
        targetBeingId: proposal.requestedByBeingId,
        payload: {
          vote: vote,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          vote.deliveryEventId = event.id;
          return { ok: true, vote: vote, event: event };
        });
    });
};

GovernanceProposalService.prototype._resolveIfReady = function (being, proposal) {
  const self = this;

  if (!proposal || proposal.status !== 'pending') {
    return Promise.resolve(proposal || null);
  }

  const votes = proposal.votes || [];
  const approvals = votes.filter(function (vote) { return vote.vote === 'approve'; });
  const rejections = votes.filter(function (vote) { return vote.vote === 'reject'; });
  const vetoIds = proposal.threshold && proposal.threshold.vetoBeingIds || [];
  const veto = rejections.find(function (vote) { return vetoIds.includes(vote.voterBeingId); });

  let resolution = null;
  if (veto) {
    resolution = 'rejected';
  }
  else if (approvals.length >= Number(proposal.threshold.approvals || 1)) {
    resolution = 'approved';
  }
  else if (rejections.length >= Number(proposal.threshold.rejections || 1)) {
    resolution = 'rejected';
  }

  if (!resolution) {
    return Promise.resolve(proposal);
  }

  proposal.status = resolution;
  proposal.resolvedAt = new Date().toISOString();
  proposal.resolution = {
    approvals: approvals.length,
    rejections: rejections.length,
    abstentions: votes.filter(function (vote) { return vote.vote === 'abstain'; }).length,
    vetoedBy: veto ? veto.voterBeingId : null
  };

  return self._sign('governance.proposal.' + resolution, being.id, {
    proposalId: proposal.id,
    status: proposal.status,
    action: proposal.action,
    resolution: proposal.resolution,
    resolvedAt: proposal.resolvedAt
  }, {
    voteReceiptIds: votes.map(function (vote) {
      return vote.receipt && vote.receipt.id || null;
    }).filter(Boolean)
  })
    .then(function (receipt) {
      proposal.resolutionReceipt = receipt;

      if (!self.publisher) {
        return proposal;
      }

      return self.publisher.publish({
        type: 'governance.proposal.' + resolution,
        sourceBeingId: being.id,
        targetBeingId: proposal.requestedByBeingId,
        payload: {
          proposalId: proposal.id,
          status: proposal.status,
          resolution: proposal.resolution,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          proposal.resolutionEventId = event.id;
          return proposal;
        });
    });
};

GovernanceProposalService.prototype.observeEvent = function (being, event) {
  const self = this;
  being.governance = being.governance || {};
  being.governance.incomingProposals = being.governance.incomingProposals || [];
  being.governance.proposals = being.governance.proposals || [];

  if (!event || !event.payload) {
    return Promise.resolve(null);
  }

  if (event.type === 'governance.proposal.created' && event.payload.proposal) {
    const incoming = clone(event.payload.proposal);
    const existing = being.governance.incomingProposals.find(function (item) {
      return item.id === incoming.id;
    });

    if (!existing) {
      incoming.receivedAt = new Date().toISOString();
      being.governance.incomingProposals.push(incoming);
      return Promise.resolve(incoming);
    }
    return Promise.resolve(existing);
  }

  if (event.type === 'governance.vote.cast' && event.payload.vote) {
    const vote = clone(event.payload.vote);
    const proposal = being.governance.proposals.find(function (item) {
      return item.id === vote.proposalId;
    });

    if (!proposal) {
      return Promise.resolve(null);
    }

    const eligible = proposal.threshold && proposal.threshold.eligibleBeingIds || [];
    if (eligible.length && !eligible.includes(vote.voterBeingId)) {
      return Promise.resolve({ ignored: true, reason: 'ineligible_voter', vote: vote });
    }

    proposal.votes = proposal.votes || [];
    const existingVote = proposal.votes.find(function (item) {
      return item.voterBeingId === vote.voterBeingId;
    });

    if (!existingVote) {
      proposal.votes.push(vote);
    }

    return self._resolveIfReady(being, proposal);
  }

  if ((event.type === 'governance.proposal.approved' || event.type === 'governance.proposal.rejected') && event.payload.proposalId) {
    const proposal = being.governance.proposals.find(function (item) {
      return item.id === event.payload.proposalId;
    });
    if (proposal) {
      proposal.status = event.payload.status || (event.type.endsWith('.approved') ? 'approved' : 'rejected');
      proposal.resolution = event.payload.resolution || proposal.resolution || null;
      proposal.resolutionObservedAt = new Date().toISOString();
    }
    return Promise.resolve(proposal || null);
  }

  return Promise.resolve(null);
};

GovernanceProposalService.prototype.decisionFromResolution = function (being, event) {
  const proposalId = event.payload && event.payload.proposalId;
  const proposals = being.governance && being.governance.proposals || [];
  const proposal = proposals.find(function (item) { return item.id === proposalId; });

  if (!proposal) {
    throw new Error('Unknown governance proposal: ' + proposalId);
  }

  if (event.type === 'governance.proposal.rejected' || proposal.status === 'rejected') {
    return {
      shouldAct: false,
      rationale: 'Governance proposal rejected',
      action: proposal.action,
      governanceResolution: {
        proposalId: proposal.id,
        status: 'rejected',
        resolution: proposal.resolution || null
      }
    };
  }

  return {
    shouldAct: true,
    rationale: proposal.rationale || 'Governance proposal approved',
    action: clone(proposal.action),
    commitment: { enabled: false },
    governanceResolution: {
      proposalId: proposal.id,
      status: 'approved',
      policyId: proposal.policyId,
      resolution: proposal.resolution || null,
      receipt: proposal.resolutionReceipt || null
    }
  };
};

module.exports = GovernanceProposalService;
