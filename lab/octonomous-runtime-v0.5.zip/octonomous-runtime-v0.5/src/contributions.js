const crypto = require('crypto');

function ContributionService(options) {
  options = options || {};
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
}

ContributionService.prototype.shouldCreate = function (context) {
  if (!context.actionResult || !context.actionResult.ok || context.actionResult.skipped) {
    return false;
  }

  if (context.actionResult.pendingApproval) {
    return false;
  }

  return true;
};

ContributionService.prototype.create = function (context) {
  const self = this;
  const being = context.being;

  if (!self.shouldCreate(context)) {
    return Promise.resolve(null);
  }

  being.contributions = being.contributions || [];

  const contribution = {
    id: crypto.randomUUID(),
    version: 'octomics.contribution.v1',
    beingId: being.id,
    eventId: context.event.id,
    eventType: context.event.type,
    createdAt: new Date().toISOString(),
    action: context.decision.action,
    outcome: context.actionResult,
    reflection: context.reflection,
    evidence: {
      commitmentId: context.commitment ? context.commitment.id : null,
      approvalId: context.decision.approvalResolution
        ? context.decision.approvalResolution.id
        : null
    }
  };

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'octomics.contribution',
      beingId: being.id,
      subject: contribution,
      evidence: contribution.evidence
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      contribution.receipt = receipt;
      being.contributions.push(contribution);

      if (being.contributions.length > 100) {
        being.contributions = being.contributions.slice(-100);
      }

      if (!self.publisher) {
        return contribution;
      }

      return self.publisher.publish({
        type: 'octomics.contribution.created',
        sourceBeingId: being.id,
        payload: {
          contribution: contribution,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          contribution.publishedEventId = event.id;
          return contribution;
        });
    });
};

module.exports = ContributionService;
