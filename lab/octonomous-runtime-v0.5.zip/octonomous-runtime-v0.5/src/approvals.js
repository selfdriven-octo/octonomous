const crypto = require('crypto');

function ApprovalService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
}

ApprovalService.prototype.request = function (context) {
  const self = this;
  const being = context.being;
  being.approvals = being.approvals || [];

  const existing = being.approvals.find(function (item) {
    return item.sourceEventId === context.event.id && item.status === 'pending';
  });

  if (existing) {
    return Promise.resolve(existing);
  }

  const approval = {
    id: crypto.randomUUID(),
    version: 'octonomous.approval.v1',
    status: 'pending',
    createdAt: new Date().toISOString(),
    sourceEventId: context.event.id,
    tool: context.decision.action.tool,
    input: context.decision.action.input || {},
    rationale: context.decision.rationale || '',
    requestedBy: being.id,
    receipt: null
  };

  being.approvals.push(approval);

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'approval.requested',
      beingId: being.id,
      subject: approval,
      evidence: { sourceEventId: context.event.id }
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      approval.receipt = receipt;

      if (!self.publisher) {
        return approval;
      }

      return self.publisher.publish({
        type: 'approval.requested',
        sourceBeingId: being.id,
        payload: {
          approval: approval,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          approval.publishedEventId = event.id;
          return approval;
        });
    });
};

ApprovalService.prototype.resolve = function (being, event) {
  const self = this;
  being.approvals = being.approvals || [];
  const approvalId = event.payload && event.payload.approvalId;
  const approval = being.approvals.find(function (item) {
    return item.id === approvalId;
  });

  if (!approval) {
    return Promise.reject(new Error('Unknown approval: ' + approvalId));
  }

  if (approval.status !== 'pending') {
    return Promise.resolve({ approval: approval, duplicate: true });
  }

  const granted = event.type === 'approval.granted';
  approval.status = granted ? 'granted' : 'denied';
  approval.resolvedAt = new Date().toISOString();
  approval.resolvedBy = (event.payload && event.payload.resolvedBy) || 'human';
  approval.note = (event.payload && event.payload.note) || '';

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: event.type,
      beingId: being.id,
      subject: {
        approvalId: approval.id,
        status: approval.status,
        tool: approval.tool,
        resolvedBy: approval.resolvedBy,
        resolvedAt: approval.resolvedAt
      },
      evidence: {
        sourceEventId: approval.sourceEventId,
        resolutionEventId: event.id
      }
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      approval.resolutionReceipt = receipt;
      return { approval: approval, duplicate: false };
    });
};

ApprovalService.prototype.decisionFromResolution = function (resolution) {
  const approval = resolution.approval;

  return {
    shouldAct: approval.status === 'granted',
    rationale: 'Resume previously proposed action after approval resolution.',
    action: {
      enabled: approval.status === 'granted',
      tool: approval.tool,
      input: approval.input
    },
    commitment: {
      enabled: false,
      title: '',
      dueAt: '',
      reason: ''
    },
    approvalResolution: {
      id: approval.id,
      status: approval.status,
      resolvedBy: approval.resolvedBy
    }
  };
};

module.exports = ApprovalService;
