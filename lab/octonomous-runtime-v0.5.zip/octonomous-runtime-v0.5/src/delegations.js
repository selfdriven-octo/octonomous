const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function DelegationService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
}

DelegationService.prototype._receipt = function (kind, beingId, subject, evidence) {
  if (!this.receipts) {
    return Promise.resolve(null);
  }

  return this.receipts.create({
    kind: kind,
    beingId: beingId,
    subject: subject,
    evidence: evidence || {}
  });
};

DelegationService.prototype.create = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};

  if (!input.targetBeingId) {
    return Promise.reject(new Error('being.delegate requires targetBeingId'));
  }

  if (!self.publisher) {
    return Promise.reject(new Error('No event publisher configured for delegation'));
  }

  being.delegations = being.delegations || [];

  const delegation = {
    id: crypto.randomUUID(),
    version: 'octonomous.delegation.v2',
    role: 'delegator',
    fromBeingId: being.id,
    toBeingId: input.targetBeingId,
    intent: input.intent || '',
    requestedAction: input.requestedAction || null,
    constraints: input.constraints || {},
    capabilityIds: input.capabilityIds || [],
    status: 'requested',
    createdAt: new Date().toISOString(),
    sourceEventId: context.event && context.event.id
  };

  being.delegations.push(delegation);

  return self._receipt('delegation.requested', being.id, delegation, {
    sourceEventId: delegation.sourceEventId
  })
    .then(function (receipt) {
      delegation.receipt = receipt;

      return self.publisher.publish({
        type: 'delegation.requested',
        sourceBeingId: being.id,
        targetBeingId: input.targetBeingId,
        payload: {
          delegation: delegation,
          sourceBeingId: being.id
        }
      });
    })
    .then(function (event) {
      delegation.deliveryEventId = event.id;
      return { ok: true, delegation: delegation, event: event };
    });
};

DelegationService.prototype.observeEvent = function (being, event) {
  being.delegations = being.delegations || [];

  if (!event || !event.payload) {
    return null;
  }

  if (event.type === 'delegation.requested' && event.payload.delegation) {
    const incoming = clone(event.payload.delegation);
    const existing = being.delegations.find(function (item) {
      return item.id === incoming.id;
    });

    if (!existing) {
      incoming.role = 'delegatee';
      incoming.receivedAt = new Date().toISOString();
      being.delegations.push(incoming);
      return incoming;
    }

    return existing;
  }

  if (['delegation.accepted', 'delegation.rejected', 'delegation.completed'].includes(event.type)) {
    const incoming = event.payload.delegation || {};
    const id = event.payload.delegationId || incoming.id;
    const existing = being.delegations.find(function (item) {
      return item.id === id;
    });

    if (existing) {
      Object.keys(incoming).forEach(function (key) {
        if (key !== 'role') {
          existing[key] = clone(incoming[key]);
        }
      });

      if (event.type === 'delegation.accepted') {
        existing.status = 'accepted';
      }
      if (event.type === 'delegation.rejected') {
        existing.status = 'rejected';
      }
      if (event.type === 'delegation.completed') {
        existing.status = 'completed';
      }

      existing.lastStatusEventId = event.id;
      return existing;
    }
  }

  return null;
};

DelegationService.prototype._findIncoming = function (being, delegationId) {
  return (being.delegations || []).find(function (item) {
    return item.id === delegationId && item.toBeingId === being.id;
  });
};

DelegationService.prototype._transition = function (kind, status, context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const delegation = self._findIncoming(being, input.delegationId);

  if (!delegation) {
    return Promise.reject(new Error('Unknown incoming delegation: ' + input.delegationId));
  }

  if (status === 'accepted' && !['requested', 'accepted'].includes(delegation.status)) {
    return Promise.reject(new Error('Delegation cannot be accepted from status: ' + delegation.status));
  }

  if (status === 'rejected' && delegation.status !== 'requested') {
    return Promise.reject(new Error('Delegation cannot be rejected from status: ' + delegation.status));
  }

  if (status === 'completed' && !['accepted', 'in_progress'].includes(delegation.status)) {
    return Promise.reject(new Error('Delegation cannot be completed from status: ' + delegation.status));
  }

  delegation.status = status;
  delegation.updatedAt = new Date().toISOString();
  delegation[kind + 'At'] = delegation.updatedAt;

  if (input.reason) {
    delegation.reason = input.reason;
  }
  if (input.outcome !== undefined) {
    delegation.outcome = input.outcome;
  }
  if (input.evidence !== undefined) {
    delegation.evidence = input.evidence;
  }

  return self._receipt('delegation.' + status, being.id, delegation, {
    sourceEventId: context.event && context.event.id
  })
    .then(function (receipt) {
      delegation[status + 'Receipt'] = receipt;

      if (!self.publisher) {
        return { ok: true, delegation: delegation, event: null };
      }

      return self.publisher.publish({
        type: 'delegation.' + status,
        sourceBeingId: being.id,
        targetBeingId: delegation.fromBeingId,
        payload: {
          delegationId: delegation.id,
          delegation: delegation,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          delegation[status + 'EventId'] = event.id;
          return { ok: true, delegation: delegation, event: event };
        });
    });
};

DelegationService.prototype.accept = function (context) {
  return this._transition('accepted', 'accepted', context);
};

DelegationService.prototype.reject = function (context) {
  return this._transition('rejected', 'rejected', context);
};

DelegationService.prototype.complete = function (context) {
  return this._transition('completed', 'completed', context);
};

module.exports = DelegationService;
