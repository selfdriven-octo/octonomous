const crypto = require('crypto');
const canonical = require('../canonical');

function snapshot(value) {
  return JSON.parse(JSON.stringify(value || {}));
}

function ReceiptService(options) {
  options = options || {};
  this.signer = options.signer || null;
}

ReceiptService.prototype.create = function (context) {
  const self = this;
  const payload = {
    version: 'octonomous.receipt.v1',
    id: context.id || crypto.randomUUID(),
    kind: context.kind,
    beingId: context.beingId,
    occurredAt: context.occurredAt || new Date().toISOString(),
    subject: snapshot(context.subject),
    evidence: snapshot(context.evidence)
  };

  const receipt = {
    id: payload.id,
    kind: payload.kind,
    beingId: payload.beingId,
    occurredAt: payload.occurredAt,
    digest: canonical.sha256(payload),
    payload: payload,
    signature: null
  };

  if (!self.signer) {
    return Promise.resolve(receipt);
  }

  return self.signer.sign(payload)
    .then(function (signature) {
      receipt.signature = signature;
      return receipt;
    });
};

ReceiptService.prototype.verify = function (receipt) {
  if (!receipt || !receipt.payload) {
    return Promise.resolve({ valid: false, reason: 'Missing receipt payload' });
  }

  const digestValid = receipt.digest === canonical.sha256(receipt.payload);

  if (!digestValid) {
    return Promise.resolve({ valid: false, digestValid: false, reason: 'Receipt digest mismatch' });
  }

  if (!this.signer || typeof this.signer.verify !== 'function') {
    return Promise.resolve({ valid: null, digestValid: true, reason: 'Signer cannot verify this receipt' });
  }

  return Promise.resolve(this.signer.verify(receipt.payload, receipt.signature))
    .then(function (valid) {
      if (valid && typeof valid === 'object' && valid.valid !== undefined) {
        return Object.assign({ digestValid: true }, valid);
      }

      return { valid: Boolean(valid), digestValid: true };
    });
};

module.exports = ReceiptService;
