const {
  SchedulerClient,
  CreateScheduleCommand
} = require('@aws-sdk/client-scheduler');

function formatAtExpression(date) {
  return date.toISOString().replace(/\.\d{3}Z$/, '');
}

function safeScheduleName(id) {
  return ('octo-' + id).replace(/[^a-zA-Z0-9-_.]/g, '-').slice(0, 64);
}

function ReminderScheduler(options) {
  options = options || {};

  this.queueArn = options.queueArn;
  this.roleArn = options.roleArn;
  this.client = options.client || new SchedulerClient({
    region: options.region
  });
}

ReminderScheduler.prototype.scheduleCommitment = function (context) {
  const self = this;
  const due = new Date(context.commitment.dueAt);

  if (Number.isNaN(due.getTime())) {
    return Promise.resolve({
      scheduled: false,
      reason: 'Invalid dueAt'
    });
  }

  if (due.getTime() <= Date.now()) {
    return Promise.resolve({
      scheduled: false,
      reason: 'dueAt is not in the future'
    });
  }

  const name = safeScheduleName(context.commitment.id);

  return self.client.send(new CreateScheduleCommand({
    Name: name,
    ScheduleExpression: 'at(' + formatAtExpression(due) + ')',
    ScheduleExpressionTimezone: 'UTC',
    FlexibleTimeWindow: {
      Mode: 'OFF'
    },
    ActionAfterCompletion: 'DELETE',
    Target: {
      Arn: self.queueArn,
      RoleArn: self.roleArn,
      Input: JSON.stringify({
        id: 'reminder:' + context.commitment.id,
        type: 'commitment.due',
        targetBeingId: context.beingId,
        payload: {
          commitmentId: context.commitment.id
        },
        occurredAt: context.commitment.dueAt
      })
    }
  }))
    .then(function (result) {
      return {
        scheduled: true,
        scheduleArn: result.ScheduleArn,
        scheduleName: name
      };
    })
    .catch(function (error) {
      if (error.name === 'ConflictException') {
        return {
          scheduled: true,
          duplicate: true,
          scheduleName: name
        };
      }

      throw error;
    });
};

module.exports = ReminderScheduler;
