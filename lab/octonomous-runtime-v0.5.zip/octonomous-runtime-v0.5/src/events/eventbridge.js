const {
  EventBridgeClient,
  PutEventsCommand
} = require('@aws-sdk/client-eventbridge');
const crypto = require('crypto');

function EventBridgePublisher(options) {
  options = options || {};

  this.busName = options.busName;
  this.source = options.source || 'octonomous';
  this.client = options.client || new EventBridgeClient({
    region: options.region
  });
}

EventBridgePublisher.prototype.publish = function (event) {
  const self = this;
  const id = event.id || crypto.randomUUID();

  const detail = {
    id: id,
    type: event.type,
    payload: event.payload || {},
    occurredAt: event.occurredAt || new Date().toISOString()
  };

  if (event.sourceBeingId) {
    detail.sourceBeingId = event.sourceBeingId;
  }

  if (event.targetBeingId) {
    detail.targetBeingId = event.targetBeingId;
  }

  return self.client.send(new PutEventsCommand({
    Entries: [{
      EventBusName: self.busName,
      Source: self.source,
      DetailType: event.type,
      Detail: JSON.stringify(detail)
    }]
  }))
    .then(function (result) {
      if (result.FailedEntryCount) {
        throw new Error('EventBridge failed to publish one or more events');
      }

      return detail;
    });
};

module.exports = EventBridgePublisher;
