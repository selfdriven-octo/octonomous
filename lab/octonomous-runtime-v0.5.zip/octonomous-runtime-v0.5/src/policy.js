function Policy(options) {
  options = options || {};
  this.capabilities = options.capabilities || null;
  this.constitutions = options.constitutions || null;
}

Policy.prototype.check = function (context) {
  const being = context.being;
  const decision = context.decision || {};
  const action = decision.action;

  if (!decision.shouldAct || !action || !action.enabled) {
    return {
      allowed: true,
      status: 'no_action'
    };
  }

  const availableNames = (context.availableTools || []).map(function (tool) {
    return tool.name;
  });

  if (!availableNames.includes(action.tool)) {
    return {
      allowed: false,
      status: 'unknown_tool',
      reason: 'Tool is not registered: ' + action.tool
    };
  }

  const constitutional = this.constitutions
    ? this.constitutions.evaluateAction(being, action)
    : null;

  if (constitutional && constitutional.effect === 'deny') {
    return {
      allowed: false,
      status: 'constitution_denied',
      reason: constitutional.reason,
      policyId: constitutional.policyId
    };
  }

  if (constitutional && constitutional.effect === 'threshold') {
    const resolution = decision.governanceResolution;
    if (resolution && resolution.status === 'approved' && resolution.policyId === constitutional.policyId) {
      return {
        allowed: true,
        status: 'governance_approved',
        policyId: constitutional.policyId,
        proposalId: resolution.proposalId,
        resolution: resolution.resolution || null
      };
    }

    if (resolution && resolution.status === 'rejected') {
      return {
        allowed: false,
        status: 'governance_rejected',
        reason: 'Governance proposal rejected',
        policyId: constitutional.policyId,
        proposalId: resolution.proposalId
      };
    }

    return {
      allowed: false,
      status: 'governance_required',
      reason: constitutional.reason,
      policyId: constitutional.policyId,
      constitutionId: being.governance && being.governance.constitution && being.governance.constitution.id,
      threshold: constitutional.threshold
    };
  }

  const authority = being.authority || {};
  const allowedTools = authority.allowedTools || [];
  const requiresApproval = authority.requiresApproval || [];
  const approval = decision.approvalResolution;

  if (requiresApproval.includes(action.tool)) {
    if (approval && approval.status === 'granted') {
      return {
        allowed: true,
        status: 'approved',
        approvalId: approval.id,
        resolvedBy: approval.resolvedBy
      };
    }

    return {
      allowed: false,
      status: 'approval_required',
      reason: 'Human approval required for tool: ' + action.tool
    };
  }

  if (allowedTools.includes(action.tool)) {
    return {
      allowed: true,
      status: constitutional && constitutional.effect === 'allow'
        ? 'constitution_authorised'
        : 'authorised',
      policyId: constitutional && constitutional.policyId || null
    };
  }

  if (this.capabilities) {
    const matching = this.capabilities.activeForAction(being, action);
    if (matching.length) {
      return {
        allowed: true,
        status: 'capability_authorised',
        capabilityId: matching[0].id,
        capabilityIssuerBeingId: matching[0].issuerBeingId,
        capabilityRootIssuerBeingId: matching[0].rootIssuerBeingId || matching[0].issuerBeingId,
        delegationDepth: Number(matching[0].delegationDepth || 0)
      };
    }
  }

  return {
    allowed: false,
    status: 'not_authorised',
    reason: 'Being is not authorised to use tool: ' + action.tool
  };
};

module.exports = Policy;
