function EvidenceReputationService(options) {
  options = options || {};
  this.receipts = options.receipts || null;
  this.weights = Object.assign({
    commitmentFulfilled: 5,
    commitmentViolated: -8,
    delegationCompleted: 2,
    contributionQuorumVerified: 5,
    contributionQuorumRejected: -3,
    challengeUpheldAgainst: -5,
    challengeDismissedAgainst: 1,
    governanceVote: 1
  }, options.weights || {});
}

EvidenceReputationService.prototype._verify = function (receipt) {
  if (!receipt) {
    return Promise.resolve(false);
  }
  if (!this.receipts || typeof this.receipts.verify !== 'function') {
    return Promise.resolve(true);
  }
  return this.receipts.verify(receipt)
    .then(function (result) {
      return result && result.valid !== false;
    })
    .catch(function () {
      return false;
    });
};

EvidenceReputationService.prototype.compute = function (being) {
  const self = this;
  const evidence = [];

  function add(kind, weight, receipt, subjectId, detail) {
    evidence.push({ kind: kind, weight: weight, receipt: receipt || null, subjectId: subjectId || null, detail: detail || null });
  }

  (being.commitments || []).forEach(function (item) {
    if (item.status === 'fulfilled') {
      add('commitment.fulfilled', self.weights.commitmentFulfilled, item.fulfilledReceipt, item.id);
    }
    if (item.status === 'violated') {
      add('commitment.violated', self.weights.commitmentViolated, item.violatedReceipt, item.id);
    }
  });

  (being.delegations || []).forEach(function (item) {
    if (item.status === 'completed' && item.delegateeBeingId === being.id) {
      add('delegation.completed', self.weights.delegationCompleted, item.completedReceipt, item.id);
    }
  });

  (being.contributions || []).forEach(function (item) {
    if (item.quorum && item.quorum.verdict === 'verified') {
      add('contribution.quorum.verified', self.weights.contributionQuorumVerified, item.quorum.receipt, item.id);
    }
    if (item.quorum && item.quorum.verdict === 'not_verified') {
      add('contribution.quorum.not_verified', self.weights.contributionQuorumRejected, item.quorum.receipt, item.id);
    }
  });

  (being.challenges || []).forEach(function (item) {
    if (item.status !== 'resolved' || item.targetBeingId !== being.id) {
      return;
    }
    if (item.verdict === 'upheld') {
      add('challenge.upheld_against', self.weights.challengeUpheldAgainst, item.resolutionReceipt, item.id);
    }
    if (item.verdict === 'dismissed') {
      add('challenge.dismissed_against', self.weights.challengeDismissedAgainst, item.resolutionReceipt, item.id);
    }
  });

  const votes = being.governance && being.governance.votes || [];
  votes.forEach(function (vote) {
    add('governance.vote', self.weights.governanceVote, vote.receipt, vote.id, { vote: vote.vote });
  });

  return Promise.all(evidence.map(function (item) {
    return self._verify(item.receipt)
      .then(function (valid) {
        item.verified = valid;
        return item;
      });
  }))
    .then(function (verifiedEvidence) {
      const accepted = verifiedEvidence.filter(function (item) { return item.verified; });
      const score = accepted.reduce(function (total, item) { return total + item.weight; }, 0);
      return {
        version: 'octonomous.evidence-reputation.v1',
        beingId: being.id,
        computedAt: new Date().toISOString(),
        score: score,
        evidenceCount: accepted.length,
        rejectedEvidenceCount: verifiedEvidence.length - accepted.length,
        weights: Object.assign({}, self.weights),
        evidence: verifiedEvidence
      };
    });
};

module.exports = EvidenceReputationService;
