const crypto = require('crypto');
const canonical = require('./canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function VerificationService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
}

VerificationService.prototype.request = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};

  if (!input.targetBeingId) {
    return Promise.reject(new Error('contribution.verification.request requires targetBeingId'));
  }

  if (!input.contribution) {
    return Promise.reject(new Error('contribution.verification.request requires contribution'));
  }

  const request = {
    id: crypto.randomUUID(),
    version: 'octomics.verification-request.v1',
    requesterBeingId: being.id,
    verifierBeingId: input.targetBeingId,
    contribution: clone(input.contribution),
    contributionDigest: canonical.sha256(input.contribution),
    status: 'requested',
    createdAt: new Date().toISOString(),
    sourceEventId: context.event && context.event.id
  };

  being.verificationRequests = being.verificationRequests || [];
  being.verificationRequests.push(request);

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'contribution.verification.requested',
      beingId: being.id,
      subject: request,
      evidence: { contributionDigest: request.contributionDigest }
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      request.receipt = receipt;

      if (!self.publisher) {
        return { ok: true, request: request, event: null };
      }

      return self.publisher.publish({
        type: 'contribution.verification.requested',
        sourceBeingId: being.id,
        targetBeingId: input.targetBeingId,
        payload: {
          request: request,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          request.deliveryEventId = event.id;
          return { ok: true, request: request, event: event };
        });
    });
};

VerificationService.prototype.verify = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const contribution = input.contribution;

  if (!contribution) {
    return Promise.reject(new Error('contribution.verify requires contribution'));
  }

  const receipt = contribution.receipt || null;
  const digestValid = receipt
    ? receipt.digest === canonical.sha256(receipt.payload)
    : false;

  const signaturePromise = receipt && self.receipts
    ? self.receipts.verify(receipt)
    : Promise.resolve({ valid: null, reason: 'No receipt verifier available' });

  return signaturePromise
    .then(function (signatureCheck) {
      const verification = {
        id: crypto.randomUUID(),
        version: 'octomics.contribution-verification.v1',
        verifierBeingId: being.id,
        contributorBeingId: contribution.beingId,
        contributionId: contribution.id,
        contributionDigest: canonical.sha256(contribution),
        receiptDigestValid: digestValid,
        receiptSignatureValid: signatureCheck.valid,
        receiptVerification: signatureCheck,
        evidenceChecks: input.evidenceChecks || {},
        verdict: input.verdict || (
          digestValid && signatureCheck.valid !== false ? 'verified' : 'not_verified'
        ),
        notes: input.notes || '',
        createdAt: new Date().toISOString(),
        receipt: null
      };

      being.verifications = being.verifications || [];
      being.verifications.push(verification);

      const proofPromise = self.receipts
        ? self.receipts.create({
          kind: 'contribution.verified',
          beingId: being.id,
          subject: verification,
          evidence: {
            contributionId: contribution.id,
            contributionDigest: verification.contributionDigest
          }
        })
        : Promise.resolve(null);

      return proofPromise.then(function (proof) {
        verification.receipt = proof;
        return verification;
      });
    })
    .then(function (verification) {
      if (!self.publisher || !verification.contributorBeingId) {
        return { ok: true, verification: verification, event: null };
      }

      return self.publisher.publish({
        type: 'contribution.verified',
        sourceBeingId: being.id,
        targetBeingId: verification.contributorBeingId,
        payload: {
          verification: verification,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          verification.deliveryEventId = event.id;
          return { ok: true, verification: verification, event: event };
        });
    });
};

VerificationService.prototype.observeEvent = function (being, event) {
  if (!event || !event.payload) {
    return null;
  }

  if (event.type === 'contribution.verification.requested' && event.payload.request) {
    being.verificationRequests = being.verificationRequests || [];
    const incoming = clone(event.payload.request);
    const exists = being.verificationRequests.find(function (item) {
      return item.id === incoming.id;
    });

    if (!exists) {
      incoming.receivedAt = new Date().toISOString();
      being.verificationRequests.push(incoming);
      return incoming;
    }
    return exists;
  }

  if (event.type === 'contribution.verified' && event.payload.verification) {
    const verification = clone(event.payload.verification);
    const contribution = (being.contributions || []).find(function (item) {
      return item.id === verification.contributionId;
    });

    if (contribution) {
      contribution.verifications = contribution.verifications || [];
      const exists = contribution.verifications.find(function (item) {
        return item.id === verification.id;
      });
      if (!exists) {
        verification.receivedAt = new Date().toISOString();
        contribution.verifications.push(verification);
      }
    }

    return verification;
  }

  return null;
};

module.exports = VerificationService;
