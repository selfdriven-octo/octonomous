const crypto = require('crypto');

function ensureRelationship(being, otherBeingId) {
  being.relationships = being.relationships || {};

  if (!being.relationships[otherBeingId]) {
    being.relationships[otherBeingId] = {
      beingId: otherBeingId,
      interactions: 0,
      successfulInteractions: 0,
      blockedInteractions: 0,
      delegationsOut: 0,
      delegationsIn: 0,
      lastInteractionAt: null,
      trustScore: 0.5
    };
  }

  return being.relationships[otherBeingId];
}

function clamp(value) {
  return Math.max(0, Math.min(1, value));
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function RelationshipService(options) {
  options = options || {};
  this.publisher = options.publisher || null;
  this.receipts = options.receipts || null;
}

RelationshipService.prototype.recordEvent = function (being, event) {
  const sourceBeingId = event.sourceBeingId || (event.payload && event.payload.sourceBeingId);

  if (!sourceBeingId || sourceBeingId === being.id) {
    return;
  }

  const rel = ensureRelationship(being, sourceBeingId);
  rel.interactions += 1;
  rel.lastInteractionAt = new Date().toISOString();

  if (event.type === 'delegation.requested') {
    rel.delegationsIn += 1;
  }
};

RelationshipService.prototype.recordOutcome = function (being, context) {
  const action = context.decision && context.decision.action;
  const input = action && action.input;
  const targetBeingId = input && input.targetBeingId;

  if (!targetBeingId || targetBeingId === being.id) {
    return;
  }

  const rel = ensureRelationship(being, targetBeingId);
  rel.interactions += 1;
  rel.lastInteractionAt = new Date().toISOString();

  if (action.tool === 'being.delegate') {
    rel.delegationsOut += 1;
  }

  if (context.actionResult && context.actionResult.ok) {
    rel.successfulInteractions += 1;
    rel.trustScore = clamp(rel.trustScore + 0.02);
  }
  else if (context.actionResult && (context.actionResult.blocked || context.actionResult.error)) {
    rel.blockedInteractions += 1;
    rel.trustScore = clamp(rel.trustScore - 0.02);
  }
};

RelationshipService.prototype.recordReputation = function (being, context) {
  being.reputation = being.reputation || {};

  const defaults = {
    actionsAttempted: 0,
    actionsSucceeded: 0,
    actionsBlocked: 0,
    approvalsRequested: 0,
    approvalsGranted: 0,
    commitmentsCreated: 0,
    commitmentsFulfilled: 0,
    commitmentsViolated: 0,
    contributionsCreated: 0,
    contributionsVerified: 0,
    delegationsAccepted: 0,
    delegationsCompleted: 0,
    capabilitiesGranted: 0,
    capabilitiesRevoked: 0
  };

  Object.keys(defaults).forEach(function (key) {
    if (being.reputation[key] === undefined) {
      being.reputation[key] = defaults[key];
    }
  });

  const action = context.decision && context.decision.action;
  if (context.decision && context.decision.shouldAct && action && action.enabled) {
    being.reputation.actionsAttempted += 1;
  }

  if (context.actionResult && context.actionResult.ok && !context.actionResult.skipped) {
    being.reputation.actionsSucceeded += 1;
  }

  if (context.actionResult && context.actionResult.blocked) {
    being.reputation.actionsBlocked += 1;
  }

  if (context.approvalRequest) {
    being.reputation.approvalsRequested += 1;
  }

  if (context.decision && context.decision.approvalResolution && context.decision.approvalResolution.status === 'granted') {
    being.reputation.approvalsGranted += 1;
  }

  if (context.commitment) {
    being.reputation.commitmentsCreated += 1;
  }

  if (context.contribution) {
    being.reputation.contributionsCreated += 1;
  }

  if (action && action.tool === 'commitment.fulfil' && context.actionResult && context.actionResult.ok) {
    being.reputation.commitmentsFulfilled += 1;
  }
  if (action && action.tool === 'commitment.violate' && context.actionResult && context.actionResult.ok) {
    being.reputation.commitmentsViolated += 1;
  }
  if (action && action.tool === 'contribution.verify' && context.actionResult && context.actionResult.ok) {
    being.reputation.contributionsVerified += 1;
  }
  if (action && action.tool === 'being.delegate.accept' && context.actionResult && context.actionResult.ok) {
    being.reputation.delegationsAccepted += 1;
  }
  if (action && action.tool === 'being.delegate.complete' && context.actionResult && context.actionResult.ok) {
    being.reputation.delegationsCompleted += 1;
  }
  if (action && action.tool === 'capability.grant' && context.actionResult && context.actionResult.ok) {
    being.reputation.capabilitiesGranted += 1;
  }
  if (action && action.tool === 'capability.revoke' && context.actionResult && context.actionResult.ok) {
    being.reputation.capabilitiesRevoked += 1;
  }
};

RelationshipService.prototype.assert = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};

  if (!input.targetBeingId) {
    return Promise.reject(new Error('relationship.assert requires targetBeingId'));
  }

  being.relationshipAssertions = being.relationshipAssertions || [];

  const assertion = {
    id: crypto.randomUUID(),
    version: 'octonomous.relationship-assertion.v1',
    fromBeingId: being.id,
    toBeingId: input.targetBeingId,
    relationshipType: input.relationshipType || 'associated',
    claims: input.claims || {},
    status: 'active',
    validUntil: input.validUntil || null,
    createdAt: new Date().toISOString(),
    sourceEventId: context.event && context.event.id,
    receipt: null
  };

  being.relationshipAssertions.push(assertion);

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'relationship.asserted',
      beingId: being.id,
      subject: assertion,
      evidence: { sourceEventId: assertion.sourceEventId }
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      assertion.receipt = receipt;

      if (!self.publisher) {
        return { ok: true, assertion: assertion, event: null };
      }

      return self.publisher.publish({
        type: 'relationship.asserted',
        sourceBeingId: being.id,
        targetBeingId: input.targetBeingId,
        payload: {
          assertion: assertion,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          assertion.deliveryEventId = event.id;
          return { ok: true, assertion: assertion, event: event };
        });
    });
};

RelationshipService.prototype.observeAssertion = function (being, event) {
  if (!event || event.type !== 'relationship.asserted' || !event.payload || !event.payload.assertion) {
    return null;
  }

  being.relationshipAssertions = being.relationshipAssertions || [];
  const incoming = clone(event.payload.assertion);
  const existing = being.relationshipAssertions.find(function (item) {
    return item.id === incoming.id;
  });

  if (!existing) {
    incoming.receivedAt = new Date().toISOString();
    incoming.direction = 'incoming';
    being.relationshipAssertions.push(incoming);
    return incoming;
  }

  return existing;
};

module.exports = RelationshipService;
