/*
 * Copy this file, implement signReceipt() with your Signify/KERIA client,
 * then set:
 *
 *   RECEIPT_MODE=keri
 *   KERI_AID=<your AID>
 *   KERI_SIGNER_MODULE=./path/to/your-provider.js
 *
 * The provider owns all interaction with KERI. The Octonomous runtime only
 * passes a canonical application receipt digest + payload to be signed.
 */

exports.createProvider = function (options) {
  return {
    signReceipt: function (request) {
      // Integrate your current Signify/KERIA client here.
      // request = { aid, digest, payload }
      // Return KERI/CESR signature metadata suitable for independent proof.
      return Promise.reject(new Error(
        'Implement this adapter against your Signify/KERIA deployment for AID ' +
        (options.aid || request.aid)
      ));
    }
  };
};
