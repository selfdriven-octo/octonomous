/*
 * Example adapter only. Replace with a provider using your preferred Cardano
 * SDK / wallet infrastructure. Do not place payment signing keys in this file.
 */
exports.createProvider = function (options) {
  return {
    anchor: function (context) {
      console.log('Would anchor Cardano metadata:', {
        network: options.network,
        label: context.metadataLabel,
        metadata: context.metadata
      });

      return Promise.resolve({
        status: 'prepared',
        network: options.network,
        txId: null
      });
    }
  };
};
