# Migration: Octonomous Runtime v0.3 → v0.4

v0.4 adds a society layer around accountable autonomous beings. Existing v0.3
being documents remain loadable; the new collections are initialised lazily.

## New being state

Add these fields when creating new beings:

```json
{
  "capabilities": { "granted": [], "received": [] },
  "relationshipAssertions": [],
  "verificationRequests": [],
  "verifications": [],
  "anchors": []
}
```

## Delegation lifecycle

v0.3 emitted `delegation.requested` only.

v0.4 supports:

```text
delegation.requested
       ├─> delegation.rejected
       └─> delegation.accepted
                 └─> delegation.completed
```

New tools:

- `being.delegate.accept`
- `being.delegate.reject`
- `being.delegate.complete`

## Capability authority

v0.4 policy checks authority in this order:

1. explicit human approval requirement
2. locally allowed tool
3. active received capability
4. deny

Capabilities may be bounded by expiry and simple input constraints. Revocation is
propagated as `capability.revoked`.

New tools:

- `capability.grant`
- `capability.revoke`

## ACDC credential adapter

`src/credentials/acdc.js` is an adapter boundary. With no provider, development
mode creates a signed receipt credential explicitly labelled as **not ACDC**.

For production, set:

```bash
export ACDC_PROVIDER_MODULE=./my-acdc-provider.js
export ACDC_REGISTRY_NAME=octonomous-capabilities
export KERIA_URL=https://...
```

The provider should expose:

```js
issueCapability(context).then(...)
revokeCredential(context).then(...)
verifyCredential(context).then(...)
```

## Commitments

New tools:

- `commitment.fulfil`
- `commitment.violate`

Terminal states are signed and cannot be changed to another terminal state.

## Relationship assertions

`relationship.assert` creates a signed, targeted assertion containing a
relationship type, claims and optional validity period.

## Contribution verification

New tools:

- `contribution.verification.request`
- `contribution.verify`

Verification checks receipt integrity, asks the configured receipt signer/provider
to verify the signature when supported, then produces a new signed verification
record from the verifier.

## Cardano evidence anchoring

`evidence.anchor` collects unanchored signed receipts, creates a deterministic
Blake2b-256 Merkle root, and passes compact metadata to an optional Cardano
provider.

Without a provider, the anchor is prepared and signed but no transaction is
submitted.

For production:

```bash
export CARDANO_ANCHOR_MODULE=./my-cardano-provider.js
export CARDANO_NETWORK=preprod
export CARDANO_METADATA_LABEL=1337
```

The provider owns wallet/key selection, transaction construction, signing,
submission and confirmation. It exposes:

```js
anchor(context).then(function (result) {
  // result.txId means submitted
});
```

Do not put Cardano payment keys into the Octonomous being document.
