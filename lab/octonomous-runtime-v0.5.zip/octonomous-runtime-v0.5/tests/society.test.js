const test = require('node:test');
const assert = require('node:assert/strict');

const Policy = require('../src/policy');
const CapabilityService = require('../src/capabilities');
const DelegationService = require('../src/delegations');
const CommitmentService = require('../src/commitments');
const VerificationService = require('../src/verifications');
const EvidenceAnchorService = require('../src/anchors/evidence');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const AcdcCredentialService = require('../src/credentials/acdc');

function eventPublisher() {
  const events = [];
  return {
    events: events,
    publish: function (event) {
      const value = Object.assign({ id: 'event-' + (events.length + 1) }, event);
      events.push(value);
      return Promise.resolve(value);
    }
  };
}

function receiptServices(aid) {
  const signer = new LocalEd25519Signer({ aid: aid });
  return {
    signer: signer,
    receipts: new ReceiptService({ signer: signer })
  };
}

test('capability grant authorises a bounded action and revocation removes authority', function () {
  const published = eventPublisher();
  const proof = receiptServices('did:key:capabilities');
  const credentials = new AcdcCredentialService({ receipts: proof.receipts });
  const service = new CapabilityService({
    publisher: published,
    receipts: proof.receipts,
    credentials: credentials
  });

  const issuer = {
    id: 'octo:issuer',
    identity: { keriAid: 'EIssuer' },
    capabilities: { granted: [], received: [] }
  };
  const receiver = {
    id: 'octo:receiver',
    authority: { allowedTools: [], requiresApproval: [] },
    capabilities: { granted: [], received: [] }
  };

  let capabilityId;

  return service.grant({
    being: issuer,
    event: { id: 'source-1' },
    input: {
      targetBeingId: receiver.id,
      tool: 'event.publish',
      constraints: { targetBeingIds: ['octo:allowed'] },
      expiresAt: '2099-01-01T00:00:00.000Z'
    }
  })
    .then(function (result) {
      capabilityId = result.capability.id;
      assert.equal(result.capability.credential.mode, 'development-receipt');
      service.observeEvent(receiver, published.events[0]);

      const policy = new Policy({ capabilities: service });
      const allowed = policy.check({
        being: receiver,
        decision: {
          shouldAct: true,
          action: {
            enabled: true,
            tool: 'event.publish',
            input: { targetBeingId: 'octo:allowed' }
          }
        },
        availableTools: [{ name: 'event.publish' }]
      });

      const blockedByConstraint = policy.check({
        being: receiver,
        decision: {
          shouldAct: true,
          action: {
            enabled: true,
            tool: 'event.publish',
            input: { targetBeingId: 'octo:other' }
          }
        },
        availableTools: [{ name: 'event.publish' }]
      });

      assert.equal(allowed.status, 'capability_authorised');
      assert.equal(blockedByConstraint.allowed, false);

      return service.revoke({
        being: issuer,
        event: { id: 'source-2' },
        input: { capabilityId: capabilityId, reason: 'completed' }
      });
    })
    .then(function () {
      service.observeEvent(receiver, published.events[1]);
      const policy = new Policy({ capabilities: service });
      const result = policy.check({
        being: receiver,
        decision: {
          shouldAct: true,
          action: { enabled: true, tool: 'event.publish', input: { targetBeingId: 'octo:allowed' } }
        },
        availableTools: [{ name: 'event.publish' }]
      });
      assert.equal(result.allowed, false);
      assert.equal(receiver.capabilities.received[0].status, 'revoked');
    });
});

test('delegation can be accepted and completed with signed transition evidence', function () {
  const published = eventPublisher();
  const proof = receiptServices('did:key:delegation');
  const service = new DelegationService({ publisher: published, receipts: proof.receipts });
  const a = { id: 'octo:a', delegations: [] };
  const b = { id: 'octo:b', delegations: [] };
  let delegationId;

  return service.create({
    being: a,
    event: { id: 'source-delegation' },
    input: { targetBeingId: b.id, intent: 'verify evidence' }
  })
    .then(function (created) {
      delegationId = created.delegation.id;
      service.observeEvent(b, published.events[0]);
      return service.accept({
        being: b,
        event: { id: 'accept-source' },
        input: { delegationId: delegationId }
      });
    })
    .then(function (accepted) {
      assert.equal(accepted.delegation.status, 'accepted');
      assert.ok(accepted.delegation.acceptedReceipt.signature);
      service.observeEvent(a, published.events[1]);
      assert.equal(a.delegations[0].status, 'accepted');

      return service.complete({
        being: b,
        event: { id: 'complete-source' },
        input: {
          delegationId: delegationId,
          outcome: { verified: true },
          evidence: { ref: 'evidence-1' }
        }
      });
    })
    .then(function (completed) {
      assert.equal(completed.delegation.status, 'completed');
      assert.ok(completed.delegation.completedReceipt.signature);
      service.observeEvent(a, published.events[2]);
      assert.equal(a.delegations[0].status, 'completed');
      assert.equal(a.delegations[0].outcome.verified, true);
    });
});

test('commitments have signed fulfilment and violation terminal states', function () {
  const proof = receiptServices('did:key:commitments');
  const service = new CommitmentService({ receipts: proof.receipts });
  const being = { id: 'octo:commit', commitments: [] };

  return service.create({
    being: being,
    event: { id: 'commit-event' },
    proposal: { title: 'Do the work', reason: 'promised', dueAt: null }
  })
    .then(function (commitment) {
      return service.fulfil({
        being: being,
        event: { id: 'fulfil-event' },
        input: { commitmentId: commitment.id, outcome: { done: true } }
      });
    })
    .then(function (result) {
      assert.equal(result.commitment.status, 'fulfilled');
      assert.ok(result.commitment.fulfilledReceipt.signature);
      return assert.rejects(function () {
        return service.violate({
          being: being,
          event: { id: 'violate-event' },
          input: { commitmentId: result.commitment.id }
        });
      }, /already final/);
    });
});

test('third-party contribution verification checks receipt integrity and signs verdict', function () {
  const proof = receiptServices('did:key:verification');
  const service = new VerificationService({ receipts: proof.receipts });
  const verifier = { id: 'octo:verifier', verifications: [] };
  const contribution = {
    id: 'contribution-1',
    beingId: 'octo:producer',
    outcome: { ok: true }
  };

  return proof.receipts.create({
    kind: 'octomics.contribution',
    beingId: contribution.beingId,
    subject: contribution,
    evidence: {}
  })
    .then(function (receipt) {
      contribution.receipt = receipt;
      return service.verify({
        being: verifier,
        event: { id: 'verify-event' },
        input: { contribution: contribution, notes: 'checked' }
      });
    })
    .then(function (result) {
      assert.equal(result.verification.receiptDigestValid, true);
      assert.equal(result.verification.receiptSignatureValid, true);
      assert.equal(result.verification.verdict, 'verified');
      assert.ok(result.verification.receipt.signature);
    });
});

test('evidence anchoring produces deterministic root and passes compact metadata to provider', function () {
  const proof = receiptServices('did:key:anchor');
  const captured = [];
  const provider = {
    anchor: function (context) {
      captured.push(context);
      return Promise.resolve({ txId: 'cardano-tx-1', network: 'preprod' });
    }
  };
  const service = new EvidenceAnchorService({
    provider: provider,
    receipts: proof.receipts,
    metadataLabel: '1337',
    network: 'preprod'
  });
  const being = {
    id: 'octo:anchor',
    memory: { receipts: [] },
    contributions: [],
    commitments: [],
    delegations: [],
    anchors: []
  };

  return Promise.all([
    proof.receipts.create({ kind: 'event.processed', beingId: being.id, subject: { n: 1 }, evidence: {} }),
    proof.receipts.create({ kind: 'event.processed', beingId: being.id, subject: { n: 2 }, evidence: {} })
  ])
    .then(function (receipts) {
      being.memory.receipts = receipts;
      const preparedA = service.prepare(being, {});
      const preparedB = service.prepare(being, {});
      assert.equal(preparedA.root, preparedB.root);
      assert.equal(preparedA.count, 2);
      assert.equal(preparedA.root.length, 64);

      return service.anchor({ being: being, event: { id: 'anchor-event' }, input: {} });
    })
    .then(function (result) {
      assert.equal(result.anchor.status, 'submitted');
      assert.equal(result.anchor.chain.txId, 'cardano-tx-1');
      assert.equal(captured[0].metadata.root.length, 64);
      assert.equal(captured[0].metadataLabel, '1337');
      assert.equal(being.anchors.length, 1);
    });
});
