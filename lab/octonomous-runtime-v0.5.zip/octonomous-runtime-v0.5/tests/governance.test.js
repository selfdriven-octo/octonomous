const test = require('node:test');
const assert = require('node:assert/strict');

const Policy = require('../src/policy');
const ConstitutionService = require('../src/governance/constitutions');
const GovernanceProposalService = require('../src/governance/proposals');
const ChallengeService = require('../src/governance/challenges');
const VerificationQuorumService = require('../src/governance/quorum');
const EvidenceReputationService = require('../src/reputation/evidence');
const CapabilityService = require('../src/capabilities');
const AcdcCredentialService = require('../src/credentials/acdc');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');

function eventPublisher() {
  const events = [];
  return {
    events: events,
    publish: function (event) {
      const value = Object.assign({ id: 'event-' + (events.length + 1) }, event);
      events.push(value);
      return Promise.resolve(value);
    }
  };
}

function receiptServices(aid) {
  const signer = new LocalEd25519Signer({ aid: aid });
  return {
    signer: signer,
    receipts: new ReceiptService({ signer: signer })
  };
}

test('constitution can require threshold governance and exact action resumes after approval', function () {
  const published = eventPublisher();
  const proof = receiptServices('did:key:governance');
  const constitutions = new ConstitutionService({ publisher: published, receipts: proof.receipts });
  const governance = new GovernanceProposalService({ publisher: published, receipts: proof.receipts });
  const being = {
    id: 'octo:requester',
    authority: { allowedTools: ['capability.grant'], requiresApproval: [] },
    governance: {}
  };
  const g1 = { id: 'octo:g1', governance: {} };
  const g2 = { id: 'octo:g2', governance: {} };
  const action = {
    enabled: true,
    tool: 'capability.grant',
    input: { targetBeingId: 'octo:worker', tool: 'echo', delegable: false }
  };
  let proposal;

  return constitutions.adopt({
    being: being,
    event: { id: 'constitution-source' },
    input: {
      constitution: {
        id: 'constitution-1',
        name: '2 of 3 Governance',
        policies: [{
          id: 'capability-grants-2of3',
          match: { tool: 'capability.grant' },
          effect: 'threshold',
          threshold: {
            approvals: 2,
            rejections: 2,
            eligibleBeingIds: ['octo:g1', 'octo:g2', 'octo:g3']
          }
        }]
      }
    }
  })
    .then(function () {
      const policy = new Policy({ constitutions: constitutions });
      const first = policy.check({
        being: being,
        decision: { shouldAct: true, action: action },
        availableTools: [{ name: 'capability.grant' }]
      });
      assert.equal(first.status, 'governance_required');

      return governance.request({
        being: being,
        event: { id: 'action-source' },
        decision: { shouldAct: true, action: action, rationale: 'Grant worker permission' },
        rule: first
      });
    })
    .then(function (created) {
      proposal = created;
      assert.equal(proposal.status, 'pending');
      assert.deepEqual(proposal.action, action);

      return governance.castVote({
        being: g1,
        event: { id: 'vote-source-1' },
        input: { proposal: proposal, vote: 'approve', reason: 'Looks bounded' }
      });
    })
    .then(function (vote1) {
      return governance.observeEvent(being, vote1.event);
    })
    .then(function () {
      assert.equal(proposal.status, 'pending');
      return governance.castVote({
        being: g2,
        event: { id: 'vote-source-2' },
        input: { proposal: proposal, vote: 'approve' }
      });
    })
    .then(function (vote2) {
      return governance.observeEvent(being, vote2.event);
    })
    .then(function () {
      assert.equal(proposal.status, 'approved');
      assert.equal(proposal.resolution.approvals, 2);
      assert.ok(proposal.resolutionReceipt.signature);

      const resolutionEvent = published.events.find(function (event) {
        return event.type === 'governance.proposal.approved';
      });
      const decision = governance.decisionFromResolution(being, resolutionEvent);
      assert.deepEqual(decision.action, action);

      const policy = new Policy({ constitutions: constitutions });
      const final = policy.check({
        being: being,
        decision: decision,
        availableTools: [{ name: 'capability.grant' }]
      });
      assert.equal(final.allowed, true);
      assert.equal(final.status, 'governance_approved');
    });
});

test('delegated capabilities cannot broaden authority or outlive their parent', function () {
  const published = eventPublisher();
  const proof = receiptServices('did:key:capability-chain');
  const credentials = new AcdcCredentialService({ receipts: proof.receipts });
  const service = new CapabilityService({ publisher: published, receipts: proof.receipts, credentials: credentials });
  const root = { id: 'octo:root', capabilities: { granted: [], received: [] } };
  const a = { id: 'octo:a', capabilities: { granted: [], received: [] } };
  const b = { id: 'octo:b', authority: { allowedTools: [], requiresApproval: [] }, capabilities: { granted: [], received: [] } };
  let parent;
  let child;

  return service.grant({
    being: root,
    event: { id: 'root-grant' },
    input: {
      targetBeingId: a.id,
      tool: 'event.publish',
      constraints: { targetBeingIds: ['octo:x', 'octo:y'] },
      delegable: true,
      expiresAt: '2099-01-01T00:00:00.000Z'
    }
  })
    .then(function (result) {
      parent = result.capability;
      service.observeEvent(a, result.event);

      return assert.rejects(function () {
        return service.delegate({
          being: a,
          event: { id: 'broad-delegation' },
          input: {
            parentCapabilityId: parent.id,
            targetBeingId: b.id,
            constraints: { targetBeingIds: ['octo:x', 'octo:z'] }
          }
        });
      }, /may not broaden/);
    })
    .then(function () {
      return service.delegate({
        being: a,
        event: { id: 'narrow-delegation' },
        input: {
          parentCapabilityId: parent.id,
          targetBeingId: b.id,
          constraints: { targetBeingIds: ['octo:x'] },
          delegable: false,
          expiresAt: '2098-01-01T00:00:00.000Z'
        }
      });
    })
    .then(function (result) {
      child = result.capability;
      assert.equal(child.delegationDepth, 1);
      assert.equal(child.rootIssuerBeingId, root.id);
      assert.equal(child.delegatedFromCapabilityId, parent.id);
      service.observeEvent(b, result.event);

      const policy = new Policy({ capabilities: service });
      const allowed = policy.check({
        being: b,
        decision: { shouldAct: true, action: { enabled: true, tool: 'event.publish', input: { targetBeingId: 'octo:x' } } },
        availableTools: [{ name: 'event.publish' }]
      });
      const blocked = policy.check({
        being: b,
        decision: { shouldAct: true, action: { enabled: true, tool: 'event.publish', input: { targetBeingId: 'octo:y' } } },
        availableTools: [{ name: 'event.publish' }]
      });
      assert.equal(allowed.status, 'capability_authorised');
      assert.equal(allowed.delegationDepth, 1);
      assert.equal(blocked.allowed, false);

      return service.revoke({
        being: root,
        event: { id: 'revoke-parent' },
        input: { capabilityId: parent.id, reason: 'root revoked' }
      });
    })
    .then(function (revoked) {
      service.observeEvent(b, revoked.event);
      assert.equal(b.capabilities.received[0].status, 'revoked_by_ancestor');
      assert.equal(b.capabilities.received[0].revokedByAncestorCapabilityId, parent.id);
    });
});

test('challenge lifecycle is signed and evidence-derived reputation uses resolved evidence', function () {
  const published = eventPublisher();
  const proof = receiptServices('did:key:challenge');
  const challenges = new ChallengeService({ publisher: published, receipts: proof.receipts });
  const reputation = new EvidenceReputationService({ receipts: proof.receipts });
  const challenger = { id: 'octo:challenger', challenges: [] };
  const target = { id: 'octo:target', challenges: [], commitments: [] };
  const resolver = { id: 'octo:resolver', challenges: [] };
  let challenge;

  return challenges.open({
    being: challenger,
    event: { id: 'challenge-source' },
    input: {
      targetBeingId: target.id,
      subjectKind: 'contribution',
      subjectId: 'contribution-1',
      claim: 'Evidence is incomplete'
    }
  })
    .then(function (opened) {
      challenge = opened.challenge;
      assert.ok(challenge.receipt.signature);
      challenges.observeEvent(target, opened.event);

      return challenges.respond({
        being: target,
        event: { id: 'response-source' },
        input: { challengeId: challenge.id, response: 'Additional evidence attached', evidence: { ref: 'e2' } }
      });
    })
    .then(function (responded) {
      challenges.observeEvent(challenger, responded.event);
      resolver.challenges.push(JSON.parse(JSON.stringify(responded.challenge)));
      return challenges.resolve({
        being: resolver,
        event: { id: 'resolve-source' },
        input: { challengeId: challenge.id, verdict: 'upheld', resolution: 'Original evidence was insufficient' }
      });
    })
    .then(function (resolved) {
      const targetEvent = resolved.events.find(function (event) { return event.targetBeingId === target.id; });
      challenges.observeEvent(target, targetEvent);
      assert.equal(target.challenges[0].verdict, 'upheld');
      assert.ok(target.challenges[0].resolutionReceipt.signature);

      return proof.receipts.create({
        kind: 'commitment.fulfilled',
        beingId: target.id,
        subject: { id: 'commitment-1', status: 'fulfilled' },
        evidence: {}
      });
    })
    .then(function (receipt) {
      target.commitments.push({ id: 'commitment-1', status: 'fulfilled', fulfilledReceipt: receipt });
      return reputation.compute(target);
    })
    .then(function (report) {
      assert.equal(report.score, 0);
      assert.equal(report.evidenceCount, 2);
      assert.equal(report.evidence.every(function (item) { return item.verified; }), true);
    });
});

test('verification quorum produces a signed consensus and reputation can consume it', function () {
  const proof = receiptServices('did:key:quorum');
  const quorum = new VerificationQuorumService({ receipts: proof.receipts });
  const reputation = new EvidenceReputationService({ receipts: proof.receipts });
  const being = {
    id: 'octo:producer',
    governance: {
      constitution: {
        verificationQuorum: {
          required: 2,
          eligibleBeingIds: ['octo:v1', 'octo:v2', 'octo:v3']
        }
      }
    },
    contributions: [{
      id: 'contribution-1',
      beingId: 'octo:producer',
      verifications: [
        { id: 'v1', verifierBeingId: 'octo:v1', verdict: 'verified' },
        { id: 'v2', verifierBeingId: 'octo:v2', verdict: 'verified' },
        { id: 'v3', verifierBeingId: 'octo:outsider', verdict: 'not_verified' }
      ]
    }],
    commitments: [],
    delegations: [],
    challenges: []
  };

  return quorum.evaluate({ being: being, contribution: being.contributions[0] })
    .then(function (result) {
      assert.equal(result.verdict, 'verified');
      assert.equal(result.verifierBeingIds.length, 2);
      assert.ok(result.receipt.signature);
      return reputation.compute(being);
    })
    .then(function (report) {
      assert.equal(report.score, 5);
      assert.equal(report.evidenceCount, 1);
      assert.equal(report.evidence[0].kind, 'contribution.quorum.verified');
    });
});

test('runtime suspends a constitutional action and resumes it only after threshold approval', function () {
  const fs = require('fs');
  const os = require('os');
  const path = require('path');
  const Runtime = require('../src/runtime');
  const ToolRegistry = require('../src/tools');
  const FileStore = require('../src/store/file');
  const ContributionService = require('../src/contributions');
  const RelationshipService = require('../src/relationships');

  const published = eventPublisher();
  const proof = receiptServices('did:key:runtime-governance');
  const constitutions = new ConstitutionService({ receipts: proof.receipts });
  const governance = new GovernanceProposalService({ publisher: published, receipts: proof.receipts });
  const tools = new ToolRegistry();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-governance-'));
  const store = new FileStore({ basePath: dir });
  let executions = 0;

  tools.register({ name: 'echo', description: 'Governed echo' }, function (input) {
    executions += 1;
    return Promise.resolve({ ok: true, output: input });
  });

  const cognition = {
    consider: function () { return Promise.resolve({ relevant: true }); },
    decide: function () {
      return Promise.resolve({
        shouldAct: true,
        rationale: 'Execute governed echo',
        action: { enabled: true, tool: 'echo', input: { message: 'hello' } },
        commitment: { enabled: false }
      });
    },
    reflect: function () { return Promise.resolve({ whatHappened: 'processed', confidence: 1 }); }
  };

  const runtime = new Runtime({
    store: store,
    cognition: cognition,
    policy: new Policy({ constitutions: constitutions }),
    tools: tools,
    relationships: new RelationshipService(),
    contributions: new ContributionService({ receipts: proof.receipts }),
    receipts: proof.receipts,
    governance: governance,
    reputation: new EvidenceReputationService({ receipts: proof.receipts })
  });

  const being = {
    id: 'octo:governed',
    purpose: ['test threshold governance'],
    character: { curious: true, caring: true, constructive: true, chill: true },
    authority: { allowedTools: ['echo'], requiresApproval: [] },
    subscriptions: ['intent.created'],
    commitments: [],
    contributions: [],
    relationships: {},
    memory: { reflections: [], receipts: [] },
    governance: {
      constitution: {
        id: 'runtime-constitution',
        policies: [{
          id: 'echo-2of2',
          match: { tool: 'echo' },
          effect: 'threshold',
          threshold: {
            approvals: 2,
            rejections: 2,
            eligibleBeingIds: ['octo:g1', 'octo:g2']
          }
        }]
      },
      proposals: []
    }
  };

  let proposal;
  let g1;
  let g2;

  return runtime.registerBeing(being)
    .then(function () {
      return runtime.handleEventForBeing(being.id, {
        id: 'governed-event-1',
        type: 'intent.created',
        payload: { intent: 'echo' }
      });
    })
    .then(function (result) {
      assert.equal(result.actionResult.pendingGovernance, true);
      assert.equal(executions, 0);
      proposal = result.governanceProposal;
      g1 = { id: 'octo:g1', governance: {} };
      g2 = { id: 'octo:g2', governance: {} };
      return governance.castVote({ being: g1, event: { id: 'g1-source' }, input: { proposal: proposal, vote: 'approve' } });
    })
    .then(function (vote1) {
      return runtime.handleEventForBeing(being.id, vote1.event);
    })
    .then(function () {
      assert.equal(executions, 0);
      return governance.castVote({ being: g2, event: { id: 'g2-source' }, input: { proposal: proposal, vote: 'approve' } });
    })
    .then(function (vote2) {
      return runtime.handleEventForBeing(being.id, vote2.event);
    })
    .then(function () {
      assert.equal(executions, 0);
      const approved = published.events.find(function (event) { return event.type === 'governance.proposal.approved'; });
      assert.ok(approved);
      return runtime.handleEventForBeing(being.id, approved);
    })
    .then(function (result) {
      assert.equal(result.governance.status, 'governance_approved');
      assert.equal(result.actionResult.ok, true);
      assert.equal(executions, 1);
    });
});
