const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const Runtime = require('../src/runtime');
const Policy = require('../src/policy');
const ToolRegistry = require('../src/tools');
const CommitmentService = require('../src/commitments');
const ApprovalService = require('../src/approvals');
const RelationshipService = require('../src/relationships');
const ContributionService = require('../src/contributions');
const DelegationService = require('../src/delegations');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const FileStore = require('../src/store/file');
const MockCognition = require('../src/cognition/mock');
const EvidenceReputationService = require('../src/reputation/evidence');

function services(cognition, tools) {
  const signer = new LocalEd25519Signer({ aid: 'did:key:test' });
  const receipts = new ReceiptService({ signer: signer });

  return {
    cognition: cognition,
    policy: new Policy(),
    tools: tools,
    commitments: new CommitmentService({ receipts: receipts }),
    approvals: new ApprovalService(),
    relationships: new RelationshipService(),
    contributions: new ContributionService({ receipts: receipts }),
    receipts: receipts,
    signer: signer,
    reputation: new EvidenceReputationService({ receipts: receipts })
  };
}

function baseBeing() {
  return {
    id: 'octo:test:1',
    purpose: ['test'],
    character: {
      curious: true,
      caring: true,
      constructive: true,
      chill: true
    },
    authority: {
      allowedTools: ['echo'],
      requiresApproval: []
    },
    subscriptions: ['intent.created'],
    commitments: [],
    approvals: [],
    relationships: {},
    contributions: [],
    memory: { reflections: [], receipts: [] }
  };
}

test('being completes governed lifecycle, creates contribution and signed receipt', function () {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-'));
  const store = new FileStore({ basePath: dir });
  const tools = new ToolRegistry();

  tools.register({ name: 'echo', description: 'Echo' }, function (input) {
    return Promise.resolve({ ok: true, output: input });
  });

  const svc = services(new MockCognition(), tools);
  const runtime = new Runtime(Object.assign({ store: store }, svc));
  const being = baseBeing();

  return runtime.registerBeing(being)
    .then(function () {
      return runtime.handleEventForBeing(being.id, {
        id: 'event-1',
        type: 'intent.created',
        payload: { intent: 'test' }
      });
    })
    .then(function (result) {
      assert.equal(result.actionResult.ok, true);
      assert.ok(result.contribution);
      assert.ok(result.receipt.signature);
      return svc.signer.verify(result.receipt.payload, result.receipt.signature);
    })
    .then(function (verified) {
      assert.equal(verified, true);
      return store.loadBeing(being.id);
    })
    .then(function (saved) {
      assert.equal(saved.memory.reflections.length, 1);
      assert.equal(saved.memory.receipts.length, 1);
      assert.equal(saved.contributions.length, 1);
      assert.equal(saved.reputation, undefined);
      assert.equal(saved.reputationEvidence.version, 'octonomous.evidence-reputation.v1');
    });
});

test('approval request persists and approval.granted resumes exact action', function () {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-approval-'));
  const store = new FileStore({ basePath: dir });
  const tools = new ToolRegistry();
  let executed = 0;

  tools.register({ name: 'send', description: 'Controlled send' }, function (input) {
    executed += 1;
    return Promise.resolve({ ok: true, sent: input.message });
  });

  const cognition = {
    consider: function () { return Promise.resolve({ relevant: true }); },
    decide: function () {
      return Promise.resolve({
        shouldAct: true,
        rationale: 'Send requires approval',
        action: { enabled: true, tool: 'send', input: { message: 'hello' } },
        commitment: { enabled: false, title: '', dueAt: '', reason: '' }
      });
    },
    reflect: function () {
      return Promise.resolve({
        whatHappened: 'processed',
        whatWasLearned: 'approval works',
        whoWasAffected: 'test',
        whatShouldChange: 'none',
        confidence: 1
      });
    }
  };

  const svc = services(cognition, tools);
  const runtime = new Runtime(Object.assign({ store: store }, svc));
  const being = baseBeing();
  being.authority = { allowedTools: [], requiresApproval: ['send'] };

  let approvalId;

  return runtime.registerBeing(being)
    .then(function () {
      return runtime.handleEventForBeing(being.id, {
        id: 'event-approval-1',
        type: 'intent.created',
        payload: { intent: 'send' }
      });
    })
    .then(function (result) {
      assert.equal(executed, 0);
      assert.equal(result.actionResult.pendingApproval, true);
      approvalId = result.approvalRequest.id;

      return runtime.handleEventForBeing(being.id, {
        id: 'event-approval-2',
        type: 'approval.granted',
        payload: { approvalId: approvalId, resolvedBy: 'mark' }
      });
    })
    .then(function (result) {
      assert.equal(result.governance.status, 'approved');
      assert.equal(result.actionResult.ok, true);
      assert.equal(executed, 1);
      return store.loadBeing(being.id);
    })
    .then(function (saved) {
      const approval = saved.approvals.find(function (item) { return item.id === approvalId; });
      assert.equal(approval.status, 'granted');
      assert.equal(saved.reputation, undefined);
      assert.equal(saved.reputationEvidence.version, 'octonomous.evidence-reputation.v1');
    });
});

test('delegation emits targeted event and signed receipt', function () {
  const published = [];
  const publisher = {
    publish: function (event) {
      const value = Object.assign({ id: 'delivery-1' }, event);
      published.push(value);
      return Promise.resolve(value);
    }
  };

  const receipts = new ReceiptService({
    signer: new LocalEd25519Signer({ aid: 'did:key:test-delegator' })
  });

  const delegations = new DelegationService({
    publisher: publisher,
    receipts: receipts
  });

  const being = { id: 'octo:a', delegations: [] };

  return delegations.create({
    being: being,
    event: { id: 'source-event' },
    input: {
      targetBeingId: 'octo:b',
      intent: 'Research durable actors'
    }
  })
    .then(function (result) {
      assert.equal(result.ok, true);
      assert.equal(published.length, 1);
      assert.equal(published[0].type, 'delegation.requested');
      assert.equal(published[0].targetBeingId, 'octo:b');
      assert.ok(result.delegation.receipt.signature);
    });
});

test('policy blocks unauthorised tools', function () {
  const result = new Policy().check({
    being: { authority: { allowedTools: [], requiresApproval: [] } },
    decision: {
      shouldAct: true,
      action: { enabled: true, tool: 'dangerous.tool' }
    },
    availableTools: [{ name: 'dangerous.tool' }]
  });

  assert.equal(result.allowed, false);
  assert.equal(result.status, 'not_authorised');
});
