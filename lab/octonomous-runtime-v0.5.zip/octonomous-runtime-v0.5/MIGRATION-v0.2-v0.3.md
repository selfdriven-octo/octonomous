# Migrating v0.2 → v0.3

v0.3 is backward-compatible with the basic being definition, but adds new state fields as they are used.

Recommended additions:

```json
{
  "approvals": [],
  "delegations": [],
  "relationships": {},
  "reputation": {
    "actionsAttempted": 0,
    "actionsSucceeded": 0,
    "actionsBlocked": 0,
    "approvalsRequested": 0,
    "approvalsGranted": 0,
    "commitmentsCreated": 0,
    "contributionsCreated": 0
  },
  "contributions": [],
  "memory": {
    "reflections": [],
    "receipts": []
  }
}
```

New environment options:

```bash
RECEIPT_MODE=local       # none | local | keri
LOCAL_RECEIPT_AID=did:key:local-development
KERI_AID=
KERIA_URL=
KERI_SIGNER_MODULE=
```

New runtime dependencies injected into `Runtime`:

- `approvals`
- `relationships`
- `contributions`
- `receipts`

Tool handlers now receive a second execution context argument:

```js
function (input, executionContext) {
  // executionContext.being
  // executionContext.event
  // executionContext.decision
  // executionContext.governance
}
```

Existing one-argument handlers continue to work in JavaScript.
