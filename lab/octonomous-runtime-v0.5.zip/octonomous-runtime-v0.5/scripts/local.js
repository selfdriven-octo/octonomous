const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const bootstrap = require('../src/bootstrap');

const being = JSON.parse(
  fs.readFileSync(path.join(__dirname, '..', 'being.example.json'), 'utf8')
);

bootstrap()
  .then(function (app) {
    return app.runtime.registerBeing(being)
      .then(function () {
        return app.runtime.handleEventForBeing(being.id, {
          id: crypto.randomUUID(),
          type: 'intent.created',
          payload: {
            intent: 'Explain why durable event-driven autonomous beings are useful.'
          },
          occurredAt: new Date().toISOString()
        });
      });
  })
  .then(function (result) {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
