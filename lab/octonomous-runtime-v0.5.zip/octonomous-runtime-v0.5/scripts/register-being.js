const fs = require('fs');
const path = require('path');
const FileStore = require('../src/store/file');
const DynamoDBStore = require('../src/store/dynamodb');

const filename = process.argv[2] || path.join(__dirname, '..', 'being.example.json');
const being = JSON.parse(fs.readFileSync(filename, 'utf8'));

const store = process.env.STORE_MODE === 'dynamodb'
  ? new DynamoDBStore({
    tableName: process.env.DYNAMODB_TABLE,
    region: process.env.AWS_REGION
  })
  : new FileStore({
    basePath: process.env.DATA_PATH || path.join(process.cwd(), 'data')
  });

store.loadBeing(being.id)
  .then(function (existing) {
    if (existing) {
      console.log('Being already exists:', being.id);
      return existing;
    }

    return store.saveBeing(being)
      .then(function () {
        console.log('Registered being:', being.id);
        return being;
      });
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
