const crypto = require('crypto');
const bootstrap = require('../src/bootstrap');

const beingId = process.argv[2];
const approvalId = process.argv[3];
const decision = (process.argv[4] || 'granted').toLowerCase();

if (!beingId || !approvalId || !['granted', 'denied'].includes(decision)) {
  console.error('Usage: node scripts/approve.js <beingId> <approvalId> [granted|denied]');
  process.exit(1);
}

bootstrap()
  .then(function (app) {
    const event = {
      id: crypto.randomUUID(),
      type: 'approval.' + decision,
      targetBeingId: beingId,
      payload: {
        approvalId: approvalId,
        resolvedBy: process.env.APPROVED_BY || 'human'
      },
      occurredAt: new Date().toISOString()
    };

    if (app.eventPublisher) {
      return app.eventPublisher.publish(event);
    }

    return app.runtime.handleEventForBeing(beingId, event);
  })
  .then(function (result) {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
