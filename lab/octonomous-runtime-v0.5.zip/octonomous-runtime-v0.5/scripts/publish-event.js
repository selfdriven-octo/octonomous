const EventBridgePublisher = require('../src/events/eventbridge');

const beingId = process.argv[2];
const type = process.argv[3] || 'intent.created';
const payloadText = process.argv[4] || '{"intent":"Hello from EventBridge"}';

if (!beingId) {
  console.error('Usage: npm run publish -- <being-id> [event-type] [payload-json]');
  process.exit(1);
}

const publisher = new EventBridgePublisher({
  busName: process.env.EVENT_BUS_NAME,
  region: process.env.AWS_REGION
});

publisher.publish({
  targetBeingId: beingId,
  type: type,
  payload: JSON.parse(payloadText)
})
  .then(function (event) {
    console.log(JSON.stringify(event, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
