module.exports = Object.freeze({
  software: '1.0.0',
  federationProtocol: 'octonomous-federation',
  preferredWireVersion: '2.0',
  supportedWireVersions: ['1.0', '1.1', '2.0'],
  conformanceProfile: 'OFP-1.0'
});
