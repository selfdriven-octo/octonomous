'use strict';

const api = {
  version: require('./src/version'),
  Runtime: require('./src/runtime'),
  Being: require('./src/being'),
  Policy: require('./src/policy'),
  ToolRegistry: require('./src/tools'),
  canonical: require('./src/canonical'),
  services: {
    Commitments: require('./src/commitments'),
    Approvals: require('./src/approvals'),
    Relationships: require('./src/relationships'),
    Contributions: require('./src/contributions'),
    Delegations: require('./src/delegations'),
    Capabilities: require('./src/capabilities'),
    Verifications: require('./src/verifications')
  },
  governance: {
    Constitutions: require('./src/governance/constitutions'),
    Proposals: require('./src/governance/proposals'),
    Challenges: require('./src/governance/challenges'),
    Quorum: require('./src/governance/quorum')
  },
  evidence: {
    ReceiptService: require('./src/receipts/service'),
    LocalEd25519Signer: require('./src/receipts/local-ed25519'),
    KeriSigner: require('./src/receipts/keri'),
    EvidenceReputation: require('./src/reputation/evidence'),
    PortableReputationProof: require('./src/reputation/portable-proof')
  },
  stores: {
    FileStore: require('./src/store/file')
  },
  cognition: {
    Mock: require('./src/cognition/mock')
  },
  integrations: {},
  cloud: {}
};

// Optional adapters are lazy so importing the core package does not require
// AWS/OpenAI packages unless that adapter is actually selected.
Object.defineProperty(api.stores, 'DynamoDBStore', {
  enumerable: true,
  get: function () { return require('./src/store/dynamodb'); }
});
Object.defineProperty(api.cognition, 'OpenAI', {
  enumerable: true,
  get: function () { return require('./src/cognition/openai'); }
});
Object.defineProperty(api.integrations, 'MCPManager', {
  enumerable: true,
  get: function () { return require('./src/mcp'); }
});
Object.defineProperty(api.cloud, 'EventBridgePublisher', {
  enumerable: true,
  get: function () { return require('./src/events/eventbridge'); }
});
Object.defineProperty(api.cloud, 'ReminderScheduler', {
  enumerable: true,
  get: function () { return require('./src/events/scheduler'); }
});
Object.defineProperty(api.cloud, 'Secrets', {
  enumerable: true,
  get: function () { return require('./src/secrets'); }
});

module.exports = api;
