# @octonomous/runtime

Production API boundary for the Octonomous Being runtime.

```js
const octo = require('@octonomous/runtime');

const runtime = new octo.Runtime({
  store: store,
  cognition: cognition,
  policy: new octo.Policy(),
  tools: new octo.ToolRegistry()
});
```

The package does not require federation services. OpenAI and MCP are optional peer dependencies used only by their adapters.
