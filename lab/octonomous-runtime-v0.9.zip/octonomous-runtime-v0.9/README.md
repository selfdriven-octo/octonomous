# Octonomous Runtime v0.9 — Federation Gateway

Node.js/CommonJS runtime for durable, governed Octonomous beings and sovereign communities.

v0.9 turns the hardened v0.8 federation protocol into a deployable gateway. The important change is not more intelligence: it is **reliable delivery between independently operated communities**.

## Architecture progression

```text
v0.1  Being
v0.2  Durable Being
v0.3  Accountable Being
v0.4  Society of Beings
v0.5  Governed Society
v0.6  Federated Societies
v0.7  Sovereign Federation
v0.8  Hardened Federation Protocol
v0.9  Federation Gateway
```

## Core v0.9 path

```text
Community A
    │
    │ local governance / being action
    ▼
create signed federation envelope
    │
    ▼
verified peer registry
    │
    ├── HTTP
    ├── MCP
    └── DIDComm adapter
    │
    ▼
Community B gateway
    │
    ├── protocol/schema check
    ├── recipient binding
    ├── signature verification
    ├── nonce/replay check
    ├── delivery idempotency
    ├── trace
    └── dispatch exactly once
    │
    ▼
Event / being / federation service
```

## Independent communities

v0.8 still had one practical deployment assumption: envelope services normally loaded both sender and recipient through the local community store.

v0.9 removes that assumption.

```text
Community A store               Community B store
┌────────────────┐             ┌────────────────┐
│ Community A    │             │ Community B    │
│ local state    │             │ local state    │
│                │             │                │
│ Peer snapshot B│◄───────────►│ Peer snapshot A│
└────────────────┘  signed      └────────────────┘
                  discovery
```

A peer snapshot contains routing/protocol/identity information from a cryptographically verified discovery descriptor. It is **not a copy of the remote community's internal governance state**.

## New gateway modules

```text
src/gateway/
├── peer-registry.js
├── idempotency.js
├── retry.js
├── dead-letter.js
├── tracing.js
├── router.js
├── inbound.js
├── outbound.js
└── transports/
    ├── registry.js
    ├── http.js
    ├── mcp.js
    └── didcomm.js

src/handlers/
└── http-gateway.js
```

## 1. Peer registry and discovery cache

A peer can only be registered from a signed discovery descriptor whose receipt is bound to the exact descriptor contents.

```js
services.gatewayPeers.register({
  input: {
    descriptor: remoteSignedDescriptor
  }
})
  .then(function (result) {
    console.log(result.peer.communityId);
  });
```

Routing can then resolve the preferred available transport:

```text
requested transport
      ↓
peer preference
      ↓
local preference
      ↓
first verified endpoint available
```

The persistent peer record is cached in memory for a bounded TTL.

## 2. HTTP transport

The HTTP adapter sends:

```http
POST /federation/envelopes
Content-Type: application/json
X-Octonomous-Envelope-Id: <envelope-id>
X-Octonomous-Idempotency-Key: <stable-delivery-id>
```

Body:

```json
{
  "envelope": {
    "id": "fenv:...",
    "senderCommunityId": "community:a",
    "recipientCommunityId": "community:b"
  }
}
```

Node's built-in `fetch()` is used; Node >=22 is required by the package.

## 3. MCP transport

An MCP peer endpoint can advertise a registered tool:

```json
{
  "mcp": {
    "tool": "mcp:peer-b:federation.receive"
  }
}
```

The transport sends the **same signed envelope** to that MCP tool. MCP is transport/capability plumbing; it does not replace federation signatures or governance.

## 4. DIDComm transport

DIDComm is intentionally a provider boundary:

```text
Octonomous gateway
      │
      ▼
DIDCOMM_GATEWAY_PROVIDER_MODULE
      │
      ▼
real DIDComm agent/library
```

See `examples/didcomm-gateway-provider.example.js`.

The runtime does not implement a partial/incompatible DIDComm protocol itself.

## 5. Replay protection + delivery idempotency

These are deliberately separate.

### Replay protection

Cryptographic record:

```text
(sender, recipient, nonce)
```

A nonce reused with different content is rejected.

### Delivery idempotency

Processing record:

```text
(recipient, envelopeId, envelopeDigest)
```

An exact duplicate after successful processing returns the stored result without dispatching again.

If the first processing attempt failed, the exact same signed envelope can be retried. This is important for HTTP/SQS-style at-least-once delivery.

## 6. Outbound retries

Retries reuse the exact signed envelope and stable delivery id.

Default policy:

```text
max attempts: 3
base delay:   250 ms
max delay:    5000 ms
```

Retryable failures include common transient HTTP states such as 408, 425, 429 and 5xx, plus transport errors marked `retryable`.

This is a small synchronous retry layer. For long retry windows, a production deployment should hand scheduled attempts to an external durable queue/scheduler rather than keeping a Lambda invocation alive.

## 7. Dead-letter records

After terminal failure the runtime persists:

```text
envelope
peer
transport
endpoint
attempt count
error
trace id
```

The envelope can later be replayed through the **current peer route**:

```text
federation.gateway.dead-letter.replay
```

External SQS DLQs can still be used around workers. Gateway dead letters are protocol/application delivery evidence, not a replacement for infrastructure DLQs.

## 8. Protocol tracing

The gateway persists protocol traces independently from being memory:

```text
envelope.received
envelope.verified
delivery.attempt
delivery.processed
delivery.duplicate
delivery.failed
```

No hidden model reasoning/chain-of-thought is recorded.

An optional provider can export trace records to OpenTelemetry, X-Ray, CloudWatch or another backend. See `examples/gateway-trace-provider.example.js`.

## 9. Inbound routing

`GatewayRouter` can register exact message handlers:

```js
services.gatewayRouter.register(
  'federation.learning.shared',
  function (context) {
    return Promise.resolve({
      ok: true,
      topic: context.envelope.payload.topic
    });
  }
);
```

The bootstrap fallback supports event-driven beings. If an inbound payload includes:

```json
{
  "targetBeingId": "octo:being:123"
}
```

the gateway can publish the verified message onto the local EventBridge bus for that being.

## 10. AWS gateway

`template.yaml` now deploys:

```text
                     ┌───────────────┐
Internet / peer ────►│ HTTP API      │
                     └───────┬───────┘
                             ▼
                     GatewayFunction
                     cognition: mock
                             │
             ┌───────────────┼───────────────┐
             ▼               ▼               ▼
          DynamoDB       EventBridge       traces
             │
      replay/idempotency/
      peers/delivery/DLQ
```

The inbound GatewayFunction does **not require an OpenAI API key**. Envelope validation and routing are deterministic infrastructure functions.

The normal WorkerFunction remains the place where cognition may be used.

## New tools

```text
federation.gateway.peer.register
federation.gateway.peer.get
federation.gateway.send
federation.gateway.dead-letter.get
federation.gateway.dead-letter.replay
federation.gateway.trace.get
```

Existing v0.1–v0.8 tools remain available.

## Local two-community example

```bash
npm install
npm run gateway:example
```

The example starts two independent FileStores with separate development signing identities, exchanges signed discovery descriptors, starts Community B's HTTP gateway, and sends a signed envelope from Community A.

See:

```text
examples/two-community-gateway.example.js
```

## Two-stack AWS example

See:

```text
examples/two-community-deployment/README.md
```

The same SAM template can be deployed as two separate stacks. Each has independent state and an independent gateway URL.

## Helper scripts

Create local community state:

```bash
npm run community:create -- community:a being:a "Community A"
```

Publish signed discovery:

```bash
npm run discovery:publish -- \
  community:a being:a \
  '{"http":{"url":"https://example/federation/envelopes"}}'
```

Register a peer descriptor:

```bash
npm run peer:register -- community-b.discovery.json
```

## Environment

```bash
GATEWAY_COMMUNITY_ID=community:a
GATEWAY_TRANSPORT_PREFERENCE=http,mcp,didcomm
GATEWAY_PEER_CACHE_TTL_SECONDS=300

GATEWAY_IDEMPOTENCY_RETENTION_SECONDS=86400
GATEWAY_PROCESSING_TIMEOUT_SECONDS=120

GATEWAY_RETRY_MAX_ATTEMPTS=3
GATEWAY_RETRY_BASE_DELAY_MS=250
GATEWAY_RETRY_MAX_DELAY_MS=5000
GATEWAY_HTTP_TIMEOUT_MS=10000

GATEWAY_TRACE_RETENTION_SECONDS=604800
GATEWAY_TRACE_LOG=false
GATEWAY_DEAD_LETTER_RETENTION_SECONDS=1209600

# Optional adapters
# GATEWAY_TRACE_PROVIDER_MODULE=./my-trace-provider.js
# DIDCOMM_GATEWAY_PROVIDER_MODULE=./my-didcomm-provider.js
```

v0.8 federation hardening settings remain:

```bash
FEDERATION_PROTOCOL_VERSIONS=1.0,1.1,2.0
FEDERATION_ENVELOPE_MAX_LIFETIME_SECONDS=900
FEDERATION_CLOCK_SKEW_SECONDS=120
FEDERATION_REPLAY_RETENTION_SECONDS=604800
```

## Security boundaries

```text
LLM proposes
Governance authorises
Community identity signs
Gateway transports
Receiver verifies + deduplicates
External custody/resource systems execute
Evidence records outcome
```

Important production requirements:

- use stable KERI/group-AID community signing rather than the development Ed25519 mode;
- rate-limit and protect public HTTP endpoints (for example WAF/mTLS/private connectivity where appropriate);
- do not treat signed envelopes as DDoS protection;
- do not put treasury/payment keys into the gateway;
- use external durable scheduling/queues for long retry horizons;
- keep remote peer discovery bounded by signature validation, expiry and local trust/treaty policy.

## Tests

```bash
npm test
```

v0.9 regression suite:

```text
47 tests
47 passed
0 failed
```

New gateway coverage includes:

- verified peer registration
- no local remote-community mirror requirement
- exactly-once handler dispatch for exact duplicate delivery
- retry after failed inbound processing
- HTTP idempotency headers
- MCP/DIDComm adapter boundaries
- outbound retry identity stability
- dead-letter + trace persistence
- real local two-community HTTP delivery

## Design invariant

v0.9 keeps the core Octonomous distinction intact:

```text
The Being is not the transport.
The LLM is not the authority.
The gateway is not the identity.
The community is not the database of every other community.
```

A sovereign community can now remain locally owned while interoperating through a small, signed, retryable and observable federation protocol.
