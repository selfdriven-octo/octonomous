const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const FileStore = require('../src/store/file');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const CommunitySigningService = require('../src/federation/community-signing');
const CommunityService = require('../src/federation/communities');
const MembershipService = require('../src/federation/memberships');
const GovernanceDelegationService = require('../src/federation/governance-delegations');
const CommunityGovernanceService = require('../src/federation/governance');
const FederationTrustService = require('../src/federation/trust');
const AcdcCredentialService = require('../src/credentials/acdc');
const EvidenceReputationService = require('../src/reputation/evidence');
const PortableReputationProofService = require('../src/reputation/portable-proof');
const Runtime = require('../src/runtime');
const Policy = require('../src/policy');
const ToolRegistry = require('../src/tools');

function publisher() {
  const events = [];
  return {
    events: events,
    publish: function (input) {
      const event = Object.assign({
        id: crypto.randomUUID(),
        occurredAt: new Date().toISOString()
      }, JSON.parse(JSON.stringify(input)));
      events.push(event);
      return Promise.resolve(event);
    }
  };
}

function createServices(options) {
  options = options || {};
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-v06-'));
  const store = new FileStore({ basePath: dir });
  const receipts = new ReceiptService({
    signer: new LocalEd25519Signer({ aid: options.aid || 'did:key:v06-test' })
  });
  const events = options.publisher === false ? null : publisher();
  const signing = new CommunitySigningService({ receipts: receipts });
  const communities = new CommunityService({
    store: store,
    signing: signing,
    publisher: events
  });
  const credentials = new AcdcCredentialService({ receipts: receipts });
  const memberships = new MembershipService({
    communities: communities,
    credentials: credentials,
    signing: signing,
    publisher: events
  });
  const governanceDelegations = new GovernanceDelegationService({
    communities: communities,
    receipts: receipts,
    publisher: events
  });
  const communityGovernance = new CommunityGovernanceService({
    communities: communities,
    signing: signing,
    receipts: receipts,
    publisher: events,
    delegations: governanceDelegations
  });
  const trust = new FederationTrustService({
    communities: communities,
    signing: signing,
    publisher: events
  });
  const reputation = new EvidenceReputationService({ receipts: receipts });
  const portable = new PortableReputationProofService({
    reputation: reputation,
    receipts: receipts,
    trust: trust,
    communities: communities
  });

  return {
    dir: dir,
    store: store,
    receipts: receipts,
    events: events,
    signing: signing,
    communities: communities,
    credentials: credentials,
    memberships: memberships,
    governanceDelegations: governanceDelegations,
    communityGovernance: communityGovernance,
    trust: trust,
    reputation: reputation,
    portable: portable
  };
}

function constitution(options) {
  options = options || {};
  return {
    id: options.id || 'constitution:1',
    version: options.version || '1.0.0',
    name: 'Federated Constitution',
    policies: [],
    federation: {
      amendment: {
        approvals: options.amendmentApprovals || 1,
        rejections: options.amendmentRejections || 1,
        eligibleRoles: ['founder', 'governor']
      },
      treasury: {
        approvals: options.treasuryApprovals || 1,
        rejections: options.treasuryRejections || 1,
        eligibleRoles: ['founder', 'governor']
      },
      resources: {
        approvals: options.resourceApprovals || 1,
        rejections: options.resourceRejections || 1,
        eligibleRoles: ['founder', 'governor']
      }
    }
  };
}

test('community is a durable resource independent from any being', function () {
  const svc = createServices();
  const founder = { id: 'octo:founder', identity: { keriAid: 'EFounder' } };

  return svc.communities.create({
    being: founder,
    event: { id: 'create-community' },
    input: {
      id: 'community:alpha',
      name: 'Alpha',
      purpose: ['Coordinate learning'],
      constitution: constitution(),
      treasury: { balances: { ADA: 1000 } }
    }
  })
    .then(function (result) {
      assert.equal(result.community.id, 'community:alpha');
      assert.equal(result.community.founders[0], founder.id);
      assert.equal(result.community.memberships[0].beingId, founder.id);
      assert.ok(result.community.receipt.signature);
      assert.ok(result.community.receipt.signature.publicKeyDer);
      return svc.store.loadCommunity('community:alpha');
    })
    .then(function (community) {
      assert.equal(community.name, 'Alpha');
      assert.equal(community.constitution.version, '1.0.0');
      assert.deepEqual(community.treasury.balances, { ADA: 1000 });
      return svc.store.loadBeing(founder.id);
    })
    .then(function (being) {
      assert.equal(being, null);
    });
});

test('membership roles are credential-backed, observable, and revocable', function () {
  const svc = createServices();
  const founder = { id: 'octo:founder' };
  const member = { id: 'octo:member', federation: {} };
  let issued;

  return svc.communities.create({
    being: founder,
    input: { id: 'community:members', name: 'Members', constitution: constitution() }
  })
    .then(function () {
      return svc.memberships.issue({
        being: founder,
        event: { id: 'issue-member' },
        input: {
          communityId: 'community:members',
          targetBeingId: member.id,
          subjectAid: 'EMember',
          roles: ['contributor', 'governor'],
          validUntil: '2099-01-01T00:00:00.000Z'
        }
      });
    })
    .then(function (result) {
      issued = result.membership;
      assert.equal(issued.credential.mode, 'development-receipt');
      assert.ok(issued.credential.receipt.signature);
      assert.ok(result.event);
      svc.memberships.observeEvent(member, result.event);
      assert.equal(member.federation.memberships[0].status, 'active');
      assert.deepEqual(member.federation.memberships[0].roles, ['contributor', 'governor']);

      return svc.memberships.revoke({
        being: founder,
        event: { id: 'revoke-member' },
        input: {
          communityId: 'community:members',
          membershipId: issued.id,
          reason: 'role ended'
        }
      });
    })
    .then(function (result) {
      assert.equal(result.membership.status, 'revoked');
      assert.ok(result.membership.revocationReceipt.signature);
      svc.memberships.observeEvent(member, result.event);
      assert.equal(member.federation.memberships[0].status, 'revoked');
      return svc.communities.load('community:members');
    })
    .then(function (community) {
      const stored = community.memberships.find(function (item) { return item.id === issued.id; });
      assert.equal(stored.status, 'revoked');
    });
});

test('constitutional amendment applies only after community threshold is reached', function () {
  const svc = createServices();
  const founder = { id: 'octo:founder' };
  const governor = { id: 'octo:governor' };
  let proposal;

  return svc.communities.create({
    being: founder,
    input: {
      id: 'community:constitutional',
      name: 'Constitutional',
      constitution: constitution({ amendmentApprovals: 2, amendmentRejections: 2 })
    }
  })
    .then(function () {
      return svc.memberships.issue({
        being: founder,
        input: {
          communityId: 'community:constitutional',
          targetBeingId: governor.id,
          roles: ['governor']
        }
      });
    })
    .then(function () {
      return svc.communityGovernance.propose({
        being: founder,
        event: { id: 'amend-propose' },
        input: {
          communityId: 'community:constitutional',
          kind: 'constitution.amend',
          patch: {
            version: '1.1.0',
            principles: { portableReputation: true }
          },
          summary: 'Add portable reputation principle'
        }
      });
    })
    .then(function (result) {
      proposal = result.proposal;
      assert.equal(proposal.threshold.approvals, 2);
      return svc.communityGovernance.castVote({
        being: founder,
        input: {
          communityId: 'community:constitutional',
          proposalId: proposal.id,
          vote: 'approve'
        }
      });
    })
    .then(function (firstVote) {
      assert.equal(firstVote.resolution.reached, false);
      return svc.communities.load('community:constitutional');
    })
    .then(function (community) {
      assert.equal(community.constitution.version, '1.0.0');
      assert.equal(community.constitution.principles, undefined);

      return svc.communityGovernance.castVote({
        being: governor,
        input: {
          communityId: 'community:constitutional',
          proposalId: proposal.id,
          vote: 'approve'
        }
      });
    })
    .then(function (secondVote) {
      assert.equal(secondVote.resolution.reached, true);
      assert.equal(secondVote.resolution.status, 'approved');
      assert.ok(secondVote.proposal.resolutionReceipt.signature);
      return svc.communities.load('community:constitutional');
    })
    .then(function (community) {
      assert.equal(community.constitution.version, '1.1.0');
      assert.equal(community.constitution.principles.portableReputation, true);
      assert.equal(community.constitutionHistory.length, 1);
    });
});

test('delegated governance is scoped and counts as the represented member once', function () {
  const svc = createServices();
  const founder = { id: 'octo:founder' };
  const governor = { id: 'octo:governor' };
  const delegatee = { id: 'octo:delegatee' };
  let treasuryProposal;
  let delegation;

  return svc.communities.create({
    being: founder,
    input: {
      id: 'community:delegated',
      name: 'Delegated',
      constitution: constitution({ treasuryApprovals: 2, amendmentApprovals: 2 }),
      treasury: { balances: { ADA: 500 } }
    }
  })
    .then(function () {
      return svc.memberships.issue({
        being: founder,
        input: {
          communityId: 'community:delegated',
          targetBeingId: governor.id,
          roles: ['governor']
        }
      });
    })
    .then(function () {
      return svc.governanceDelegations.create({
        being: governor,
        input: {
          communityId: 'community:delegated',
          delegateeBeingId: delegatee.id,
          scopes: ['treasury.allocate'],
          validUntil: '2099-01-01T00:00:00.000Z'
        }
      });
    })
    .then(function (result) {
      delegation = result.delegation;
      assert.ok(delegation.receipt.signature);
      return svc.communityGovernance.propose({
        being: founder,
        input: {
          communityId: 'community:delegated',
          kind: 'treasury.allocate',
          asset: 'ADA',
          amount: 100,
          target: 'project:one',
          purpose: 'Fund project one'
        }
      });
    })
    .then(function (result) {
      treasuryProposal = result.proposal;
      return svc.communityGovernance.castVote({
        being: founder,
        input: {
          communityId: 'community:delegated',
          proposalId: treasuryProposal.id,
          vote: 'approve'
        }
      });
    })
    .then(function () {
      return svc.communityGovernance.castVote({
        being: delegatee,
        input: {
          communityId: 'community:delegated',
          proposalId: treasuryProposal.id,
          representingBeingId: governor.id,
          vote: 'approve'
        }
      });
    })
    .then(function (result) {
      assert.equal(result.resolution.status, 'approved');
      assert.equal(result.vote.representedBeingId, governor.id);
      assert.equal(result.vote.governanceDelegationId, delegation.id);
      return svc.communities.load('community:delegated');
    })
    .then(function (community) {
      assert.equal(community.treasury.allocations.length, 1);
      assert.equal(community.treasury.allocations[0].amount, 100);
      assert.equal(community.treasury.allocations[0].status, 'authorised');
      assert.equal(community.treasury.balances.ADA, 500);

      return svc.communityGovernance.propose({
        being: founder,
        input: {
          communityId: 'community:delegated',
          kind: 'constitution.amend',
          patch: { version: '1.0.1' }
        }
      });
    })
    .then(function (result) {
      return assert.rejects(function () {
        return svc.communityGovernance.castVote({
          being: delegatee,
          input: {
            communityId: 'community:delegated',
            proposalId: result.proposal.id,
            representingBeingId: governor.id,
            vote: 'approve'
          }
        });
      }, /no valid delegated governance mandate/);
    });
});

test('resource governance authorises allocation without mutating the underlying pool', function () {
  const svc = createServices();
  const founder = { id: 'octo:founder' };
  let proposal;

  return svc.communities.create({
    being: founder,
    input: {
      id: 'community:resources',
      name: 'Resources',
      constitution: constitution({ resourceApprovals: 1 }),
      resources: { pools: { computeHours: 100 } }
    }
  })
    .then(function () {
      return svc.communityGovernance.propose({
        being: founder,
        input: {
          communityId: 'community:resources',
          kind: 'resource.allocate',
          resource: 'computeHours',
          quantity: 10,
          target: 'octo:researcher',
          purpose: 'Run experiments'
        }
      });
    })
    .then(function (result) {
      proposal = result.proposal;
      return svc.communities.load('community:resources');
    })
    .then(function (community) {
      assert.equal(community.resources.allocations.length, 0);
      return svc.communityGovernance.castVote({
        being: founder,
        input: {
          communityId: 'community:resources',
          proposalId: proposal.id,
          vote: 'approve'
        }
      });
    })
    .then(function () {
      return svc.communities.load('community:resources');
    })
    .then(function (community) {
      assert.equal(community.resources.allocations.length, 1);
      assert.equal(community.resources.allocations[0].quantity, 10);
      assert.equal(community.resources.pools.computeHours, 100);
    });
});

test('cross-community trust can accept an independently verifiable portable reputation proof', function () {
  const svc = createServices({ aid: 'did:key:producer-runtime' });
  const founderA = { id: 'octo:founder-a' };
  const founderB = { id: 'octo:founder-b' };
  const producer = {
    id: 'octo:producer',
    identity: { keriAid: 'EProducer' },
    commitments: [],
    delegations: [],
    contributions: [],
    challenges: [],
    governance: { votes: [] }
  };
  let proof;

  return svc.communities.create({
    being: founderA,
    input: { id: 'community:alpha-proof', name: 'Alpha Proof', constitution: constitution() }
  })
    .then(function () {
      return svc.communities.create({
        being: founderB,
        input: { id: 'community:beta-proof', name: 'Beta Proof', constitution: constitution() }
      });
    })
    .then(function () {
      return svc.memberships.issue({
        being: founderA,
        input: {
          communityId: 'community:alpha-proof',
          targetBeingId: producer.id,
          subjectAid: producer.identity.keriAid,
          roles: ['contributor']
        }
      });
    })
    .then(function () {
      return svc.trust.assert({
        being: founderB,
        input: {
          sourceCommunityId: 'community:beta-proof',
          targetCommunityId: 'community:alpha-proof',
          level: 'trusted',
          scopes: ['reputation'],
          validUntil: '2099-01-01T00:00:00.000Z'
        }
      });
    })
    .then(function () {
      return svc.receipts.create({
        kind: 'commitment.fulfilled',
        beingId: producer.id,
        subject: { id: 'commitment-1', status: 'fulfilled' },
        evidence: { outcome: 'delivered' }
      });
    })
    .then(function (receipt) {
      producer.commitments.push({
        id: 'commitment-1',
        status: 'fulfilled',
        fulfilledReceipt: receipt
      });
      return svc.portable.issue({
        being: producer,
        input: {
          issuerCommunityId: 'community:alpha-proof',
          audienceCommunityId: 'community:beta-proof',
          scope: 'collaboration',
          validUntil: '2099-01-01T00:00:00.000Z'
        }
      });
    })
    .then(function (result) {
      proof = result.proof;
      assert.equal(proof.score, 5);
      assert.equal(proof.issuerCommunityMembership.roles[0], 'contributor');
      assert.ok(proof.receipt.signature.publicKeyDer);

      const verifierReceipts = new ReceiptService({
        signer: new LocalEd25519Signer({ aid: 'did:key:independent-verifier' })
      });
      const verifier = new PortableReputationProofService({
        reputation: svc.reputation,
        receipts: verifierReceipts,
        trust: svc.trust,
        communities: svc.communities
      });

      return verifier.verify({
        proof: proof,
        relyingCommunityId: 'community:beta-proof'
      })
        .then(function (verified) {
          assert.equal(verified.valid, true);
          assert.equal(verified.subjectMatches, true);
          assert.equal(verified.cryptographic.valid, true);
          assert.equal(verified.trust.trusted, true);

          const tampered = JSON.parse(JSON.stringify(proof));
          tampered.score += 100;
          return verifier.verify({
            proof: tampered,
            relyingCommunityId: 'community:beta-proof'
          });
        });
    })
    .then(function (tamperedResult) {
      assert.equal(tamperedResult.valid, false);
      assert.equal(tamperedResult.reason, 'proof_subject_mismatch');
    });
});

test('runtime observes targeted membership events as federation state', function () {
  const svc = createServices();
  const founder = { id: 'octo:founder' };
  const target = {
    id: 'octo:runtime-member',
    purpose: ['test federation observation'],
    character: { curious: true, caring: true, constructive: true, chill: true },
    authority: { allowedTools: [], requiresApproval: [] },
    subscriptions: [],
    memory: { reflections: [], receipts: [] },
    commitments: [],
    federation: {}
  };
  const cognition = {
    consider: function () { return Promise.resolve({ relevant: true }); },
    decide: function () {
      return Promise.resolve({
        shouldAct: false,
        rationale: 'System event only',
        action: { enabled: false },
        commitment: { enabled: false }
      });
    },
    reflect: function () { return Promise.resolve({ whatHappened: 'observed membership', confidence: 1 }); }
  };
  const runtime = new Runtime({
    store: svc.store,
    cognition: cognition,
    policy: new Policy(),
    tools: new ToolRegistry(),
    receipts: svc.receipts,
    memberships: svc.memberships,
    communityGovernance: svc.communityGovernance,
    governanceDelegations: svc.governanceDelegations,
    reputation: svc.reputation
  });
  let event;

  return runtime.registerBeing(target)
    .then(function () {
      return svc.communities.create({
        being: founder,
        input: { id: 'community:runtime-observe', name: 'Runtime Observe', constitution: constitution() }
      });
    })
    .then(function () {
      return svc.memberships.issue({
        being: founder,
        input: {
          communityId: 'community:runtime-observe',
          targetBeingId: target.id,
          roles: ['member']
        }
      });
    })
    .then(function (result) {
      event = result.event;
      return runtime.handleEventForBeing(target.id, event);
    })
    .then(function (result) {
      assert.equal(result.societyObservation.federation.membership.communityId, 'community:runtime-observe');
      return svc.store.loadBeing(target.id);
    })
    .then(function (stored) {
      assert.equal(stored.federation.memberships.length, 1);
      assert.equal(stored.federation.memberships[0].roles[0], 'member');
    });
});
