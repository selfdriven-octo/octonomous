const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const FileStore = require('../src/store/file');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const CommunitySigningService = require('../src/federation/community-signing');
const CommunityService = require('../src/federation/communities');
const MembershipService = require('../src/federation/memberships');
const FederationTrustService = require('../src/federation/trust');
const TreatyService = require('../src/federation/treaties');
const FederatedProposalService = require('../src/federation/federated-proposals');
const FederatedDisputeService = require('../src/federation/disputes');
const FederationTrustPathService = require('../src/federation/trust-paths');
const ResourceExchangeService = require('../src/federation/resource-exchange');
const GroupIdentityService = require('../src/federation/group-identity');
const AcdcCredentialService = require('../src/credentials/acdc');
const Runtime = require('../src/runtime');
const Policy = require('../src/policy');
const ToolRegistry = require('../src/tools');
const MockCognition = require('../src/cognition/mock');

function publisher() {
  const events = [];
  return {
    events: events,
    publish: function (input) {
      const event = Object.assign({
        id: crypto.randomUUID(),
        occurredAt: new Date().toISOString()
      }, JSON.parse(JSON.stringify(input)));
      events.push(event);
      return Promise.resolve(event);
    }
  };
}

function constitution() {
  return {
    id: 'constitution:' + crypto.randomUUID(),
    version: '1.0.0',
    name: 'Sovereign Federation Constitution',
    policies: [],
    federation: {
      amendment: { approvals: 1, rejections: 1, eligibleRoles: ['founder', 'governor'] },
      treasury: { approvals: 1, rejections: 1, eligibleRoles: ['founder', 'governor'] },
      resources: { approvals: 1, rejections: 1, eligibleRoles: ['founder', 'governor'] }
    }
  };
}

function createServices(options) {
  options = options || {};
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'octonomous-v07-'));
  const store = new FileStore({ basePath: dir });
  const receipts = new ReceiptService({ signer: new LocalEd25519Signer({ aid: 'did:key:v07-test' }) });
  const events = publisher();
  const signing = new CommunitySigningService({ receipts: receipts });
  const communities = new CommunityService({ store: store, signing: signing, publisher: events });
  const credentials = new AcdcCredentialService({ receipts: receipts });
  const memberships = new MembershipService({ communities: communities, credentials: credentials, signing: signing, publisher: events });
  const trust = new FederationTrustService({ communities: communities, signing: signing, publisher: events });
  const treaties = new TreatyService({ store: store, communities: communities, signing: signing, receipts: receipts, publisher: events });
  const proposals = new FederatedProposalService({ store: store, communities: communities, signing: signing, receipts: receipts, publisher: events, treaties: treaties });
  const disputes = new FederatedDisputeService({ store: store, communities: communities, signing: signing, publisher: events, treaties: treaties });
  const trustPaths = new FederationTrustPathService({ communities: communities, trust: trust, treaties: treaties });
  const exchanges = new ResourceExchangeService({ store: store, communities: communities, signing: signing, publisher: events, treaties: treaties });
  const groupIdentity = new GroupIdentityService({ communities: communities, signing: signing, provider: options.groupIdentityProvider || null });

  return {
    dir: dir,
    store: store,
    receipts: receipts,
    events: events,
    signing: signing,
    communities: communities,
    memberships: memberships,
    trust: trust,
    treaties: treaties,
    proposals: proposals,
    disputes: disputes,
    trustPaths: trustPaths,
    exchanges: exchanges,
    groupIdentity: groupIdentity
  };
}

function makeCommunity(svc, id, founder, options) {
  options = options || {};
  return svc.communities.create({
    being: founder,
    input: {
      id: id,
      name: options.name || id,
      constitution: constitution(),
      treasury: { balances: options.balances || {} },
      resources: { pools: options.resources || {} }
    }
  });
}

function createAndActivateTreaty(svc, a, founderA, b, founderB, options) {
  options = options || {};
  let treaty;
  return svc.treaties.propose({
    being: founderA,
    input: {
      proposerCommunityId: a,
      participantCommunityIds: [b],
      scopes: options.scopes || ['*'],
      disputeResolverCommunityId: options.disputeResolverCommunityId || null
    }
  })
    .then(function (result) {
      treaty = result.treaty;
      return svc.treaties.ratify({ being: founderA, input: { treatyId: treaty.id, communityId: a } });
    })
    .then(function () {
      return svc.treaties.ratify({ being: founderB, input: { treatyId: treaty.id, communityId: b } });
    })
    .then(function () { return treaty; });
}

test('treaty activates only after independently signed community ratifications', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  let treaty;

  return Promise.all([
    makeCommunity(svc, 'community:a', a),
    makeCommunity(svc, 'community:b', b)
  ])
    .then(function () {
      return svc.treaties.propose({
        being: a,
        input: {
          proposerCommunityId: 'community:a',
          participantCommunityIds: ['community:b'],
          scopes: ['resource.exchange']
        }
      });
    })
    .then(function (result) {
      treaty = result.treaty;
      assert.equal(treaty.status, 'proposed');
      assert.ok(treaty.proposalReceipt.signature);
      return svc.treaties.ratify({ being: a, input: { treatyId: treaty.id, communityId: 'community:a' } });
    })
    .then(function (result) {
      assert.equal(result.treaty.status, 'proposed');
      assert.ok(result.ratification.receipt.signature);
      return svc.treaties.ratify({ being: b, input: { treatyId: treaty.id, communityId: 'community:b' } });
    })
    .then(function (result) {
      assert.equal(result.treaty.status, 'active');
      assert.ok(result.treaty.activationReceipt.signature);
      assert.equal(svc.treaties.isActive(result.treaty, 'community:a', 'community:b', 'resource.exchange'), true);
    });
});

test('federated proposal counts one signed decision per sovereign community', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  let treaty;
  let proposal;

  return Promise.all([makeCommunity(svc, 'community:a', a), makeCommunity(svc, 'community:b', b)])
    .then(function () { return createAndActivateTreaty(svc, 'community:a', a, 'community:b', b, { scopes: ['federation.proposal'] }); })
    .then(function (t) {
      treaty = t;
      return svc.proposals.create({
        being: a,
        input: {
          proposerCommunityId: 'community:a',
          participantCommunityIds: ['community:b'],
          treatyId: treaty.id,
          scope: 'federation.proposal',
          kind: 'shared-standard',
          approvals: 2,
          payload: { standard: 'evidence-v1' }
        }
      });
    })
    .then(function (result) {
      proposal = result.proposal;
      return svc.proposals.castCommunityVote({ being: a, input: { proposalId: proposal.id, communityId: 'community:a', vote: 'approve' } });
    })
    .then(function (first) {
      assert.equal(first.proposal.status, 'pending');
      return svc.proposals.castCommunityVote({ being: b, input: { proposalId: proposal.id, communityId: 'community:b', vote: 'approve' } });
    })
    .then(function (second) {
      assert.equal(second.proposal.status, 'approved');
      assert.equal(second.resolution.approvals, 2);
      assert.ok(second.proposal.resolutionReceipt.signature);
      return assert.rejects(function () {
        return svc.proposals.castCommunityVote({ being: b, input: { proposalId: proposal.id, communityId: 'community:b', vote: 'approve' } });
      }, /not pending|already decided/);
    });
});

test('treaty scopes prevent accidental authority expansion', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  let treaty;

  return Promise.all([makeCommunity(svc, 'community:a', a), makeCommunity(svc, 'community:b', b)])
    .then(function () { return createAndActivateTreaty(svc, 'community:a', a, 'community:b', b, { scopes: ['federation.proposal'] }); })
    .then(function (t) {
      treaty = t;
      return assert.rejects(function () {
        return svc.exchanges.offer({
          being: a,
          input: {
            sourceCommunityId: 'community:a', targetCommunityId: 'community:b', treatyId: treaty.id,
            give: [{ asset: 'ADA', amount: 10 }], receive: [{ resource: 'computeHours', quantity: 1 }]
          }
        });
      }, /does not authorise resource.exchange/);
    });
});

test('cross-community dispute is resolved only by the treaty-designated resolver community', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  const r = { id: 'being:resolver' };
  let treaty;
  let dispute;

  return Promise.all([
    makeCommunity(svc, 'community:a', a),
    makeCommunity(svc, 'community:b', b),
    makeCommunity(svc, 'community:resolver', r)
  ])
    .then(function () {
      return createAndActivateTreaty(svc, 'community:a', a, 'community:b', b, {
        scopes: ['*'], disputeResolverCommunityId: 'community:resolver'
      });
    })
    .then(function (t) {
      treaty = t;
      return svc.disputes.open({
        being: a,
        input: {
          treatyId: treaty.id, claimantCommunityId: 'community:a', respondentCommunityId: 'community:b',
          claim: 'Delivery evidence is incomplete'
        }
      });
    })
    .then(function (result) {
      dispute = result.dispute;
      assert.ok(dispute.openingReceipt.signature);
      return svc.disputes.respond({ being: b, input: { disputeId: dispute.id, statement: 'Evidence supplied' } });
    })
    .then(function () {
      return assert.rejects(function () {
        return svc.disputes.resolve({ being: a, input: { disputeId: dispute.id, verdict: 'dismissed' } });
      }, /not authorised to resolve/);
    })
    .then(function () {
      return svc.disputes.resolve({ being: r, input: { disputeId: dispute.id, verdict: 'partially_upheld', reasoning: 'Some evidence arrived late' } });
    })
    .then(function (result) {
      assert.equal(result.dispute.status, 'resolved');
      assert.equal(result.dispute.resolution.resolverCommunityId, 'community:resolver');
      assert.ok(result.dispute.resolution.receipt.signature);
    });
});

test('trust path composes signed assertions and active treaties without a global trust authority', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  const c = { id: 'being:c' };

  return Promise.all([
    makeCommunity(svc, 'community:a', a),
    makeCommunity(svc, 'community:b', b),
    makeCommunity(svc, 'community:c', c)
  ])
    .then(function () {
      return svc.trust.assert({
        being: a,
        input: { sourceCommunityId: 'community:a', targetCommunityId: 'community:b', level: 'trusted', scopes: ['reputation'] }
      });
    })
    .then(function () {
      return createAndActivateTreaty(svc, 'community:b', b, 'community:c', c, { scopes: ['reputation'] });
    })
    .then(function () {
      return svc.trustPaths.compute({ sourceCommunityId: 'community:a', targetCommunityId: 'community:c', scope: 'reputation', maxHops: 4 });
    })
    .then(function (pathResult) {
      assert.equal(pathResult.found, true);
      assert.equal(pathResult.hops, 2);
      assert.equal(pathResult.path[0].kind, 'trust-assertion');
      assert.equal(pathResult.path[1].kind, 'treaty');
      assert.equal(pathResult.score, 0.95);
    });
});

test('resource exchange creates bilateral authorisations without mutating treasury or resource pools', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  let treaty;
  let exchange;

  return Promise.all([
    makeCommunity(svc, 'community:a', a, { balances: { ADA: 100 } }),
    makeCommunity(svc, 'community:b', b, { resources: { computeHours: 50 } })
  ])
    .then(function () { return createAndActivateTreaty(svc, 'community:a', a, 'community:b', b, { scopes: ['resource.exchange'] }); })
    .then(function (t) {
      treaty = t;
      return svc.exchanges.offer({
        being: a,
        input: {
          sourceCommunityId: 'community:a', targetCommunityId: 'community:b', treatyId: treaty.id,
          give: [{ kind: 'treasury', asset: 'ADA', amount: 10 }],
          receive: [{ kind: 'resource', resource: 'computeHours', quantity: 5 }]
        }
      });
    })
    .then(function (result) {
      exchange = result.exchange;
      assert.equal(exchange.status, 'offered');
      return svc.exchanges.accept({ being: b, input: { exchangeId: exchange.id } });
    })
    .then(function (result) {
      assert.equal(result.exchange.status, 'authorised');
      assert.equal(result.exchange.authorisations.length, 2);
      return Promise.all([svc.communities.load('community:a'), svc.communities.load('community:b')]);
    })
    .then(function (communities) {
      assert.equal(communities[0].treasury.balances.ADA, 100);
      assert.equal(communities[1].resources.pools.computeHours, 50);
    });
});

test('resource exchange settlement remains external and reaches settled only after both communities record evidence', function () {
  const svc = createServices();
  const a = { id: 'being:a' };
  const b = { id: 'being:b' };
  let exchange;

  return Promise.all([makeCommunity(svc, 'community:a', a), makeCommunity(svc, 'community:b', b)])
    .then(function () { return createAndActivateTreaty(svc, 'community:a', a, 'community:b', b, { scopes: ['resource.exchange'] }); })
    .then(function (treaty) {
      return svc.exchanges.offer({ being: a, input: { sourceCommunityId: 'community:a', targetCommunityId: 'community:b', treatyId: treaty.id, give: [], receive: [] } });
    })
    .then(function (result) {
      exchange = result.exchange;
      return svc.exchanges.accept({ being: b, input: { exchangeId: exchange.id } });
    })
    .then(function () {
      return svc.exchanges.recordSettlement({ being: a, input: { exchangeId: exchange.id, communityId: 'community:a', externalReference: 'tx:a' } });
    })
    .then(function (one) {
      assert.equal(one.exchange.status, 'authorised');
      return svc.exchanges.recordSettlement({ being: b, input: { exchangeId: exchange.id, communityId: 'community:b', externalReference: 'job:b' } });
    })
    .then(function (two) {
      assert.equal(two.exchange.status, 'settled');
      assert.equal(two.exchange.settlements.length, 2);
    });
});

test('community group identity is an adapter boundary with an explicitly marked development binding', function () {
  const svc = createServices();
  const founder = { id: 'being:founder' };

  return makeCommunity(svc, 'community:group', founder)
    .then(function () {
      return svc.groupIdentity.bind({
        being: founder,
        input: {
          communityId: 'community:group', aid: 'EGroupAID', memberAids: ['EA', 'EB', 'EC'], threshold: '2-of-3'
        }
      });
    })
    .then(function (result) {
      assert.equal(result.identity.aid, 'EGroupAID');
      assert.equal(result.identity.mode, 'development-binding');
      assert.ok(result.identity.receipt.signature);
      return svc.groupIdentity.describe({ communityId: 'community:group' });
    })
    .then(function (described) {
      assert.equal(described.identity.threshold, '2-of-3');
      assert.deepEqual(described.identity.memberAids, ['EA', 'EB', 'EC']);
    });
});

test('federation protocol events wake beings as system events and are retained as bounded observations', function () {
  const svc = createServices();
  const runtime = new Runtime({
    store: svc.store,
    cognition: new MockCognition(),
    policy: new Policy(),
    tools: new ToolRegistry(),
    receipts: svc.receipts
  });
  const being = {
    id: 'being:observer',
    identity: {},
    purpose: [],
    character: {},
    authority: { allowedTools: [], requiresApproval: [] },
    subscriptions: [],
    commitments: [],
    memory: { reflections: [], receipts: [] },
    federation: {}
  };

  return runtime.registerBeing(being)
    .then(function () {
      return runtime.handleEventForBeing(being.id, {
        id: 'event:federation',
        type: 'federation.treaty.activated',
        payload: { treatyId: 'treaty:one', status: 'active' }
      });
    })
    .then(function (result) {
      assert.equal(result.beingId, being.id);
      assert.equal(result.societyObservation.federation.protocol.type, 'federation.treaty.activated');
      return svc.store.loadBeing(being.id);
    })
    .then(function (saved) {
      assert.equal(saved.federation.protocolEvents.length, 1);
      assert.equal(saved.federation.protocolEvents[0].payload.treatyId, 'treaty:one');
    });
});
