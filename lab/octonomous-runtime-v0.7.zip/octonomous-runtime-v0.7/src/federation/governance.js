const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function mergePatch(target, patch) {
  if (patch === null || typeof patch !== 'object' || Array.isArray(patch)) {
    return clone(patch);
  }

  const out = target && typeof target === 'object' && !Array.isArray(target)
    ? clone(target)
    : {};

  Object.keys(patch).forEach(function (key) {
    const value = patch[key];
    if (value === null) {
      delete out[key];
      return;
    }
    out[key] = mergePatch(out[key], value);
  });

  return out;
}

function CommunityGovernanceService(options) {
  options = options || {};
  this.communities = options.communities;
  this.signing = options.signing || null;
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
  this.delegations = options.delegations || null;
}

CommunityGovernanceService.prototype._policyFor = function (community, kind) {
  const federation = community.constitution && community.constitution.federation || {};
  let policy;

  if (kind === 'constitution.amend') {
    policy = federation.amendment || {};
  }
  else if (kind === 'treasury.allocate') {
    policy = federation.treasury || {};
  }
  else if (kind === 'resource.allocate') {
    policy = federation.resources || {};
  }
  else {
    policy = federation.general || {};
  }

  return {
    approvals: Number(policy.approvals || 1),
    rejections: Number(policy.rejections || 1),
    eligibleRoles: Array.isArray(policy.eligibleRoles) && policy.eligibleRoles.length
      ? policy.eligibleRoles.slice()
      : ['founder', 'governor'],
    vetoRoles: Array.isArray(policy.vetoRoles) ? policy.vetoRoles.slice() : []
  };
};

CommunityGovernanceService.prototype._eligibleMemberships = function (community, policy) {
  const active = this.communities.activeMemberships(community);
  return active.filter(function (membership) {
    return (membership.roles || []).some(function (role) {
      return policy.eligibleRoles.includes(role);
    });
  });
};

CommunityGovernanceService.prototype._proposalPayload = function (kind, input) {
  if (kind === 'constitution.amend') {
    if (!input.patch || typeof input.patch !== 'object') {
      throw new Error('constitution.amend proposal requires patch');
    }
    return { patch: clone(input.patch), summary: input.summary || '' };
  }

  if (kind === 'treasury.allocate') {
    if (!input.asset || input.amount === undefined || !input.target) {
      throw new Error('treasury.allocate proposal requires asset, amount, and target');
    }
    const amount = Number(input.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      throw new Error('treasury.allocate amount must be a positive number');
    }
    return {
      asset: input.asset,
      amount: amount,
      target: input.target,
      purpose: input.purpose || '',
      reference: input.reference || null
    };
  }

  if (kind === 'resource.allocate') {
    if (!input.resource || input.quantity === undefined || !input.target) {
      throw new Error('resource.allocate proposal requires resource, quantity, and target');
    }
    const quantity = Number(input.quantity);
    if (!Number.isFinite(quantity) || quantity <= 0) {
      throw new Error('resource.allocate quantity must be a positive number');
    }
    return {
      resource: input.resource,
      quantity: quantity,
      target: input.target,
      purpose: input.purpose || '',
      reference: input.reference || null
    };
  }

  return clone(input.payload || {});
};

CommunityGovernanceService.prototype.propose = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const kind = input.kind;
  let community;
  let proposal;
  let eligibleMemberships;

  if (!input.communityId || !kind) {
    return Promise.reject(new Error('community.governance.propose requires communityId and kind'));
  }

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      if (!loaded) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      community = loaded;
      const proposerMembership = self.communities.membershipFor(community, being.id);
      if (!proposerMembership) {
        throw new Error('Only an active member may create a community governance proposal');
      }

      const policy = self._policyFor(community, kind);
      eligibleMemberships = self._eligibleMemberships(community, policy);
      if (!eligibleMemberships.length) {
        throw new Error('Community governance proposal has no eligible voters');
      }

      proposal = {
        id: crypto.randomUUID(),
        version: 'octonomous.community-governance-proposal.v1',
        communityId: community.id,
        kind: kind,
        proposedByBeingId: being.id,
        proposedByMembershipId: proposerMembership.id,
        payload: self._proposalPayload(kind, input),
        threshold: {
          approvals: policy.approvals,
          rejections: policy.rejections,
          eligibleRoles: policy.eligibleRoles,
          vetoRoles: policy.vetoRoles,
          eligibleMemberBeingIds: eligibleMemberships.map(function (item) { return item.beingId; })
        },
        votes: [],
        status: 'pending',
        createdAt: new Date().toISOString(),
        receipt: null,
        resolutionReceipt: null
      };

      const signPromise = self.signing
        ? self.signing.sign(community, 'community.governance.proposal.created', proposal, {
          proposedByBeingId: being.id,
          sourceEventId: context.event && context.event.id
        })
        : Promise.resolve(null);
      return signPromise;
    })
    .then(function (receipt) {
      proposal.receipt = receipt;
      community.governance = community.governance || {};
      community.governance.proposals = community.governance.proposals || [];
      community.governance.proposals.push(proposal);
      return self.communities.save(community);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, proposal: proposal, events: [] };
      }

      return Promise.all(eligibleMemberships.map(function (membership) {
        return self.publisher.publish({
          type: 'community.governance.proposal.created',
          sourceBeingId: being.id,
          targetBeingId: membership.beingId,
          payload: {
            communityId: community.id,
            proposal: proposal,
            sourceBeingId: being.id
          }
        });
      }))
        .then(function (events) {
          proposal.deliveryEventIds = events.map(function (event) { return event.id; });
          return { ok: true, proposal: proposal, events: events };
        });
    });
};

CommunityGovernanceService.prototype._resolveVotingIdentity = function (community, proposal, voterBeingId, representingBeingId) {
  const eligible = proposal.threshold.eligibleMemberBeingIds || [];
  if (eligible.includes(voterBeingId) && (!representingBeingId || representingBeingId === voterBeingId)) {
    return {
      representedBeingId: voterBeingId,
      delegation: null
    };
  }

  if (!this.delegations) {
    return null;
  }

  const mandates = this.delegations.activeMandatesFor(community, voterBeingId, proposal.kind);
  const selected = mandates.find(function (mandate) {
    return eligible.includes(mandate.principalBeingId) &&
      (!representingBeingId || mandate.principalBeingId === representingBeingId);
  });

  if (!selected) {
    return null;
  }

  return {
    representedBeingId: selected.principalBeingId,
    delegation: selected
  };
};

CommunityGovernanceService.prototype.castVote = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const voteValue = String(input.vote || '').toLowerCase();
  let community;
  let proposal;
  let votingIdentity;
  let vote;

  if (!input.communityId || !input.proposalId) {
    return Promise.reject(new Error('community.governance.vote requires communityId and proposalId'));
  }
  if (!['approve', 'reject', 'abstain'].includes(voteValue)) {
    return Promise.reject(new Error('community.governance.vote must be approve, reject, or abstain'));
  }

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      if (!loaded) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      community = loaded;
      proposal = community.governance && (community.governance.proposals || []).find(function (item) {
        return item.id === input.proposalId;
      });
      if (!proposal) {
        throw new Error('Unknown community governance proposal: ' + input.proposalId);
      }
      if (proposal.status !== 'pending') {
        throw new Error('Community governance proposal is not pending');
      }

      votingIdentity = self._resolveVotingIdentity(
        community,
        proposal,
        being.id,
        input.representingBeingId || null
      );
      if (!votingIdentity) {
        throw new Error('Being is not eligible to vote and has no valid delegated governance mandate');
      }

      const duplicate = (proposal.votes || []).find(function (item) {
        return item.representedBeingId === votingIdentity.representedBeingId;
      });
      if (duplicate) {
        throw new Error('The represented member has already voted on this proposal');
      }

      vote = {
        id: crypto.randomUUID(),
        version: 'octonomous.community-governance-vote.v1',
        communityId: community.id,
        proposalId: proposal.id,
        kind: proposal.kind,
        voterBeingId: being.id,
        representedBeingId: votingIdentity.representedBeingId,
        governanceDelegationId: votingIdentity.delegation ? votingIdentity.delegation.id : null,
        vote: voteValue,
        reason: input.reason || '',
        createdAt: new Date().toISOString(),
        receipt: null
      };

      if (self.receipts) {
        return self.receipts.create({
          kind: 'community.governance.vote.cast',
          beingId: being.id,
          subject: vote,
          evidence: {
            representedBeingId: vote.representedBeingId,
            governanceDelegationId: vote.governanceDelegationId
          }
        });
      }

      return null;
    })
    .then(function (receipt) {
      vote.receipt = receipt;
      proposal.votes = proposal.votes || [];
      proposal.votes.push(vote);
      return self._resolveIfReady(community, proposal);
    })
    .then(function (resolution) {
      return self.communities.save(community)
        .then(function () {
          if (!self.publisher || !resolution || !resolution.reached) {
            return [];
          }

          const targets = proposal.threshold.eligibleMemberBeingIds || [];
          const eventType = 'community.governance.proposal.resolved';
          return Promise.all(targets.map(function (targetBeingId) {
            return self.publisher.publish({
              type: eventType,
              sourceBeingId: being.id,
              targetBeingId: targetBeingId,
              payload: {
                communityId: community.id,
                proposalId: proposal.id,
                kind: proposal.kind,
                status: proposal.status,
                resolution: proposal.resolution,
                sourceBeingId: being.id
              }
            });
          }));
        })
        .then(function (events) {
          return {
            ok: true,
            vote: vote,
            proposal: proposal,
            resolution: resolution,
            events: events
          };
        });
    });
};

CommunityGovernanceService.prototype._hasVeto = function (community, proposal, vote) {
  if (!proposal.threshold.vetoRoles || !proposal.threshold.vetoRoles.length) {
    return false;
  }
  const membership = this.communities.membershipFor(community, vote.representedBeingId);
  if (!membership) {
    return false;
  }
  return vote.vote === 'reject' && (membership.roles || []).some(function (role) {
    return proposal.threshold.vetoRoles.includes(role);
  });
};

CommunityGovernanceService.prototype._resolveIfReady = function (community, proposal) {
  const self = this;
  if (proposal.status !== 'pending') {
    return Promise.resolve(proposal.resolution || null);
  }

  const approvals = (proposal.votes || []).filter(function (vote) { return vote.vote === 'approve'; });
  const rejections = (proposal.votes || []).filter(function (vote) { return vote.vote === 'reject'; });
  const veto = rejections.find(function (vote) { return self._hasVeto(community, proposal, vote); });

  let status = null;
  if (veto || rejections.length >= Number(proposal.threshold.rejections || 1)) {
    status = 'rejected';
  }
  else if (approvals.length >= Number(proposal.threshold.approvals || 1)) {
    status = 'approved';
  }

  if (!status) {
    return Promise.resolve({ reached: false, status: 'pending' });
  }

  proposal.status = status;
  proposal.resolvedAt = new Date().toISOString();
  proposal.resolution = {
    reached: true,
    status: status,
    approvals: approvals.length,
    rejections: rejections.length,
    abstentions: (proposal.votes || []).filter(function (vote) { return vote.vote === 'abstain'; }).length,
    vetoedBy: veto ? veto.representedBeingId : null,
    applied: false
  };

  if (status === 'approved') {
    self._applyApprovedProposal(community, proposal);
    proposal.resolution.applied = true;
  }

  const signPromise = self.signing
    ? self.signing.sign(community, 'community.governance.proposal.' + status, {
      proposalId: proposal.id,
      kind: proposal.kind,
      resolution: proposal.resolution,
      payload: proposal.payload,
      resolvedAt: proposal.resolvedAt
    }, {
      voteReceiptIds: (proposal.votes || []).map(function (vote) {
        return vote.receipt && vote.receipt.id || null;
      }).filter(Boolean)
    })
    : Promise.resolve(null);

  return signPromise
    .then(function (receipt) {
      proposal.resolutionReceipt = receipt;
      return proposal.resolution;
    });
};

CommunityGovernanceService.prototype._applyApprovedProposal = function (community, proposal) {
  if (proposal.kind === 'constitution.amend') {
    const previous = clone(community.constitution || {});
    community.constitutionHistory = community.constitutionHistory || [];
    community.constitutionHistory.push({
      constitution: previous,
      supersededAt: new Date().toISOString(),
      supersededByProposalId: proposal.id
    });
    community.constitution = mergePatch(previous, proposal.payload.patch);
    community.constitution.id = community.constitution.id || (community.id + ':constitution:' + crypto.randomUUID());
    community.constitution.amendedAt = new Date().toISOString();
    community.constitution.amendedByProposalId = proposal.id;
    return;
  }

  if (proposal.kind === 'treasury.allocate') {
    community.treasury = community.treasury || { balances: {}, allocations: [] };
    community.treasury.allocations = community.treasury.allocations || [];
    community.treasury.allocations.push({
      id: crypto.randomUUID(),
      proposalId: proposal.id,
      asset: proposal.payload.asset,
      amount: proposal.payload.amount,
      target: proposal.payload.target,
      purpose: proposal.payload.purpose,
      reference: proposal.payload.reference,
      status: 'authorised',
      authorisedAt: new Date().toISOString()
    });
    return;
  }

  if (proposal.kind === 'resource.allocate') {
    community.resources = community.resources || { pools: {}, allocations: [] };
    community.resources.allocations = community.resources.allocations || [];
    community.resources.allocations.push({
      id: crypto.randomUUID(),
      proposalId: proposal.id,
      resource: proposal.payload.resource,
      quantity: proposal.payload.quantity,
      target: proposal.payload.target,
      purpose: proposal.payload.purpose,
      reference: proposal.payload.reference,
      status: 'authorised',
      authorisedAt: new Date().toISOString()
    });
  }
};

CommunityGovernanceService.mergePatch = mergePatch;

module.exports = CommunityGovernanceService;

CommunityGovernanceService.prototype.observeEvent = function (being, event) {
  if (!event || !event.payload || !event.type.startsWith('community.governance.')) {
    return null;
  }
  being.federation = being.federation || {};
  being.federation.communityGovernance = being.federation.communityGovernance || [];
  const observation = {
    eventId: event.id || null,
    type: event.type,
    communityId: event.payload.communityId || event.payload.proposal && event.payload.proposal.communityId || null,
    proposalId: event.payload.proposal && event.payload.proposal.id || event.payload.proposalId || null,
    observedAt: new Date().toISOString()
  };
  being.federation.communityGovernance.push(observation);
  if (being.federation.communityGovernance.length > 50) {
    being.federation.communityGovernance = being.federation.communityGovernance.slice(-50);
  }
  return observation;
};
