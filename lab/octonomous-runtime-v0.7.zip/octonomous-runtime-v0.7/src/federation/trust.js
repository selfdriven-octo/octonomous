const crypto = require('crypto');

function FederationTrustService(options) {
  options = options || {};
  this.communities = options.communities;
  this.signing = options.signing || null;
  this.publisher = options.publisher || null;
}

FederationTrustService.prototype.assert = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let sourceCommunity;
  let targetCommunity;
  let assertion;

  if (!input.sourceCommunityId || !input.targetCommunityId) {
    return Promise.reject(new Error('community.trust.assert requires sourceCommunityId and targetCommunityId'));
  }
  if (input.sourceCommunityId === input.targetCommunityId) {
    return Promise.reject(new Error('A community cannot federate with itself'));
  }

  return Promise.all([
    self.communities.load(input.sourceCommunityId),
    self.communities.load(input.targetCommunityId)
  ])
    .then(function (loaded) {
      sourceCommunity = loaded[0];
      targetCommunity = loaded[1];
      if (!sourceCommunity) {
        throw new Error('Unknown source community: ' + input.sourceCommunityId);
      }
      if (!targetCommunity) {
        throw new Error('Unknown target community: ' + input.targetCommunityId);
      }
      if (!self.communities.hasRole(sourceCommunity, being.id, ['founder', 'governor', 'federation-admin'])) {
        throw new Error('Being is not authorised to assert federation trust for source community');
      }

      assertion = {
        id: crypto.randomUUID(),
        version: 'octonomous.federation-trust.v1',
        sourceCommunityId: sourceCommunity.id,
        targetCommunityId: targetCommunity.id,
        level: input.level || 'trusted',
        scopes: Array.isArray(input.scopes) && input.scopes.length ? input.scopes.slice() : ['*'],
        claims: input.claims || {},
        validUntil: input.validUntil || null,
        status: 'active',
        assertedAt: new Date().toISOString(),
        assertedByBeingId: being.id,
        receipt: null
      };

      return self.signing
        ? self.signing.sign(sourceCommunity, 'community.trust.asserted', assertion, {
          targetCommunityId: targetCommunity.id,
          assertedByBeingId: being.id
        })
        : null;
    })
    .then(function (receipt) {
      assertion.receipt = receipt;
      sourceCommunity.trustAssertions = sourceCommunity.trustAssertions || [];
      sourceCommunity.trustAssertions.push(assertion);
      return self.communities.save(sourceCommunity);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, assertion: assertion, event: null };
      }
      return self.publisher.publish({
        type: 'community.trust.asserted',
        sourceBeingId: being.id,
        payload: {
          assertion: assertion,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          return { ok: true, assertion: assertion, event: event };
        });
    });
};

FederationTrustService.prototype.revoke = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let community;
  let assertion;

  if (!input.sourceCommunityId || !input.assertionId) {
    return Promise.reject(new Error('community.trust.revoke requires sourceCommunityId and assertionId'));
  }

  return self.communities.load(input.sourceCommunityId)
    .then(function (loaded) {
      community = loaded;
      if (!community) {
        throw new Error('Unknown source community: ' + input.sourceCommunityId);
      }
      if (!self.communities.hasRole(community, being.id, ['founder', 'governor', 'federation-admin'])) {
        throw new Error('Being is not authorised to revoke federation trust');
      }
      assertion = (community.trustAssertions || []).find(function (item) {
        return item.id === input.assertionId;
      });
      if (!assertion) {
        throw new Error('Unknown trust assertion: ' + input.assertionId);
      }
      assertion.status = 'revoked';
      assertion.revokedAt = new Date().toISOString();
      assertion.revokedByBeingId = being.id;
      assertion.revocationReason = input.reason || '';
      return self.signing
        ? self.signing.sign(community, 'community.trust.revoked', assertion, {
          revokedByBeingId: being.id
        })
        : null;
    })
    .then(function (receipt) {
      assertion.revocationReceipt = receipt;
      return self.communities.save(community);
    })
    .then(function () {
      return { ok: true, assertion: assertion };
    });
};

FederationTrustService.prototype.evaluate = function (sourceCommunityId, targetCommunityId, scope) {
  const self = this;
  const now = Date.now();
  return self.communities.load(sourceCommunityId)
    .then(function (community) {
      if (!community) {
        return { trusted: false, reason: 'unknown_source_community' };
      }
      const assertion = (community.trustAssertions || []).find(function (item) {
        if (item.status !== 'active' || item.targetCommunityId !== targetCommunityId) {
          return false;
        }
        if (item.validUntil && Date.parse(item.validUntil) <= now) {
          return false;
        }
        const scopes = item.scopes || ['*'];
        return scopes.includes('*') || scopes.includes(scope || '*');
      });

      if (!assertion) {
        return { trusted: false, reason: 'no_active_trust_assertion' };
      }

      if (!self.signing || typeof self.signing.verify !== 'function') {
        return {
          trusted: true,
          level: assertion.level,
          assertionId: assertion.id,
          receipt: assertion.receipt || null,
          cryptographic: null
        };
      }

      return self.signing.verify(community, assertion.receipt)
        .then(function (verification) {
          if (verification && verification.valid === false) {
            return {
              trusted: false,
              reason: 'invalid_trust_assertion_receipt',
              assertionId: assertion.id,
              cryptographic: verification
            };
          }
          return {
            trusted: true,
            level: assertion.level,
            assertionId: assertion.id,
            receipt: assertion.receipt || null,
            cryptographic: verification || null
          };
        });
    });
};

module.exports = FederationTrustService;
