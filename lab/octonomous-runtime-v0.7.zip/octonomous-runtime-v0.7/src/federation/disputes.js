const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function FederatedDisputeService(options) {
  options = options || {};
  this.store = options.store;
  this.communities = options.communities;
  this.signing = options.signing || null;
  this.publisher = options.publisher || null;
  this.treaties = options.treaties;
}

FederatedDisputeService.prototype.load = function (id) {
  return this.store.loadResource('federated-dispute', id);
};

FederatedDisputeService.prototype.save = function (dispute) {
  return this.store.saveResource('federated-dispute', dispute);
};

FederatedDisputeService.prototype._canRepresent = function (community, beingId) {
  return this.communities.hasRole(community, beingId, ['founder', 'governor', 'federation-admin', 'arbiter']);
};

FederatedDisputeService.prototype.open = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let treaty;
  let claimant;
  let respondent;
  let dispute;

  if (!input.treatyId || !input.claimantCommunityId || !input.respondentCommunityId) {
    return Promise.reject(new Error('federation.dispute.open requires treatyId, claimantCommunityId, and respondentCommunityId'));
  }

  return Promise.all([
    self.treaties.load(input.treatyId),
    self.communities.load(input.claimantCommunityId),
    self.communities.load(input.respondentCommunityId)
  ])
    .then(function (loaded) {
      treaty = loaded[0];
      claimant = loaded[1];
      respondent = loaded[2];
      if (!treaty || !claimant || !respondent) {
        throw new Error('Unknown treaty or dispute community');
      }
      if (!treaty.participantCommunityIds.includes(claimant.id) || !treaty.participantCommunityIds.includes(respondent.id)) {
        throw new Error('Dispute parties must be participants in the treaty');
      }
      if (!self._canRepresent(claimant, being.id)) {
        throw new Error('Being is not authorised to open a dispute for claimant community');
      }

      const resolverCommunityId = input.resolverCommunityId || treaty.dispute && treaty.dispute.resolverCommunityId;
      if (!resolverCommunityId) {
        throw new Error('Federated dispute requires a resolver community');
      }

      dispute = {
        id: input.id || ('federated-dispute:' + crypto.randomUUID()),
        version: 'octonomous.federated-dispute.v1',
        treatyId: treaty.id,
        claimantCommunityId: claimant.id,
        respondentCommunityId: respondent.id,
        resolverCommunityId: resolverCommunityId,
        subject: {
          kind: input.subjectKind || 'treaty',
          id: input.subjectId || treaty.id
        },
        claim: input.claim || '',
        evidence: clone(input.evidence || {}),
        status: 'open',
        openedAt: new Date().toISOString(),
        openedByBeingId: being.id,
        openingReceipt: null,
        response: null,
        resolution: null
      };

      return self.signing
        ? self.signing.sign(claimant, 'federation.dispute.opened', dispute, { treatyId: treaty.id })
        : null;
    })
    .then(function (receipt) {
      dispute.openingReceipt = receipt;
      return self.save(dispute);
    })
    .then(function () {
      return { ok: true, dispute: dispute };
    });
};

FederatedDisputeService.prototype.respond = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let dispute;
  let respondent;

  if (!input.disputeId) {
    return Promise.reject(new Error('federation.dispute.respond requires disputeId'));
  }

  return self.load(input.disputeId)
    .then(function (loaded) {
      dispute = loaded;
      if (!dispute) {
        throw new Error('Unknown federated dispute: ' + input.disputeId);
      }
      if (dispute.status !== 'open') {
        throw new Error('Federated dispute is not open');
      }
      return self.communities.load(dispute.respondentCommunityId);
    })
    .then(function (community) {
      respondent = community;
      if (!self._canRepresent(respondent, being.id)) {
        throw new Error('Being is not authorised to respond for respondent community');
      }
      dispute.response = {
        statement: input.statement || '',
        evidence: clone(input.evidence || {}),
        respondedAt: new Date().toISOString(),
        respondedByBeingId: being.id,
        receipt: null
      };
      dispute.status = 'responded';
      return self.signing
        ? self.signing.sign(respondent, 'federation.dispute.responded', dispute.response, {
          disputeId: dispute.id,
          openingReceiptId: dispute.openingReceipt && dispute.openingReceipt.id || null
        })
        : null;
    })
    .then(function (receipt) {
      dispute.response.receipt = receipt;
      return self.save(dispute);
    })
    .then(function () { return { ok: true, dispute: dispute }; });
};

FederatedDisputeService.prototype.resolve = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let dispute;
  let resolver;

  if (!input.disputeId || !['upheld', 'dismissed', 'settled', 'partially_upheld'].includes(input.verdict)) {
    return Promise.reject(new Error('federation.dispute.resolve requires disputeId and a valid verdict'));
  }

  return self.load(input.disputeId)
    .then(function (loaded) {
      dispute = loaded;
      if (!dispute) {
        throw new Error('Unknown federated dispute: ' + input.disputeId);
      }
      if (!['open', 'responded'].includes(dispute.status)) {
        throw new Error('Federated dispute is not resolvable');
      }
      return self.communities.load(dispute.resolverCommunityId);
    })
    .then(function (community) {
      resolver = community;
      if (!resolver) {
        throw new Error('Unknown resolver community: ' + dispute.resolverCommunityId);
      }
      if (!self._canRepresent(resolver, being.id)) {
        throw new Error('Being is not authorised to resolve for resolver community');
      }
      dispute.status = 'resolved';
      dispute.resolution = {
        verdict: input.verdict,
        reasoning: input.reasoning || '',
        remedy: clone(input.remedy || {}),
        evidence: clone(input.evidence || {}),
        resolvedAt: new Date().toISOString(),
        resolvedByBeingId: being.id,
        resolverCommunityId: resolver.id,
        receipt: null
      };
      return self.signing
        ? self.signing.sign(resolver, 'federation.dispute.resolved', dispute.resolution, {
          disputeId: dispute.id,
          openingReceiptId: dispute.openingReceipt && dispute.openingReceipt.id || null,
          responseReceiptId: dispute.response && dispute.response.receipt && dispute.response.receipt.id || null
        })
        : null;
    })
    .then(function (receipt) {
      dispute.resolution.receipt = receipt;
      return self.save(dispute);
    })
    .then(function () { return { ok: true, dispute: dispute }; });
};

module.exports = FederatedDisputeService;
