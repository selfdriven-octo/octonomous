const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function unique(values) {
  return Array.from(new Set(values));
}

function TreatyService(options) {
  options = options || {};
  this.store = options.store;
  this.communities = options.communities;
  this.signing = options.signing || null;
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
}

TreatyService.prototype.load = function (id) {
  return this.store.loadResource('treaty', id);
};

TreatyService.prototype.save = function (treaty) {
  return this.store.saveResource('treaty', treaty);
};

TreatyService.prototype._canRepresent = function (community, beingId) {
  return this.communities.hasRole(community, beingId, ['founder', 'governor', 'federation-admin']);
};

TreatyService.prototype._linkCommunity = function (communityId, treaty) {
  const self = this;
  return self.communities.load(communityId)
    .then(function (community) {
      if (!community) {
        throw new Error('Unknown treaty community: ' + communityId);
      }
      community.federation = community.federation || {};
      community.federation.treaties = community.federation.treaties || [];
      const existing = community.federation.treaties.find(function (item) {
        return item.treatyId === treaty.id;
      });
      const ratifiedCommunityIds = (treaty.ratification && treaty.ratification.ratifications || []).map(function (item) {
        return item.communityId;
      });
      const ref = {
        treatyId: treaty.id,
        status: treaty.status,
        ratified: ratifiedCommunityIds.includes(communityId),
        scopes: clone(treaty.scopes),
        participantCommunityIds: clone(treaty.participantCommunityIds),
        updatedAt: new Date().toISOString()
      };
      if (existing) {
        Object.assign(existing, ref);
      }
      else {
        community.federation.treaties.push(ref);
      }
      return self.communities.save(community);
    });
};

TreatyService.prototype._syncLinks = function (treaty) {
  const self = this;
  return Promise.all((treaty.participantCommunityIds || []).map(function (communityId) {
    return self._linkCommunity(communityId, treaty);
  }));
};

TreatyService.prototype.propose = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let proposerCommunity;
  let treaty;

  if (!input.proposerCommunityId) {
    return Promise.reject(new Error('federation.treaty.propose requires proposerCommunityId'));
  }

  const participants = unique([input.proposerCommunityId].concat(input.participantCommunityIds || []));
  if (participants.length < 2) {
    return Promise.reject(new Error('A treaty requires at least two distinct communities'));
  }

  return Promise.all(participants.map(function (communityId) {
    return self.communities.load(communityId);
  }))
    .then(function (communities) {
      if (communities.some(function (community) { return !community; })) {
        throw new Error('Treaty includes an unknown community');
      }
      proposerCommunity = communities.find(function (community) {
        return community.id === input.proposerCommunityId;
      });
      if (!self._canRepresent(proposerCommunity, being.id)) {
        throw new Error('Being is not authorised to propose treaties for community: ' + proposerCommunity.id);
      }

      const minimum = Number(input.minimumRatifications || participants.length);
      if (!Number.isInteger(minimum) || minimum < 2 || minimum > participants.length) {
        throw new Error('minimumRatifications must be between 2 and the number of treaty participants');
      }

      treaty = {
        id: input.id || ('treaty:' + crypto.randomUUID()),
        version: 'octonomous.federation-treaty.v1',
        name: input.name || 'Federation Treaty',
        proposerCommunityId: proposerCommunity.id,
        participantCommunityIds: participants,
        scopes: Array.isArray(input.scopes) && input.scopes.length ? unique(input.scopes) : ['*'],
        terms: clone(input.terms || {}),
        dispute: {
          resolverCommunityId: input.disputeResolverCommunityId || null,
          process: clone(input.disputeProcess || {})
        },
        validity: {
          validFrom: input.validFrom || null,
          validUntil: input.validUntil || null
        },
        ratification: {
          minimum: minimum,
          requiredCommunityIds: participants,
          ratifications: []
        },
        status: 'proposed',
        createdAt: new Date().toISOString(),
        createdByBeingId: being.id,
        proposalReceipt: null,
        activationReceipt: null,
        termination: null
      };

      return self.signing
        ? self.signing.sign(proposerCommunity, 'federation.treaty.proposed', treaty, {
          participantCommunityIds: participants,
          sourceEventId: context.event && context.event.id
        })
        : null;
    })
    .then(function (receipt) {
      treaty.proposalReceipt = receipt;
      return self.save(treaty);
    })
    .then(function () {
      return self._syncLinks(treaty);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, treaty: treaty, event: null };
      }
      return self.publisher.publish({
        type: 'federation.treaty.proposed',
        sourceBeingId: being.id,
        payload: { treaty: treaty, sourceBeingId: being.id }
      }).then(function (event) {
        return { ok: true, treaty: treaty, event: event };
      });
    });
};

TreatyService.prototype.ratify = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let treaty;
  let community;
  let ratification;

  if (!input.treatyId || !input.communityId) {
    return Promise.reject(new Error('federation.treaty.ratify requires treatyId and communityId'));
  }

  return Promise.all([
    self.load(input.treatyId),
    self.communities.load(input.communityId)
  ])
    .then(function (loaded) {
      treaty = loaded[0];
      community = loaded[1];
      if (!treaty) {
        throw new Error('Unknown treaty: ' + input.treatyId);
      }
      if (!community) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      if (!['proposed', 'active'].includes(treaty.status)) {
        throw new Error('Treaty is not open for ratification');
      }
      if (!treaty.participantCommunityIds.includes(community.id)) {
        throw new Error('Community is not a treaty participant');
      }
      if (!self._canRepresent(community, being.id)) {
        throw new Error('Being is not authorised to ratify for community: ' + community.id);
      }
      if ((treaty.ratification.ratifications || []).some(function (item) {
        return item.communityId === community.id;
      })) {
        throw new Error('Community has already ratified this treaty');
      }

      ratification = {
        id: crypto.randomUUID(),
        treatyId: treaty.id,
        communityId: community.id,
        ratifiedByBeingId: being.id,
        localGovernanceProposalId: input.localGovernanceProposalId || null,
        statement: input.statement || 'ratified',
        ratifiedAt: new Date().toISOString(),
        receipt: null
      };

      return self.signing
        ? self.signing.sign(community, 'federation.treaty.ratified', ratification, {
          treatyProposalReceiptId: treaty.proposalReceipt && treaty.proposalReceipt.id || null
        })
        : null;
    })
    .then(function (receipt) {
      ratification.receipt = receipt;
      treaty.ratification.ratifications.push(ratification);

      if (treaty.status === 'active' || treaty.ratification.ratifications.length < treaty.ratification.minimum) {
        return null;
      }

      treaty.status = 'active';
      treaty.activatedAt = new Date().toISOString();

      if (!self.receipts) {
        return null;
      }
      return self.receipts.create({
        kind: 'federation.treaty.activated',
        beingId: 'federation:' + treaty.id,
        subject: {
          treatyId: treaty.id,
          participantCommunityIds: treaty.participantCommunityIds,
          scopes: treaty.scopes,
          activatedAt: treaty.activatedAt
        },
        evidence: {
          ratificationReceiptIds: treaty.ratification.ratifications.map(function (item) {
            return item.receipt && item.receipt.id || null;
          }).filter(Boolean)
        }
      });
    })
    .then(function (activationReceipt) {
      if (activationReceipt) {
        treaty.activationReceipt = activationReceipt;
      }
      return self.save(treaty);
    })
    .then(function () {
      return self._syncLinks(treaty);
    })
    .then(function () {
      const result = {
        ok: true,
        treaty: treaty,
        ratification: ratification,
        activated: treaty.status === 'active'
      };
      if (!self.publisher) {
        return result;
      }
      return self.publisher.publish({
        type: treaty.status === 'active' ? 'federation.treaty.activated' : 'federation.treaty.ratified',
        sourceBeingId: being.id,
        payload: {
          treatyId: treaty.id,
          communityId: community.id,
          status: treaty.status,
          ratification: ratification,
          sourceBeingId: being.id
        }
      }).then(function (event) {
        result.event = event;
        return result;
      });
    });
};

TreatyService.prototype.terminate = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let treaty;
  let community;

  if (!input.treatyId || !input.communityId) {
    return Promise.reject(new Error('federation.treaty.terminate requires treatyId and communityId'));
  }

  return Promise.all([self.load(input.treatyId), self.communities.load(input.communityId)])
    .then(function (loaded) {
      treaty = loaded[0];
      community = loaded[1];
      if (!treaty || !community) {
        throw new Error('Unknown treaty or community');
      }
      if (!treaty.participantCommunityIds.includes(community.id)) {
        throw new Error('Only a treaty participant may terminate it');
      }
      if (!self._canRepresent(community, being.id)) {
        throw new Error('Being is not authorised to terminate for community');
      }
      if (!['active', 'proposed'].includes(treaty.status)) {
        throw new Error('Treaty cannot be terminated from status: ' + treaty.status);
      }

      treaty.status = 'terminated';
      treaty.termination = {
        communityId: community.id,
        terminatedByBeingId: being.id,
        reason: input.reason || '',
        terminatedAt: new Date().toISOString(),
        receipt: null
      };

      return self.signing
        ? self.signing.sign(community, 'federation.treaty.terminated', treaty.termination, {
          treatyId: treaty.id
        })
        : null;
    })
    .then(function (receipt) {
      treaty.termination.receipt = receipt;
      return self.save(treaty);
    })
    .then(function () { return self._syncLinks(treaty); })
    .then(function () {
      return { ok: true, treaty: treaty };
    });
};

TreatyService.prototype.isActive = function (treaty, communityA, communityB, scope) {
  if (!treaty || treaty.status !== 'active') {
    return false;
  }
  const now = Date.now();
  if (treaty.validity && treaty.validity.validFrom && Date.parse(treaty.validity.validFrom) > now) {
    return false;
  }
  if (treaty.validity && treaty.validity.validUntil && Date.parse(treaty.validity.validUntil) <= now) {
    return false;
  }
  if (!treaty.participantCommunityIds.includes(communityA) || !treaty.participantCommunityIds.includes(communityB)) {
    return false;
  }
  const ratified = new Set((treaty.ratification && treaty.ratification.ratifications || []).map(function (item) {
    return item.communityId;
  }));
  if (!ratified.has(communityA) || !ratified.has(communityB)) {
    return false;
  }
  const scopes = treaty.scopes || ['*'];
  return scopes.includes('*') || scopes.includes(scope || '*');
};

module.exports = TreatyService;
