const crypto = require('crypto');

function GovernanceDelegationService(options) {
  options = options || {};
  this.communities = options.communities;
  this.receipts = options.receipts || null;
  this.publisher = options.publisher || null;
}

GovernanceDelegationService.prototype.create = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let community;
  let delegation;

  if (!input.communityId || !input.delegateeBeingId) {
    return Promise.reject(new Error('community.governance.delegate requires communityId and delegateeBeingId'));
  }

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      if (!loaded) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      community = loaded;
      const membership = self.communities.membershipFor(community, being.id);
      if (!membership) {
        throw new Error('Only an active community member may delegate governance authority');
      }

      delegation = {
        id: crypto.randomUUID(),
        version: 'octonomous.community-governance-delegation.v1',
        communityId: community.id,
        principalBeingId: being.id,
        principalMembershipId: membership.id,
        delegateeBeingId: input.delegateeBeingId,
        scopes: Array.isArray(input.scopes) && input.scopes.length ? input.scopes.slice() : ['*'],
        validUntil: input.validUntil || null,
        status: 'active',
        createdAt: new Date().toISOString(),
        receipt: null
      };

      const receiptPromise = self.receipts
        ? self.receipts.create({
          kind: 'community.governance.delegation.created',
          beingId: being.id,
          subject: delegation,
          evidence: { communityId: community.id, sourceEventId: context.event && context.event.id }
        })
        : Promise.resolve(null);

      return receiptPromise;
    })
    .then(function (receipt) {
      delegation.receipt = receipt;
      community.governance = community.governance || {};
      community.governance.delegations = community.governance.delegations || [];
      community.governance.delegations.push(delegation);
      return self.communities.save(community);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, delegation: delegation, event: null };
      }
      return self.publisher.publish({
        type: 'community.governance.delegation.created',
        sourceBeingId: being.id,
        targetBeingId: delegation.delegateeBeingId,
        payload: { delegation: delegation, sourceBeingId: being.id }
      })
        .then(function (event) {
          return { ok: true, delegation: delegation, event: event };
        });
    });
};

GovernanceDelegationService.prototype.revoke = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let community;
  let delegation;

  if (!input.communityId || !input.delegationId) {
    return Promise.reject(new Error('community.governance.delegation.revoke requires communityId and delegationId'));
  }

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      if (!loaded) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      community = loaded;
      delegation = community.governance && (community.governance.delegations || []).find(function (item) {
        return item.id === input.delegationId;
      });
      if (!delegation) {
        throw new Error('Unknown governance delegation: ' + input.delegationId);
      }
      if (delegation.principalBeingId !== being.id) {
        throw new Error('Only the principal may revoke this governance delegation');
      }
      if (delegation.status !== 'active') {
        throw new Error('Governance delegation is not active');
      }

      delegation.status = 'revoked';
      delegation.revokedAt = new Date().toISOString();
      delegation.revocationReason = input.reason || '';

      const receiptPromise = self.receipts
        ? self.receipts.create({
          kind: 'community.governance.delegation.revoked',
          beingId: being.id,
          subject: delegation,
          evidence: { communityId: community.id }
        })
        : Promise.resolve(null);
      return receiptPromise;
    })
    .then(function (receipt) {
      delegation.revocationReceipt = receipt;
      return self.communities.save(community);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, delegation: delegation, event: null };
      }
      return self.publisher.publish({
        type: 'community.governance.delegation.revoked',
        sourceBeingId: being.id,
        targetBeingId: delegation.delegateeBeingId,
        payload: { delegation: delegation, sourceBeingId: being.id }
      })
        .then(function (event) {
          return { ok: true, delegation: delegation, event: event };
        });
    });
};

GovernanceDelegationService.prototype.activeMandatesFor = function (community, delegateeBeingId, scope) {
  const now = Date.now();
  const delegations = community && community.governance && community.governance.delegations || [];
  return delegations.filter(function (delegation) {
    if (delegation.status !== 'active' || delegation.delegateeBeingId !== delegateeBeingId) {
      return false;
    }
    if (delegation.validUntil && Date.parse(delegation.validUntil) <= now) {
      return false;
    }
    const scopes = delegation.scopes || ['*'];
    return scopes.includes('*') || scopes.includes(scope);
  });
};

module.exports = GovernanceDelegationService;

GovernanceDelegationService.prototype.observeEvent = function (being, event) {
  if (!event || !event.payload || !event.payload.delegation) {
    return null;
  }
  if (!['community.governance.delegation.created', 'community.governance.delegation.revoked'].includes(event.type)) {
    return null;
  }
  being.federation = being.federation || {};
  being.federation.governanceDelegations = being.federation.governanceDelegations || [];
  const incoming = JSON.parse(JSON.stringify(event.payload.delegation));
  const existing = being.federation.governanceDelegations.find(function (item) {
    return item.id === incoming.id;
  });
  if (existing) {
    Object.assign(existing, incoming);
    existing.observedAt = new Date().toISOString();
    return existing;
  }
  incoming.observedAt = new Date().toISOString();
  being.federation.governanceDelegations.push(incoming);
  return incoming;
};
