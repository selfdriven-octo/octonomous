function FederationTrustPathService(options) {
  options = options || {};
  this.communities = options.communities;
  this.trust = options.trust;
  this.treaties = options.treaties;
}

function levelWeight(level) {
  if (level === 'high' || level === 'strong') return 1;
  if (level === 'trusted') return 0.95;
  if (level === 'conditional') return 0.75;
  if (level === 'limited') return 0.5;
  return 0.8;
}

FederationTrustPathService.prototype._outgoing = function (communityId, scope) {
  const self = this;
  return self.communities.load(communityId)
    .then(function (community) {
      if (!community) {
        return [];
      }
      const assertionTargets = (community.trustAssertions || []).map(function (assertion) {
        return { kind: 'assertion', targetCommunityId: assertion.targetCommunityId, assertion: assertion };
      });
      const treatyRefs = community.federation && community.federation.treaties || [];

      return Promise.all([
        Promise.all(assertionTargets.map(function (edge) {
          return self.trust.evaluate(communityId, edge.targetCommunityId, scope)
            .then(function (result) {
              if (!result.trusted) return null;
              return {
                from: communityId,
                to: edge.targetCommunityId,
                kind: 'trust-assertion',
                weight: levelWeight(result.level),
                evidenceId: result.assertionId
              };
            });
        })),
        Promise.all(treatyRefs.map(function (ref) {
          return self.treaties.load(ref.treatyId)
            .then(function (treaty) {
              if (!treaty || treaty.status !== 'active') return [];
              return treaty.participantCommunityIds.filter(function (target) {
                return target !== communityId && self.treaties.isActive(treaty, communityId, target, scope);
              }).map(function (target) {
                return {
                  from: communityId,
                  to: target,
                  kind: 'treaty',
                  weight: 1,
                  evidenceId: treaty.id
                };
              });
            });
        }))
      ]).then(function (parts) {
        return parts[0].filter(Boolean).concat(parts[1].flat());
      });
    });
};

FederationTrustPathService.prototype.compute = function (input) {
  const self = this;
  input = input || {};
  const source = input.sourceCommunityId;
  const target = input.targetCommunityId;
  const scope = input.scope || '*';
  const maxHops = Number(input.maxHops || 5);

  if (!source || !target) {
    return Promise.reject(new Error('federation.trust.path requires sourceCommunityId and targetCommunityId'));
  }
  if (source === target) {
    return Promise.resolve({ found: true, sourceCommunityId: source, targetCommunityId: target, scope: scope, path: [], hops: 0, score: 1 });
  }

  const queue = [{ communityId: source, path: [], score: 1 }];
  const visited = new Set([source]);

  function next() {
    if (!queue.length) {
      return Promise.resolve({ found: false, sourceCommunityId: source, targetCommunityId: target, scope: scope, path: [], hops: null, score: 0 });
    }
    const current = queue.shift();
    if (current.path.length >= maxHops) {
      return next();
    }
    return self._outgoing(current.communityId, scope)
      .then(function (edges) {
        for (const edge of edges) {
          const newPath = current.path.concat([edge]);
          const newScore = current.score * edge.weight;
          if (edge.to === target) {
            return {
              found: true,
              sourceCommunityId: source,
              targetCommunityId: target,
              scope: scope,
              path: newPath,
              hops: newPath.length,
              score: Number(newScore.toFixed(6))
            };
          }
          if (!visited.has(edge.to)) {
            visited.add(edge.to);
            queue.push({ communityId: edge.to, path: newPath, score: newScore });
          }
        }
        return next();
      });
  }

  return next();
};

module.exports = FederationTrustPathService;
