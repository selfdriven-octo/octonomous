function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function GroupIdentityService(options) {
  options = options || {};
  this.communities = options.communities;
  this.signing = options.signing || null;
  this.provider = options.provider || null;
}

GroupIdentityService.prototype._canManage = function (community, beingId) {
  return this.communities.hasRole(community, beingId, ['founder', 'governor', 'federation-admin']);
};

GroupIdentityService.prototype.bind = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let community;
  let identity;

  if (!input.communityId || !input.aid) {
    return Promise.reject(new Error('community.group-identity.bind requires communityId and aid'));
  }

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      community = loaded;
      if (!community) throw new Error('Unknown community: ' + input.communityId);
      if (!self._canManage(community, being.id)) {
        throw new Error('Being is not authorised to manage community group identity');
      }

      const request = {
        community: clone(community),
        aid: input.aid,
        memberAids: clone(input.memberAids || []),
        threshold: input.threshold || null,
        metadata: clone(input.metadata || {})
      };

      if (self.provider && typeof self.provider.bindGroupIdentity === 'function') {
        return Promise.resolve(self.provider.bindGroupIdentity(request));
      }

      return Promise.resolve({
        mode: 'development-binding',
        aid: input.aid,
        memberAids: clone(input.memberAids || []),
        threshold: input.threshold || null,
        metadata: clone(input.metadata || {}),
        note: 'Development binding only. Configure COMMUNITY_GROUP_IDENTITY_MODULE for KERI multisig/group AID lifecycle.'
      });
    })
    .then(function (providerResult) {
      identity = {
        version: 'octonomous.community-group-identity.v1',
        aid: providerResult.aid || input.aid,
        mode: providerResult.mode || 'provider',
        memberAids: clone(providerResult.memberAids || input.memberAids || []),
        threshold: providerResult.threshold !== undefined ? providerResult.threshold : (input.threshold || null),
        metadata: clone(providerResult.metadata || input.metadata || {}),
        provider: clone(providerResult.provider || null),
        boundAt: new Date().toISOString(),
        boundByBeingId: being.id,
        receipt: null
      };
      return self.signing
        ? self.signing.sign(community, 'community.group-identity.bound', identity, { previousAid: community.identity && community.identity.group && community.identity.group.aid || null })
        : null;
    })
    .then(function (receipt) {
      identity.receipt = receipt;
      community.identity = community.identity || {};
      community.identity.group = identity;
      return self.communities.save(community);
    })
    .then(function () { return { ok: true, identity: identity, community: community }; });
};

GroupIdentityService.prototype.describe = function (input) {
  const self = this;
  return self.communities.load(input.communityId)
    .then(function (community) {
      if (!community) throw new Error('Unknown community: ' + input.communityId);
      const identity = community.identity && community.identity.group || null;
      if (!identity) return { ok: true, identity: null, verified: null };
      if (self.provider && typeof self.provider.describeGroupIdentity === 'function') {
        return Promise.resolve(self.provider.describeGroupIdentity({ community: community, identity: identity }))
          .then(function (provider) { return { ok: true, identity: identity, provider: provider }; });
      }
      return { ok: true, identity: identity, provider: null };
    });
};

module.exports = GroupIdentityService;
