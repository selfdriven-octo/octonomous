const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function MembershipService(options) {
  options = options || {};
  this.communities = options.communities;
  this.credentials = options.credentials || null;
  this.signing = options.signing || null;
  this.publisher = options.publisher || null;
}

MembershipService.prototype._canManage = function (community, beingId) {
  return this.communities.hasRole(community, beingId, ['founder', 'governor', 'membership-admin']);
};

MembershipService.prototype.issue = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};

  if (!input.communityId || !input.targetBeingId) {
    return Promise.reject(new Error('community.membership.issue requires communityId and targetBeingId'));
  }
  if (!Array.isArray(input.roles) || !input.roles.length) {
    return Promise.reject(new Error('community.membership.issue requires roles[]'));
  }

  let community;
  let membership;

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      if (!loaded) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      community = loaded;

      if (!self._canManage(community, being.id)) {
        throw new Error('Being is not authorised to manage membership for community: ' + community.id);
      }

      const existing = self.communities.membershipFor(community, input.targetBeingId);
      if (existing) {
        throw new Error('Target already has an active membership in community: ' + community.id);
      }

      membership = {
        id: crypto.randomUUID(),
        version: 'octonomous.community-membership.v1',
        communityId: community.id,
        communityName: community.name,
        beingId: input.targetBeingId,
        subjectAid: input.subjectAid || null,
        roles: input.roles.slice(),
        status: 'active',
        issuedAt: new Date().toISOString(),
        issuedByBeingId: being.id,
        validUntil: input.validUntil || null,
        credential: null,
        receipt: null
      };

      if (self.credentials && typeof self.credentials.issueMembership === 'function') {
        return self.credentials.issueMembership({
          issuerBeing: being,
          community: community,
          membership: membership
        });
      }
      return null;
    })
    .then(function (credential) {
      membership.credential = credential;
      const signPromise = self.signing
        ? self.signing.sign(community, 'community.membership.issued', membership, {
          issuedByBeingId: being.id,
          sourceEventId: context.event && context.event.id
        })
        : Promise.resolve(null);
      return signPromise;
    })
    .then(function (receipt) {
      membership.receipt = receipt;
      community.memberships = community.memberships || [];
      community.memberships.push(membership);
      return self.communities.save(community);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, membership: membership, event: null };
      }
      return self.publisher.publish({
        type: 'community.membership.issued',
        sourceBeingId: being.id,
        targetBeingId: membership.beingId,
        payload: {
          membership: membership,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          return { ok: true, membership: membership, event: event };
        });
    });
};

MembershipService.prototype.revoke = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let community;
  let membership;

  if (!input.communityId || !input.membershipId) {
    return Promise.reject(new Error('community.membership.revoke requires communityId and membershipId'));
  }

  return self.communities.load(input.communityId)
    .then(function (loaded) {
      if (!loaded) {
        throw new Error('Unknown community: ' + input.communityId);
      }
      community = loaded;
      if (!self._canManage(community, being.id)) {
        throw new Error('Being is not authorised to manage membership for community: ' + community.id);
      }

      membership = (community.memberships || []).find(function (item) {
        return item.id === input.membershipId;
      });
      if (!membership) {
        throw new Error('Unknown membership: ' + input.membershipId);
      }
      if (membership.status !== 'active') {
        throw new Error('Membership is not active');
      }

      membership.status = 'revoked';
      membership.revokedAt = new Date().toISOString();
      membership.revokedByBeingId = being.id;
      membership.revocationReason = input.reason || '';

      if (self.credentials && membership.credential && typeof self.credentials.revokeMembership === 'function') {
        return self.credentials.revokeMembership({
          issuerBeing: being,
          community: community,
          credential: membership.credential,
          reason: membership.revocationReason
        });
      }
      return null;
    })
    .then(function (credentialRevocation) {
      membership.credentialRevocation = credentialRevocation;
      const signPromise = self.signing
        ? self.signing.sign(community, 'community.membership.revoked', membership, {
          revokedByBeingId: being.id,
          sourceEventId: context.event && context.event.id
        })
        : Promise.resolve(null);
      return signPromise;
    })
    .then(function (receipt) {
      membership.revocationReceipt = receipt;
      return self.communities.save(community);
    })
    .then(function () {
      if (!self.publisher) {
        return { ok: true, membership: membership, event: null };
      }
      return self.publisher.publish({
        type: 'community.membership.revoked',
        sourceBeingId: being.id,
        targetBeingId: membership.beingId,
        payload: {
          membership: membership,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          return { ok: true, membership: membership, event: event };
        });
    });
};

MembershipService.prototype.observeEvent = function (being, event) {
  if (!event || !event.payload || !event.payload.membership) {
    return null;
  }
  if (!['community.membership.issued', 'community.membership.revoked'].includes(event.type)) {
    return null;
  }

  being.federation = being.federation || {};
  being.federation.memberships = being.federation.memberships || [];

  const incoming = clone(event.payload.membership);
  const existing = being.federation.memberships.find(function (item) {
    return item.id === incoming.id;
  });

  if (!existing) {
    incoming.observedAt = new Date().toISOString();
    being.federation.memberships.push(incoming);
    return incoming;
  }

  Object.assign(existing, incoming);
  existing.observedAt = new Date().toISOString();
  return existing;
};

MembershipService.prototype.activeForBeing = function (being, communityId) {
  const now = Date.now();
  const memberships = being && being.federation && being.federation.memberships || [];
  return memberships.filter(function (membership) {
    return membership.communityId === communityId &&
      membership.status === 'active' &&
      (!membership.validUntil || Date.parse(membership.validUntil) > now);
  });
};

module.exports = MembershipService;
