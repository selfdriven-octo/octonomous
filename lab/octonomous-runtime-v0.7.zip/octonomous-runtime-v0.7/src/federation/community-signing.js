function CommunitySigningService(options) {
  options = options || {};
  this.provider = options.provider || null;
  this.receipts = options.receipts || null;
}

CommunitySigningService.prototype.sign = function (community, kind, subject, evidence) {
  if (!community || !community.id) {
    return Promise.reject(new Error('Community signing requires a community'));
  }

  if (this.provider && typeof this.provider.signCommunity === 'function') {
    return Promise.resolve(this.provider.signCommunity({
      community: community,
      kind: kind,
      subject: subject,
      evidence: evidence || {}
    }));
  }

  if (!this.receipts) {
    return Promise.resolve(null);
  }

  return this.receipts.create({
    kind: kind,
    beingId: 'community:' + community.id,
    subject: subject,
    evidence: Object.assign({
      note: 'Development/runtime receipt. Configure COMMUNITY_SIGNER_MODULE for a community-controlled KERI/group AID signer.'
    }, evidence || {})
  });
};

module.exports = CommunitySigningService;

CommunitySigningService.prototype.verify = function (community, receipt) {
  if (this.provider && typeof this.provider.verifyCommunity === 'function') {
    return Promise.resolve(this.provider.verifyCommunity({
      community: community,
      receipt: receipt
    }));
  }

  if (!this.receipts || typeof this.receipts.verify !== 'function') {
    return Promise.resolve({ valid: null, reason: 'No community receipt verifier configured' });
  }

  return this.receipts.verify(receipt);
};
