const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function CommunityService(options) {
  options = options || {};
  this.store = options.store;
  this.signing = options.signing || null;
  this.publisher = options.publisher || null;
}

CommunityService.prototype.load = function (communityId) {
  if (!this.store || typeof this.store.loadCommunity !== 'function') {
    return Promise.reject(new Error('Store does not support communities'));
  }
  return this.store.loadCommunity(communityId);
};

CommunityService.prototype.save = function (community) {
  if (!this.store || typeof this.store.saveCommunity !== 'function') {
    return Promise.reject(new Error('Store does not support communities'));
  }
  return this.store.saveCommunity(community);
};

CommunityService.prototype.create = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  const communityId = input.id || ('community:' + crypto.randomUUID());
  const now = new Date().toISOString();

  if (!being || !being.id) {
    return Promise.reject(new Error('community.create requires an initiating being'));
  }

  const constitution = clone(input.constitution || {
    id: communityId + ':constitution:1',
    version: '1.0.0',
    name: (input.name || communityId) + ' Constitution',
    policies: [],
    federation: {
      amendment: {
        approvals: 1,
        rejections: 1,
        eligibleRoles: ['founder', 'governor']
      },
      treasury: {
        approvals: 1,
        rejections: 1,
        eligibleRoles: ['founder', 'governor']
      },
      resources: {
        approvals: 1,
        rejections: 1,
        eligibleRoles: ['founder', 'governor']
      }
    }
  });

  const community = {
    id: communityId,
    version: 'octonomous.community.v1',
    name: input.name || communityId,
    purpose: input.purpose || [],
    identity: input.identity || {},
    founders: [being.id],
    constitution: constitution,
    constitutionHistory: [],
    memberships: [{
      id: crypto.randomUUID(),
      communityId: communityId,
      beingId: being.id,
      roles: ['founder', 'governor'],
      status: 'active',
      issuedAt: now,
      issuedByBeingId: being.id,
      source: 'founding-record',
      credential: null
    }],
    governance: {
      proposals: [],
      delegations: []
    },
    trustAssertions: [],
    federation: {
      treaties: [],
      exchanges: [],
      protocolVersion: 'octonomous.federation.v1'
    },
    treasury: {
      balances: clone(input.treasury && input.treasury.balances || {}),
      allocations: []
    },
    resources: {
      pools: clone(input.resources && input.resources.pools || {}),
      allocations: []
    },
    createdAt: now,
    createdByBeingId: being.id,
    receipt: null
  };

  return self.load(communityId)
    .then(function (existing) {
      if (existing) {
        throw new Error('Community already exists: ' + communityId);
      }

      const signPromise = self.signing
        ? self.signing.sign(community, 'community.created', community, {
          sourceEventId: context.event && context.event.id,
          createdByBeingId: being.id
        })
        : Promise.resolve(null);

      return signPromise;
    })
    .then(function (receipt) {
      community.receipt = receipt;
      if (receipt) {
        community.memberships[0].receipt = receipt;
      }
      return self.save(community);
    })
    .then(function (saved) {
      if (!self.publisher) {
        return { ok: true, community: saved, event: null };
      }

      return self.publisher.publish({
        type: 'community.created',
        sourceBeingId: being.id,
        payload: {
          communityId: saved.id,
          name: saved.name,
          sourceBeingId: being.id
        }
      })
        .then(function (event) {
          return { ok: true, community: saved, event: event };
        });
    });
};

CommunityService.prototype.activeMemberships = function (community) {
  const now = Date.now();
  return (community.memberships || []).filter(function (membership) {
    if (membership.status !== 'active') {
      return false;
    }
    if (membership.validUntil && Date.parse(membership.validUntil) <= now) {
      return false;
    }
    return true;
  });
};

CommunityService.prototype.membershipFor = function (community, beingId) {
  return this.activeMemberships(community).find(function (membership) {
    return membership.beingId === beingId;
  }) || null;
};

CommunityService.prototype.hasRole = function (community, beingId, roles) {
  roles = Array.isArray(roles) ? roles : [roles];
  const membership = this.membershipFor(community, beingId);
  if (!membership) {
    return false;
  }
  return roles.some(function (role) {
    return (membership.roles || []).includes(role);
  });
};

module.exports = CommunityService;
