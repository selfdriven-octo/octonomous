const crypto = require('crypto');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function ResourceExchangeService(options) {
  options = options || {};
  this.store = options.store;
  this.communities = options.communities;
  this.signing = options.signing || null;
  this.treaties = options.treaties;
  this.publisher = options.publisher || null;
}

ResourceExchangeService.prototype.load = function (id) {
  return this.store.loadResource('resource-exchange', id);
};

ResourceExchangeService.prototype.save = function (exchange) {
  return this.store.saveResource('resource-exchange', exchange);
};

ResourceExchangeService.prototype._canRepresent = function (community, beingId) {
  return this.communities.hasRole(community, beingId, ['founder', 'governor', 'federation-admin', 'treasurer', 'resource-manager']);
};

ResourceExchangeService.prototype.offer = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let source;
  let target;
  let treaty;
  let exchange;

  if (!input.sourceCommunityId || !input.targetCommunityId || !input.treatyId) {
    return Promise.reject(new Error('federation.exchange.offer requires sourceCommunityId, targetCommunityId, and treatyId'));
  }

  return Promise.all([
    self.communities.load(input.sourceCommunityId),
    self.communities.load(input.targetCommunityId),
    self.treaties.load(input.treatyId)
  ])
    .then(function (loaded) {
      source = loaded[0];
      target = loaded[1];
      treaty = loaded[2];
      if (!source || !target || !treaty) {
        throw new Error('Unknown exchange community or treaty');
      }
      if (!self._canRepresent(source, being.id)) {
        throw new Error('Being is not authorised to offer exchange for source community');
      }
      if (!self.treaties.isActive(treaty, source.id, target.id, 'resource.exchange')) {
        throw new Error('Active treaty does not authorise resource.exchange');
      }

      exchange = {
        id: input.id || ('resource-exchange:' + crypto.randomUUID()),
        version: 'octonomous.resource-exchange.v1',
        treatyId: treaty.id,
        sourceCommunityId: source.id,
        targetCommunityId: target.id,
        give: clone(input.give || []),
        receive: clone(input.receive || []),
        terms: clone(input.terms || {}),
        status: 'offered',
        offeredAt: new Date().toISOString(),
        offeredByBeingId: being.id,
        offerReceipt: null,
        acceptance: null,
        authorisations: []
      };

      return self.signing
        ? self.signing.sign(source, 'federation.exchange.offered', exchange, { treatyId: treaty.id })
        : null;
    })
    .then(function (receipt) {
      exchange.offerReceipt = receipt;
      return self.save(exchange);
    })
    .then(function () { return { ok: true, exchange: exchange }; });
};

ResourceExchangeService.prototype.accept = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let exchange;
  let target;

  if (!input.exchangeId) {
    return Promise.reject(new Error('federation.exchange.accept requires exchangeId'));
  }

  return self.load(input.exchangeId)
    .then(function (loaded) {
      exchange = loaded;
      if (!exchange) {
        throw new Error('Unknown resource exchange: ' + input.exchangeId);
      }
      if (exchange.status !== 'offered') {
        throw new Error('Resource exchange is not open for acceptance');
      }
      return self.communities.load(exchange.targetCommunityId);
    })
    .then(function (community) {
      target = community;
      if (!self._canRepresent(target, being.id)) {
        throw new Error('Being is not authorised to accept exchange for target community');
      }
      return self.treaties.load(exchange.treatyId);
    })
    .then(function (treaty) {
      if (!self.treaties.isActive(treaty, exchange.sourceCommunityId, exchange.targetCommunityId, 'resource.exchange')) {
        throw new Error('Treaty no longer authorises this resource exchange');
      }
      exchange.acceptance = {
        acceptedAt: new Date().toISOString(),
        acceptedByBeingId: being.id,
        statement: input.statement || 'accepted',
        receipt: null
      };
      return self.signing
        ? self.signing.sign(target, 'federation.exchange.accepted', exchange.acceptance, {
          exchangeId: exchange.id,
          offerReceiptId: exchange.offerReceipt && exchange.offerReceipt.id || null
        })
        : null;
    })
    .then(function (receipt) {
      exchange.acceptance.receipt = receipt;
      exchange.status = 'authorised';
      exchange.authorisedAt = new Date().toISOString();
      exchange.authorisations = [
        {
          communityId: exchange.sourceCommunityId,
          direction: 'provide',
          items: clone(exchange.give),
          status: 'authorised'
        },
        {
          communityId: exchange.targetCommunityId,
          direction: 'provide',
          items: clone(exchange.receive),
          status: 'authorised'
        }
      ];
      return self.save(exchange);
    })
    .then(function () { return { ok: true, exchange: exchange }; });
};

ResourceExchangeService.prototype.recordSettlement = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let exchange;
  let reportingCommunity;

  return self.load(input.exchangeId)
    .then(function (loaded) {
      exchange = loaded;
      if (!exchange) throw new Error('Unknown resource exchange: ' + input.exchangeId);
      if (exchange.status !== 'authorised') throw new Error('Only an authorised exchange may record settlement');
      if (![exchange.sourceCommunityId, exchange.targetCommunityId].includes(input.communityId)) {
        throw new Error('Settlement reporter must be an exchange community');
      }
      return self.communities.load(input.communityId);
    })
    .then(function (community) {
      reportingCommunity = community;
      if (!self._canRepresent(reportingCommunity, being.id)) {
        throw new Error('Being is not authorised to record settlement for community');
      }
      exchange.settlements = exchange.settlements || [];
      if (exchange.settlements.some(function (item) { return item.communityId === reportingCommunity.id; })) {
        throw new Error('Community has already recorded settlement evidence for this exchange');
      }
      const settlement = {
        id: crypto.randomUUID(),
        communityId: reportingCommunity.id,
        externalReference: input.externalReference || null,
        evidence: clone(input.evidence || {}),
        recordedAt: new Date().toISOString(),
        recordedByBeingId: being.id,
        receipt: null
      };
      return (self.signing
        ? self.signing.sign(reportingCommunity, 'federation.exchange.settlement.recorded', settlement, { exchangeId: exchange.id })
        : Promise.resolve(null))
        .then(function (receipt) {
          settlement.receipt = receipt;
          exchange.settlements.push(settlement);
          if (new Set(exchange.settlements.map(function (item) { return item.communityId; })).size >= 2) {
            exchange.status = 'settled';
            exchange.settledAt = new Date().toISOString();
          }
          return self.save(exchange).then(function () {
            return { ok: true, exchange: exchange, settlement: settlement };
          });
        });
    });
};

module.exports = ResourceExchangeService;
