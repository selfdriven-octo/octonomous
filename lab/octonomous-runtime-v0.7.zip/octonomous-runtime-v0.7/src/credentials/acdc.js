/*
 * ACDC credential adapter boundary.
 *
 * Production mode expects a provider backed by Signify/KERIA (or another
 * KERI/ACDC implementation) with:
 *
 *   issueCapability({ issuerAid, subjectAid, capability })
 *   revokeCredential({ issuerAid, credential, reason })
 *   verifyCredential({ credential })
 *
 * The Octonomous runtime deliberately does not own KERI key or TEL lifecycle.
 */
function AcdcCredentialService(options) {
  options = options || {};
  this.provider = options.provider || null;
  this.receipts = options.receipts || null;
}

AcdcCredentialService.prototype.issueCapability = function (context) {
  const self = this;
  const issuerBeing = context.issuerBeing;
  const capability = context.capability;

  if (self.provider && typeof self.provider.issueCapability === 'function') {
    return Promise.resolve(self.provider.issueCapability({
      issuerAid: issuerBeing.identity && issuerBeing.identity.keriAid,
      subjectAid: capability.subjectAid || null,
      capability: capability
    }))
      .then(function (credential) {
        return Object.assign({ mode: 'acdc' }, credential || {});
      });
  }

  if (!self.receipts) {
    return Promise.resolve(null);
  }

  return self.receipts.create({
    kind: 'credential.capability.development',
    beingId: issuerBeing.id,
    subject: {
      capabilityId: capability.id,
      subjectBeingId: capability.subjectBeingId,
      tool: capability.tool,
      constraints: capability.constraints,
      expiresAt: capability.expiresAt
    },
    evidence: {
      note: 'Development receipt credential; not an ACDC/TEL credential.'
    }
  })
    .then(function (receipt) {
      return {
        mode: 'development-receipt',
        credentialId: receipt.id,
        receipt: receipt
      };
    });
};

AcdcCredentialService.prototype.revokeCapability = function (context) {
  if (this.provider && typeof this.provider.revokeCredential === 'function') {
    return Promise.resolve(this.provider.revokeCredential({
      issuerAid: context.issuerBeing.identity && context.issuerBeing.identity.keriAid,
      credential: context.credential,
      reason: context.reason || ''
    }));
  }

  return Promise.resolve({
    mode: 'development-receipt',
    status: 'revoked-locally',
    at: new Date().toISOString()
  });
};

AcdcCredentialService.prototype.verify = function (credential) {
  if (this.provider && typeof this.provider.verifyCredential === 'function') {
    return Promise.resolve(this.provider.verifyCredential({ credential: credential }));
  }

  return Promise.resolve({
    valid: null,
    mode: 'development-receipt',
    reason: 'No ACDC provider configured'
  });
};

module.exports = AcdcCredentialService;

AcdcCredentialService.prototype.issueMembership = function (context) {
  const self = this;
  const issuerBeing = context.issuerBeing;
  const community = context.community;
  const membership = context.membership;

  if (self.provider && typeof self.provider.issueMembership === 'function') {
    return Promise.resolve(self.provider.issueMembership({
      issuerAid: community.identity && community.identity.keriAid || issuerBeing.identity && issuerBeing.identity.keriAid,
      communityId: community.id,
      subjectAid: membership.subjectAid || null,
      membership: membership
    }))
      .then(function (credential) {
        return Object.assign({ mode: 'acdc' }, credential || {});
      });
  }

  if (!self.receipts) {
    return Promise.resolve(null);
  }

  return self.receipts.create({
    kind: 'credential.membership.development',
    beingId: issuerBeing.id,
    subject: {
      communityId: community.id,
      membershipId: membership.id,
      subjectBeingId: membership.beingId,
      roles: membership.roles,
      validUntil: membership.validUntil
    },
    evidence: {
      note: 'Development receipt credential; not an ACDC/TEL credential.'
    }
  })
    .then(function (receipt) {
      return {
        mode: 'development-receipt',
        credentialId: receipt.id,
        receipt: receipt
      };
    });
};

AcdcCredentialService.prototype.revokeMembership = function (context) {
  if (this.provider && typeof this.provider.revokeCredential === 'function') {
    return Promise.resolve(this.provider.revokeCredential({
      issuerAid: context.community.identity && context.community.identity.keriAid || context.issuerBeing.identity && context.issuerBeing.identity.keriAid,
      credential: context.credential,
      reason: context.reason || ''
    }));
  }

  return Promise.resolve({
    mode: 'development-receipt',
    status: 'revoked-locally',
    at: new Date().toISOString()
  });
};
