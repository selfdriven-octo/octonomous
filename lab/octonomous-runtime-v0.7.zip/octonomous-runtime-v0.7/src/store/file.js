const fs = require('fs');
const path = require('path');

function cloneWithoutVersion(being) {
  const value = JSON.parse(JSON.stringify(being));
  delete value._version;
  return value;
}

function FileStore(options) {
  options = options || {};

  this.basePath = options.basePath || path.join(process.cwd(), 'data');
  fs.mkdirSync(this.basePath, { recursive: true });
}

FileStore.prototype._fileFor = function (id) {
  return path.join(
    this.basePath,
    id.replace(/[^a-zA-Z0-9-_]/g, '_') + '.json'
  );
};

FileStore.prototype.loadBeing = function (id) {
  const filename = this._fileFor(id);

  return fs.promises.readFile(filename, 'utf8')
    .then(function (content) {
      return JSON.parse(content);
    })
    .catch(function (error) {
      if (error.code === 'ENOENT') {
        return null;
      }
      throw error;
    });
};

FileStore.prototype.saveBeing = function (being) {
  const filename = this._fileFor(being.id);
  const currentVersion = Number(being._version || 0);
  const next = cloneWithoutVersion(being);
  next._version = currentVersion + 1;

  return fs.promises.writeFile(filename, JSON.stringify(next, null, 2), 'utf8')
    .then(function () {
      being._version = next._version;
      return being;
    });
};

module.exports = FileStore;

FileStore.prototype._resourceFileFor = function (kind, id) {
  const dir = path.join(this.basePath, String(kind).replace(/[^a-zA-Z0-9-_]/g, '_'));
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, id.replace(/[^a-zA-Z0-9-_]/g, '_') + '.json');
};

FileStore.prototype.loadResource = function (kind, id) {
  const filename = this._resourceFileFor(kind, id);
  return fs.promises.readFile(filename, 'utf8')
    .then(function (content) { return JSON.parse(content); })
    .catch(function (error) {
      if (error.code === 'ENOENT') {
        return null;
      }
      throw error;
    });
};

FileStore.prototype.saveResource = function (kind, resource) {
  const filename = this._resourceFileFor(kind, resource.id);
  const currentVersion = Number(resource._version || 0);
  const next = cloneWithoutVersion(resource);
  next._version = currentVersion + 1;
  return fs.promises.writeFile(filename, JSON.stringify(next, null, 2), 'utf8')
    .then(function () {
      resource._version = next._version;
      return resource;
    });
};

FileStore.prototype.loadCommunity = function (id) {
  return this.loadResource('communities', id);
};

FileStore.prototype.saveCommunity = function (community) {
  return this.saveResource('communities', community);
};
