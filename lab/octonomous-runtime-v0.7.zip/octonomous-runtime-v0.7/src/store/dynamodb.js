const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand
} = require('@aws-sdk/lib-dynamodb');

function cloneWithoutVersion(being) {
  const value = JSON.parse(JSON.stringify(being));
  delete value._version;
  return value;
}

function DynamoDBStore(options) {
  options = options || {};

  this.tableName = options.tableName;
  this.client = options.client || DynamoDBDocumentClient.from(
    new DynamoDBClient({ region: options.region })
  );
}

DynamoDBStore.prototype.loadBeing = function (id) {
  const self = this;

  return self.client.send(new GetCommand({
    TableName: self.tableName,
    Key: {
      pk: 'BEING#' + id,
      sk: 'STATE'
    },
    ConsistentRead: true
  }))
    .then(function (result) {
      if (!result.Item) {
        return null;
      }

      const being = result.Item.state;
      being._version = result.Item.version;
      return being;
    });
};

DynamoDBStore.prototype.saveBeing = function (being) {
  const self = this;
  const expectedVersion = being._version;
  const nextVersion = expectedVersion === undefined ? 1 : Number(expectedVersion) + 1;
  const state = cloneWithoutVersion(being);

  const params = {
    TableName: self.tableName,
    Item: {
      pk: 'BEING#' + being.id,
      sk: 'STATE',
      version: nextVersion,
      state: state,
      updatedAt: new Date().toISOString()
    }
  };

  if (expectedVersion === undefined) {
    params.ConditionExpression = 'attribute_not_exists(pk)';
  }
  else {
    params.ConditionExpression = '#version = :expectedVersion';
    params.ExpressionAttributeNames = {
      '#version': 'version'
    };
    params.ExpressionAttributeValues = {
      ':expectedVersion': Number(expectedVersion)
    };
  }

  return self.client.send(new PutCommand(params))
    .then(function () {
      being._version = nextVersion;
      return being;
    });
};

module.exports = DynamoDBStore;

DynamoDBStore.prototype.loadResource = function (kind, id) {
  const self = this;
  const prefix = String(kind).toUpperCase().replace(/[^A-Z0-9-_]/g, '_');
  return self.client.send(new GetCommand({
    TableName: self.tableName,
    Key: { pk: prefix + '#' + id, sk: 'STATE' },
    ConsistentRead: true
  }))
    .then(function (result) {
      if (!result.Item) {
        return null;
      }
      const resource = result.Item.state;
      resource._version = result.Item.version;
      return resource;
    });
};

DynamoDBStore.prototype.saveResource = function (kind, resource) {
  const self = this;
  const prefix = String(kind).toUpperCase().replace(/[^A-Z0-9-_]/g, '_');
  const expectedVersion = resource._version;
  const nextVersion = expectedVersion === undefined ? 1 : Number(expectedVersion) + 1;
  const state = cloneWithoutVersion(resource);
  const params = {
    TableName: self.tableName,
    Item: {
      pk: prefix + '#' + resource.id,
      sk: 'STATE',
      version: nextVersion,
      state: state,
      updatedAt: new Date().toISOString()
    }
  };

  if (expectedVersion === undefined) {
    params.ConditionExpression = 'attribute_not_exists(pk)';
  }
  else {
    params.ConditionExpression = '#version = :expectedVersion';
    params.ExpressionAttributeNames = { '#version': 'version' };
    params.ExpressionAttributeValues = { ':expectedVersion': Number(expectedVersion) };
  }

  return self.client.send(new PutCommand(params))
    .then(function () {
      resource._version = nextVersion;
      return resource;
    });
};

DynamoDBStore.prototype.loadCommunity = function (id) {
  return this.loadResource('community', id);
};

DynamoDBStore.prototype.saveCommunity = function (community) {
  return this.saveResource('community', community);
};
