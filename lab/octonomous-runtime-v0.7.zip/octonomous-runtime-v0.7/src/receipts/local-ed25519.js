const crypto = require('crypto');
const canonical = require('../canonical');

function LocalEd25519Signer(options) {
  options = options || {};

  if (options.privateKeyPem && options.publicKeyPem) {
    this.privateKey = crypto.createPrivateKey(options.privateKeyPem);
    this.publicKey = crypto.createPublicKey(options.publicKeyPem);
  }
  else {
    const pair = crypto.generateKeyPairSync('ed25519');
    this.privateKey = pair.privateKey;
    this.publicKey = pair.publicKey;
  }

  this.aid = options.aid || 'did:key:local-development';
}

LocalEd25519Signer.prototype.sign = function (payload) {
  const bytes = Buffer.from(canonical.canonicalJson(payload), 'utf8');
  const signature = crypto.sign(null, bytes, this.privateKey);
  const publicKeyDer = this.publicKey.export({
    type: 'spki',
    format: 'der'
  });

  return Promise.resolve({
    mode: 'local-ed25519',
    aid: this.aid,
    algorithm: 'Ed25519',
    publicKeyFingerprint: canonical.sha256(publicKeyDer.toString('base64')),
    publicKeyDer: publicKeyDer.toString('base64url'),
    signature: signature.toString('base64url')
  });
};

LocalEd25519Signer.prototype.verify = function (payload, receipt) {
  const bytes = Buffer.from(canonical.canonicalJson(payload), 'utf8');
  if (!receipt || !receipt.signature) {
    return Promise.resolve(false);
  }

  const signature = Buffer.from(receipt.signature, 'base64url');
  let publicKey = this.publicKey;

  if (receipt.publicKeyDer) {
    publicKey = crypto.createPublicKey({
      key: Buffer.from(receipt.publicKeyDer, 'base64url'),
      type: 'spki',
      format: 'der'
    });
  }

  return Promise.resolve(
    crypto.verify(null, bytes, publicKey, signature)
  );
};

module.exports = LocalEd25519Signer;
