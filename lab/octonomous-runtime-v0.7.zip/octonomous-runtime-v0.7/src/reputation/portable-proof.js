const crypto = require('crypto');
const canonical = require('../canonical');

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function PortableReputationProofService(options) {
  options = options || {};
  this.reputation = options.reputation;
  this.receipts = options.receipts || null;
  this.trust = options.trust || null;
  this.communities = options.communities || null;
}

PortableReputationProofService.prototype._communityContext = function (being, issuerCommunityId) {
  const self = this;
  if (!issuerCommunityId) {
    return Promise.resolve(null);
  }
  if (!self.communities) {
    return Promise.reject(new Error('issuerCommunityId requires a community service'));
  }

  return self.communities.load(issuerCommunityId)
    .then(function (community) {
      if (!community) {
        throw new Error('Unknown issuer community: ' + issuerCommunityId);
      }
      const membership = self.communities.membershipFor(community, being.id);
      if (!membership) {
        throw new Error('Being is not an active member of issuer community: ' + issuerCommunityId);
      }
      return {
        community: community,
        membership: membership
      };
    });
};

PortableReputationProofService.prototype.issue = function (context) {
  const self = this;
  const being = context.being;
  const input = context.input || {};
  let communityContext;

  return self._communityContext(being, input.issuerCommunityId || null)
    .then(function (resolved) {
      communityContext = resolved;
      return self.reputation.compute(being);
    })
    .then(function (report) {
      const accepted = (report.evidence || []).filter(function (item) {
        return item.verified;
      });
      const evidenceRefs = accepted.map(function (item) {
        return {
          kind: item.kind,
          subjectId: item.subjectId,
          receiptId: item.receipt && item.receipt.id || null,
          receiptDigest: item.receipt && item.receipt.digest || null,
          weight: item.weight
        };
      });

      const membership = communityContext && communityContext.membership;
      const proof = {
        id: crypto.randomUUID(),
        version: 'octonomous.portable-reputation-proof.v1',
        subjectBeingId: being.id,
        subjectAid: being.identity && being.identity.keriAid || null,
        issuerCommunityId: input.issuerCommunityId || null,
        issuerCommunityMembership: membership ? {
          membershipId: membership.id,
          roles: (membership.roles || []).slice(),
          credential: membership.credential || null,
          validUntil: membership.validUntil || null
        } : null,
        audienceCommunityId: input.audienceCommunityId || null,
        scope: input.scope || 'general',
        score: report.score,
        evidenceCount: report.evidenceCount,
        evidenceRoot: canonical.sha256(evidenceRefs),
        evidenceRefs: input.includeEvidenceRefs === false ? [] : evidenceRefs,
        issuedAt: new Date().toISOString(),
        validUntil: input.validUntil || null,
        receipt: null
      };

      const receiptPromise = self.receipts
        ? self.receipts.create({
          kind: 'reputation.proof.issued',
          beingId: being.id,
          subject: proof,
          evidence: {
            reportVersion: report.version,
            evidenceRoot: proof.evidenceRoot,
            issuerCommunityId: proof.issuerCommunityId,
            membershipId: membership && membership.id || null
          }
        })
        : Promise.resolve(null);

      return receiptPromise.then(function (receipt) {
        proof.receipt = receipt;
        being.reputationProofs = being.reputationProofs || [];
        being.reputationProofs.push(proof);
        if (being.reputationProofs.length > 20) {
          being.reputationProofs = being.reputationProofs.slice(-20);
        }
        return { ok: true, proof: proof };
      });
    });
};

PortableReputationProofService.prototype.verify = function (context) {
  const self = this;
  const proof = context.proof;
  const relyingCommunityId = context.relyingCommunityId || null;

  if (!proof || !proof.receipt) {
    return Promise.resolve({ valid: false, reason: 'missing_proof_or_receipt' });
  }
  if (proof.validUntil && Date.parse(proof.validUntil) <= Date.now()) {
    return Promise.resolve({ valid: false, reason: 'proof_expired' });
  }

  const signedSubject = proof.receipt.payload && proof.receipt.payload.subject;
  const proofSnapshot = clone(proof);
  proofSnapshot.receipt = null;
  const subjectMatches = Boolean(signedSubject) &&
    canonical.sha256(proofSnapshot) === canonical.sha256(signedSubject);

  if (!subjectMatches) {
    return Promise.resolve({
      valid: false,
      reason: 'proof_subject_mismatch',
      subjectMatches: false
    });
  }

  const verificationPromise = self.receipts
    ? self.receipts.verify(proof.receipt)
    : Promise.resolve({ valid: null, reason: 'no_receipt_verifier' });

  return verificationPromise
    .then(function (verification) {
      if (verification.valid === false) {
        return { valid: false, subjectMatches: true, cryptographic: verification, trust: null };
      }

      if (!relyingCommunityId || !proof.issuerCommunityId || !self.trust) {
        return {
          valid: verification.valid !== false,
          subjectMatches: true,
          cryptographic: verification,
          trust: null
        };
      }

      return self.trust.evaluate(relyingCommunityId, proof.issuerCommunityId, 'reputation')
        .then(function (trust) {
          return {
            valid: verification.valid !== false && trust.trusted,
            subjectMatches: true,
            cryptographic: verification,
            trust: trust
          };
        });
    });
};

module.exports = PortableReputationProofService;
