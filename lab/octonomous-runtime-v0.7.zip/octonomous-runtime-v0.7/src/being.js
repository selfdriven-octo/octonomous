function Being(options) {
  options = options || {};

  this.definition = options.definition;
  this.store = options.store;
  this.cognition = options.cognition;
  this.policy = options.policy;
  this.tools = options.tools;
  this.commitments = options.commitments;
  this.approvals = options.approvals;
  this.relationships = options.relationships;
  this.contributions = options.contributions;
  this.receipts = options.receipts;
  this.delegations = options.delegations;
  this.capabilities = options.capabilities;
  this.verifications = options.verifications;
  this.governance = options.governance;
  this.challenges = options.challenges;
  this.quorum = options.quorum;
  this.reputation = options.reputation;
  this.memberships = options.memberships;
  this.communityGovernance = options.communityGovernance;
  this.governanceDelegations = options.governanceDelegations;
  this.federationTrust = options.federationTrust;
  this.portableReputation = options.portableReputation;
}

Being.prototype.handleEvent = function (event) {
  const self = this;
  const context = { event: event };

  return self.wake(event, context)
    .then(function () { return self.observe(event, context); })
    .then(function () { return self.consider(event, context); })
    .then(function () { return self.decide(event, context); })
    .then(function () { return self.govern(event, context); })
    .then(function () { return self.commit(event, context); })
    .then(function () { return self.act(event, context); })
    .then(function () { return self.reflect(event, context); })
    .then(function () { return self.contribute(event, context); })
    .then(function () { return self.remember(event, context); })
    .then(function () { return self.sleep(event, context); })
    .then(function () {
      return {
        beingId: self.definition.id,
        eventId: event.id,
        decision: context.decision,
        governance: context.governance,
        governanceProposal: context.governanceProposal || null,
        approvalRequest: context.approvalRequest || null,
        commitment: context.commitment || null,
        societyObservation: context.societyObservation || null,
        actionResult: context.actionResult,
        reflection: context.reflection,
        contribution: context.contribution || null,
        reputation: context.reputation || null,
        receipt: context.receipt || null
      };
    });
};

Being.prototype.wake = function (event, context) {
  context.wokeAt = new Date().toISOString();
  return Promise.resolve();
};

Being.prototype.observe = function (event, context) {
  const self = this;
  const memory = self.definition.memory || {};
  const reflections = memory.reflections || [];
  const society = {};

  if (self.relationships) {
    self.relationships.recordEvent(self.definition, event);
    const assertion = self.relationships.observeAssertion(self.definition, event);
    if (assertion) {
      society.relationshipAssertion = assertion;
    }
  }

  if (self.delegations) {
    const delegation = self.delegations.observeEvent(self.definition, event);
    if (delegation) {
      society.delegation = delegation;
    }
  }

  if (self.capabilities) {
    const capability = self.capabilities.observeEvent(self.definition, event);
    if (capability) {
      society.capability = capability;
    }
  }

  if (self.verifications) {
    const verification = self.verifications.observeEvent(self.definition, event);
    if (verification) {
      society.verification = verification;
    }
  }

  if (self.challenges) {
    const challenge = self.challenges.observeEvent(self.definition, event);
    if (challenge) {
      society.challenge = challenge;
    }
  }

  const federation = {};
  if (self.memberships) {
    const membership = self.memberships.observeEvent(self.definition, event);
    if (membership) {
      federation.membership = membership;
    }
  }
  if (self.communityGovernance && typeof self.communityGovernance.observeEvent === 'function') {
    const communityGovernance = self.communityGovernance.observeEvent(self.definition, event);
    if (communityGovernance) {
      federation.communityGovernance = communityGovernance;
    }
  }
  if (self.governanceDelegations && typeof self.governanceDelegations.observeEvent === 'function') {
    const governanceDelegation = self.governanceDelegations.observeEvent(self.definition, event);
    if (governanceDelegation) {
      federation.governanceDelegation = governanceDelegation;
    }
  }
  if (event.type && (event.type.startsWith('federation.') || event.type.startsWith('community.group-identity.'))) {
    self.definition.federation = self.definition.federation || {};
    self.definition.federation.protocolEvents = self.definition.federation.protocolEvents || [];
    const protocolObservation = {
      eventId: event.id || null,
      type: event.type,
      payload: event.payload || {},
      observedAt: new Date().toISOString()
    };
    self.definition.federation.protocolEvents.push(protocolObservation);
    if (self.definition.federation.protocolEvents.length > 50) {
      self.definition.federation.protocolEvents = self.definition.federation.protocolEvents.slice(-50);
    }
    federation.protocol = protocolObservation;
  }
  if (Object.keys(federation).length) {
    society.federation = federation;
  }

  if (event.type === 'commitment.due' && self.commitments) {
    context.dueCommitment = self.commitments.markDue(
      self.definition,
      event.payload && event.payload.commitmentId
    );
  }

  const governancePromise = self.governance
    ? self.governance.observeEvent(self.definition, event)
    : Promise.resolve(null);

  return governancePromise
    .then(function (governanceObservation) {
      if (governanceObservation) {
        society.governance = governanceObservation;
      }

      if (!self.quorum) {
        return null;
      }
      return self.quorum.observeVerificationEvent(self.definition, event);
    })
    .then(function (quorumObservation) {
      if (quorumObservation) {
        society.verificationQuorum = quorumObservation;
      }

      context.societyObservation = Object.keys(society).length ? society : null;
      context.observation = {
        event: event,
        society: context.societyObservation,
        dueCommitment: context.dueCommitment || null,
        being: {
          id: self.definition.id,
          identity: self.definition.identity,
          purpose: self.definition.purpose,
          character: self.definition.character,
          commitments: self.definition.commitments || [],
          delegations: (self.definition.delegations || []).slice(-20),
          capabilities: self.definition.capabilities || { granted: [], received: [] },
          relationships: self.definition.relationships || {},
          relationshipAssertions: (self.definition.relationshipAssertions || []).slice(-20),
          governance: self.definition.governance || {},
          challenges: (self.definition.challenges || []).slice(-20),
          reputation: self.definition.reputationEvidence || null,
          federation: self.definition.federation || {},
          recentReflections: reflections.slice(-5)
        }
      };
    });
};

Being.prototype.consider = function (event, context) {
  if (event.type === 'approval.granted' || event.type === 'approval.denied') {
    context.consideration = {
      relevant: true,
      approvalResolution: true
    };
    return Promise.resolve();
  }

  if (event.type === 'governance.proposal.approved' || event.type === 'governance.proposal.rejected') {
    context.consideration = {
      relevant: true,
      governanceResolution: true
    };
    return Promise.resolve();
  }

  if (event.type === 'governance.vote.cast') {
    context.consideration = {
      relevant: true,
      governanceVoteObserved: true,
      systemOnly: true
    };
    return Promise.resolve();
  }

  return this.cognition.consider({
    being: this.definition,
    event: event,
    observation: context.observation,
    tools: this.tools.listMetadata()
  })
    .then(function (consideration) {
      context.consideration = consideration;
    });
};

Being.prototype.decide = function (event, context) {
  const self = this;

  if ((event.type === 'approval.granted' || event.type === 'approval.denied') && self.approvals) {
    return self.approvals.resolve(self.definition, event)
      .then(function (resolution) {
        context.approvalResolution = resolution;
        context.decision = self.approvals.decisionFromResolution(resolution);
      });
  }

  if ((event.type === 'governance.proposal.approved' || event.type === 'governance.proposal.rejected') && self.governance) {
    context.decision = self.governance.decisionFromResolution(self.definition, event);
    return Promise.resolve();
  }

  if (event.type === 'governance.vote.cast') {
    context.decision = {
      shouldAct: false,
      rationale: 'Governance vote recorded and threshold evaluated',
      action: { enabled: false },
      commitment: { enabled: false }
    };
    return Promise.resolve();
  }

  return self.cognition.decide({
    being: self.definition,
    event: event,
    observation: context.observation,
    consideration: context.consideration,
    tools: self.tools.listMetadata()
  })
    .then(function (decision) {
      context.decision = decision;
    });
};

Being.prototype.govern = function (event, context) {
  context.governance = this.policy.check({
    being: this.definition,
    decision: context.decision,
    availableTools: this.tools.listMetadata()
  });

  return Promise.resolve();
};

Being.prototype.commit = function (event, context) {
  const self = this;
  const proposal = context.decision && context.decision.commitment;

  if (!proposal || !proposal.enabled || !self.commitments) {
    return Promise.resolve();
  }

  return self.commitments.create({
    being: self.definition,
    event: event,
    proposal: proposal
  })
    .then(function (commitment) {
      context.commitment = commitment;
    });
};

Being.prototype.act = function (event, context) {
  const self = this;
  const decision = context.decision || {};
  const governance = context.governance || {};
  const action = decision.action;

  if (!decision.shouldAct || !action || !action.enabled) {
    context.actionResult = {
      ok: true,
      skipped: true,
      reason: decision.approvalResolution && decision.approvalResolution.status === 'denied'
        ? 'Approval denied'
        : (decision.governanceResolution && decision.governanceResolution.status === 'rejected'
          ? 'Governance rejected'
          : 'No action selected')
    };
    return Promise.resolve();
  }

  if (!governance.allowed && governance.status === 'approval_required' && self.approvals) {
    return self.approvals.request({
      being: self.definition,
      event: event,
      decision: decision
    })
      .then(function (approval) {
        context.approvalRequest = approval;
        context.actionResult = {
          ok: true,
          pendingApproval: true,
          approvalId: approval.id,
          tool: approval.tool
        };
      });
  }

  if (!governance.allowed && governance.status === 'governance_required' && self.governance) {
    return self.governance.request({
      being: self.definition,
      event: event,
      decision: decision,
      rule: governance
    })
      .then(function (proposal) {
        context.governanceProposal = proposal;
        context.actionResult = {
          ok: true,
          pendingGovernance: true,
          proposalId: proposal.id,
          tool: proposal.action.tool,
          threshold: proposal.threshold
        };
      });
  }

  if (!governance.allowed) {
    context.actionResult = {
      ok: false,
      blocked: true,
      status: governance.status,
      reason: governance.reason
    };
    return Promise.resolve();
  }

  return self.tools.execute(action.tool, action.input, {
    being: self.definition,
    event: event,
    decision: decision,
    governance: governance
  })
    .then(function (result) {
      context.actionResult = result;
    })
    .catch(function (error) {
      context.actionResult = {
        ok: false,
        error: error.message
      };
    });
};

Being.prototype.reflect = function (event, context) {
  return this.cognition.reflect({
    being: this.definition,
    event: event,
    decision: context.decision,
    governance: context.governance,
    societyObservation: context.societyObservation,
    governanceProposal: context.governanceProposal,
    approvalRequest: context.approvalRequest,
    commitment: context.commitment,
    actionResult: context.actionResult
  })
    .then(function (reflection) {
      context.reflection = reflection;
    });
};

Being.prototype.contribute = function (event, context) {
  if (!this.contributions) {
    return Promise.resolve();
  }

  return this.contributions.create({
    being: this.definition,
    event: event,
    decision: context.decision,
    commitment: context.commitment,
    actionResult: context.actionResult,
    reflection: context.reflection
  })
    .then(function (contribution) {
      context.contribution = contribution;
    });
};

Being.prototype.remember = function (event, context) {
  const self = this;

  if (self.relationships) {
    self.relationships.recordOutcome(self.definition, context);
  }

  self.definition.memory = self.definition.memory || {};
  self.definition.memory.reflections = self.definition.memory.reflections || [];
  self.definition.memory.receipts = self.definition.memory.receipts || [];

  self.definition.memory.reflections.push({
    at: new Date().toISOString(),
    eventId: event.id,
    eventType: event.type,
    societyObservation: context.societyObservation || null,
    decision: context.decision,
    governance: context.governance,
    governanceProposalId: context.governanceProposal ? context.governanceProposal.id : null,
    approvalId: context.approvalRequest ? context.approvalRequest.id : null,
    commitmentId: context.commitment ? context.commitment.id : null,
    contributionId: context.contribution ? context.contribution.id : null,
    result: context.actionResult,
    reflection: context.reflection
  });

  if (self.definition.memory.reflections.length > 100) {
    self.definition.memory.reflections = self.definition.memory.reflections.slice(-100);
  }

  const receiptPromise = self.receipts
    ? self.receipts.create({
      kind: 'event.processed',
      beingId: self.definition.id,
      occurredAt: new Date().toISOString(),
      subject: {
        eventId: event.id,
        eventType: event.type,
        governance: context.governance,
        actionResult: context.actionResult,
        contributionId: context.contribution ? context.contribution.id : null
      },
      evidence: {
        sourceBeingId: event.sourceBeingId || null
      }
    })
    : Promise.resolve(null);

  return receiptPromise
    .then(function (receipt) {
      context.receipt = receipt;
      if (receipt) {
        self.definition.memory.receipts.push(receipt);
        if (self.definition.memory.receipts.length > 100) {
          self.definition.memory.receipts = self.definition.memory.receipts.slice(-100);
        }
      }

      if (!self.reputation) {
        return null;
      }
      return self.reputation.compute(self.definition);
    })
    .then(function (report) {
      if (report) {
        context.reputation = report;
        self.definition.reputationEvidence = report;
      }
      return self.store.saveBeing(self.definition);
    })
    .then(function (saved) {
      self.definition = saved;
    });
};

Being.prototype.sleep = function (event, context) {
  context.sleptAt = new Date().toISOString();
  return Promise.resolve();
};

module.exports = Being;
