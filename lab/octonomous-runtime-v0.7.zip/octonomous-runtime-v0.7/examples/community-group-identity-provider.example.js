// Production adapter boundary for community KERI multisig/group identity.
// Keep KERI/KERIA key-event and threshold-signing lifecycle outside the Octonomous runtime.

function createProvider(options) {
  options = options || {};

  return {
    bindGroupIdentity: function (context) {
      // Replace this with Signify/KERIA calls that inspect or create the group AID.
      // Do not return private keys to Octonomous.
      return Promise.resolve({
        mode: 'keri-group-aid',
        aid: context.aid,
        memberAids: context.memberAids,
        threshold: context.threshold,
        provider: {
          keriaUrl: options.keriaUrl || null,
          managedExternally: true
        }
      });
    },

    describeGroupIdentity: function (context) {
      // Replace with current group AID/key-state lookup.
      return Promise.resolve({
        aid: context.identity.aid,
        status: 'externally-managed',
        privateMaterialExposed: false
      });
    }
  };
}

module.exports = {
  createProvider: createProvider
};
