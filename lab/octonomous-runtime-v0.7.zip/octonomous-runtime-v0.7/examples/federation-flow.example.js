const path = require('path');
const FileStore = require('../src/store/file');
const ReceiptService = require('../src/receipts/service');
const LocalEd25519Signer = require('../src/receipts/local-ed25519');
const CommunitySigningService = require('../src/federation/community-signing');
const CommunityService = require('../src/federation/communities');
const MembershipService = require('../src/federation/memberships');
const GovernanceDelegationService = require('../src/federation/governance-delegations');
const CommunityGovernanceService = require('../src/federation/governance');
const AcdcCredentialService = require('../src/credentials/acdc');

const store = new FileStore({
  basePath: path.join(process.cwd(), 'data', 'federation-example')
});

const receipts = new ReceiptService({
  signer: new LocalEd25519Signer({ aid: 'did:key:federation-example' })
});

const signing = new CommunitySigningService({ receipts: receipts });
const communities = new CommunityService({ store: store, signing: signing });
const credentials = new AcdcCredentialService({ receipts: receipts });
const memberships = new MembershipService({
  communities: communities,
  credentials: credentials,
  signing: signing
});
const governanceDelegations = new GovernanceDelegationService({
  communities: communities,
  receipts: receipts
});
const governance = new CommunityGovernanceService({
  communities: communities,
  signing: signing,
  receipts: receipts,
  delegations: governanceDelegations
});

const founder = { id: 'octo:founder' };
const governor = { id: 'octo:governor' };
let proposal;

communities.create({
  being: founder,
  input: {
    id: 'community:federation-example',
    name: 'Federation Example',
    constitution: {
      id: 'community:federation-example:constitution:1',
      version: '1.0.0',
      policies: [],
      federation: {
        amendment: {
          approvals: 2,
          rejections: 2,
          eligibleRoles: ['founder', 'governor']
        }
      }
    }
  }
})
  .catch(function (error) {
    // Makes the example re-runnable if the community already exists.
    if (!String(error.message).includes('already exists')) {
      throw error;
    }
  })
  .then(function () {
    return communities.load('community:federation-example');
  })
  .then(function (community) {
    const existing = communities.membershipFor(community, governor.id);
    if (existing) {
      return existing;
    }

    return memberships.issue({
      being: founder,
      input: {
        communityId: community.id,
        targetBeingId: governor.id,
        roles: ['governor']
      }
    });
  })
  .then(function () {
    return governance.propose({
      being: founder,
      input: {
        communityId: 'community:federation-example',
        kind: 'constitution.amend',
        patch: {
          version: '1.1.0',
          principles: {
            portableReputation: true
          }
        }
      }
    });
  })
  .then(function (result) {
    proposal = result.proposal;
    return governance.castVote({
      being: founder,
      input: {
        communityId: proposal.communityId,
        proposalId: proposal.id,
        vote: 'approve'
      }
    });
  })
  .then(function () {
    return governance.castVote({
      being: governor,
      input: {
        communityId: proposal.communityId,
        proposalId: proposal.id,
        vote: 'approve'
      }
    });
  })
  .then(function () {
    return communities.load('community:federation-example');
  })
  .then(function (community) {
    console.log(JSON.stringify({
      communityId: community.id,
      constitution: community.constitution,
      memberships: community.memberships.map(function (membership) {
        return {
          beingId: membership.beingId,
          roles: membership.roles,
          status: membership.status
        };
      })
    }, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
