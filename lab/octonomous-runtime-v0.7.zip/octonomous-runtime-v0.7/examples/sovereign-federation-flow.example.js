const bootstrap = require('../src/bootstrap');

// This example assumes the three communities and beings already exist.
// It demonstrates the protocol order rather than provisioning identities.

bootstrap()
  .then(function (app) {
    const alphaGovernor = { id: 'octo:alpha-governor' };
    const betaGovernor = { id: 'octo:beta-governor' };
    let treaty;

    return app.treaties.propose({
      being: alphaGovernor,
      input: {
        proposerCommunityId: 'community:alpha',
        participantCommunityIds: ['community:beta'],
        name: 'Alpha / Beta Collaboration Compact',
        scopes: ['federation.proposal', 'resource.exchange'],
        disputeResolverCommunityId: 'community:resolver',
        terms: {
          purpose: 'Share compute and independently verifiable learning evidence'
        }
      }
    })
      .then(function (result) {
        treaty = result.treaty;
        return app.treaties.ratify({
          being: alphaGovernor,
          input: {
            treatyId: treaty.id,
            communityId: 'community:alpha'
          }
        });
      })
      .then(function () {
        return app.treaties.ratify({
          being: betaGovernor,
          input: {
            treatyId: treaty.id,
            communityId: 'community:beta'
          }
        });
      })
      .then(function () {
        return app.resourceExchange.offer({
          being: alphaGovernor,
          input: {
            sourceCommunityId: 'community:alpha',
            targetCommunityId: 'community:beta',
            treatyId: treaty.id,
            give: [{ kind: 'treasury', asset: 'ADA', amount: 100 }],
            receive: [{ kind: 'resource', resource: 'computeHours', quantity: 20 }]
          }
        });
      });
  })
  .then(function (result) {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch(function (error) {
    console.error(error);
    process.exitCode = 1;
  });
