/*
 * Production boundary for community-controlled signing.
 *
 * A community should ideally use a KERI group AID / multisig controller or
 * another external signing service. Keep key lifecycle outside this runtime.
 */
exports.createProvider = function (options) {
  return {
    signCommunity: function (context) {
      return Promise.reject(new Error(
        'Implement community signing for ' + context.community.id +
        ' using its KERI/group AID. Configured AID: ' +
        (options.aid || '(none)')
      ));
    },

    verifyCommunity: function (context) {
      return Promise.reject(new Error(
        'Implement verification for community receipt on ' + context.community.id
      ));
    }
  };
};
