/*
 * Production adapter shape for Signify/KERIA-backed ACDC credentials.
 *
 * Wire these methods to your KERIA registry + credential flows. The runtime
 * deliberately keeps AID keys, registries and TEL operations out of core.
 */
exports.createProvider = function (options) {
  return {
    issueCapability: function (context) {
      return Promise.reject(new Error(
        'Implement ACDC issuance using Signify/KERIA. Registry: ' +
        (options.registryName || '(configure ACDC_REGISTRY_NAME)')
      ));
    },


    issueMembership: function (context) {
      return Promise.reject(new Error(
        'Implement ACDC membership/role issuance using Signify/KERIA for community ' +
        context.communityId
      ));
    },

    revokeCredential: function () {
      return Promise.reject(new Error('Implement ACDC revocation using the credential TEL'));
    },

    verifyCredential: function () {
      return Promise.reject(new Error('Implement ACDC verification using Signify/KERIA'));
    }
  };
};
