# Migration: v0.6 → v0.7

v0.7 adds **sovereign federation protocols**. Existing v0.6 being/community state remains valid; no destructive data migration is required.

## 1. Package version

```json
{
  "version": "0.7.0"
}
```

## 2. New durable resources

The generic `loadResource` / `saveResource` store API is reused for:

```text
treaty
federated-proposal
federated-dispute
resource-exchange
```

No additional DynamoDB table is required.

## 3. Community state

New communities include:

```json
{
  "federation": {
    "treaties": [],
    "exchanges": [],
    "protocolVersion": "octonomous.federation.v1"
  }
}
```

Existing communities are upgraded lazily when a treaty is linked; you do not need to rewrite stored v0.6 records.

## 4. New tools

```text
federation.treaty.propose
federation.treaty.ratify
federation.treaty.terminate

federation.proposal.create
federation.proposal.vote

federation.dispute.open
federation.dispute.respond
federation.dispute.resolve

federation.trust.path

federation.exchange.offer
federation.exchange.accept
federation.exchange.settlement.record

community.group-identity.bind
community.group-identity.describe
```

## 5. Treaty activation

A treaty is not active merely because one community proposed it.

```text
proposal
  ↓
community A signed ratification
  ↓
community B signed ratification
  ↓
threshold reached
  ↓
active treaty
```

Even if a treaty uses a threshold smaller than all named participants, `isActive()` only creates authority between communities that have individually ratified it.

## 6. Local governance evidence

Treaty ratifications and federated community votes include an optional:

```text
localGovernanceProposalId
```

Use this to bind sovereign protocol decisions to the community's own constitutional governance workflow. v0.7 preserves the evidence slot but does not assume every community uses the same internal voting mechanism.

## 7. Group identity adapter

Add, when required:

```bash
COMMUNITY_GROUP_IDENTITY_MODULE=./my-community-group-identity.js
```

This is intentionally separate from:

```bash
COMMUNITY_SIGNER_MODULE=...
```

The lifecycle adapter manages/describes group AID state. The signer signs community protocol records. Neither interface requires Octonomous to hold private KERI signing material.

## 8. Resource exchange boundary

v0.7 creates bilateral authorisations and settlement evidence. It still does not transfer tokens, debit balances, schedule compute, or hold custody keys.

```text
Octonomous authorisation
      ↓
external executor / multisig / scheduler
      ↓
external settlement evidence
      ↓
Octonomous signed settlement record
```

## 9. Runtime system events

All event types beginning with:

```text
federation.
community.group-identity.
```

are treated as system events and can wake a being even when not explicitly listed in its subscriptions. The being retains a bounded recent protocol-event observation history.

## 10. Tests

Run:

```bash
npm test
```

v0.7 includes all v0.6 tests plus sovereign-federation tests.
