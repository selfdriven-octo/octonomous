# Migration: v0.5 → v0.6

v0.6 adds **federated community state** while preserving the v0.5 being runtime and being-local governance model.

## What remains compatible

Existing v0.5 beings continue to use:

```text
being.governance.constitution
capability chains
human approvals
commitments
delegations
challenges
verification quorum
evidence-derived reputation
Cardano evidence anchoring
```

A community resource is optional. A v0.5 being does not need to join a community to continue operating.

## New durable resource type

v0.6 adds a community resource stored independently from beings:

```text
community.constitution
community.memberships
community.governance
community.trustAssertions
community.treasury
community.resources
```

### File store

Communities are stored under a dedicated resource directory.

### DynamoDB

The existing table is reused with a separate partition-key namespace:

```text
BEING#<beingId>
COMMUNITY#<communityId>
```

No table migration is required.

## Community-owned vs being-owned constitutions

v0.5:

```text
being.governance.constitution
```

v0.6 adds:

```text
community.constitution
```

Use the being constitution for constraints on one autonomous being.

Use the community constitution for shared membership, amendments, treasury/resource governance, and federation rules.

They may coexist.

## Recommended migration sequence

### 1. Deploy v0.6 without changing existing beings

Run the existing test suite and deploy normally.

No community state is required.

### 2. Create a community

Call:

```text
community.create
```

The initiating being becomes the founding member with:

```text
founder
governor
```

roles.

### 3. Issue memberships

Use:

```text
community.membership.issue
```

For production credential-backed membership, extend your ACDC provider with:

```text
issueMembership(...)
```

Existing capability credential methods remain unchanged.

### 4. Move shared policy into the community constitution

Example:

```json
{
  "federation": {
    "amendment": {
      "approvals": 2,
      "rejections": 2,
      "eligibleRoles": ["governor"]
    },
    "treasury": {
      "approvals": 2,
      "rejections": 2,
      "eligibleRoles": ["governor"]
    }
  }
}
```

Do not remove being-local policy unless that policy truly belongs to the community rather than the being.

### 5. Add community signing

Development mode works without additional configuration.

For production, configure:

```text
COMMUNITY_SIGNER_MODULE
COMMUNITY_KERI_AID
```

The provider should sign community state transitions using the community-controlled identity, ideally a KERI group AID/multisig arrangement.

### 6. Introduce governance delegations if required

Use:

```text
community.governance.delegate
```

These are distinct from capability delegation.

```text
capability delegation
    → authority to perform a bounded action

community governance delegation
    → authority to cast a vote as a specific member
```

Delegated voting does not create new membership or voting power.

### 7. Move treasury decisions to authorisation records

Use:

```text
community.treasury.propose
```

The v0.6 runtime records approved allocations but does not perform the transfer.

Existing Cardano or finance execution should consume the signed authorisation as an input.

This is intentional.

### 8. Establish explicit federation trust

Use:

```text
community.trust.assert
```

Start with narrow scopes such as:

```text
reputation
membership
verification
```

Avoid treating trust as automatically transitive.

### 9. Issue portable reputation proofs

Use:

```text
reputation.proof.issue
```

A relying community can verify the proof and apply its own trust relationship to the issuer community.

## Local Ed25519 receipt change

v0.6 adds:

```text
signature.publicKeyDer
```

to local development Ed25519 signatures.

This makes local receipts independently verifiable after serialization.

Existing v0.5 receipts without this field still verify inside the original signer runtime. New receipts can be verified by another v0.6 local signer instance using the embedded public key.

This development envelope should not replace KERI identity in production.

## ACDC provider extension

Existing provider methods:

```text
issueCapability
revokeCredential
verifyCredential
```

Optional new method:

```text
issueMembership
```

If it is not supplied, the runtime falls back to a development receipt credential.

## New system events

Targeted federation events may wake a being automatically:

```text
community.membership.issued
community.membership.revoked
community.governance.proposal.created
community.governance.proposal.resolved
community.governance.delegation.created
community.governance.delegation.revoked
```

These do not need to be added to ordinary subscriptions.

## New tools to add to authority where appropriate

```text
community.create
community.membership.issue
community.membership.revoke
community.governance.propose
community.constitution.propose
community.treasury.propose
community.resource.propose
community.governance.vote
community.governance.delegate
community.governance.delegation.revoke
community.trust.assert
community.trust.revoke
reputation.proof.issue
reputation.proof.verify
```

Do not give all beings all community tools by default. Use role/capability/being policy appropriate to the deployment.

## Recommended production boundary

```text
Octonomous runtime
      │
      ├─ cognition proposes
      ├─ being policy constrains
      ├─ community governance resolves
      ├─ KERI/ACDC proves identity and roles
      └─ signed authorisation emitted
                  │
                  ▼
      external execution systems
      ├─ treasury wallet / multisig
      ├─ Cardano transaction builder
      ├─ resource scheduler
      └─ operational systems
```

v0.6 is deliberately a governance and evidence layer, not a custody layer.
