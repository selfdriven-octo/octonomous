# Octonomous Runtime v0.7 — Sovereign Federation

CommonJS Node.js runtime for durable, event-driven **Octonomous beings, governed communities, and sovereign community-to-community protocols**.

v0.7 extends v0.6 Federated Societies with treaty, inter-community proposal, dispute, trust-path, resource-exchange, and community group-identity primitives.

## Core model

```text
Being
  = autonomous actor

Community
  = durable governed social entity

Treaty
  = bounded agreement between sovereign communities

Federated proposal
  = decision whose voting units are communities

Trust path
  = explainable path of scoped signed assertions/treaties

Resource exchange
  = bilateral authorisation, not custody or settlement
```

The runtime keeps a strict boundary:

```text
intelligence proposes
community governance authorises
communities sign protocol state
federation coordinates
external systems execute
signed evidence records outcome
```

## Architecture

```text
                         SOVEREIGN FEDERATION

       Community Alpha                              Community Beta
   ┌────────────────────┐                       ┌────────────────────┐
   │ Constitution       │                       │ Constitution       │
   │ Members / roles    │                       │ Members / roles    │
   │ Group identity     │                       │ Group identity     │
   │ Treasury auth      │                       │ Treasury auth      │
   │ Resource auth      │                       │ Resource auth      │
   └─────────┬──────────┘                       └─────────┬──────────┘
             │                                            │
             │       signed treaty / protocol state       │
             ├────────────────┬───────────────────────────┤
             │                │                           │
             │        ┌───────▼────────┐                  │
             │        │ Treaty        │                  │
             │        │ Proposals     │                  │
             │        │ Exchanges     │                  │
             │        │ Disputes      │                  │
             │        └───────┬────────┘                  │
             │                │                           │
             └──────── trust paths / evidence ────────────┘
                              │
                              ▼
                   external execution systems
                   Cardano / multisig / compute
                   human / organisational systems
```

## Run

```bash
npm install
npm test
npm start
```

Mock cognition is the default when no OpenAI key is configured.

```bash
COGNITION_MODE=mock npm start
```

For OpenAI cognition:

```bash
export OPENAI_API_KEY="..."
export COGNITION_MODE=openai
npm start
```

The runtime remains CommonJS and Promise/`.then()` oriented.

# 1. Treaties

A treaty is a durable resource independent from any one community record.

```text
federation.treaty.propose
federation.treaty.ratify
federation.treaty.terminate
```

Example treaty:

```json
{
  "proposerCommunityId": "community:alpha",
  "participantCommunityIds": ["community:beta"],
  "name": "Alpha / Beta Compact",
  "scopes": ["federation.proposal", "resource.exchange"],
  "disputeResolverCommunityId": "community:resolver",
  "terms": {
    "purpose": "Share resources and evidence"
  }
}
```

Lifecycle:

```text
proposed
   ↓
community A ratifies + signs
   ↓
community B ratifies + signs
   ↓
ratification threshold reached
   ↓
active
   ↓
terminated / expired
```

The activation receipt references the independent community ratification receipts.

### No silent binding

A treaty can use a ratification threshold smaller than all named participants, but authority only exists between communities that have **actually ratified**.

```text
named in treaty ≠ automatically bound
```

`TreatyService.isActive()` checks:

- treaty status
- validity window
- both communities are named participants
- both communities individually ratified
- requested scope is authorised

# 2. Federated proposals

A federated proposal is different from a community governance proposal.

```text
community governance proposal
    voters = members / delegated member slots

federated proposal
    voters = sovereign communities
```

Tools:

```text
federation.proposal.create
federation.proposal.vote
```

Example:

```json
{
  "proposerCommunityId": "community:alpha",
  "participantCommunityIds": ["community:beta", "community:gamma"],
  "treatyId": "treaty:...",
  "scope": "federation.proposal",
  "kind": "shared-standard",
  "approvals": 2,
  "rejections": 1,
  "payload": {
    "standard": "evidence-v1"
  }
}
```

Each community gets exactly one decision slot:

```text
Alpha  ─ approve ─┐
Beta   ─ approve ─┼─ threshold → approved
Gamma  ─ pending ─┘
```

Each community decision is signed by the community-signing layer.

The vote can carry:

```text
localGovernanceProposalId
```

so a community can prove that its federated decision was authorised by its own constitution before being exported to the federation.

# 3. Cross-community dispute resolution

Tools:

```text
federation.dispute.open
federation.dispute.respond
federation.dispute.resolve
```

A treaty can designate a resolver community:

```json
{
  "dispute": {
    "resolverCommunityId": "community:resolver"
  }
}
```

Protocol:

```text
claimant community
      │ signed opening
      ▼
respondent community
      │ signed response
      ▼
resolver community
      │ signed resolution
      ▼
upheld | dismissed | partially_upheld | settled
```

A member of one disputing community cannot simply self-appoint as resolver when another resolver community is named.

# 4. Trust paths

Direct federation trust from v0.6 remains supported:

```text
community.trust.assert
community.trust.revoke
```

v0.7 adds:

```text
federation.trust.path
```

It performs bounded graph traversal across:

```text
signed directed trust assertions
+
active, scope-compatible treaties
```

Example:

```text
Alpha --trusted/reputation--> Beta
Beta  ===== treaty/reputation ===== Gamma

Alpha → Gamma
path found: 2 hops
```

Returned path records identify the evidence edge used at each hop.

Trust remains local and composable. There is no required global root authority.

# 5. Governed resource exchange

Tools:

```text
federation.exchange.offer
federation.exchange.accept
federation.exchange.settlement.record
```

Example:

```json
{
  "sourceCommunityId": "community:alpha",
  "targetCommunityId": "community:beta",
  "treatyId": "treaty:...",
  "give": [
    { "kind": "treasury", "asset": "ADA", "amount": 100 }
  ],
  "receive": [
    { "kind": "resource", "resource": "computeHours", "quantity": 20 }
  ]
}
```

Acceptance creates paired authorisation records:

```text
Alpha authorised to provide ADA
Beta  authorised to provide computeHours
```

It deliberately does **not** mutate:

```text
community.treasury.balances
community.resources.pools
```

Those values describe external reality/context. The actual executor owns the custody/scheduling capability.

Settlement evidence can later be recorded independently by each community:

```text
external transfer/scheduling
       ↓
community A settlement evidence
       ↓
community B settlement evidence
       ↓
exchange = settled
```

# 6. Community group identity

v0.6 already separated community signing from the being signer.

v0.7 adds an explicit lifecycle/binding adapter:

```text
community.group-identity.bind
community.group-identity.describe
```

Configuration:

```bash
COMMUNITY_GROUP_IDENTITY_MODULE=./my-community-group-identity.js
```

The provider interface is intentionally small:

```js
bindGroupIdentity(context)
describeGroupIdentity(context)
```

Production implementations can connect this to KERI/KERIA group-AID/multisig lifecycle.

The runtime must not require private group signing material to be returned by the adapter.

Without a provider, local mode stores an explicitly labelled:

```text
mode: development-binding
```

It does not claim that a local JSON record is a real KERI group AID.

See:

```text
examples/community-group-identity-provider.example.js
```

# 7. Federation event wake-ups

All events beginning with:

```text
federation.
community.group-identity.
```

are treated as system events by `Runtime.handleEventForBeing()`.

A being can therefore react to protocol state without manually subscribing to every future federation event type.

The being stores a bounded recent observation history:

```text
being.federation.protocolEvents
```

# 8. Persistence

v0.7 reuses the generic resource store already introduced in previous versions.

Durable federation resources include:

```text
treaty
federated-proposal
federated-dispute
resource-exchange
```

File mode stores them under resource-specific directories beneath `DATA_PATH`.

DynamoDB mode stores them in the existing table using distinct partition-key prefixes. No new table is required.

# 9. Evidence model

The useful proof chain is now:

```text
community membership/role evidence
          ↓
local community governance evidence (optional binding)
          ↓
community-signed ratification / decision
          ↓
federation resolution
          ↓
external execution evidence
          ↓
community settlement evidence
          ↓
Merkle evidence batch
          ↓
optional Cardano anchor
```

The runtime continues to support the v0.4+ Cardano evidence-root adapter. Federation records can be included as signed evidence without moving large protocol state on-chain.

# 10. AWS deployment

The existing event-driven architecture remains valid:

```text
EventBridge
    ↓
SQS
    ↓
Lambda worker
    ↓
Octonomous runtime
    ├─ DynamoDB state
    ├─ OpenAI/local cognition
    ├─ MCP tools
    ├─ KERI/KERIA adapters
    └─ external execution adapters
```

No continuously running LLM loop is required.

# 11. Important security invariants

```text
1. A named treaty participant is not bound until it ratifies.
2. Treaty scope cannot silently expand.
3. A federated proposal counts a community at most once.
4. Community protocol state is signed independently.
5. Dispute resolver authority is explicit.
6. Trust paths are bounded and evidence-addressable.
7. Resource exchange authorises; it does not custody or execute.
8. Private KERI/payment keys stay outside the runtime.
9. External settlement is recorded as evidence, not invented by the LLM.
10. Intelligence never substitutes for authority.
```

# 12. Tests

```bash
npm test
```

v0.7 currently contains **30 passing tests** covering all previous layers plus:

- treaty proposal/ratification/activation
- treaty scope enforcement
- community-level federated proposal voting
- designated cross-community dispute resolution
- multi-hop trust paths
- bilateral resource-exchange authorisation
- two-sided external settlement evidence
- community group-identity adapter boundary
- automatic federation protocol wake/observation

# 13. Version progression

```text
v0.1  Being
v0.2  Durable Being
v0.3  Accountable Being
v0.4  Society of Beings
v0.5  Governed Society
v0.6  Federated Societies
v0.7  Sovereign Federation
```

The next architectural step would be less about adding more agent behaviour and more about **protocol hardening**: schema/version negotiation, replay protection, protocol capability discovery, cryptographic federation envelopes, local-governance proof verification, and Byzantine/fault-tolerant federation resolution rules.
