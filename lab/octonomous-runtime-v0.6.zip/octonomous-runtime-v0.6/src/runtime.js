const Being = require('./being');

function Runtime(options) {
  options = options || {};

  this.store = options.store;
  this.cognition = options.cognition;
  this.policy = options.policy;
  this.tools = options.tools;
  this.commitments = options.commitments;
  this.approvals = options.approvals;
  this.relationships = options.relationships;
  this.contributions = options.contributions;
  this.receipts = options.receipts;
  this.delegations = options.delegations;
  this.capabilities = options.capabilities;
  this.verifications = options.verifications;
  this.governance = options.governance;
  this.challenges = options.challenges;
  this.quorum = options.quorum;
  this.reputation = options.reputation;
  this.memberships = options.memberships;
  this.communityGovernance = options.communityGovernance;
  this.governanceDelegations = options.governanceDelegations;
  this.federationTrust = options.federationTrust;
  this.portableReputation = options.portableReputation;
}

Runtime.prototype.createBeing = function (definition) {
  return new Being({
    definition: definition,
    store: this.store,
    cognition: this.cognition,
    policy: this.policy,
    tools: this.tools,
    commitments: this.commitments,
    approvals: this.approvals,
    relationships: this.relationships,
    contributions: this.contributions,
    receipts: this.receipts,
    delegations: this.delegations,
    capabilities: this.capabilities,
    verifications: this.verifications,
    governance: this.governance,
    challenges: this.challenges,
    quorum: this.quorum,
    reputation: this.reputation,
    memberships: this.memberships,
    communityGovernance: this.communityGovernance,
    governanceDelegations: this.governanceDelegations,
    federationTrust: this.federationTrust,
    portableReputation: this.portableReputation
  });
};

Runtime.prototype.registerBeing = function (definition) {
  const self = this;

  return self.store.loadBeing(definition.id)
    .then(function (existing) {
      if (existing) {
        return existing;
      }

      return self.store.saveBeing(definition);
    });
};

Runtime.prototype.handleEventForBeing = function (beingId, event) {
  const self = this;

  return self.store.loadBeing(beingId)
    .then(function (definition) {
      if (!definition) {
        throw new Error('Unknown being: ' + beingId);
      }

      const subscriptions = definition.subscriptions || [];
      const systemEvent = [
        'approval.granted',
        'approval.denied',
        'commitment.due',
        'delegation.requested',
        'delegation.accepted',
        'delegation.rejected',
        'delegation.completed',
        'capability.granted',
        'capability.revoked',
        'relationship.asserted',
        'contribution.verification.requested',
        'contribution.verified',
        'contribution.quorum.reached',
        'governance.proposal.created',
        'governance.vote.cast',
        'governance.proposal.approved',
        'governance.proposal.rejected',
        'constitution.adopted',
        'challenge.opened',
        'challenge.responded',
        'challenge.resolved',
        'community.membership.issued',
        'community.membership.revoked',
        'community.governance.proposal.created',
        'community.governance.proposal.resolved',
        'community.governance.delegation.created',
        'community.governance.delegation.revoked',
        'community.trust.asserted'
      ].includes(event.type);

      if (!systemEvent && !subscriptions.includes(event.type)) {
        return {
          beingId: beingId,
          skipped: true,
          reason: 'Being is not subscribed to event type: ' + event.type
        };
      }

      return self.createBeing(definition).handleEvent(event);
    });
};

module.exports = Runtime;
