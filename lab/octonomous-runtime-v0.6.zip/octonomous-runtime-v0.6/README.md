# Octonomous Runtime v0.6 — Federated Societies

A CommonJS Node.js runtime for durable, event-driven **Octonomous beings and federated communities**.

v0.6 builds on the governed-society primitives in v0.5 and adds a durable community layer so that constitutions, membership, governance authority, federation trust, treasury/resource authorisations, and portable reputation are not owned by any single being.

## Core rule

```text
Beings have agency.
Communities have constitutions.
Membership carries roles.
Governance is evidence-producing state.
Delegation never invents membership.
Federation trust is scoped, explicit, and revocable.
Treasury governance authorises; payment systems execute.
Reputation is derived from signed evidence and can travel.
```

## Architecture

```text
                        FEDERATION

        Community A                       Community B
   ┌──────────────────┐              ┌──────────────────┐
   │ Constitution     │              │ Constitution     │
   │ Memberships      │              │ Memberships      │
   │ Roles            │              │ Roles            │
   │ Governance       │              │ Governance       │
   │ Treasury auths   │              │ Treasury auths   │
   │ Resource auths   │              │ Resource auths   │
   │ Trust assertions │──── trust ──>│ Trust assertions │
   └────────┬─────────┘              └────────┬─────────┘
            │                                 │
      memberships                        memberships
            │                                 │
       ┌────▼────┐                       ┌────▼────┐
       │ Being A │                       │ Being B │
       └────┬────┘                       └────┬────┘
            │                                 │
            └──── portable evidence/proofs ───┘
```

A **community is a first-class durable resource** stored independently from beings.

## Community resource

A community contains state such as:

```json
{
  "id": "community:example",
  "version": "octonomous.community.v1",
  "name": "Example Community",
  "purpose": ["Coordinate useful contribution"],
  "identity": {
    "keriAid": "E..."
  },
  "constitution": {},
  "constitutionHistory": [],
  "memberships": [],
  "governance": {
    "proposals": [],
    "delegations": []
  },
  "trustAssertions": [],
  "treasury": {
    "balances": {},
    "allocations": []
  },
  "resources": {
    "pools": {},
    "allocations": []
  }
}
```

The file store persists communities separately under `data/communities/`. DynamoDB uses the same table as beings with a distinct community partition key.

## Membership and roles

Community membership is explicitly represented as a credential-bound record:

```text
community.membership.issue
community.membership.revoke
```

A membership includes:

```text
communityId
beingId
roles[]
status
validUntil
credential
signed receipt
```

Production credentials are delegated to the configured ACDC/KERIA adapter. Development mode creates a signed receipt credential and clearly marks it as non-ACDC.

Example roles:

```text
founder
governor
membership-admin
federation-admin
contributor
verifier
resource-steward
```

Roles are community-local. `governor` in one community does not imply authority in another.

## Community-owned constitutions

A v0.6 community constitution can include federation governance policy:

```json
{
  "federation": {
    "amendment": {
      "approvals": 2,
      "rejections": 2,
      "eligibleRoles": ["founder", "governor"]
    },
    "treasury": {
      "approvals": 2,
      "rejections": 2,
      "eligibleRoles": ["founder", "governor"]
    },
    "resources": {
      "approvals": 2,
      "rejections": 2,
      "eligibleRoles": ["founder", "governor"]
    }
  }
}
```

This is different from v0.5 being-local governance. Both models remain supported:

```text
being.governance.constitution
    governs an individual being

community.constitution
    governs shared community state
```

## Constitutional amendments

Use:

```text
community.constitution.propose
```

Amendments use JSON Merge Patch semantics.

```text
proposal
   ↓
freeze patch + eligible membership snapshot
   ↓
signed votes
   ↓
threshold reached?
   │
   ├─ no  → constitution unchanged
   │
   └─ yes → old constitution archived
             ↓
           patch applied
             ↓
        signed resolution
```

The prior constitution is preserved in `constitutionHistory`.

## Community governance delegation

A member can delegate **voting authority**, not membership:

```text
community.governance.delegate
community.governance.delegation.revoke
```

Example:

```json
{
  "communityId": "community:example",
  "delegateeBeingId": "octo:delegate",
  "scopes": ["treasury.allocate"],
  "validUntil": "2027-01-01T00:00:00.000Z"
}
```

The important invariant is:

```text
delegatee casts vote
       ↓
vote counts as principal member
       ↓
principal identity is the voting slot
       ↓
principal cannot also vote again
```

This prevents delegated voting from multiplying voting power.

Delegations are also scope- and expiry-bounded. A `treasury.allocate` mandate cannot vote on `constitution.amend`.

## Treasury governance

Use:

```text
community.treasury.propose
```

Example:

```json
{
  "communityId": "community:example",
  "asset": "ADA",
  "amount": 1000,
  "target": "project:learning-01",
  "purpose": "Fund pilot"
}
```

When threshold approval is reached the runtime records:

```text
status: authorised
proposalId
asset
amount
target
purpose
signed governance resolution
```

**The runtime does not hold wallet/payment keys and does not spend funds.**

The allocation is governance evidence that a separate treasury adapter, multisig wallet, Cardano transaction builder, finance system, or human operator can consume.

This preserves the boundary:

```text
community decides
      ↓
authorisation evidence
      ↓
treasury/payment system executes
```

## Non-financial resources

The same model applies to scarce resources:

```text
community.resource.propose
```

Examples:

```text
computeHours
labHours
meetingRoomHours
grantSlots
GPUCredits
reviewCapacity
mentorHours
```

Approval creates an authorisation record without mutating the source pool. Execution/allocation reconciliation can remain in the external operational system.

## Federation trust

Communities can explicitly trust another community for bounded purposes:

```text
community.trust.assert
community.trust.revoke
```

Example:

```json
{
  "sourceCommunityId": "community:beta",
  "targetCommunityId": "community:alpha",
  "level": "trusted",
  "scopes": ["reputation", "membership"],
  "validUntil": "2027-12-31T00:00:00.000Z"
}
```

This means:

```text
Beta says:
"For these scopes, we accept assertions originating from Alpha."
```

It does **not** create universal or transitive trust automatically.

Trust assertions are:

- scoped
- expiring
- revocable
- signed by the source community signing boundary

## Portable reputation proofs

v0.6 adds:

```text
reputation.proof.issue
reputation.proof.verify
```

A proof is derived from signed evidence, not mutable reputation counters.

```text
commitment receipts
verified contributions
delegation completion
challenge resolutions
governance evidence
        ↓
EvidenceReputationService
        ↓
score + evidence references
        ↓
evidenceRoot
        ↓
signed portable proof
```

A proof can optionally be issued in the context of a community membership:

```json
{
  "subjectBeingId": "octo:producer",
  "issuerCommunityId": "community:alpha",
  "issuerCommunityMembership": {
    "membershipId": "...",
    "roles": ["contributor"],
    "credential": {}
  },
  "scope": "collaboration",
  "score": 12,
  "evidenceRoot": "...",
  "receipt": {}
}
```

A relying community can then apply two checks:

```text
1. Is this proof cryptographically valid?
2. Do we trust the issuer community for the reputation scope?
```

That allows reputation to be portable without becoming globally authoritative.

### Self-contained development verification

The v0.6 local Ed25519 signature now includes the public SPKI key bytes in the signature envelope. This allows a serialized development receipt to be verified by another runtime instance rather than only by the signer that created it.

The verifier also checks that the outer portable proof exactly matches the signed receipt subject, preventing score or membership fields from being changed after signing.

For production, use the KERI signer adapter instead of treating the development key envelope as identity infrastructure.

## Community signing boundary

Community state should ideally be controlled by a community KERI/group AID, multisig identity, or another shared signing service rather than by a single autonomous being.

Configure:

```text
COMMUNITY_SIGNER_MODULE=./my-community-signer.js
COMMUNITY_KERI_AID=E...
```

Expected provider shape:

```js
{
  signCommunity: function (context) {
    // Sign with the community-controlled identity.
  },

  verifyCommunity: function (context) {
    // Verify a community-controlled receipt.
  }
}
```

Federation trust evaluation verifies the trust assertion receipt when a verifier is available.

See:

```text
examples/community-signer-provider.example.js
```

Without a provider, development mode creates ordinary runtime receipts with a logical `community:<id>` signer subject and an explicit development note.

## ACDC boundary

The ACDC adapter now supports both capability and membership credentials.

Expected optional provider methods:

```text
issueCapability(...)
issueMembership(...)
revokeCredential(...)
verifyCredential(...)
```

The runtime deliberately does not reimplement:

```text
KERI key lifecycle
KERIA agent lifecycle
credential registries
TEL issuance/revocation state
```

See:

```text
examples/acdc-provider.example.js
```

## v0.6 tools

New tools:

```text
community.create
community.membership.issue
community.membership.revoke

community.governance.propose
community.constitution.propose
community.treasury.propose
community.resource.propose
community.governance.vote
community.governance.delegate
community.governance.delegation.revoke

community.trust.assert
community.trust.revoke

reputation.proof.issue
reputation.proof.verify
```

All v0.5 tools remain available.

## Being lifecycle

The core being lifecycle remains unchanged:

```text
event
  ↓
wake
  ↓
observe
  │  ├─ local society state
  │  └─ federation membership/governance events
  ↓
consider
  ↓
decide
  ↓
govern
  ↓
commit
  ↓
act
  ↓
reflect
  ↓
contribute
  ↓
remember
  ↓
sleep
```

Federation events such as `community.membership.issued` are system events and can wake a target being even when they are not in its ordinary subscriptions list.

## Local run

```bash
npm install
cp .env.example .env
npm start
```

For offline/mock cognition:

```bash
export COGNITION_MODE=mock
npm start
```

For OpenAI cognition:

```bash
export OPENAI_API_KEY="..."
export COGNITION_MODE=openai
npm start
```

## Tests

```bash
npm test
```

Current suite:

```text
21 tests
21 passed
0 failed
```

The federation tests cover:

- community persistence separate from beings
- credential-backed membership and revocation
- threshold constitutional amendments
- scoped governance delegation
- delegated votes counting as the principal member
- treasury authorisation without spending
- resource authorisation without mutating source pools
- cross-community trust
- independently verifiable portable reputation proofs
- tamper detection
- runtime observation of targeted membership events

## AWS persistence

No additional DynamoDB table is required.

The existing store now supports generic durable resources and maps communities into a distinct partition-key namespace while retaining optimistic concurrency.

```text
BEING#<id>       → being state
COMMUNITY#<id>   → community state
```

The existing EventBridge/SQS/Lambda wake architecture remains valid.

## File layout

```text
src/
  federation/
    communities.js
    community-signing.js
    memberships.js
    governance.js
    governance-delegations.js
    trust.js

  reputation/
    evidence.js
    portable-proof.js

  credentials/
    acdc.js

  receipts/
    local-ed25519.js

  store/
    file.js
    dynamodb.js
```

## Version progression

```text
v0.1  Being
v0.2  Durable Being
v0.3  Accountable Being
v0.4  Society of Beings
v0.5  Governed Society
v0.6  Federated Societies
```

The central v0.6 idea is that **autonomous beings can participate in communities without communities collapsing into the identity or memory of any one autonomous being**.

That provides a clean path toward many independently governed communities that can cooperate through credentials, explicit trust, signed evidence, and portable proofs while preserving local sovereignty.

See `MIGRATION-v0.5-v0.6.md` for migration notes.
